package com.fluidone.launcher

import android.content.ComponentName
import android.content.Intent
import android.graphics.RectF
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.Message
import android.os.Messenger
import android.os.ParcelUuid
import android.os.Process
import android.os.SystemClock
import android.view.MotionEvent
import android.view.SurfaceView
import android.view.View
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.Shadows.shadowOf
import org.robolectric.annotation.Config
import org.robolectric.annotation.GraphicsMode
import org.robolectric.annotation.LooperMode
import java.util.UUID

/** Fluid One 1.3: app animations on real phones, Outside mode, widget stacks. */
@RunWith(RobolectricTestRunner::class)
@Config(sdk = [35], qualifiers = "w384dp-h832dp-xxhdpi")
@GraphicsMode(GraphicsMode.Mode.NATIVE)
@LooperMode(LooperMode.Mode.PAUSED)
class V13Test : LauncherTestBase() {

    private fun send(v: View, action: Int, x: Float, y: Float, down: Long) {
        val loc = IntArray(2); v.getLocationInWindow(loc)
        val e = MotionEvent.obtain(down, SystemClock.uptimeMillis(), action, loc[0] + x, loc[1] + y, 0)
        a.rootView.dispatchTouchEvent(e); e.recycle()
    }

    // ---- Opening apps ----------------------------------------------------------------------------------------

    // ---- Closing with gestures: the gesture nav contract ----------------------------------------------------

    // ---- Outside mode -----------------------------------------------------------------------------------------

    @Test
    fun outsideMode() {
        val keys = a.apps.apps.take(3).map { it.key }
        a.prefs.outsidePins = keys.joinToString(",")
        a.prefs.outsideGoal = 30
        OutsideMode.start(a); idle(1200)
        val o = a.overlays.filterIsInstance<OutsideOverlay>().single()
        assertTrue(texts().contains("OUTSIDE"))
        assertTrue(texts().contains("Just started"))
        assertEquals(3, keys.count { o.iconFor(it) != null })
        o.scene.fixedHour = 18.3
        o.scene.advance(4f)
        hwShot("v13_outside")
        // Home and theme changes keep it; Back asks you to hold End.
        controller.newIntent(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)); idle(400)
        a.applyThemeChange(); idle(300)
        @Suppress("DEPRECATION") a.onBackPressed(); idle(300)
        assertTrue(a.overlays.any { it === o })
        // The launcher restarting doesn't end it.
        a.prefs.outsideActiveSince = System.currentTimeMillis() - 25 * 60_000L
        idle(1100)
        assertTrue(texts().toString(), texts().contains("25 min"))
        assertTrue(texts().contains("of 30 min"))
        controller.pause().stop().destroy(); idle(100)
        controller = org.robolectric.Robolectric.buildActivity(MainActivity::class.java).setup()
        a = controller.get(); idle(1500)
        val o2 = a.overlays.filterIsInstance<OutsideOverlay>().single()
        // Hold to end: the summary shows the time, and it's logged.
        all(a.rootView).filterIsInstance<HoldButton>().single().complete(); idle(900)
        assertFalse(OutsideMode.isActive(a.prefs))
        assertTrue(a.overlays.none { it === o2 })
        assertTrue(texts().toString(), texts().contains("25 min"))
        assertTrue(texts().any { it.startsWith("This week: 25 min") })
        hwShot("v13_outside_summary")
        assertEquals(25, OutsideStats.minutesOnDay(a.prefs, 0).toInt().coerceAtMost(25))
    }

    @Test
    fun outsideSceneThroughTheDay() {
        // Morning, noon, golden hour, dusk and night, side by side (for checking the look).
        val scenes = listOf(7.5, 12.5, 17.8, 19.4, 23.0)
        val bmps = scenes.map { h ->
            val s = NatureScene(a)
            s.fixedHour = h
            s.measure(View.MeasureSpec.makeMeasureSpec(360, View.MeasureSpec.EXACTLY), View.MeasureSpec.makeMeasureSpec(720, View.MeasureSpec.EXACTLY))
            s.layout(0, 0, 360, 720)
            s.advance(3f)
            val b = android.graphics.Bitmap.createBitmap(360, 720, android.graphics.Bitmap.Config.ARGB_8888)
            s.draw(android.graphics.Canvas(b))
            b
        }
        val sheet = android.graphics.Bitmap.createBitmap(360 * bmps.size, 720, android.graphics.Bitmap.Config.ARGB_8888)
        val c = android.graphics.Canvas(sheet)
        bmps.forEachIndexed { i, b -> c.drawBitmap(b, (i * 360).toFloat(), 0f, null) }
        java.io.FileOutputStream(java.io.File(shots, "v13_outside_day.png")).use { sheet.compress(android.graphics.Bitmap.CompressFormat.PNG, 95, it) }
        val day = SunTimes.day()
        if (day.sunrise != null) assertTrue(day.sunrise!! < day.sunset!!)
    }

    // ---- Widget stacks ----------------------------------------------------------------------------------------

    private fun stackView(): StackFrame = all(a.rootView).filterIsInstance<StackFrame>().first { it.isShown }

    @Test
    fun widgetStacks() {
        a.workspace.snapTo(1); idle(400)
        a.addStack(); idle(900)
        val stack = a.model.pages.flatten().first { it.type == HomeItem.STACK }
        assertEquals(3, stack.children.size)
        var v = stackView()
        assertEquals(3, v.count)
        assertEquals(0, v.currentIndex)
        // Swipe up: the next widget rises in.
        val t = SystemClock.uptimeMillis()
        val x = v.width / 2f; val y0 = v.height * 0.7f
        send(v, MotionEvent.ACTION_DOWN, x, y0, t); idle(30)
        for (i in 1..6) { send(v, MotionEvent.ACTION_MOVE, x, y0 - i * a.dp(12f), t); idle(16) }
        hwShot("v13_stack_swipe")
        send(v, MotionEvent.ACTION_UP, x, y0 - a.dp(72f), t); idle(900)
        assertEquals(1, v.currentIndex)
        assertEquals(1, stack.stackIndex)
        // Swipe down twice: back past the first one to the last (it wraps around).
        repeat(2) {
            val t2 = SystemClock.uptimeMillis()
            send(v, MotionEvent.ACTION_DOWN, x, v.height * 0.3f, t2); idle(30)
            for (i in 1..6) { send(v, MotionEvent.ACTION_MOVE, x, v.height * 0.3f + i * a.dp(12f), t2); idle(16) }
            send(v, MotionEvent.ACTION_UP, x, v.height * 0.3f + a.dp(72f), t2); idle(900)
        }
        assertEquals(2, v.currentIndex)
        hwShot("v13_stack")
        // Saved and restored.
        a.model.save()
        val copy = HomeItem.fromJson(stack.toJson())
        assertEquals(stack.children.map { it.builtin }, copy.children.map { it.builtin })
        assertEquals(2, copy.stackIndex)
        // Any widget can become a stack.
        val clock = a.model.pages[0].first { it.type == HomeItem.BUILTIN && it.builtin == Builtins.CLOCK }
        a.addBuiltinToStack(clock, Builtins.BATTERY); idle(900)
        val made = a.model.pages[0].first { it.type == HomeItem.STACK }
        assertEquals(listOf(Builtins.CLOCK, Builtins.BATTERY), made.children.map { it.builtin })
        assertEquals("the clock keeps its id (and its look)", clock.id, made.children[0].id)
        // Removing down to one widget turns it back into a plain widget.
        a.removeFromStack(made, made.children[1]); idle(600)
        assertTrue(a.model.pages[0].none { it.type == HomeItem.STACK })
        assertTrue(a.model.pages[0].any { it === clock })
        checkModel()
        // The menu offers the stack actions.
        a.workspace.snapTo(1); idle(400)
        v = stackView()
        a.onItemLongPress(v); idle(500)
        assertTrue(texts().containsAll(listOf("Edit stack", "Add a widget")))
    }

    @Test
    fun aboutBannerAndChance() {
        a.openSettingsPage("about"); idle(1200)
        assertTrue(all(a.rootView).any { it is AboutBanner && it.isShown })
        assertTrue(all(a.rootView).count { it is InfoTile } >= 4)
        hwShot("v121_about")
        @Suppress("DEPRECATION") a.onBackPressed(); idle(600)
        a.openDrawer(focusSearch = true); idle(900)
        a.drawer.search.setText("flip a coin"); idle(400)
        assertTrue(texts().toString(), texts().contains("Heads") || texts().contains("Tails"))
        a.drawer.search.setText("roll 2 dice"); idle(400)
        assertTrue(texts().any { it.contains(" = ") })
        a.drawer.search.setText("random number 1-6"); idle(400)
        assertTrue(texts().any { it in listOf("1", "2", "3", "4", "5", "6") })
    }
}
