package com.fluidone.launcher

import android.content.Intent
import android.os.SystemClock
import android.view.MotionEvent
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import org.robolectric.annotation.GraphicsMode
import org.robolectric.annotation.LooperMode
import java.util.Random

/**
 * Random use: a few hundred seeded taps, long presses, swipes, Home and Back presses, settings pages, Outside mode,
 * stacks and app launches. Nothing may crash, and the home layout must stay consistent after every step.
 */
@RunWith(RobolectricTestRunner::class)
@Config(sdk = [35], qualifiers = "w384dp-h832dp-xxhdpi")
@GraphicsMode(GraphicsMode.Mode.NATIVE)
@LooperMode(LooperMode.Mode.PAUSED)
class MonkeyTest : LauncherTestBase() {

    private fun tap(x: Float, y: Float) {
        val t = SystemClock.uptimeMillis()
        touch(MotionEvent.ACTION_DOWN, x, y, t); idle(60)
        touch(MotionEvent.ACTION_UP, x, y, t); idle(300)
    }

    private fun longPress(x: Float, y: Float, moveTo: Pair<Float, Float>?) {
        val t = SystemClock.uptimeMillis()
        touch(MotionEvent.ACTION_DOWN, x, y, t); idle(700)
        if (moveTo != null) for (i in 1..8) { touch(MotionEvent.ACTION_MOVE, x + (moveTo.first - x) * i / 8, y + (moveTo.second - y) * i / 8, t); idle(32) }
        touch(MotionEvent.ACTION_UP, moveTo?.first ?: x, moveTo?.second ?: y, t); idle(600)
    }

    private fun home() { controller.newIntent(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)); idle(700) }

    @Test
    fun randomUse() {
        val r = Random(1303)
        val w = a.rootView.width.toFloat(); val h = a.rootView.height.toFloat()
        val pages = listOf("layout", "dock", "icons", "theme", "blur", "glass_advanced", "animations", "gestures", "drawer", "search", "device", "about", "outside")
        var steps = 0
        repeat(260) { step ->
            when (r.nextInt(14)) {
                0, 1 -> tap(r.nextFloat() * w, r.nextFloat() * h)
                2 -> longPress(r.nextFloat() * w, h * (0.1f + r.nextFloat() * 0.8f), if (r.nextBoolean()) (r.nextFloat() * w to r.nextFloat() * h) else null)
                3 -> swipe(w * 0.8f, h * 0.5f, w * 0.15f, h * 0.5f)
                4 -> swipe(w * 0.2f, h * 0.5f, w * 0.85f, h * 0.5f)
                5 -> swipe(w * 0.5f, h * 0.75f, w * 0.5f, h * 0.25f)   // drawer
                6 -> { @Suppress("DEPRECATION") a.onBackPressed(); idle(500) }
                7 -> home()
                8 -> { a.openSettingsPage(pages[r.nextInt(pages.size)]); idle(800) }
                9 -> {
                    // Open an app and come back.
                    a.dock.icons.getOrNull(r.nextInt(4))?.let { v -> v.entry?.let { e -> a.launchApp(e, v, IconView.SOURCE_DOCK) } }
                    idle(300)
                    controller.pause().stop(); idle(100)
                    controller.restart().resume(); idle(900)
                }
                10 -> if (!a.isEditing && a.overlays.isEmpty()) { a.addStack(); idle(700) }
                11 -> {
                    if (OutsideMode.isActive(a.prefs)) {
                        all(a.rootView).filterIsInstance<HoldButton>().firstOrNull()?.complete(); idle(800)
                        @Suppress("DEPRECATION") a.onBackPressed(); idle(500)
                    } else { OutsideMode.start(a); idle(900) }
                }
                12 -> { all(a.rootView).filterIsInstance<StackFrame>().firstOrNull { it.isShown }?.flip(r.nextBoolean()); idle(600) }
                13 -> { a.applyThemeChange(); idle(400) }
            }
            checkModel()
            steps++
        }
        // Leave things tidy.
        if (OutsideMode.isActive(a.prefs)) { all(a.rootView).filterIsInstance<HoldButton>().firstOrNull()?.complete(); idle(800) }
        home(); home()
        assertTrue(steps == 260)
        hwShot("monkey_end")
    }
}
