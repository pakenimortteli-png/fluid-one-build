package com.fluidone.launcher

import android.graphics.Bitmap
import android.graphics.BlurMaskFilter
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.text.TextPaint
import android.view.View
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.annotation.Config
import org.robolectric.annotation.GraphicsMode
import java.io.File
import java.io.FileOutputStream
import kotlin.math.roundToInt

/** Renders the GitHub release banner for Fluid One 1.3 (2400 × 1260). */
@RunWith(RobolectricTestRunner::class)
@Config(sdk = [35], qualifiers = "w400dp-h800dp-xxhdpi")
@GraphicsMode(GraphicsMode.Mode.NATIVE)
class ReleaseArt13Test {
    private val ctx get() = RuntimeEnvironment.getApplication()

    private fun gpu(w: Int, h: Int, draw: (Canvas) -> Unit): Bitmap {
        val node = android.graphics.RenderNode("art")
        node.setPosition(0, 0, w, h)
        val rc = node.beginRecording(); draw(rc); node.endRecording()
        val reader = android.media.ImageReader.newInstance(w, h, android.graphics.PixelFormat.RGBA_8888, 1,
            android.hardware.HardwareBuffer.USAGE_GPU_SAMPLED_IMAGE or android.hardware.HardwareBuffer.USAGE_GPU_COLOR_OUTPUT)
        val renderer = android.graphics.HardwareRenderer()
        renderer.setSurface(reader.surface); renderer.setContentRoot(node)
        renderer.createRenderRequest().setWaitForPresent(true).syncAndDraw()
        val image = reader.acquireNextImage(); val plane = image.planes[0]
        val wide = Bitmap.createBitmap(plane.rowStride / plane.pixelStride, h, Bitmap.Config.ARGB_8888)
        wide.copyPixelsFromBuffer(plane.buffer)
        image.close(); renderer.destroy(); reader.close()
        return Bitmap.createBitmap(wide, 0, 0, w, h)
    }

    private class Glass(val rect: RectF, val radius: Float, val tint: Int)

    private fun glassPass(src: Bitmap, shapes: List<Glass>, overlay: (Canvas) -> Unit = {}): Bitmap {
        val blurred = BlurEngine.blur(src, 0.25f, 8)
        val bm = Matrix().apply { setScale(src.width / blurred.width.toFloat(), src.height / blurred.height.toFloat()) }
        return gpu(src.width, src.height) { c ->
            c.drawBitmap(src, 0f, 0f, null)
            val shadow = Paint(Paint.ANTI_ALIAS_FLAG).apply { maskFilter = BlurMaskFilter(22f, BlurMaskFilter.Blur.NORMAL); color = Color.argb(60, 0, 0, 0) }
            for (g in shapes) {
                c.drawRoundRect(g.rect.left + 6f, g.rect.top + 14f, g.rect.right - 6f, g.rect.bottom + 14f, g.radius, g.radius, shadow)
                GlassPainter(ctx).draw(c, g.rect, g.radius, 0.95f, g.tint, src, Matrix(), blurred, bm)
            }
            overlay(c)
        }
    }

    private fun icon(c: Canvas, res: Int, r: RectF, color: Int = Color.WHITE, scale: Float = 0.5f) {
        val d = ctx.getDrawable(res)?.mutate() ?: return
        d.setTint(color)
        val s = r.width() * scale
        d.setBounds((r.centerX() - s / 2).roundToInt(), (r.centerY() - s / 2).roundToInt(), (r.centerX() + s / 2).roundToInt(), (r.centerY() + s / 2).roundToInt())
        d.draw(c)
    }

    private val text = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; textAlign = Paint.Align.CENTER }

    /** Home screen: glass icons, a widget stack, search capsule and dock, over a glass wallpaper. */
    private fun homeScreen(w: Int, h: Int): Bitmap {
        val wall = Wallpapers.render(Wallpapers.preset("azure_glass"), w, h)
        val shapes = ArrayList<Glass>()
        val cols = 4
        val margin = w * 0.07f
        val cell = (w - 2 * margin) / cols
        val iconSize = cell * 0.66f
        val icons = listOf(R.drawable.ic_phone, R.drawable.ic_message, R.drawable.ic_camera, R.drawable.ic_globe,
            R.drawable.ic_place, R.drawable.ic_play, R.drawable.ic_mail, R.drawable.ic_calendar)
        val gridTop = h * 0.47f
        val rects = icons.indices.map { i ->
            val cx = margin + cell * (i % cols + 0.5f); val cy = gridTop + (i / cols) * cell * 1.2f + iconSize / 2f
            RectF(cx - iconSize / 2, cy - iconSize / 2, cx + iconSize / 2, cy + iconSize / 2)
        }
        rects.forEach { shapes += Glass(it, it.width() * 0.32f, Color.argb(26, 255, 255, 255)) }
        val stack = RectF(margin, h * 0.2f, w - margin, h * 0.4f)
        shapes += Glass(stack, w * 0.075f, Color.argb(40, 16, 24, 54))
        val search = RectF(w * 0.3f, h * 0.79f, w * 0.7f, h * 0.79f + w * 0.11f)
        shapes += Glass(search, search.height() / 2, Color.argb(32, 255, 255, 255))
        val dock = RectF(margin * 0.6f, h * 0.875f, w - margin * 0.6f, h * 0.875f + cell * 1.05f)
        shapes += Glass(dock, dock.height() * 0.42f, Color.argb(26, 255, 255, 255))
        return glassPass(wall, shapes) { c ->
            text.typeface = Fonts.semibold; text.textSize = w * 0.048f; text.textAlign = Paint.Align.CENTER
            c.drawText("Friday, 20 November", w / 2f, h * 0.07f, text)
            text.typeface = Fonts.bold; text.textSize = w * 0.19f
            c.drawText("9:41", w / 2f, h * 0.07f + w * 0.19f, text)
            // The stack: calendar in front, dots on its edge.
            text.textAlign = Paint.Align.LEFT
            text.typeface = Fonts.bold; text.textSize = w * 0.1f
            c.drawText("20", stack.left + w * 0.06f, stack.top + w * 0.15f, text)
            text.typeface = Fonts.semibold; text.textSize = w * 0.042f; text.color = Color.rgb(140, 190, 255)
            c.drawText("FRIDAY", stack.left + w * 0.2f, stack.top + w * 0.135f, text)
            text.color = Color.WHITE; text.typeface = Fonts.medium; text.textSize = w * 0.036f
            val bar = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(120, 180, 255) }
            listOf("Walk by the lake" to "18:00", "Dinner with Ella" to "19:30").forEachIndexed { i, (t, s) ->
                val y = stack.top + w * 0.25f + i * w * 0.085f
                c.drawRoundRect(stack.left + w * 0.06f, y - w * 0.035f, stack.left + w * 0.068f, y + w * 0.035f, 4f, 4f, bar)
                c.drawText(t, stack.left + w * 0.09f, y - w * 0.002f, text)
                text.color = Color.argb(180, 255, 255, 255); text.textSize = w * 0.03f
                c.drawText(s, stack.left + w * 0.09f, y + w * 0.034f, text)
                text.color = Color.WHITE; text.textSize = w * 0.036f
            }
            val dot = Paint(Paint.ANTI_ALIAS_FLAG)
            for (k in 0 until 3) {
                dot.color = if (k == 0) Color.WHITE else Color.argb(110, 255, 255, 255)
                val y = stack.centerY() + (k - 1) * w * 0.03f
                val half = if (k == 0) w * 0.014f else w * 0.007f
                c.drawRoundRect(stack.right - w * 0.024f, y - half, stack.right - w * 0.016f, y + half, 4f, 4f, dot)
            }
            text.textAlign = Paint.Align.CENTER
            rects.forEachIndexed { i, r -> icon(c, icons[i], r) }
            icon(c, R.drawable.ic_search, RectF(search.left + search.height() * 0.2f, search.top, search.left + search.height() * 1.0f, search.bottom), scale = 0.4f)
            text.typeface = Fonts.medium; text.textSize = w * 0.038f
            c.drawText("Search", search.centerX() + search.height() * 0.25f, search.centerY() + w * 0.013f, text)
            listOf(R.drawable.ic_phone, R.drawable.ic_message, R.drawable.ic_globe, R.drawable.ic_camera).forEachIndexed { i, res ->
                val cx = dock.left + dock.width() * (i + 0.5f) / 4f
                val s = iconSize * 0.9f
                icon(c, res, RectF(cx - s / 2, dock.centerY() - s / 2, cx + s / 2, dock.centerY() + s / 2), scale = 0.62f)
            }
        }
    }

    /** Outside mode at golden hour. */
    private fun outsideScreen(w: Int, h: Int): Bitmap {
        val scene = NatureScene(ctx)
        scene.fixedHour = 16.0
        scene.measure(View.MeasureSpec.makeMeasureSpec(w, View.MeasureSpec.EXACTLY), View.MeasureSpec.makeMeasureSpec(h, View.MeasureSpec.EXACTLY))
        scene.layout(0, 0, w, h)
        scene.advance(6f)
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        scene.draw(c)
        text.textAlign = Paint.Align.CENTER
        text.setShadowLayer(8f, 0f, 2f, Color.argb(110, 0, 0, 0))
        text.typeface = Fonts.semibold; text.textSize = w * 0.03f; text.color = Color.argb(210, 255, 255, 255); text.letterSpacing = 0.14f
        c.drawText("OUTSIDE", w / 2f, h * 0.075f, text)
        text.letterSpacing = 0f; text.color = Color.WHITE
        text.typeface = Fonts.light; text.textSize = w * 0.21f
        c.drawText("16:04", w / 2f, h * 0.075f + w * 0.21f, text)
        text.typeface = Fonts.medium; text.textSize = w * 0.042f
        c.drawText("Friday, 20 November", w / 2f, h * 0.075f + w * 0.27f, text)
        text.typeface = Fonts.regular; text.textSize = w * 0.034f; text.color = Color.argb(220, 255, 255, 255)
        c.drawText("Sunset around 16:32 · 28 min of daylight left", w / 2f, h * 0.075f + w * 0.33f, text)
        text.color = Color.WHITE
        // The ring
        val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = w * 0.014f; strokeCap = Paint.Cap.ROUND; color = Color.argb(70, 255, 255, 255) }
        val rr = RectF(w * 0.27f, h * 0.36f, w * 0.73f, h * 0.36f + w * 0.46f)
        c.drawArc(rr, 0f, 360f, false, ring)
        ring.color = Color.WHITE
        c.drawArc(rr, -90f, 290f, false, ring)
        text.typeface = Fonts.semibold; text.textSize = w * 0.085f
        c.drawText("24 min", rr.centerX(), rr.centerY() + w * 0.02f, text)
        text.typeface = Fonts.medium; text.textSize = w * 0.034f; text.color = Color.argb(215, 255, 255, 255)
        c.drawText("of 30 min · 2,140 steps", rr.centerX(), rr.centerY() + w * 0.075f, text)
        text.color = Color.WHITE; text.typeface = Fonts.medium; text.textSize = w * 0.044f
        c.drawText("Listen. What can you hear?", w / 2f, h * 0.7f, text)
        text.clearShadowLayer()
        // Pinned apps and Hold to end
        val bar = RectF(w * 0.06f, h * 0.77f, w * 0.94f, h * 0.77f + w * 0.22f)
        val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(60, 255, 255, 255) }
        c.drawRoundRect(bar, w * 0.08f, w * 0.08f, p)
        val pins = listOf(R.drawable.ic_camera to Color.rgb(250, 170, 60), R.drawable.ic_place to Color.rgb(60, 170, 110),
            R.drawable.ic_phone to Color.rgb(70, 140, 255), R.drawable.ic_play to Color.rgb(240, 80, 110))
        val labels = listOf("Camera", "Maps", "Phone", "Music")
        pins.forEachIndexed { i, (res, col) ->
            val cx = bar.left + bar.width() * (i + 0.5f) / 4f
            val s = w * 0.12f
            val r = RectF(cx - s / 2, bar.top + w * 0.03f, cx + s / 2, bar.top + w * 0.03f + s)
            p.color = col
            c.drawRoundRect(r, s * 0.3f, s * 0.3f, p)
            icon(c, res, r, scale = 0.55f)
            text.typeface = Fonts.medium; text.textSize = w * 0.03f
            c.drawText(labels[i], cx, r.bottom + w * 0.045f, text)
        }
        val hold = RectF(w * 0.12f, h * 0.905f, w * 0.88f, h * 0.905f + w * 0.11f)
        p.color = Color.argb(80, 255, 255, 255)
        c.drawRoundRect(hold, hold.height() / 2, hold.height() / 2, p)
        text.typeface = Fonts.semibold; text.textSize = w * 0.037f
        c.drawText("Hold to end", hold.centerX(), hold.centerY() + w * 0.013f, text)
        return bmp
    }

    /** An app opening: the home screen falls back and blurs while the icon grows into the app's card. */
    private fun openingScreen(w: Int, h: Int): Bitmap {
        val wall = Wallpapers.render(Wallpapers.preset("crimson_glass"), w, h)
        val blurred = BlurEngine.blur(wall, 0.25f, 10)
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        c.drawBitmap(blurred, null, RectF(-w * 0.06f, -h * 0.06f, w * 1.06f, h * 1.06f), Paint(Paint.FILTER_BITMAP_FLAG))
        c.drawColor(Color.argb(70, 0, 0, 0))
        val card = RectF(w * 0.09f, h * 0.12f, w * 0.91f, h * 0.86f)
        val shadow = Paint(Paint.ANTI_ALIAS_FLAG).apply { maskFilter = BlurMaskFilter(40f, BlurMaskFilter.Blur.NORMAL); color = Color.argb(120, 0, 0, 0) }
        c.drawRoundRect(card.left, card.top + 24f, card.right, card.bottom + 30f, 70f, 70f, shadow)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.shader = LinearGradient(0f, card.top, 0f, card.bottom, Color.rgb(255, 176, 92), Color.rgb(244, 132, 70), Shader.TileMode.CLAMP)
        c.drawRoundRect(card, 70f, 70f, p)
        p.shader = null
        val s = w * 0.26f
        val ir = RectF(card.centerX() - s / 2, card.centerY() - s / 2, card.centerX() + s / 2, card.centerY() + s / 2)
        p.color = Color.argb(60, 255, 255, 255)
        c.drawRoundRect(ir, s * 0.3f, s * 0.3f, p)
        icon(c, R.drawable.ic_camera, ir, scale = 0.56f)
        // A ghost of the icon it grew from, lower down.
        p.color = Color.argb(90, 255, 255, 255); p.style = Paint.Style.STROKE; p.strokeWidth = 3f
        val small = RectF(w * 0.62f, h * 0.9f, w * 0.62f + w * 0.13f, h * 0.9f + w * 0.13f)
        c.drawRoundRect(small, w * 0.04f, w * 0.04f, p)
        p.style = Paint.Style.FILL
        return bmp
    }

    /** A phone (titanium edge, screen) as a bitmap. */
    private fun phone(screen: Bitmap): Bitmap {
        val pad = 16f
        val w = screen.width + (pad * 2).toInt(); val h = screen.height + (pad * 2).toInt()
        val b = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(b)
        val body = RectF(0f, 0f, w.toFloat(), h.toFloat())
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.shader = LinearGradient(0f, 0f, w.toFloat(), h.toFloat(), intArrayOf(Color.rgb(70, 72, 78), Color.rgb(22, 22, 26), Color.rgb(54, 56, 62)), null, Shader.TileMode.CLAMP)
        c.drawRoundRect(body, 86f, 86f, p)
        p.shader = null
        p.color = Color.rgb(6, 6, 8)
        c.drawRoundRect(RectF(4f, 4f, w - 4f, h - 4f), 82f, 82f, p)
        val screenRect = RectF(pad, pad, pad + screen.width, pad + screen.height)
        val s = c.save()
        c.clipPath(Path().apply { addRoundRect(screenRect, 72f, 72f, Path.Direction.CW) })
        c.drawBitmap(screen, null, screenRect, Paint(Paint.FILTER_BITMAP_FLAG))
        c.restoreToCount(s)
        p.color = Color.rgb(8, 8, 10)
        c.drawCircle(screenRect.centerX(), screenRect.top + 28f, 12f, p)
        // A thin highlight along the top-left of the frame.
        p.style = Paint.Style.STROKE; p.strokeWidth = 2.5f
        p.shader = LinearGradient(0f, 0f, w.toFloat(), h.toFloat(), intArrayOf(Color.argb(150, 255, 255, 255), Color.argb(10, 255, 255, 255), Color.argb(60, 255, 255, 255)), null, Shader.TileMode.CLAMP)
        c.drawRoundRect(RectF(1.5f, 1.5f, w - 1.5f, h - 1.5f), 85f, 85f, p)
        return b
    }

    /**
     * Draws [phone] standing on the floor at [floorY], centred on [cx], [height] tall, turned by [turn] (-1..1, how
     * far the right edge recedes), with its reflection in the glossy floor.
     */
    private fun stand(c: Canvas, phone: Bitmap, cx: Float, floorY: Float, height: Float, turn: Float, canvasW: Int, canvasH: Int) {
        val scale = height / phone.height
        val w = phone.width * scale
        val recede = 0.07f * turn
        val l = cx - w / 2; val r = cx + w / 2; val t = floorY - height
        // The receding edge gets a little shorter and narrower.
        val near = if (turn >= 0) l else r
        val far = if (turn >= 0) r else l
        val shrink = height * kotlin.math.abs(recede)
        val src = floatArrayOf(0f, 0f, phone.width.toFloat(), 0f, phone.width.toFloat(), phone.height.toFloat(), 0f, phone.height.toFloat())
        val dst = if (turn >= 0) floatArrayOf(near, t, far - w * kotlin.math.abs(recede), t + shrink, far - w * kotlin.math.abs(recede), floorY - shrink * 0.2f, near, floorY)
                  else floatArrayOf(far + w * kotlin.math.abs(recede), t + shrink, near, t, near, floorY, far + w * kotlin.math.abs(recede), floorY - shrink * 0.2f)
        val m = Matrix(); m.setPolyToPoly(src, 0, dst, 0, 4)
        val fp = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
        // Soft contact shadow
        val sh = Paint(Paint.ANTI_ALIAS_FLAG).apply { maskFilter = BlurMaskFilter(30f, BlurMaskFilter.Blur.NORMAL); color = Color.argb(180, 0, 0, 0) }
        c.drawOval(l + w * 0.05f, floorY - 14f, r - w * 0.05f, floorY + 22f, sh)
        c.drawBitmap(phone, m, fp)
        // Reflection: flipped about the floor, fading out.
        val save = c.saveLayer(0f, floorY, canvasW.toFloat(), canvasH.toFloat(), null)
        c.save()
        c.scale(1f, -1f, 0f, floorY)
        fp.alpha = 90
        c.drawBitmap(phone, m, fp)
        c.restore()
        val mask = Paint().apply {
            shader = LinearGradient(0f, floorY, 0f, floorY + height * 0.28f, Color.BLACK, Color.TRANSPARENT, Shader.TileMode.CLAMP)
            xfermode = PorterDuffXfermode(PorterDuff.Mode.DST_IN)
        }
        c.drawRect(0f, floorY, canvasW.toFloat(), canvasH.toFloat(), mask)
        c.restoreToCount(save)
    }

    @Test fun renderReleaseImage() {
        val W = 2400; val H = 1260
        val sw = 540; val sh = 1140
        val home = phone(homeScreen(sw, sh))
        val outside = phone(outsideScreen(sw, sh))
        val opening = phone(openingScreen(sw, sh))

        val art = Bitmap.createBitmap(W, H, Bitmap.Config.ARGB_8888)
        val c = Canvas(art)
        c.drawColor(Color.BLACK)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        // Stage light: cool from above-right, warm low on the left of the phones, all very soft.
        p.shader = RadialGradient(1780f, 380f, 900f, intArrayOf(Color.argb(120, 52, 74, 170), Color.argb(40, 40, 50, 120), Color.TRANSPARENT), floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP)
        c.drawRect(0f, 0f, W.toFloat(), H.toFloat(), p)
        p.shader = RadialGradient(1300f, 980f, 620f, intArrayOf(Color.argb(70, 230, 120, 70), Color.TRANSPARENT), null, Shader.TileMode.CLAMP)
        c.drawRect(0f, 0f, W.toFloat(), H.toFloat(), p)
        // Glossy floor
        val floorY = 1050f
        p.shader = LinearGradient(0f, floorY - 2f, 0f, H.toFloat(), Color.argb(40, 255, 255, 255), Color.TRANSPARENT, Shader.TileMode.CLAMP)
        c.drawRect(1050f, floorY, W.toFloat(), floorY + 3f, p)
        p.shader = null

        stand(c, outside, 1410f, floorY, 840f, 0.9f, W, H)
        stand(c, opening, 2195f, floorY, 840f, -0.9f, W, H)
        stand(c, home, 1800f, floorY, 960f, 0f, W, H)

        // Words
        val left = 130f
        val t = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }
        t.color = Color.WHITE
        t.typeface = Fonts.bold; t.textSize = 168f
        t.shader = LinearGradient(0f, 200f, 0f, 340f, Color.WHITE, Color.rgb(196, 198, 206), Shader.TileMode.CLAMP)
        c.drawText("Fluid One", left - 6f, 340f, t)
        val titleW = t.measureText("Fluid One")
        t.shader = null
        // The version on a small slab of dark glass.
        val tile = RectF(left + titleW + 40f, 200f, left + titleW + 40f + 230f, 350f)
        p.shader = LinearGradient(tile.left, tile.top, tile.right, tile.bottom, intArrayOf(Color.rgb(54, 54, 60), Color.rgb(18, 18, 21), Color.rgb(10, 10, 12)), floatArrayOf(0f, 0.55f, 1f), Shader.TileMode.CLAMP)
        c.drawRoundRect(tile, 40f, 40f, p)
        p.shader = LinearGradient(tile.left, tile.top, tile.right, tile.bottom, intArrayOf(Color.argb(170, 255, 255, 255), Color.argb(20, 255, 255, 255), Color.argb(70, 255, 255, 255)), floatArrayOf(0f, 0.6f, 1f), Shader.TileMode.CLAMP)
        p.style = Paint.Style.STROKE; p.strokeWidth = 2.5f
        c.drawRoundRect(tile, 40f, 40f, p)
        p.style = Paint.Style.FILL; p.shader = null
        t.textSize = 104f; t.textAlign = Paint.Align.CENTER
        t.shader = LinearGradient(0f, tile.top + 30f, 0f, tile.bottom - 20f, Color.WHITE, Color.rgb(150, 150, 162), Shader.TileMode.CLAMP)
        c.drawText("1.3", tile.centerX(), tile.centerY() + 37f, t)
        t.shader = null; t.textAlign = Paint.Align.LEFT

        t.typeface = Fonts.medium; t.textSize = 48f; t.color = Color.argb(235, 255, 255, 255)
        c.drawText("App animations drawn by Fluid One itself,", left, 450f, t)
        c.drawText("a quiet Outside mode and widget stacks.", left, 512f, t)

        val features = listOf(
            Triple(R.drawable.ic_animation, "App animations", "Open from the icon, land back in it") to Color.rgb(255, 150, 120),
            Triple(R.drawable.ic_outside, "Outside mode", "A calm screen while you're out") to Color.rgb(140, 220, 160),
            Triple(R.drawable.ic_stack, "Widget stacks", "Swipe to flip between widgets") to Color.rgb(255, 210, 120),
            Triple(R.drawable.ic_drop, "Glass that bends light", "Refraction, colour split, moving highlights") to Color.rgb(160, 196, 255)
        )
        features.forEachIndexed { i, (f, tint) ->
            val x = left; val y = 610f + i * 118f
            val chip = RectF(x, y, x + 92f, y + 92f)
            p.shader = LinearGradient(chip.left, chip.top, chip.right, chip.bottom, Color.rgb(46, 46, 52), Color.rgb(20, 20, 23), Shader.TileMode.CLAMP)
            c.drawRoundRect(chip, 26f, 26f, p)
            p.shader = null
            p.style = Paint.Style.STROKE; p.strokeWidth = 2f; p.color = Color.argb(40, 255, 255, 255)
            c.drawRoundRect(chip, 26f, 26f, p); p.style = Paint.Style.FILL
            icon(c, f.first, chip, tint, 0.52f)
            t.typeface = Fonts.semibold; t.textSize = 37f; t.color = Color.WHITE
            c.drawText(f.second, x + 120f, y + 40f, t)
            t.typeface = Fonts.regular; t.textSize = 28f; t.color = Color.argb(155, 255, 255, 255)
            c.drawText(f.third, x + 120f, y + 80f, t)
        }
        t.typeface = Fonts.medium; t.textSize = 28f; t.color = Color.argb(120, 255, 255, 255)
        c.drawText("Android 12 and newer  ·  No internet access  ·  Free", left, 1175f, t)

        val dir = File(System.getProperty("shots.dir", "build/screenshots")).apply { mkdirs() }
        FileOutputStream(File(dir, "release_fluid_one_1_3.png")).use { art.compress(Bitmap.CompressFormat.PNG, 100, it) }
    }
}
