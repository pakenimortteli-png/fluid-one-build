package com.fluidone.launcher

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.RuntimeShader
import android.graphics.Shader
import android.graphics.Typeface
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.annotation.Config
import org.robolectric.annotation.GraphicsMode
import java.io.File
import java.io.FileOutputStream

/** Renders the previous Fluid Glass shader next to the current one on the same scenes (a visual lab). */
@RunWith(RobolectricTestRunner::class)
@Config(sdk = [35], qualifiers = "w400dp-h800dp-xxhdpi")
@GraphicsMode(GraphicsMode.Mode.NATIVE)
class GlassCompareTest {
    private val ctx get() = RuntimeEnvironment.getApplication()
    private val dir = File(System.getProperty("shots.dir", "build/screenshots")).apply { mkdirs() }

    private fun gpu(w: Int, h: Int, draw: (Canvas) -> Unit): Bitmap {
        val node = android.graphics.RenderNode("lab")
        node.setPosition(0, 0, w, h)
        val rc = node.beginRecording(); draw(rc); node.endRecording()
        val reader = android.media.ImageReader.newInstance(w, h, android.graphics.PixelFormat.RGBA_8888, 1,
            android.hardware.HardwareBuffer.USAGE_GPU_SAMPLED_IMAGE or android.hardware.HardwareBuffer.USAGE_GPU_COLOR_OUTPUT)
        val renderer = android.graphics.HardwareRenderer()
        renderer.setSurface(reader.surface); renderer.setContentRoot(node)
        renderer.createRenderRequest().setWaitForPresent(true).syncAndDraw()
        val image = reader.acquireNextImage(); val plane = image.planes[0]
        val wide = Bitmap.createBitmap(plane.rowStride / plane.pixelStride, h, Bitmap.Config.ARGB_8888)
        wide.copyPixelsFromBuffer(plane.buffer)
        image.close(); renderer.destroy(); reader.close()
        return Bitmap.createBitmap(wide, 0, 0, w, h)
    }

    private fun textScene(w: Int, h: Int, dark: Boolean): Bitmap {
        val b = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(b)
        c.drawColor(if (dark) Color.rgb(16, 18, 26) else Color.rgb(236, 237, 240))
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.color = if (dark) Color.argb(60, 255, 255, 255) else Color.argb(40, 0, 0, 0); p.strokeWidth = 3f
        var x = 30f; while (x < w) { c.drawLine(x, 0f, x, h.toFloat(), p); x += 70f }
        var y = 30f; while (y < h) { c.drawLine(0f, y, w.toFloat(), y, p); y += 70f }
        p.typeface = Typeface.DEFAULT_BOLD; p.textSize = 120f
        p.color = if (dark) Color.WHITE else Color.rgb(20, 20, 24)
        c.drawText("Fluid", 60f, 200f, p)
        p.color = Color.rgb(255, 90, 60); c.drawText("Glass", 160f, 340f, p)
        p.shader = LinearGradient(0f, 380f, w.toFloat(), 380f, intArrayOf(Color.rgb(40, 120, 255), Color.rgb(250, 60, 130), Color.rgb(255, 200, 40)), null, Shader.TileMode.CLAMP)
        c.drawRect(0f, 380f, w.toFloat(), 440f, p)
        return b
    }

    private fun render(src: Bitmap, shapes: List<Pair<RectF, Float>>, source: String?, intensity: Float, tint: Int): Bitmap {
        val blurred = BlurEngine.blur(src, 0.25f, 7)
        val bm = Matrix().apply { setScale(src.width / blurred.width.toFloat(), src.height / blurred.height.toFloat()) }
        var drew = true
        val out = gpu(src.width, src.height) { rc ->
            rc.drawBitmap(src, 0f, 0f, null)
            for ((r, radius) in shapes) {
                val gp = GlassPainter(ctx).apply { sourceOverride = source }
                drew = drew && gp.draw(rc, r, radius, intensity, tint, src, Matrix(), blurred, bm)
            }
        }
        assertTrue("shader drew", drew)
        return out
    }

    @Test fun oldVersusNew() {
        RuntimeShader(FluidGlass.AGSL)
        RuntimeShader(OLD_AGSL)
        val w = 720; val h = 480
        val shapes = listOf(RectF(60f, 60f, 330f, 330f) to 135f, RectF(380f, 120f, 680f, 260f) to 70f, RectF(60f, 360f, 660f, 450f) to 45f)
        val scenes = listOf(
            textScene(w, h, false) to Color.argb(18, 255, 255, 255),
            textScene(w, h, true) to Color.argb(30, 255, 255, 255),
            Wallpapers.render(Wallpapers.preset("violet_horizon"), w, h) to Color.argb(24, 255, 255, 255)
        )
        val sheet = Bitmap.createBitmap(w * 3, h * scenes.size, Bitmap.Config.ARGB_8888)
        val sc = Canvas(sheet)
        scenes.forEachIndexed { row, (src, tint) ->
            sc.drawBitmap(src, 0f, (row * h).toFloat(), null)
            sc.drawBitmap(render(src, shapes, OLD_AGSL, 1f, tint), w.toFloat(), (row * h).toFloat(), null)
            sc.drawBitmap(render(src, shapes, null, 1f, tint), (2 * w).toFloat(), (row * h).toFloat(), null)
        }
        FileOutputStream(File(dir, "g_compare.png")).use { sheet.compress(Bitmap.CompressFormat.PNG, 100, it) }
        // The light can move: a highlight from the top-right instead of the top-left.
        FluidGlass.lightX = 0.62f; FluidGlass.lightY = -0.78f
        val moved = render(scenes[2].first, shapes, null, 1f, scenes[2].second)
        FluidGlass.lightX = -0.62f; FluidGlass.lightY = -0.78f
        FileOutputStream(File(dir, "g_compare_light.png")).use { moved.compress(Bitmap.CompressFormat.PNG, 100, it) }
    }

    companion object {
        /** Fluid One 1.2's shader, for comparison. */
        const val OLD_AGSL = """
uniform shader sharp;
uniform shader blurred;
uniform float2 size;
uniform float radius;
uniform float intensity;
uniform float bevel;
uniform float refraction;
uniform float blurPx;
uniform float dp;
uniform float4 tint;
uniform float2 light;
uniform float press;
uniform float magnify;
uniform float rimAmt;
uniform float shadeAmt;
uniform float dispersion;
uniform float quality;
uniform float2 lightDir;

float sdRR(float2 p, float2 b, float r) {
    float2 q = abs(p) - b + float2(r, r);
    return min(max(q.x, q.y), 0.0) + length(max(q, float2(0.0, 0.0))) - r;
}

float3 tap(float2 at) { return float3(sharp.eval(at).rgb); }

float3 soft(float2 at, float r) {
    float d = r * 0.7071;
    float3 s = tap(at) * 0.2;
    s += (tap(at + float2(r, 0.0)) + tap(at - float2(r, 0.0)) + tap(at + float2(0.0, r)) + tap(at - float2(0.0, r))) * 0.1;
    s += (tap(at + float2(d, d)) + tap(at - float2(d, d)) + tap(at + float2(d, -d)) + tap(at + float2(-d, d))) * 0.1;
    return s;
}

half4 main(float2 coord) {
    float2 c = size * 0.5;
    float2 p = coord - c;
    float r = min(radius, min(c.x, c.y));
    float d = sdRR(p, c, r);
    float cover = clamp(0.5 - d, 0.0, 1.0);
    if (cover <= 0.0) { return half4(0.0); }
    float rn = min(max(r, bevel), min(c.x, c.y));
    float dn = sdRR(p, c, rn);
    float2 g = float2(sdRR(p + float2(1.0, 0.0), c, rn) - sdRR(p - float2(1.0, 0.0), c, rn),
                      sdRR(p + float2(0.0, 1.0), c, rn) - sdRR(p - float2(0.0, 1.0), c, rn));
    float2 n = g / max(length(g), 0.0001);
    float k = clamp(1.0 + dn / bevel, 0.0, 1.0);
    float f = k * k * (0.55 + 0.45 * k);
    float i = intensity;
    float bulge = 1.0 + 0.4 * press;
    float2 base = c + p * (1.0 - magnify * i * bulge);
    float shift = refraction * i * bulge * f;
    float2 bent = base + n * shift;
    float br = blurPx * (1.0 + 1.6 * f);
    float3 clear = soft(bent, br);
    if (dispersion > 0.01) {
        float spread = min(shift * 0.028 * dispersion, 0.9 * dp * dispersion);
        float edge = min(1.0, f * 1.2) * 0.8;
        clear.r = mix(clear.r, tap(bent + n * spread).r, edge);
        clear.b = mix(clear.b, tap(bent - n * spread).b, edge);
    }
    float3 frost = float3(blurred.eval(coord + n * shift * 0.5).rgb);
    float3 col = mix(clear, frost, pow(1.0 - i, 1.6));
    float l = dot(col, float3(0.2126, 0.7152, 0.0722));
    col = clamp(mix(float3(l, l, l), col, 1.0 + 0.2 * i), 0.0, 1.0);
    float3 tintRgb = tint.a > 0.001 ? tint.rgb / tint.a : float3(0.0, 0.0, 0.0);
    col = mix(col, tintRgb, tint.a * (1.0 - 0.5 * i));
    col = col * (1.0 - 0.05 * i) + 0.035 * i;
    float facing = dot(n, float2(-0.6222, -0.7828));
    float glint = facing * facing;
    float rimW = 1.25 * dp;
    float rim = clamp((d + rimW + 0.5) / rimW, 0.0, 1.0);
    float bright = smoothstep(0.62, 0.95, dot(col, float3(0.2126, 0.7152, 0.0722)));
    col = mix(col, float3(1.0, 1.0, 1.0), clamp(rim * (0.22 + 0.68 * glint) * (0.35 + 0.65 * i) * (1.0 - 0.7 * bright) * rimAmt, 0.0, 1.0));
    col *= 1.0 - clamp(rim * bright * (0.16 + 0.14 * (1.0 - glint)) * (0.4 + 0.6 * i) * rimAmt, 0.0, 0.8);
    float inner = (d + 2.6 * dp) / (1.2 * dp);
    col *= 1.0 - clamp(exp(-inner * inner) * (1.0 - 0.7 * glint) * 0.12 * i * shadeAmt, 0.0, 0.6);
    col = clamp(col, 0.0, 1.0);
    return half4(half3(col * cover), half(cover));
}
"""
    }
}
