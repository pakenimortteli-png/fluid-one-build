package com.fluidone.launcher

import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PathMeasure
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.os.SystemClock
import android.provider.Settings
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.VelocityTracker
import android.view.View
import android.view.ViewConfiguration
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sin

/**
 * First run: "Welcome to Fluid One", a few swipeable pages that show what the launcher does, with live,
 * animated illustrations. After an update it says "What's new" instead. Shown once per version.
 */
class WelcomeOverlay(launcher: MainActivity, private val isUpdate: Boolean, private val version: String) : Overlay(launcher) {
    private val aurora = AuroraView(launcher)
    private val pages = ArrayList<WelcomePage>()
    private val pager = WelcomePager(launcher)
    private val indicator = LiquidDots(launcher)
    private val primary = WelcomeButton(launcher, "Continue")
    private val secondary = launcher.textView("", 15f, Color.argb(220, 255, 255, 255), Fonts.medium, Gravity.CENTER)
    private val skip = launcher.textView("Skip", 15f, Color.argb(200, 255, 255, 255), Fonts.medium, Gravity.CENTER)
    private var shownPage = -1

    init {
        root.isClickable = true
        root.setBackgroundColor(Color.rgb(8, 8, 14))
        root.addView(aurora, flp(MATCH, MATCH))
        if (isUpdate) buildWhatsNew() else buildWelcome()
    }

    // ---- Fresh install: welcome pages ---------------------------------------------------------------------

    private fun buildWelcome() {
        val brand = launcher.brand
        pages += WelcomePage(launcher, LogoHero(launcher), "Welcome to\nFluid One",
            "Your new home screen. Here's a quick look at what it does.")
        pages += WelcomePage(launcher, FluidGlassPreview(launcher), "Fluid Glass",
            "Glass that bends whatever is behind it. Drag the lens to try it, and change how it looks in Settings.")
        pages += WelcomePage(launcher, SearchHero(launcher), "Search everything",
            "Find apps, people and settings, do quick sums and conversions, all from one search bar.")
        pages += WelcomePage(launcher, StylesHero(launcher), "Make it yours",
            "Icon styles and shapes, widgets you can stack, any accent colour and over 20 wallpapers.")
        pages += WelcomePage(launcher, OutsideHero(launcher), "Outside mode",
            "When you want a break, turn your home screen into a quiet view of the outdoors with just the apps you need.")
        pages += WelcomePage(launcher, BrandHero(launcher), if (brand == Brand.OTHER) "Tuned for your phone" else "${brand.modeName} is on",
            if (brand == Brand.OTHER) "Fluid One adjusts its effects to your phone so everything stays smooth."
            else "Fluid One recognised your ${brand.label} phone and tuned itself for ${brand.system}. Change it any time in Settings.")
        pages += WelcomePage(launcher, PrivacyHero(launcher), "Private by design",
            "Fluid One has no internet access. Your apps, contacts and searches stay on this phone and are never shared with third parties.")
        pages.forEach { pager.addPage(it) }
        root.addView(pager, flp(MATCH, MATCH))

        skip.apply {
            setPadding(launcher.dpi(16), launcher.dpi(10), launcher.dpi(16), launcher.dpi(10))
            background = pressable(null, Color.argb(40, 255, 255, 255), launcher.dp(18f))
            isClickable = true
            contentDescription = "Skip introduction"
            setOnClickListener { launcher.haptic(it, HapticFeedbackConstants.CONTEXT_CLICK); finishWelcome() }
        }
        root.addView(skip, flp(WRAP, WRAP, Gravity.TOP or Gravity.END).apply { topMargin = launcher.insetTop + launcher.dpi(8); rightMargin = launcher.dpi(12) })

        val bottom = LinearLayout(launcher).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL }
        indicator.count = pages.size
        bottom.addView(indicator, llp(MATCH, launcher.dpi(24)))
        primary.setOnClickListener {
            launcher.haptic(it, HapticFeedbackConstants.CONTEXT_CLICK)
            if (pager.current < pages.size - 1) pager.goTo(pager.current + 1) else finishWelcome()
        }
        bottom.addView(primary, llp(MATCH, launcher.dpi(56)).apply { topMargin = launcher.dpi(14); marginStart = launcher.dpi(28); marginEnd = launcher.dpi(28) })
        secondary.apply {
            setPadding(launcher.dpi(16), launcher.dpi(12), launcher.dpi(16), launcher.dpi(12))
            background = pressable(null, Color.argb(40, 255, 255, 255), launcher.dp(18f))
            isClickable = true
            setOnClickListener {
                launcher.haptic(it, HapticFeedbackConstants.CONTEXT_CLICK)
                launcher.startSafely(Intent(Settings.ACTION_HOME_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK), it)
            }
        }
        bottom.addView(secondary, llp(WRAP, WRAP).apply { topMargin = launcher.dpi(6) })
        root.addView(bottom, flp(MATCH, WRAP, Gravity.BOTTOM).apply { bottomMargin = launcher.insetBottom + launcher.dpi(18) })

        pager.onScroll = { pos -> indicator.position = pos; updateButtons(pos) }
        pager.onPage = { i -> showPage(i) }
    }

    private fun updateButtons(pos: Float) {
        val last = pages.size - 1
        val t = clamp01(pos - (last - 1))
        primary.label = if (t > 0.5f) "Get started" else "Continue"
        primary.labelAlpha = 1f - 2f * abs(t - 0.5f).let { 0.5f - it }.coerceAtLeast(0f)
        val showHome = !launcher.isDefaultLauncher()
        secondary.text = "Set Fluid One as your home app"
        secondary.alpha = if (showHome) t else 0f
        secondary.visibility = if (showHome && t > 0.02f) View.VISIBLE else View.INVISIBLE
        skip.alpha = 1f - t
        skip.visibility = if (t > 0.98f) View.INVISIBLE else View.VISIBLE
    }

    private fun showPage(i: Int) {
        if (i == shownPage) return
        shownPage = i
        pages.getOrNull(i)?.reveal()
        launcher.haptic(root, HapticFeedbackConstants.CLOCK_TICK)
    }

    // ---- Update: what's new --------------------------------------------------------------------------------

    private fun buildWhatsNew() {
        // Black, with a single glass tile that catches the light. Quiet on purpose.
        root.setBackgroundColor(Color.BLACK)
        aurora.visibility = View.GONE
        val scroll = ScrollView(launcher).apply { isVerticalScrollBarEnabled = false; overScrollMode = View.OVER_SCROLL_IF_CONTENT_SCROLLS; clipToPadding = false }
        val col = LinearLayout(launcher).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(launcher.dpi(24), launcher.insetTop + launcher.dpi(36), launcher.dpi(24), launcher.insetBottom + launcher.dpi(120))
        }
        val badge = launcher.textView("FLUID ONE", 12f, Color.argb(150, 255, 255, 255), Fonts.semibold, Gravity.CENTER).apply { letterSpacing = 0.22f }
        val hero = VersionHero(launcher, version)
        val title = launcher.textView("What's new in $version", 32f, Color.WHITE, Fonts.bold, Gravity.CENTER)
        val sub = launcher.textView("Everything you set up is still here.", 15f, Color.argb(150, 255, 255, 255), gravity = Gravity.CENTER).apply { setPadding(0, launcher.dpi(8), 0, launcher.dpi(24)) }
        col.addView(badge, llp(MATCH, WRAP))
        col.addView(hero, llp(MATCH, launcher.dpi(300)).apply { topMargin = launcher.dpi(6) })
        col.addView(title, llp(MATCH, WRAP).apply { topMargin = -launcher.dpi(28) })
        col.addView(sub, llp(MATCH, WRAP))
        val items = whatsNewItems()
        val rows = ArrayList<View>()
        items.forEachIndexed { i, item ->
            if (i > 0) col.addView(View(launcher).apply { setBackgroundColor(Color.argb(34, 255, 255, 255)) }, llp(MATCH, 1).apply { marginStart = launcher.dpi(58) })
            val row = LinearLayout(launcher).apply {
                orientation = LinearLayout.HORIZONTAL
                setPadding(0, launcher.dpi(16), 0, launcher.dpi(16))
            }
            val chip = FrameLayout(launcher).apply {
                background = android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation.TL_BR,
                    intArrayOf(Color.rgb(44, 44, 48), Color.rgb(22, 22, 25))).apply { cornerRadius = launcher.dp(12f); setStroke(launcher.dpi(1), Color.argb(30, 255, 255, 255)) }
            }
            chip.addView(launcher.iconImage(item.icon, item.tint, 9), flp(MATCH, MATCH))
            row.addView(chip, llp(launcher.dpi(42), launcher.dpi(42)).apply { marginEnd = launcher.dpi(16) })
            val texts = LinearLayout(launcher).apply { orientation = LinearLayout.VERTICAL }
            texts.addView(launcher.textView(item.title, 17f, Color.WHITE, Fonts.semibold))
            texts.addView(launcher.textView(item.body, 14.5f, Color.argb(165, 255, 255, 255)).apply { setPadding(0, launcher.dpi(4), 0, 0); setLineSpacing(launcher.dp(2.5f), 1f) })
            row.addView(texts, llp(0, WRAP, 1f))
            col.addView(row, llp(MATCH, WRAP))
            rows += row
        }
        scroll.addView(col, flp(MATCH, WRAP))
        root.addView(scroll, flp(MATCH, MATCH))
        val fade = View(launcher).apply {
            background = android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation.BOTTOM_TOP,
                intArrayOf(Color.BLACK, Color.argb(220, 0, 0, 0), Color.TRANSPARENT))
        }
        root.addView(fade, flp(MATCH, launcher.insetBottom + launcher.dpi(140), Gravity.BOTTOM))
        primary.label = "Continue"
        primary.setOnClickListener { launcher.haptic(it, HapticFeedbackConstants.CONFIRM); finishWelcome() }
        root.addView(primary, flp(MATCH, launcher.dpi(56), Gravity.BOTTOM).apply {
            bottomMargin = launcher.insetBottom + launcher.dpi(22); leftMargin = launcher.dpi(28); rightMargin = launcher.dpi(28)
        })
        // The tile arrives first, then the words, then each row as it scrolls into view.
        hero.alpha = 0f; hero.scaleX = 0.86f; hero.scaleY = 0.86f
        val heroSpring = Spring(0.8f, 0.7f)
        hero.animate().alpha(1f).scaleX(1f).scaleY(1f).setStartDelay(Motion.d(80)).setDuration(heroSpring.ms).setInterpolator(heroSpring).withEndAction { hero.sweep() }.start()
        listOf<View>(badge, title, sub).forEachIndexed { i, v ->
            v.alpha = 0f; v.translationY = launcher.dp(16f)
            val sp = Spring(0.85f, 0.55f)
            v.animate().alpha(1f).translationY(0f).setStartDelay(Motion.d(260L + i * 70L)).setDuration(sp.ms).setInterpolator(sp).start()
        }
        val revealed = HashSet<View>()
        rows.forEach { it.alpha = 0f; it.translationY = launcher.dp(22f) }
        fun reveal() {
            val visibleBottom = scroll.scrollY + scroll.height
            var k = 0
            rows.forEach { r ->
                if (r in revealed || r.top > visibleBottom - launcher.dp(20f) + col.top) return@forEach
                revealed += r
                val sp = Spring(0.85f, 0.5f)
                r.animate().alpha(1f).translationY(0f).setStartDelay(Motion.d(if (revealed.size <= 4) 520L + revealed.size * 60L else k++ * 50L))
                    .setDuration(sp.ms).setInterpolator(sp).start()
            }
        }
        scroll.setOnScrollChangeListener { _, _, y, _, _ -> reveal(); hero.parallax = y.toFloat() }
        scroll.post { reveal() }
        primary.alpha = 0f; primary.translationY = launcher.dp(40f)
        val spring = Spring(0.75f, 0.5f)
        primary.animate().alpha(1f).translationY(0f).setStartDelay(Motion.d(640)).setDuration(spring.ms).setInterpolator(spring).start()
    }

    private class NewItem(val icon: Int, val title: String, val body: String, val tint: Int)

    private fun whatsNewItems(): List<NewItem> = listOf(
        NewItem(R.drawable.ic_outside, "Outside mode",
            "A calm view of the outdoors, a clock you can read in the sun and only the apps you pinned. Hold End when you're back.", Color.rgb(140, 220, 160)),
        NewItem(R.drawable.ic_stack, "Widget stacks",
            "Put a few widgets in one spot and swipe up or down to flip through them. Long-press any widget to start a stack.", Color.rgb(255, 210, 120)),
        NewItem(R.drawable.ic_info, "A new About page",
            "A banner in the style of ColorOS, plus your phone's storage, memory, processor and display at a glance.", Color.rgb(150, 200, 255)),
        NewItem(R.drawable.ic_wallpaper, "A new wallpaper every day",
            "Turn it on in Wallpapers and Fluid One moves on to the next one each morning.", Color.rgb(200, 170, 255)),
        NewItem(R.drawable.ic_sparkle, "Small things",
            "Type \"flip a coin\", \"roll 2 dice\" or \"random number 1-100\" in search. Clearer wording in Settings, and app opening is back to your phone's own animation.", Color.rgb(220, 220, 228))
    )

    // ---- Lifecycle -----------------------------------------------------------------------------------------

    fun show() {
        launcher.showOverlay(this)
        root.alpha = 0f
        root.animate().alpha(1f).setDuration(Motion.d(320)).setInterpolator(Motion.decel).start()
        if (!isUpdate) {
            indicator.alpha = 0f; primary.alpha = 0f; primary.translationY = launcher.dp(40f); skip.alpha = 0f
            val spring = Spring(0.75f, 0.5f)
            indicator.animate().alpha(1f).setStartDelay(Motion.d(520)).setDuration(Motion.d(400)).start()
            primary.animate().alpha(1f).translationY(0f).setStartDelay(Motion.d(460)).setDuration(spring.ms).setInterpolator(spring).start()
            skip.animate().alpha(1f).setStartDelay(Motion.d(700)).setDuration(Motion.d(400)).start()
            root.post { showPage(0); updateButtons(0f) }
        }
    }

    private fun finishWelcome() {
        launcher.markWelcomeSeen()
        close(true)
    }

    override val sticky: Boolean get() = true

    override fun onBack(): Boolean {
        if (!isUpdate && pager.current > 0) { pager.goTo(pager.current - 1); return true }
        finishWelcome()
        return true
    }

    override fun close(animate: Boolean) {
        if (closing) return
        closing = true
        launcher.markWelcomeSeen()
        if (!animate) { finish(); launcher.onWelcomeClosed(); return }
        root.animate().alpha(0f).scaleX(1.05f).scaleY(1.05f).setDuration(Motion.d(340)).setInterpolator(Motion.accel)
            .withEndAction { finish(); }.start()
        // The home screen gathers in underneath as the welcome lifts away.
        launcher.rootView.postDelayed({ launcher.onWelcomeClosed() }, Motion.d(120))
    }

    /** Test hook: the current welcome page. */
    val currentPage: Int get() = pager.current
    fun next() = pager.goTo(pager.current + 1)
}

/** A welcome page: illustration, title and text, with parallax while swiping and a staggered entrance. */
class WelcomePage(launcher: MainActivity, val hero: View, title: String, body: String) : LinearLayout(launcher) {
    private val titleView: TextView = launcher.textView(title, 34f, Color.WHITE, Fonts.bold, Gravity.CENTER).apply { setLineSpacing(0f, 0.95f) }
    private val bodyView: TextView = launcher.textView(body, 16f, Color.argb(200, 255, 255, 255), Fonts.regular, Gravity.CENTER).apply { setLineSpacing(launcher.dp(3f), 1f) }
    private var revealed = false

    init {
        orientation = VERTICAL
        gravity = Gravity.CENTER_HORIZONTAL
        setPadding(launcher.dpi(28), launcher.insetTop + launcher.dpi(72), launcher.dpi(28), 0)
        val heroH = if (hero is FluidGlassPreview) WRAP else launcher.dpi(236)
        addView(hero, llp(MATCH, heroH))
        addView(titleView, llp(MATCH, WRAP).apply { topMargin = launcher.dpi(34) })
        addView(bodyView, llp(MATCH, WRAP).apply { topMargin = launcher.dpi(14) })
        listOf(hero, titleView, bodyView).forEach { it.alpha = 0f }
    }

    /** Plays the entrance once: illustration springs in, then title and text rise into place. */
    fun reveal() {
        if (revealed) return
        revealed = true
        val parts = listOf(hero, titleView, bodyView)
        parts.forEachIndexed { i, v ->
            v.alpha = 0f
            v.translationY = dp(if (i == 0) 10f else 26f)
            val s = if (i == 0) 0.86f else 1f
            v.scaleX = s; v.scaleY = s
            val spring = if (i == 0) Spring(0.7f, 0.55f) else Spring(0.85f, 0.5f)
            v.animate().alpha(1f).translationY(0f).scaleX(1f).scaleY(1f).setStartDelay(Motion.d(40L + i * 90L))
                .setDuration(spring.ms).setInterpolator(spring).start()
        }
        (hero as? Hero)?.start()
    }

    /** -1..1: how far this page is from the centre while swiping. */
    fun parallax(offset: Float, width: Int) {
        hero.translationX = offset * width * 0.28f
        bodyView.translationX = -offset * width * 0.12f
        val fade = 1f - min(1f, abs(offset)) * 0.6f
        if (revealed) { titleView.alpha = fade; bodyView.alpha = fade; hero.alpha = fade }
    }
}

/** Horizontal pager with spring snapping. */
class WelcomePager(context: android.content.Context) : ViewGroup(context) {
    private val pages = ArrayList<WelcomePage>()
    var position = 0f
        private set
    val current: Int get() = position.roundToInt().coerceIn(0, (pages.size - 1).coerceAtLeast(0))
    var onScroll: ((Float) -> Unit)? = null
    var onPage: ((Int) -> Unit)? = null
    private val spring = SpringValue(0f) { setPos(it) }
    private var downX = 0f
    private var downY = 0f
    private var startPos = 0f
    private var dragging = false
    private var velocity: VelocityTracker? = null
    private val slop = ViewConfiguration.get(context).scaledTouchSlop

    fun addPage(p: WelcomePage) { pages += p; addView(p) }

    fun goTo(i: Int) {
        val target = i.coerceIn(0, pages.size - 1).toFloat()
        spring.animateTo(target, 300f, 0.86f)
        onPage?.invoke(target.toInt())
    }

    private fun setPos(p: Float) {
        position = p
        layoutPages()
        onScroll?.invoke(p)
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val w = MeasureSpec.getSize(widthMeasureSpec); val h = MeasureSpec.getSize(heightMeasureSpec)
        pages.forEach { it.measure(MeasureSpec.makeMeasureSpec(w, MeasureSpec.EXACTLY), MeasureSpec.makeMeasureSpec(h, MeasureSpec.EXACTLY)) }
        setMeasuredDimension(w, h)
    }

    override fun onLayout(changed: Boolean, l: Int, t: Int, r: Int, b: Int) {
        pages.forEach { it.layout(0, 0, r - l, b - t) }
        layoutPages()
    }

    private fun layoutPages() {
        val w = width
        pages.forEachIndexed { i, p ->
            val offset = i - position
            p.translationX = offset * w
            p.visibility = if (abs(offset) < 1.2f) VISIBLE else INVISIBLE
            p.parallax(offset, w)
        }
    }

    override fun onInterceptTouchEvent(ev: MotionEvent): Boolean {
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN -> { downX = ev.x; downY = ev.y; dragging = false }
            MotionEvent.ACTION_MOVE -> if (!dragging && abs(ev.x - downX) > slop * 1.5f && abs(ev.x - downX) > abs(ev.y - downY) * 1.4f) {
                // The Fluid Glass playground keeps its own drags on its lens.
                if (!heroWantsTouch(downX, downY)) { startDrag(ev); return true }
            }
        }
        return false
    }

    private fun heroWantsTouch(x: Float, y: Float): Boolean {
        val page = pages.getOrNull(current) ?: return false
        val hero = page.hero as? FluidGlassPreview ?: return false
        val loc = IntArray(2); hero.getLocationInWindow(loc)
        val me = IntArray(2); getLocationInWindow(me)
        val hx = x + me[0] - loc[0]; val hy = y + me[1] - loc[1]
        return hx >= 0 && hy >= 0 && hx <= hero.width && hy <= hero.height
    }

    private fun startDrag(ev: MotionEvent) {
        dragging = true
        downX = ev.x
        startPos = position
        spring.stop()
        velocity?.recycle(); velocity = VelocityTracker.obtain()
        parent?.requestDisallowInterceptTouchEvent(true)
    }

    override fun onTouchEvent(ev: MotionEvent): Boolean {
        if (ev.actionMasked == MotionEvent.ACTION_DOWN) { downX = ev.x; downY = ev.y; return true }
        if (!dragging && ev.actionMasked == MotionEvent.ACTION_MOVE && abs(ev.x - downX) > slop) startDrag(ev)
        if (!dragging) return true
        velocity?.addMovement(ev)
        when (ev.actionMasked) {
            MotionEvent.ACTION_MOVE -> {
                var p = startPos - (ev.x - downX) / width.coerceAtLeast(1)
                val maxP = (pages.size - 1).toFloat()
                if (p < 0f) p *= 0.3f
                if (p > maxP) p = maxP + (p - maxP) * 0.3f
                spring.snapTo(p)
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                dragging = false
                velocity?.computeCurrentVelocity(1000)
                val vx = velocity?.xVelocity ?: 0f
                velocity?.recycle(); velocity = null
                val target = when {
                    vx < -dp(500f) -> kotlin.math.floor(position) + 1
                    vx > dp(500f) -> kotlin.math.ceil(position) - 1
                    else -> position.roundToInt().toFloat()
                }
                goTo(target.roundToInt())
            }
        }
        return true
    }
}

/** Page dots where the active one is a pill that stretches like liquid between pages. */
class LiquidDots(context: android.content.Context) : View(context) {
    var count = 1
        set(v) { field = v; invalidate() }
    var position = 0f
        set(v) { field = v; invalidate() }
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)

    override fun onDraw(canvas: Canvas) {
        val d = dp(7f); val gap = dp(10f)
        val total = count * d + (count - 1) * gap
        val x0 = (width - total) / 2f
        val cy = height / 2f
        paint.color = Color.argb(70, 255, 255, 255)
        for (i in 0 until count) canvas.drawCircle(x0 + i * (d + gap) + d / 2f, cy, d / 2f, paint)
        // Active pill: its two ends follow the position at different speeds, so it stretches and snaps.
        val p = position.coerceIn(0f, (count - 1).toFloat())
        val frac = p - kotlin.math.floor(p)
        val base = kotlin.math.floor(p)
        val lead = base + min(1f, frac * 1.8f)
        val tail = base + max(0f, frac * 1.8f - 0.8f)
        val left = x0 + tail * (d + gap)
        val right = x0 + lead * (d + gap) + d
        paint.color = Color.WHITE
        canvas.drawRoundRect(left - dp(4f), cy - d / 2f, right + dp(4f), cy + d / 2f, d / 2f, d / 2f, paint)
    }
}

/** The big white pill button of the welcome screen, with a springy press. */
class WelcomeButton(context: android.content.Context, initial: String) : View(context) {
    var label = initial
        set(v) { if (field != v) { field = v; contentDescription = v; invalidate() } }
    var labelAlpha = 1f
        set(v) { field = v; invalidate() }
    private val bg = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }
    private val text = android.text.TextPaint(Paint.ANTI_ALIAS_FLAG).apply { typeface = Fonts.semibold; color = Color.rgb(14, 14, 20); textAlign = Paint.Align.CENTER }
    private var press = 0f
    private val spring = SpringValue(0f) { press = it; scaleX = 1f - 0.04f * it; scaleY = 1f - 0.04f * it; invalidate() }

    init { isClickable = true; contentDescription = initial }

    override fun onDraw(canvas: Canvas) {
        val r = height / 2f
        bg.alpha = (255 * (0.96f - 0.08f * press)).roundToInt().coerceIn(0, 255)
        canvas.drawRoundRect(0f, 0f, width.toFloat(), height.toFloat(), r, r, bg)
        text.textSize = dp(17f)
        text.alpha = (255 * labelAlpha.coerceIn(0.25f, 1f)).roundToInt()
        canvas.drawText(label, width / 2f, height / 2f - (text.ascent() + text.descent()) / 2f, text)
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> spring.animateTo(1f, 700f, 0.7f)
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> spring.animateTo(0f, 300f, 0.4f)
        }
        return super.onTouchEvent(event)
    }
}

/** Slowly drifting colour light behind the welcome screen. */
class AuroraView(private val launcher: MainActivity) : View(launcher) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val start = SystemClock.uptimeMillis()
    private val colors: IntArray = run {
        val a = launcher.prefs.accent
        val hsv = FloatArray(3); android.graphics.Color.colorToHSV(a, hsv)
        IntArray(3) { i -> Color.HSVToColor(floatArrayOf((hsv[0] + i * 55f) % 360f, 0.75f, 0.85f)) }
    }

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        if (w <= 0f) return
        val t = (SystemClock.uptimeMillis() - start) / 1000f
        for (i in 0 until 3) {
            val ph = t * (0.12f + i * 0.04f) + i * 2.1f
            val cx = w * (0.5f + 0.38f * sin(ph * 1.3f + i))
            val cy = h * (0.32f + 0.3f * cos(ph + i * 1.7f))
            val r = w * (0.75f + 0.15f * sin(ph * 0.7f))
            paint.shader = RadialGradient(cx, cy, r, intArrayOf(withAlpha(colors[i], 0.55f), withAlpha(colors[i], 0f)), null, Shader.TileMode.CLAMP)
            canvas.drawCircle(cx, cy, r, paint)
        }
        paint.shader = null
        if (isAttachedToWindow) postInvalidateOnAnimation()
    }
}

/** Illustrations that run an animation once they are on screen. */
interface Hero { fun start() }

/** The Fluid One mark: a glossy app tile breathing gently, with glass beads circling it. */
class LogoHero(private val launcher: MainActivity) : View(launcher), Hero {
    private val icon: Bitmap? = try { FluidLogo.render(launcher, launcher.dpi(120)) } catch (_: Exception) { null }
    private val glow = Paint(Paint.ANTI_ALIAS_FLAG)
    private val bead = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rim = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val bmp = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private var t0 = 0L

    override fun start() { t0 = SystemClock.uptimeMillis(); invalidate() }

    override fun onDraw(canvas: Canvas) {
        val cx = width / 2f; val cy = height / 2f
        val t = if (t0 == 0L) 0f else (SystemClock.uptimeMillis() - t0) / 1000f
        val breathe = 1f + 0.035f * sin(t * 2.2f)
        val s = dp(120f) * breathe
        glow.shader = RadialGradient(cx, cy, s * 1.3f, intArrayOf(withAlpha(launcher.prefs.accent, 0.55f), Color.TRANSPARENT), null, Shader.TileMode.CLAMP)
        canvas.drawCircle(cx, cy, s * 1.3f, glow)
        icon?.let { canvas.drawBitmap(it, null, RectF(cx - s / 2f, cy - s / 2f, cx + s / 2f, cy + s / 2f), bmp) }
        // Glass beads in orbit: translucent, with a bright rim and a soft highlight.
        for (i in 0 until 3) {
            val a = t * (0.9f + i * 0.25f) + i * 2.1f
            val rr = dp(96f) + dp(12f) * i
            val bx = cx + rr * cos(a); val by = cy + rr * 0.42f * sin(a)
            val br = dp(13f) - dp(3f) * i
            val front = sin(a) > 0f
            bead.color = Color.argb(if (front) 70 else 36, 255, 255, 255)
            canvas.drawCircle(bx, by, br, bead)
            rim.strokeWidth = dp(1.2f); rim.color = Color.argb(if (front) 200 else 90, 255, 255, 255)
            canvas.drawCircle(bx, by, br, rim)
        }
        if (isAttachedToWindow && t0 != 0L) postInvalidateOnAnimation()
    }
}

/** A search bar that types real queries and shows what Fluid One would answer. */
class SearchHero(private val launcher: MainActivity) : View(launcher), Hero {
    private val queries = listOf("spotify" to "Opens the app", "12*7" to "= 84", "time in tokyo" to "World clock", "wifi" to "Wi-Fi settings", "timer 5 min" to "Start a 5 min timer")
    private val pill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rim = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val text = android.text.TextPaint(Paint.ANTI_ALIAS_FLAG).apply { typeface = Fonts.medium; color = Color.WHITE }
    private val result = android.text.TextPaint(Paint.ANTI_ALIAS_FLAG).apply { typeface = Fonts.semibold; color = Color.WHITE }
    private val searchIcon = launcher.getDrawable(R.drawable.ic_search)?.mutate()
    private var t0 = 0L

    override fun start() { t0 = SystemClock.uptimeMillis(); invalidate() }

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        val t = if (t0 == 0L) 0f else (SystemClock.uptimeMillis() - t0) / 1000f
        val cycle = 2.6f
        val idx = ((t / cycle).toInt()) % queries.size
        val local = t % cycle
        val (q, answer) = queries[idx]
        val typed = q.take(((local / 0.9f) * q.length).toInt().coerceIn(0, q.length))
        val ph = dp(56f)
        val top = h * 0.28f
        val r = RectF(dp(8f), top, w - dp(8f), top + ph)
        pill.color = Color.argb(46, 255, 255, 255)
        canvas.drawRoundRect(r, ph / 2f, ph / 2f, pill)
        rim.strokeWidth = dp(1.2f); rim.color = Color.argb(120, 255, 255, 255)
        canvas.drawRoundRect(r, ph / 2f, ph / 2f, rim)
        searchIcon?.let { d ->
            d.setTint(Color.WHITE)
            val s = dp(20f).roundToInt()
            d.setBounds((r.left + dp(20f)).roundToInt(), (r.centerY() - s / 2f).roundToInt(), (r.left + dp(20f)).roundToInt() + s, (r.centerY() + s / 2f).roundToInt())
            d.draw(canvas)
        }
        text.textSize = dp(18f)
        val tx = r.left + dp(54f)
        val baseline = r.centerY() - (text.ascent() + text.descent()) / 2f
        canvas.drawText(typed, tx, baseline, text)
        // Blinking caret.
        if ((t * 2f).toInt() % 2 == 0 || typed.length < q.length) {
            val cxp = tx + text.measureText(typed) + dp(2f)
            pill.color = Color.WHITE
            canvas.drawRect(cxp, r.centerY() - dp(11f), cxp + dp(2f), r.centerY() + dp(11f), pill)
        }
        // The answer card rises in once the query is typed.
        val appear = clamp01((local - 1.0f) / 0.35f).let { it * it * (3 - 2 * it) }
        val fadeOut = clamp01((cycle - local) / 0.3f)
        if (appear > 0f) {
            val a = appear * fadeOut
            val cardTop = r.bottom + dp(18f) + dp(14f) * (1f - appear)
            val card = RectF(dp(8f), cardTop, w - dp(8f), cardTop + dp(64f))
            pill.color = Color.argb((34 * a).roundToInt(), 255, 255, 255)
            canvas.drawRoundRect(card, dp(22f), dp(22f), pill)
            rim.color = Color.argb((80 * a).roundToInt(), 255, 255, 255)
            canvas.drawRoundRect(card, dp(22f), dp(22f), rim)
            result.textSize = dp(20f); result.alpha = (255 * a).roundToInt()
            canvas.drawText(answer, card.left + dp(22f), card.centerY() - (result.ascent() + result.descent()) / 2f, result)
        }
        if (isAttachedToWindow && t0 != 0L) postInvalidateOnAnimation()
    }
}

/** Real app icons cycling through icon styles with a springy pop. */
class StylesHero(private val launcher: MainActivity) : FrameLayout(launcher), Hero {
    private val styles = listOf("original", "glass", "themed_dark", "pastel", "neon", "tinted", "gradient", "mono")
    private val tiles = ArrayList<android.widget.ImageView>()
    private val frames = HashMap<String, List<Bitmap>>()
    private var step = 0
    private val tick = object : Runnable {
        override fun run() {
            if (!isAttachedToWindow) return
            step++
            apply(styles[step % styles.size])
            postDelayed(this, 1500)
        }
    }

    init {
        val row = LinearLayout(launcher).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        repeat(3) {
            val iv = android.widget.ImageView(launcher)
            tiles += iv
            row.addView(iv, llp(launcher.dpi(76), launcher.dpi(76)).apply { marginStart = launcher.dpi(10); marginEnd = launcher.dpi(10) })
        }
        addView(row, flp(MATCH, MATCH))
        // Render every style in the background so the animation never stutters.
        val apps = launcher.previewApps(3)
        val size = launcher.dpi(76)
        Thread {
            styles.forEach { st ->
                val list = apps.map { e -> try { launcher.icons.forDisplay(launcher.icons.preview(e, size, IconOverride("style", style = st))) } catch (_: Throwable) { null } }
                if (list.all { it != null }) synchronized(frames) { frames[st] = list.filterNotNull() }
            }
            post { apply(styles[step % styles.size]) }
        }.apply { isDaemon = true; priority = Thread.MIN_PRIORITY }.start()
    }

    private fun apply(style: String) {
        val bmps = synchronized(frames) { frames[style] } ?: return
        tiles.forEachIndexed { i, iv ->
            iv.animate().cancel()
            iv.animate().scaleX(0.82f).scaleY(0.82f).alpha(0.4f).setStartDelay(i * 70L).setDuration(Motion.d(120)).withEndAction {
                bmps.getOrNull(i)?.let { iv.setImageBitmap(it) }
                val spring = Spring(0.55f, 0.42f)
                iv.animate().scaleX(1f).scaleY(1f).alpha(1f).setStartDelay(0).setDuration(spring.ms).setInterpolator(spring).start()
            }.start()
        }
    }

    override fun start() { removeCallbacks(tick); postDelayed(tick, 1200) }
    override fun onDetachedFromWindow() { removeCallbacks(tick); super.onDetachedFromWindow() }
}

/** A phone outline with the brand's name and a check mark that draws itself. */
class BrandHero(private val launcher: MainActivity) : View(launcher), Hero {
    private val frame = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; color = Color.argb(200, 255, 255, 255); strokeCap = Paint.Cap.ROUND }
    private val screen = Paint(Paint.ANTI_ALIAS_FLAG)
    private val check = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; color = Color.WHITE; strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND }
    private val text = android.text.TextPaint(Paint.ANTI_ALIAS_FLAG).apply { typeface = Fonts.semibold; color = Color.WHITE; textAlign = Paint.Align.CENTER }
    private var t0 = 0L
    private val path = Path()
    private val seg = Path()

    override fun start() { t0 = SystemClock.uptimeMillis(); invalidate() }

    override fun onDraw(canvas: Canvas) {
        val cx = width / 2f; val cy = height / 2f
        val t = if (t0 == 0L) 0f else (SystemClock.uptimeMillis() - t0) / 1000f
        val pw = dp(112f); val ph = dp(220f)
        val r = RectF(cx - pw / 2f, cy - ph / 2f, cx + pw / 2f, cy + ph / 2f)
        screen.shader = LinearGradient(r.left, r.top, r.right, r.bottom, withAlpha(launcher.prefs.accent, 0.55f), Color.argb(40, 255, 255, 255), Shader.TileMode.CLAMP)
        canvas.drawRoundRect(r, dp(24f), dp(24f), screen)
        frame.strokeWidth = dp(3f)
        canvas.drawRoundRect(r, dp(24f), dp(24f), frame)
        text.textSize = dp(17f)
        val name = launcher.brand.label
        canvas.drawText(name, cx, r.top + dp(46f), text)
        // Check mark drawn progressively.
        val p = clamp01((t - 0.3f) / 0.6f).let { it * it * (3 - 2 * it) }
        path.reset()
        path.moveTo(cx - dp(24f), cy + dp(6f)); path.lineTo(cx - dp(6f), cy + dp(24f)); path.lineTo(cx + dp(28f), cy - dp(14f))
        val pm = PathMeasure(path, false)
        seg.reset()
        pm.getSegment(0f, pm.length * p, seg, true)
        check.strokeWidth = dp(7f)
        canvas.drawPath(seg, check)
        if (isAttachedToWindow && t0 != 0L && t < 1.2f) postInvalidateOnAnimation()
    }
}

/** A shield with calm pulses: privacy. */
class PrivacyHero(private val launcher: MainActivity) : View(launcher), Hero {
    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; color = Color.WHITE }
    private val disc = Paint(Paint.ANTI_ALIAS_FLAG)
    private val shield = launcher.getDrawable(R.drawable.ic_shield)?.mutate()
    private var t0 = 0L

    override fun start() { t0 = SystemClock.uptimeMillis(); invalidate() }

    override fun onDraw(canvas: Canvas) {
        val cx = width / 2f; val cy = height / 2f
        val t = if (t0 == 0L) 0f else (SystemClock.uptimeMillis() - t0) / 1000f
        val base = dp(62f)
        for (i in 0 until 2) {
            val ph = ((t * 0.55f + i * 0.5f) % 1f)
            ring.strokeWidth = dp(2f)
            ring.alpha = ((1f - ph) * 150).roundToInt()
            canvas.drawCircle(cx, cy, base + ph * dp(70f), ring)
        }
        disc.color = Color.rgb(20, 150, 120)
        canvas.drawCircle(cx, cy, base, disc)
        shield?.let { d ->
            d.setTint(Color.WHITE)
            val s = dp(64f).roundToInt()
            d.setBounds((cx - s / 2f).roundToInt(), (cy - s / 2f).roundToInt(), (cx + s / 2f).roundToInt(), (cy + s / 2f).roundToInt())
            d.draw(canvas)
        }
        if (isAttachedToWindow && t0 != 0L) postInvalidateOnAnimation()
    }
}

/** The Fluid One mark: a glossy squircle in the accent colours with a white drop. */
object FluidLogo {
    fun render(launcher: MainActivity, size: Int, accent: Int = launcher.prefs.accent): Bitmap {
        val out = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val c = Canvas(out)
        val path = IconShapes.path("squircle", size.toFloat())
        val hsv = FloatArray(3); Color.colorToHSV(accent, hsv)
        val second = Color.HSVToColor(floatArrayOf((hsv[0] + 50f) % 360f, (hsv[1] * 0.9f).coerceIn(0.4f, 1f), 0.75f))
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.shader = LinearGradient(0f, 0f, size.toFloat(), size.toFloat(), blendColors(accent, Color.WHITE, 0.15f), second, Shader.TileMode.CLAMP)
        c.drawPath(path, p)
        // Glass sheen on the top half.
        p.shader = LinearGradient(0f, 0f, 0f, size * 0.6f, Color.argb(90, 255, 255, 255), Color.argb(0, 255, 255, 255), Shader.TileMode.CLAMP)
        c.save(); c.clipPath(path); c.drawRect(0f, 0f, size.toFloat(), size * 0.6f, p); c.restore()
        p.shader = null
        p.style = Paint.Style.STROKE; p.strokeWidth = size / 40f; p.color = Color.argb(120, 255, 255, 255)
        c.drawPath(path, p)
        launcher.getDrawable(R.drawable.ic_drop)?.mutate()?.let { d ->
            d.setTint(Color.WHITE)
            val g = (size * 0.5f).roundToInt(); val o = (size - g) / 2
            d.setBounds(o, o + size / 30, o + g, o + g + size / 30)
            d.draw(c)
        }
        return out
    }
}

/**
 * The "1.3" tile on the What's new screen: dark glass with a silver number, a reflection on the floor below,
 * and a slow sheen. It leans a little towards your finger or as you tilt the phone, and settles back.
 */
class VersionHero(private val launcher: MainActivity, private val version: String) : View(launcher), android.hardware.SensorEventListener {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val text = Paint(Paint.ANTI_ALIAS_FLAG).apply { typeface = Fonts.bold; textAlign = Paint.Align.CENTER }
    private val tile = RectF()
    private val path = Path()
    private var sheen = -0.6f
    private var tiltX = 0f
    private var tiltY = 0f
    private val springX = SpringValue(0f) { tiltX = it; applyTilt() }
    private val springY = SpringValue(0f) { tiltY = it; applyTilt() }
    private var touching = false
    private var sensorOn = false
    /** Scroll position, so the tile drifts up a little slower than the page. */
    var parallax = 0f
        set(v) { field = v; translationY = v * 0.25f; alpha = clamp01(1f - v / (height.coerceAtLeast(1) * 1.1f)) }

    init {
        isClickable = true
        contentDescription = "Fluid One $version"
        cameraDistance = 14000f * resources.displayMetrics.density
    }

    private fun applyTilt() { rotationY = tiltX; rotationX = -tiltY; invalidate() }

    /** One slow pass of light across the glass. */
    fun sweep() {
        Motion.animate(1400, Motion.emphasized, update = { sheen = -0.6f + 2.2f * it; invalidate() })
    }

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        val size = minOf(w * 0.6f, h * 0.66f)
        tile.set((w - size) / 2f, h * 0.06f, (w + size) / 2f, h * 0.06f + size)
        val r = size * 0.24f
        drawTile(canvas, 1f)
        // The reflection on the black floor: the tile upside down, fading out quickly.
        val save = canvas.saveLayer(0f, tile.bottom, w, h, null)
        canvas.save()
        canvas.scale(1f, -1f, 0f, tile.bottom + size * 0.04f)
        drawTile(canvas, 0.32f)
        canvas.restore()
        paint.shader = LinearGradient(0f, tile.bottom, 0f, tile.bottom + size * 0.5f, Color.BLACK, Color.TRANSPARENT, Shader.TileMode.CLAMP)
        paint.xfermode = android.graphics.PorterDuffXfermode(android.graphics.PorterDuff.Mode.DST_IN)
        canvas.drawRect(0f, tile.bottom, w, h, paint)
        paint.xfermode = null; paint.shader = null
        canvas.restoreToCount(save)
        if (r <= 0f) return
    }

    private fun drawTile(canvas: Canvas, alpha: Float) {
        val size = tile.width()
        val r = size * 0.24f
        path.reset(); path.addRoundRect(tile, r, r, Path.Direction.CW)
        // Body: very dark glass, a touch lighter at the top-left.
        paint.shader = LinearGradient(tile.left, tile.top, tile.right, tile.bottom,
            intArrayOf(Color.rgb(46, 46, 52), Color.rgb(18, 18, 21), Color.rgb(8, 8, 10)), floatArrayOf(0f, 0.55f, 1f), Shader.TileMode.CLAMP)
        paint.alpha = (alpha * 255).roundToInt()
        canvas.drawPath(path, paint)
        canvas.save()
        canvas.clipPath(path)
        // The number, in brushed silver.
        text.textSize = size * 0.42f
        text.shader = LinearGradient(0f, tile.top + size * 0.3f, 0f, tile.top + size * 0.7f, Color.WHITE, Color.rgb(150, 150, 160), Shader.TileMode.CLAMP)
        text.alpha = (alpha * 255).roundToInt()
        canvas.drawText(version, tile.centerX() - tiltX * size * 0.004f, tile.centerY() - (text.ascent() + text.descent()) / 2f, text)
        // A soft band of light crosses the glass; tilting moves it.
        val pos = sheen + tiltX * 0.03f - tiltY * 0.02f
        val cx = tile.left + size * pos
        paint.shader = LinearGradient(cx - size * 0.35f, tile.top, cx + size * 0.35f, tile.bottom,
            intArrayOf(Color.TRANSPARENT, Color.argb((alpha * 46).roundToInt(), 255, 255, 255), Color.TRANSPARENT), floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP)
        paint.alpha = 255
        canvas.drawRect(tile, paint)
        // A broad, faint reflection over the top half.
        paint.shader = LinearGradient(0f, tile.top, 0f, tile.centerY(), Color.argb((alpha * 26).roundToInt(), 255, 255, 255), Color.TRANSPARENT, Shader.TileMode.CLAMP)
        canvas.drawRect(tile.left, tile.top, tile.right, tile.centerY(), paint)
        canvas.restore()
        // The rim: bright along the top-left, nearly gone at the bottom-right.
        paint.shader = LinearGradient(tile.left, tile.top, tile.right, tile.bottom,
            intArrayOf(Color.argb((alpha * 150).roundToInt(), 255, 255, 255), Color.argb((alpha * 20).roundToInt(), 255, 255, 255), Color.argb((alpha * 60).roundToInt(), 255, 255, 255)),
            floatArrayOf(0f, 0.6f, 1f), Shader.TileMode.CLAMP)
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = resources.displayMetrics.density * 1.2f
        canvas.drawPath(path, paint)
        paint.style = Paint.Style.FILL
        paint.shader = null
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_MOVE -> {
                touching = true
                parent?.requestDisallowInterceptTouchEvent(e.actionMasked == MotionEvent.ACTION_MOVE)
                // Lean towards the finger, gently.
                val nx = ((e.x / width.coerceAtLeast(1)) - 0.5f) * 2f
                val ny = ((e.y / height.coerceAtLeast(1)) - 0.4f) * 2f
                springX.animateTo(nx.coerceIn(-1f, 1f) * 9f, 260f, 0.8f)
                springY.animateTo(ny.coerceIn(-1f, 1f) * 7f, 260f, 0.8f)
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                touching = false
                springX.animateTo(0f, 120f, 0.45f)
                springY.animateTo(0f, 120f, 0.45f)
                if (e.actionMasked == MotionEvent.ACTION_UP) sweep()
            }
        }
        return true
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        val sm = context.getSystemService(android.hardware.SensorManager::class.java)
        sm?.getDefaultSensor(android.hardware.Sensor.TYPE_GRAVITY)?.let { sensorOn = sm.registerListener(this, it, android.hardware.SensorManager.SENSOR_DELAY_UI) }
    }

    override fun onDetachedFromWindow() {
        if (sensorOn) context.getSystemService(android.hardware.SensorManager::class.java)?.unregisterListener(this)
        sensorOn = false
        springX.stop(); springY.stop()
        super.onDetachedFromWindow()
    }

    override fun onSensorChanged(event: android.hardware.SensorEvent) {
        if (touching) return
        // A few degrees at most: just enough for the light to move.
        val gx = (-event.values[0] / 9.81f).coerceIn(-1f, 1f) * 5f
        val gy = ((event.values[1] / 9.81f) - 0.7f).coerceIn(-1f, 1f) * 4f
        if (kotlin.math.abs(gx - springX.target) > 0.3f) springX.animateTo(gx, 60f, 1f)
        if (kotlin.math.abs(gy - springY.target) > 0.3f) springY.animateTo(gy, 60f, 1f)
    }

    override fun onAccuracyChanged(sensor: android.hardware.Sensor?, accuracy: Int) {}
}

/** A small window onto the Outside mode landscape, at the real time of day. */
class OutsideHero(launcher: MainActivity) : FrameLayout(launcher), Hero {
    private val scene = NatureScene(launcher)
    init {
        val card = FrameLayout(launcher).apply {
            background = roundRect(Color.BLACK, launcher.dp(30f))
            clipToOutline = true
            outlineProvider = android.view.ViewOutlineProvider.BACKGROUND
        }
        card.addView(scene, flp(MATCH, MATCH))
        addView(card, flp(launcher.dpi(230), launcher.dpi(230), Gravity.CENTER))
    }
    override fun start() { scene.start() }
    override fun onDetachedFromWindow() { scene.stop(); super.onDetachedFromWindow() }
}
