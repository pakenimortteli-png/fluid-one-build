package com.fluidone.launcher

import android.Manifest
import android.app.Activity
import android.app.ActivityOptions
import android.content.ComponentName
import android.app.KeyguardManager
import android.app.WallpaperManager
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProviderInfo
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.LauncherApps
import android.content.pm.PackageManager
import android.content.pm.ShortcutInfo
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.ImageDecoder
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.drawable.ColorDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.os.SystemClock
import android.os.UserHandle
import android.provider.MediaStore
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.VelocityTracker
import android.view.View
import android.view.ViewConfiguration
import android.view.WindowInsets
import android.view.WindowInsetsController
import android.view.WindowManager
import android.view.inputmethod.InputMethodManager
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.io.File
import java.io.FileOutputStream
import java.util.Collections
import java.util.WeakHashMap
import java.util.concurrent.Executors
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * Fluid One — a ColorOS 17 inspired home screen.
 * This activity owns the view tree and wires the model, workspace, dock, drawer, overlays, drag and motion.
 */
class MainActivity : Activity() {
    lateinit var prefs: LauncherPrefs
    lateinit var model: LauncherModel
    lateinit var apps: AppRepository
    lateinit var icons: IconFactory
    lateinit var ui: UiTheme
    private lateinit var wallpaperStore: WallpaperStore
    private lateinit var launcherApps: LauncherApps
    private lateinit var widgetHost: LauncherWidgetHost
    private lateinit var widgetManager: AppWidgetManager

    lateinit var rootView: LauncherRoot
    lateinit var wallpaperView: WallpaperView
    lateinit var contentLayer: FrameLayout
    lateinit var homeLayout: HomeLayout
    lateinit var workspace: Workspace
    lateinit var dock: DockView
    lateinit var drawer: AppDrawer
    lateinit var dragLayer: FrameLayout
    lateinit var morphView: MorphView
    lateinit var removeBar: RemoveBar
    private lateinit var overlayLayer: FrameLayout
    private lateinit var scrim: View
    private lateinit var pillRow: FrameLayout
    lateinit var searchPill: SearchPill
        private set
    private lateinit var indicator: PageIndicator
    private lateinit var editBar: LinearLayout
    private lateinit var editDone: GlassView
    private lateinit var indexBubble: TextView

    lateinit var backdrop: Backdrop
    lateinit var drag: DragController
    lateinit var animator: LaunchAnimator
    /** Answers the system's swipe-home "gesture nav contract" so closing apps fly into their icon. */
    val iconLanding: IconLanding by lazy { IconLanding(this) }
    val overlays = mutableListOf<Overlay>()
    val openFolder: FolderOverlay? get() = overlays.lastOrNull { it is FolderOverlay && !it.closing } as? FolderOverlay

    var insetTop = 0
        private set
    var insetBottom = 0
        private set
    private var imeBottom = 0
    var iconSizePx = 0
        private set
    var wallpaperIsLight = false
        private set
    var isEditing = false
        private set
    private var editProgress = 0f
    private var editAnim: android.animation.ValueAnimator? = null
    val isDrawerOpen: Boolean get() = ::drawer.isInitialized && drawer.progress > 0.01f

    private val glassViews: MutableSet<View> = Collections.newSetFromMap(WeakHashMap())
    private val io = Executors.newSingleThreadExecutor()
    private val thumbs = Executors.newFixedThreadPool(2)
    private val thumbCache = HashMap<String, Bitmap>()
    private val main = Handler(Looper.getMainLooper())
    private val revealItemIds = HashSet<Long>()
    private val revealDockKeys = HashSet<String>()
    private var stoppedSinceResume = true
    /** Home gestures that open system UI only count if they start after this (uptime ms). */
    private var gestureReadyAt = 0L
    private var started = false
    private var resumed = false
    private var reduceTransparency = false
    private var powerSaving = false
    private var pendingWidgetId = -1
    private var pendingWidgetPage = 0
    private var pendingIconKey: String? = null
    private var firstFrame = true
    private var lastCellW = 0f
    private var lastBarFlags = -1

    // ---- Lifecycle -----------------------------------------------------------------------------------------

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = LauncherPrefs(this)
        FluidGlass.load(prefs, effectsTier())
        Motion.speed = prefs.animSpeed / 100f
        ui = makeTheme()
        launcherApps = getSystemService(LauncherApps::class.java)!!
        widgetManager = AppWidgetManager.getInstance(this)
        widgetHost = LauncherWidgetHost(this, WIDGET_HOST_ID)
        apps = AppRepository(launcherApps, prefs, packageName)
        apps.refresh()
        icons = IconFactory(this)
        model = LauncherModel(prefs)
        wallpaperStore = WallpaperStore(this)
        backdrop = Backdrop(this)
        drag = DragController(this)
        animator = LaunchAnimator(this)
        reduceTransparency = Device.samsungReduceTransparency(this)

        setupWindow()
        buildViews()
        // An existing home layout means Fluid One was updated, not freshly installed.
        val existingInstall = prefs.sp.contains("home_model") || prefs.sp.contains("wallpaper_id") || prefs.sp.contains("icon_style")
        if (!existingInstall) applyFreshInstallBrandDefaults()
        if (!model.load()) seedDefaultLayout() else cleanupModel()
        iconSizePx = estimateIconSize()
        bindAll()
        val start = prefs.defaultPage.coerceIn(0, model.pages.size - 1)
        workspace.snapTo(savedInstanceState?.getInt("page", start) ?: start, animate = false)
        loadWallpaper(animate = false)
        registerReceivers()
        try { launcherApps.registerCallback(appsCallback) } catch (_: Exception) { }
        applyDeviceTuning()
        scheduleIconPrewarm(1500L)
        if (savedInstanceState == null) animator.primeUnlock()
        maybeShowWelcome(existingInstall)
        SunTimes.appContext = applicationContext
        // Outside mode survives the launcher being restarted.
        if (OutsideMode.isActive(prefs)) rootView.post { if (!isDestroyed) OutsideMode.start(this) }
    }

    /** A brand new install gets the looks that fit the phone: Nothing's dot clock, Pixel's Material You colours. */
    private fun applyFreshInstallBrandDefaults() {
        when (brand) {
            Brand.NOTHING -> prefs.dotClock = true
            Brand.GOOGLE -> if (Build.VERSION.SDK_INT >= 31) prefs.systemAccent = true
            else -> {}
        }
    }

    // ---- Welcome / What's new ------------------------------------------------------------------------------

    private fun versionCode(): Long = try { packageManager.getPackageInfo(packageName, 0).longVersionCode } catch (_: Exception) { 0L }

    private fun maybeShowWelcome(existingInstall: Boolean) {
        val code = versionCode()
        if (prefs.sp.getLong("welcome_seen_code", 0L) >= code) return
        val version = versionName().substringBefore('-').ifEmpty { "1.2.1" }
        rootView.post { if (!isDestroyed && overlays.none { it is WelcomeOverlay }) WelcomeOverlay(this, existingInstall, version).show() }
    }

    fun markWelcomeSeen() { prefs.sp.edit().putLong("welcome_seen_code", versionCode()).apply() }

    /** The welcome lifted away: let the home screen arrive with the entrance animation. */
    fun onWelcomeClosed() {
        animator.cancelUnlockPrime()
        animator.playEntrance(prefs.unlockAnim.takeIf { it != "off" } ?: "gather")
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putInt("page", workspace.currentPage)
    }

    override fun onStart() {
        super.onStart()
        started = true
        try { widgetHost.startListening() } catch (_: Exception) { }
    }

    override fun onResume() {
        super.onResume()
        reduceTransparency = Device.samsungReduceTransparency(this)
        powerSaving = Device.powerSave(this)
        FluidGlass.load(prefs, effectsTier())
        Motion.speed = prefs.animSpeed / 100f
        applyDeviceTuning()
        refreshCalendarWidgets()
        resumed = true
        rootView.post { animator.onResumed() }
        overlays.toList().forEach { it.onHostResumed() }
        maybeChangeDailyWallpaper()
        glassLight.start()
        // Never leave the home screen hidden if an unlock/entrance could not play.
        main.removeCallbacks(unlockSafety)
        main.postDelayed(unlockSafety, 2500)
        stoppedSinceResume = false
        gestureReadyAt = SystemClock.uptimeMillis() + 350
        updateSystemBars()
        resumePendingWidget()
    }

    override fun onPause() {
        super.onPause()
        resumed = false
        animator.onPaused()
        overlays.toList().forEach { it.onHostPaused() }
        glassLight.stop()
        if (drag.isDragging) drag.cancel()
    }

    override fun onStop() {
        super.onStop()
        stoppedSinceConfig = true
        started = false
        stoppedSinceResume = true
        try { widgetHost.stopListening() } catch (_: Exception) { }
        animator.onStopped()
        val pm = getSystemService(PowerManager::class.java)
        if (pm != null && !pm.isInteractive) animator.primeUnlock()
    }

    override fun onDestroy() {
        try { unregisterReceiver(screenReceiver) } catch (_: Exception) { }
        try { launcherApps.unregisterCallback(appsCallback) } catch (_: Exception) { }
        io.shutdown()
        thumbs.shutdown()
        super.onDestroy()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        val alreadyHome = !stoppedSinceResume
        if (drag.isDragging) drag.cancel()
        if (alreadyHome) {
            when {
                overlays.isNotEmpty() -> closeAllOverlays(true)
                isDrawerOpen -> setDrawerOpen(false)
                isEditing -> exitEditMode()
                else -> workspace.snapTo(prefs.defaultPage)
            }
        } else {
            closeAllOverlays(false)
            if (isDrawerOpen) { drawer.setProgress(0f); drawer.resetState() }
            if (isEditing) exitEditMode(animate = false)
        }
        // Swipe home from an app: the system asks where the app's icon is so the window can fly into it.
        val contract = GestureContract.from(intent)
        if (contract != null && !alreadyHome && prefs.launchAnimations && prefs.returnAnim) {
            animator.prepareForLanding()
            iconLanding.handle(contract)
        }
    }

    /**
     * Where an app that is closing should land: its icon on the current page or in the dock, or its tile in a
     * folder there. Null when it isn't on screen (the system then uses its own close animation).
     */
    fun findCloseTarget(component: ComponentName, user: android.os.UserHandle): LandingTarget? {
        val key = AppEntry.keyFor(component, user)
        val pkg = component.packageName
        val loc = IntArray(2); val win = IntArray(2)
        rootView.getLocationOnScreen(loc); rootView.getLocationInWindow(win)
        val dx = (loc[0] - win[0]).toFloat(); val dy = (loc[1] - win[1]).toFloat()
        fun onScreen(r: RectF) = RectF(r).apply { offset(dx, dy) }
        fun forIcon(v: IconView) = LandingTarget(onScreen(v.iconRectInWindow()), { c, w, h -> v.drawIconOnly(c, w, h) }, { v.landingHidden = it }, v)
        // In Outside mode the home screen is hidden: land on the pinned icon, if the app is one of them.
        outsideOverlay()?.let { o ->
            val v = o.iconFor(key) ?: apps.apps.firstOrNull { it.packageName == pkg && it.user == user }?.let { o.iconFor(it.key) }
            return v?.let { forIcon(it) }
        }
        val page = workspace.pages.getOrNull(workspace.currentPage)?.childList().orEmpty()
        val plain = page.filterIsInstance<IconView>().filter { it !is FolderIconView && it.isShown } + dock.icons.filter { it.isShown }
        plain.firstOrNull { it.entry?.key == key }?.let { return forIcon(it) }
        plain.firstOrNull { it.entry?.packageName == pkg && it.entry?.user == user }?.let { return forIcon(it) }
        for (f in page.filterIsInstance<FolderIconView>()) {
            val item = f.item ?: continue
            if (!f.isShown) continue
            val idx = item.apps.indexOfFirst { it == key || apps[it]?.let { e -> e.packageName == pkg && e.user == user } == true }
            if (idx < 0) continue
            if (f.isLarge && idx < 8) {
                val entry = apps[item.apps[idx]] ?: return forIcon(f)
                val r = onScreen(f.previewRectInWindow(idx))
                val bmp = icons.appIconForDisplay(entry, r.width().roundToInt().coerceAtLeast(8))
                val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
                return LandingTarget(r, { c, w, h -> c.drawBitmap(bmp, null, RectF(0f, 0f, w.toFloat(), h.toFloat()), paint) }, {}, f)
            }
            return forIcon(f)
        }
        return null
    }

    /**
     * Fluid One's opening starts the app with no system animation. Some phones animate it anyway; then the launcher
     * stays on screen for the length of that animation. If that happens on two of the last three openings, switch
     * to the phone's own animation so it never plays twice.
     */
    fun onFluidLaunchTiming(ms: Long) {
        val scale = NavMode.transitionScale(this)
        if (scale <= 0.01f) return
        // Without a system animation the window is hidden as soon as the app's first frame (or splash) is up,
        // well under 300 ms; with one, it stays up for the length of that animation as well.
        val slow = ms > (130 + 220 * scale).toLong()
        val mask = ((prefs.fluidSlowMask shl 1) or (if (slow) 1 else 0)) and 0b111
        prefs.fluidSlowMask = mask
        lastFluidHandoffMs = ms
        if (Integer.bitCount(mask) >= 2 && !prefs.fluidLaunchIgnored) prefs.fluidLaunchIgnored = true
    }

    fun outsideOverlay(): OutsideOverlay? = overlays.lastOrNull { it is OutsideOverlay && !it.closing } as? OutsideOverlay

    /** How long the last Fluid One opening kept the launcher on screen (Settings › Animations shows it). */
    var lastFluidHandoffMs = -1L
        private set

    /** The opening style actually used: Fluid One's own, unless this phone was seen overriding it. */
    fun effectiveLaunchStyle(): String {
        val s = prefs.launchAnim
        return if (s == "fluid" && prefs.fluidLaunchIgnored) "zoom" else s
    }

    @Deprecated("Back is handled for the whole launcher here")
    override fun onBackPressed() {
        when {
            drag.isDragging -> drag.cancel()
            overlays.isNotEmpty() -> overlays.last().onBack()
            isDrawerOpen -> if (!drawer.onBack()) setDrawerOpen(false)
            isEditing -> exitEditMode()
        }
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus && animator.isUnlockPrimed && !isKeyguardLocked()) animator.playUnlock()
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        val dark = makeTheme().dark
        if (dark != ui.dark) applyThemeChange()
        homeLayout.requestLayout()
    }

    // ---- Window & views ------------------------------------------------------------------------------------

    private fun setupWindow() {
        window.setDecorFitsSystemWindows(false)
        @Suppress("DEPRECATION")
        window.statusBarColor = Color.TRANSPARENT
        @Suppress("DEPRECATION")
        window.navigationBarColor = Color.TRANSPARENT
        window.isNavigationBarContrastEnforced = false
        window.isStatusBarContrastEnforced = false
        window.attributes = window.attributes.apply { layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS }
        window.setBackgroundDrawable(ColorDrawable(Color.BLACK))
        window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_NOTHING or WindowManager.LayoutParams.SOFT_INPUT_STATE_HIDDEN)
    }

    private fun buildViews() {
        rootView = LauncherRoot()
        wallpaperView = WallpaperView(this)
        wallpaperView.parallaxEnabled = prefs.parallax
        wallpaperView.onGeometryChanged = { invalidateGlass() }
        rootView.addView(wallpaperView, flp(MATCH, MATCH))

        contentLayer = FrameLayout(this).apply { clipChildren = false }
        rootView.addView(contentLayer, flp(MATCH, MATCH))

        homeLayout = HomeLayout(this, this)
        workspace = Workspace(this, this)
        homeLayout.workspace = workspace
        homeLayout.addView(workspace)
        workspace.onScroll = { pos -> onWorkspaceScroll(pos) }
        workspace.onSettled = { onWorkspaceSettled() }

        pillRow = FrameLayout(this)
        indicator = PageIndicator(this)
        searchPill = SearchPill(this, this)
        pillRow.addView(indicator, flp(MATCH, MATCH))
        pillRow.addView(searchPill, flp(MATCH, MATCH))
        homeLayout.pillRow = pillRow
        homeLayout.addView(pillRow)

        dock = DockView(this, this)
        homeLayout.dock = dock
        homeLayout.addView(dock)

        editBar = buildEditBar()
        homeLayout.addView(editBar, FrameLayout.LayoutParams(MATCH, dpi(104), Gravity.BOTTOM).apply { bottomMargin = dpi(8) })
        editDone = GlassView(this, dp(20f), GlassView.Style.HOME).apply {
            addView(textView("Done", 15f, Color.WHITE, Fonts.semibold, Gravity.CENTER), flp(MATCH, MATCH))
            isClickable = true
            contentDescription = "Finish editing"
            setOnClickListener { haptic(it, HapticFeedbackConstants.CONTEXT_CLICK); exitEditMode() }
            enableLiquidPress()
        }
        homeLayout.addView(editDone, FrameLayout.LayoutParams(dpi(84), dpi(40), Gravity.TOP or Gravity.END).apply { rightMargin = dpi(18); topMargin = dpi(6) })
        editBar.visibility = View.INVISIBLE
        editDone.visibility = View.INVISIBLE
        contentLayer.addView(homeLayout, flp(MATCH, MATCH))

        drawer = AppDrawer(this)
        contentLayer.addView(drawer, flp(MATCH, MATCH))

        scrim = View(this).apply { setBackgroundColor(Color.BLACK); alpha = 0f; visibility = View.GONE }
        rootView.addView(scrim, flp(MATCH, MATCH))

        overlayLayer = FrameLayout(this)
        rootView.addView(overlayLayer, flp(MATCH, MATCH))

        removeBar = RemoveBar(this)
        rootView.addView(removeBar, flp(MATCH, dpi(48), Gravity.TOP).apply { leftMargin = dpi(20); rightMargin = dpi(20) })

        dragLayer = FrameLayout(this).apply { clipChildren = false; isClickable = false }
        rootView.addView(dragLayer, flp(MATCH, MATCH))

        morphView = MorphView(this).apply { visibility = View.GONE }
        rootView.addView(morphView, flp(MATCH, MATCH))

        indexBubble = textView("", 30f, inkOn(prefs.accent), Fonts.semibold, Gravity.CENTER).apply {
            background = oval(prefs.accent)
            visibility = View.INVISIBLE
            elevation = dp(8f)
        }
        rootView.addView(indexBubble, flp(dpi(68), dpi(68)))

        rootView.setOnApplyWindowInsetsListener { _, insets -> onInsets(insets); WindowInsets.CONSUMED }
        rootView.viewTreeObserver.addOnPreDrawListener { refreshMovedGlass(); true }
        setContentView(rootView)
    }

    private fun onInsets(insets: WindowInsets) {
        val bars = insets.getInsets(WindowInsets.Type.systemBars() or WindowInsets.Type.displayCutout())
        insetTop = bars.top
        insetBottom = insets.getInsets(WindowInsets.Type.navigationBars()).bottom
        val ime = insets.getInsets(WindowInsets.Type.ime()).bottom
        homeLayout.insetTop = insetTop
        homeLayout.insetBottom = insetBottom
        drawer.applyInsets(insetTop, max(insetBottom, ime))
        (removeBar.layoutParams as FrameLayout.LayoutParams).topMargin = insetTop + dpi(8)
        removeBar.requestLayout()
        if (ime != imeBottom) {
            imeBottom = ime
            overlays.forEach { it.onImeInset(ime) }
        }
        homeLayout.requestLayout()
    }

    private fun buildEditBar(): LinearLayout {
        val bar = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER; setPadding(dpi(12), 0, dpi(12), 0) }
        val items = listOf(
            Triple(R.drawable.ic_wallpaper, "Wallpapers") { WallpaperSheet(this).show() },
            Triple(R.drawable.ic_widgets, "Widgets") { WidgetsSheet(this).show() },
            Triple(R.drawable.ic_palette, "Icons") { IconsSheet(this).show() },
            Triple(R.drawable.ic_grid, "Layout") { LayoutSheet(this).show() },
            Triple(R.drawable.ic_settings, "Settings") { openSettings() }
        )
        items.forEach { (icon, label, action) ->
            val col = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER_HORIZONTAL
                isClickable = true
                contentDescription = label
                setOnClickListener { haptic(it, HapticFeedbackConstants.CONTEXT_CLICK); action() }
            }
            val circle = GlassView(this, dp(27f), GlassView.Style.HOME)
            circle.addView(iconImage(icon, Color.WHITE, 15), flp(MATCH, MATCH))
            circle.enableLiquidPress(col)
            col.addView(circle, llp(dpi(54), dpi(54)))
            col.addView(textView(label, 12f, Color.WHITE, Fonts.medium, Gravity.CENTER, maxLines = 1).apply {
                setShadowLayer(dp(3f), 0f, dp(0.5f), Color.argb(110, 0, 0, 0)); setPadding(0, dpi(8), 0, 0)
            }, llp(MATCH, WRAP))
            bar.addView(col, llp(0, WRAP, 1f))
        }
        return bar
    }

    // ---- Theme / system bars -------------------------------------------------------------------------------

    private fun makeTheme(): UiTheme {
        val dark = when (prefs.theme) { "dark" -> true; "light" -> false; else -> isSystemDark() }
        return UiTheme(dark, prefs.accent)
    }

    fun updateSystemBars() {
        val settingsOpen = overlays.any { it is SettingsPanel && !it.closing }
        val light = when {
            settingsOpen -> !ui.dark
            isDrawerOpen || isEditing || overlays.isNotEmpty() -> false
            else -> wallpaperView.isLightAtTop
        }
        val flags = if (light) WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS or WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS else 0
        if (flags == lastBarFlags) return
        lastBarFlags = flags
        window.insetsController?.setSystemBarsAppearance(flags,
            WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS or WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS)
    }

    fun applyThemeChange() {
        val panel = overlays.filterIsInstance<SettingsPanel>().firstOrNull()
        val reopenSettings = panel != null
        val reopenAt = panel?.currentPageId() ?: "theme"
        ui = makeTheme()
        indexBubble.background = oval(prefs.accent); indexBubble.setTextColor(inkOn(prefs.accent))
        closeAllOverlays(false)
        icons.clear()
        syncAll()
        drawer.refreshIcons()
        if (reopenSettings) SettingsPanel(this, reopenAt).show()
        updateSystemBars()
    }

    // ---- Glass ---------------------------------------------------------------------------------------------

    fun registerGlass(v: View) { glassViews.add(v) }
    fun unregisterGlass(v: View) { glassViews.remove(v) }
    fun invalidateGlass() {
        FluidGlass.load(prefs, effectsTier())
        glassViews.toList().forEach { it.invalidate() }
    }

    /** Moves the glass highlights with the phone's tilt. */
    val glassLight: GlassLight by lazy { GlassLight(this) }

    /** The light moved: redraw glass that is on screen (cheap: no wallpaper work). */
    fun onGlassLightChanged() {
        if (!resumed || animator.isBusy || drag.isDragging) return
        glassViews.toList().forEach { if (it.isShown) it.invalidate() }
    }

    private val glassMatrix = Matrix()
    private val glassValues = FloatArray(9)

    /**
     * Glass samples the wallpaper for the place it is drawn. When Android moves an already-drawn view (a sheet
     * sliding up, a folder growing, a menu springing open) it reuses the old drawing, so any glass that moved
     * since its last draw is redrawn here, once per frame, before anything is drawn.
     */
    fun refreshMovedGlass() {
        if (!wallpaperView.hasWallpaper) return
        for (v in glassViews.toList()) {
            if (!v.isAttachedToWindow || !v.isShown || v.alpha <= 0f || (v is GlassView && !v.isGlassActive)) continue
            val stamp = v.getTag(R.id.tag_glass_matrix) as? FloatArray
            glassMatrix.reset()
            v.transformMatrixToGlobal(glassMatrix)
            glassMatrix.getValues(glassValues)
            if (stamp == null || !sameTransform(stamp, glassValues)) v.invalidate()
        }
    }

    private fun sameTransform(a: FloatArray, b: FloatArray): Boolean {
        for (i in 0 until 9) {
            val tolerance = if (i == 2 || i == 5) 0.5f else 0.0005f   // translation in px, scale/skew unitless
            if (kotlin.math.abs(a[i] - b[i]) > tolerance) return false
        }
        return true
    }

    fun liveBlurAllowed(): Boolean = !reduceTransparency && !(brandModeOn() && prefs.batteryBlur && powerSaving) && effectsTier() != Tier.LITE

    /** Fluid Glass strength for a glass style: 0 = plain frosted blur, 1 = clear liquid glass. */
    fun fluidIntensity(style: GlassView.Style): Float {
        if (!prefs.fluidGlass) return 0f
        val base = prefs.fluidIntensity.coerceIn(0, 100) / 100f
        return base * when (style) {
            GlassView.Style.HOME -> 1f
            GlassView.Style.MENU -> 0.75f      // menus and sheets stay readable over busy wallpapers
            GlassView.Style.CARD_LIGHT -> 0.6f
        }
    }

    fun setScrim(alpha: Float) {
        scrim.alpha = alpha
        scrim.visibility = if (alpha > 0.003f) View.VISIBLE else View.GONE
    }

    /** Applies the backdrop's live blur to whichever surface is behind the overlays. */
    fun setContentBlur(radius: Float) {
        if (isDrawerOpen && drawer.progress > 0.5f) {
            homeLayout.setLiveBlur(0f)
            drawer.setLiveBlur(radius)
        } else {
            drawer.setLiveBlur(0f)
            homeLayout.setLiveBlur(radius)
        }
    }

    // ---- Wallpaper -----------------------------------------------------------------------------------------

    private fun screenSize(): Pair<Int, Int> {
        val b = windowManager.currentWindowMetrics.bounds
        var w = min(b.width(), b.height())
        var h = max(b.width(), b.height())
        if (w > 1440) { h = h * 1440 / w; w = 1440 }
        return max(w, 360) to max(h, 640)
    }

    private fun loadWallpaper(animate: Boolean) {
        val id = prefs.wallpaper
        val (w, h) = screenSize()
        val strength = prefs.blurStrength
        io.execute {
            val bmp = wallpaperStore.load(id, w, h) ?: wallpaperStore.load(Wallpapers.DEFAULT_ID, w, h) ?: return@execute
            val glass = makeGlassBlur(bmp, strength)
            val heavy = BlurEngine.blur(bmp, WallpaperView.HEAVY_SCALE, WallpaperView.heavyRadius(max(strength, 45)))
            main.post {
                if (isDestroyed) return@post
                wallpaperView.setWallpaper(bmp, glass, heavy, animate)
                onWallpaperChanged()
            }
        }
    }

    private fun makeGlassBlur(bmp: Bitmap, strength: Int): Bitmap =
        if (strength <= 0) BlurEngine.blur(bmp, 0.33f, 0) else BlurEngine.blur(bmp, WallpaperView.GLASS_SCALE, WallpaperView.glassRadius(strength))

    private val blurRebuild = Runnable {
        val src = wallpaperView.thumbnailSource() ?: return@Runnable
        val strength = prefs.blurStrength
        io.execute {
            val glass = makeGlassBlur(src, strength)
            val heavy = BlurEngine.blur(src, WallpaperView.HEAVY_SCALE, WallpaperView.heavyRadius(max(strength, 45)))
            main.post { if (!isDestroyed) { wallpaperView.setWallpaper(src, glass, heavy, false); invalidateGlass() } }
        }
    }

    fun scheduleBlurRebuild() {
        main.removeCallbacks(blurRebuild)
        main.postDelayed(blurRebuild, 90)
    }

    private val unlockSafety = Runnable {
        if (animator.isUnlockPrimed && !isKeyguardLocked()) {
            if (wallpaperView.hasWallpaper) animator.playUnlock() else animator.cancelUnlockPrime()
        }
    }

    private fun onWallpaperChanged() {
        if (firstFrame) {
            firstFrame = false
            if (animator.isUnlockPrimed && resumed && !isKeyguardLocked()) rootView.post { animator.playUnlock() }
        }
        val light = wallpaperView.isLight
        val changed = light != wallpaperIsLight
        wallpaperIsLight = light
        searchPill.setDark(light)
        indicator.dark = light
        if (changed) syncAll()
        forEachHomeView { v -> if (v is WidgetFrame) v.refreshContent() }
        invalidateGlass()
        updateSystemBars()
    }

    /** Daily wallpaper: on the first visit home each day, move on to the next built-in wallpaper. */
    private fun maybeChangeDailyWallpaper() {
        if (!prefs.dailyWallpaper) return
        val today = (System.currentTimeMillis() + java.util.TimeZone.getDefault().getOffset(System.currentTimeMillis())) / 86_400_000L
        if (prefs.dailyWallpaperDay == today.toInt()) return
        prefs.dailyWallpaperDay = today.toInt()
        val list = Wallpapers.presets
        val i = list.indexOfFirst { it.id == prefs.wallpaper }
        setWallpaper(list[(i + 1).mod(list.size)].id)
    }

    fun setWallpaper(id: String) {
        prefs.wallpaper = id
        loadWallpaper(animate = true)
        if (prefs.lockWallpaper) main.postDelayed({ applyLockWallpaper() }, 600)
    }

    fun applyLockWallpaper() {
        val (w, h) = screenSize()
        val id = prefs.wallpaper
        io.execute {
            val bmp = wallpaperStore.load(id, w, h) ?: return@execute
            try {
                WallpaperManager.getInstance(this).setBitmap(bmp, null, true, WallpaperManager.FLAG_LOCK)
                main.post { toast("Lock screen wallpaper updated") }
            } catch (_: Exception) {
                main.post { toast("Couldn't set the lock screen wallpaper") }
            }
        }
    }

    fun wallpaperThumbnail(id: String, w: Int, h: Int, callback: (Bitmap) -> Unit) {
        val key = "$id|$w|$h"
        thumbCache[key]?.let { callback(it); return }
        thumbs.execute {
            val bmp = try { Wallpapers.render(Wallpapers.preset(id), w, h) } catch (_: Throwable) { null } ?: return@execute
            main.post { thumbCache[key] = bmp; callback(bmp) }
        }
    }

    fun pickWallpaperImage() {
        val intent = if (Build.VERSION.SDK_INT >= 33) Intent(MediaStore.ACTION_PICK_IMAGES).setType("image/*")
                     else Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("image/*")
        try { startActivityForResult(intent, REQ_WALLPAPER) } catch (_: Exception) {
            try { startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("image/*"), REQ_WALLPAPER) }
            catch (_: Exception) { toast("No image picker available") }
        }
    }

    fun pickIconImage(entry: AppEntry) {
        pendingIconKey = entry.key
        val intent = if (Build.VERSION.SDK_INT >= 33) Intent(MediaStore.ACTION_PICK_IMAGES).setType("image/*")
                     else Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("image/*")
        try { startActivityForResult(intent, REQ_ICON_IMAGE) } catch (_: Exception) { toast("No image picker available") }
    }

    // ---- Binding -------------------------------------------------------------------------------------------

    private fun estimateIconSize(): Int {
        val (w, _) = screenSize()
        val cellW = (w - dpi(20)) / prefs.columns.toFloat()
        return computeIconSize(cellW, dp(110f))
    }

    private fun computeIconSize(cellW: Float, cellH: Float): Int {
        val labelRoom = if (prefs.showLabels) dp(24f) else dp(6f)
        val base = minOf(cellW * 0.66f, cellH - labelRoom - dp(8f), dp(62f))
        return (base * prefs.iconScale / 100f).coerceIn(dp(32f), min(cellW - dp(6f), cellH - labelRoom)).roundToInt()
    }

    /** Called after every home layout pass; recomputes icon size from the real cell size. */
    fun onHomeLayout() {
        val cl = workspace.pages.firstOrNull() ?: return
        if (cl.cellW <= 0f) return
        val size = computeIconSize(cl.cellW, cl.cellH)
        dock.slotWidth = cl.cellW.roundToInt()
        if (size != iconSizePx || cl.cellW != lastCellW) {
            lastCellW = cl.cellW
            if (size != iconSizePx) {
                iconSizePx = size
                rootView.post { syncAll(); drawer.refreshIcons(); scheduleIconPrewarm() }
            }
        }
        if (isEditing) workspace.applyTransforms()
    }

    private fun newPage(index: Int): CellLayout = CellLayout(this, this).apply {
        cols = prefs.columns
        rows = prefs.rows
        setPadding(dpi(10), dpi(2), dpi(10), dpi(2))
        onEmptyLongPress = { _, _, _ -> if (!isEditing && overlays.isEmpty()) { haptic(this, HapticFeedbackConstants.LONG_PRESS); enterEditMode() } }
        onEmptyTap = { cl ->
            if (isEditing) {
                val idx = workspace.pages.indexOf(cl)
                if (idx != workspace.currentPage) workspace.snapTo(idx) else exitEditMode()
            }
        }
        contentDescription = "Home page ${index + 1}"
    }

    private fun bindAll() {
        workspace.effect = prefs.pageEffect
        workspace.setPageCount(model.pages.size) { newPage(it) }
        applyChromeVisibility()
        syncAll()
        drawer.reload()
    }

    private fun applyChromeVisibility() {
        dock.style = prefs.dockStyle
        dock.visibility = if (prefs.dockStyle == "off") View.GONE else View.VISIBLE
        dock.showLabels = prefs.dockLabels
        searchPill.visibility = if (prefs.searchBar) View.VISIBLE else View.INVISIBLE
        indicator.alpha = if (prefs.searchBar) 0f else 1f
        wallpaperView.parallaxEnabled = prefs.parallax
        workspace.effect = prefs.pageEffect
    }

    /** Rebuilds views from the model. Revealed items stay invisible until their flight lands. */
    fun syncAll(
        revealItem: HomeItem? = null,
        revealDockKey: String? = null,
        revealItems: Collection<HomeItem> = emptyList(),
        revealKeys: Collection<String> = emptyList()
    ) {
        model.normalizeFolders()
        revealItem?.let { revealItemIds.add(it.id) }
        revealDockKey?.let { revealDockKeys.add(it) }
        revealItems.forEach { revealItemIds.add(it.id) }
        revealDockKeys.addAll(revealKeys)
        if (workspace.pageCount != model.pages.size) workspace.setPageCount(model.pages.size) { newPage(it) }
        workspace.pages.forEachIndexed { i, cl ->
            cl.cols = prefs.columns
            cl.rows = prefs.rows
            cl.contentDescription = "Home page ${i + 1}"
            syncPage(i)
        }
        syncDock()
        indicator.count = model.pages.size
        indicator.position = workspace.scrollPos
        workspace.refreshHeaders()
        openFolder?.let { if (model.pageOf(it.item) < 0) it.close() }
    }

    fun revealDone() {
        revealItemIds.clear()
        revealDockKeys.clear()
    }

    fun revealDone(item: HomeItem?, key: String?) {
        item?.let { revealItemIds.remove(it.id) }
        key?.let { revealDockKeys.remove(it) }
    }

    private fun kindTag(item: HomeItem): String = when (item.type) {
        HomeItem.APP -> "app:${item.appKey}"
        HomeItem.FOLDER -> if (item.isLargeFolder) "folderL" else "folder"
        HomeItem.WIDGET -> "widget:${item.widgetId}"
        HomeItem.STACK -> "stack:" + item.children.joinToString(",") { it.id.toString() }
        else -> "builtin:${item.builtin}"
    }

    private fun syncPage(i: Int) {
        val cl = workspace.pages.getOrNull(i) ?: return
        val items = model.pages.getOrNull(i) ?: return
        for (child in cl.childList()) {
            val it = child.getTag(R.id.tag_item) as? HomeItem
            if (it == null || items.none { x -> x === it } || child.getTag(R.id.tag_kind) != kindTag(it)) cl.removeView(child)
        }
        for (item in items) {
            var v = cl.childFor(item)
            if (v == null) {
                v = createItemView(item) ?: continue
                v.setTag(R.id.tag_item, item)
                v.setTag(R.id.tag_kind, kindTag(item))
                cl.addView(v, CellLayout.LP(item.x, item.y, item.spanX, item.spanY))
            } else {
                val lp = v.layoutParams as CellLayout.LP
                if (lp.cellX != item.x || lp.cellY != item.y || lp.spanX != item.spanX || lp.spanY != item.spanY) {
                    lp.cellX = item.x; lp.cellY = item.y; lp.spanX = item.spanX; lp.spanY = item.spanY
                    v.translationX = 0f; v.translationY = 0f
                    v.layoutParams = lp
                }
                refreshItemView(v, item)
            }
            if (item.id in revealItemIds) v.alpha = 0f
        }
        cl.requestLayout()
        cl.invalidate()
    }

    private fun createItemView(item: HomeItem): View? = when (item.type) {
        HomeItem.APP -> apps[item.appKey]?.let { e -> createAppIcon(e, IconView.SOURCE_WORKSPACE).also { it.item = item } }
        HomeItem.FOLDER -> FolderIconView(this, this).also { v ->
            v.item = item
            refreshItemView(v, item)
            v.onTap = { view, x, y -> onFolderTap(view as FolderIconView, x, y) }
            v.onLongPress = { onItemLongPress(it) }
        }
        HomeItem.WIDGET -> createWidgetView(item)
        HomeItem.STACK -> createStackView(item)
        else -> WidgetFrame(this).also { frame ->
            frame.item = item
            val surface = Builtins.create(this, item)
            // A search bar is a capsule centred in its cells, not a tall card.
            val lp = if (item.builtin == Builtins.SEARCH) flp(MATCH, dpi(58), Gravity.CENTER_VERTICAL) else flp(MATCH, MATCH)
            frame.addView(surface, lp)
            val pad = dpi(6)
            frame.setPadding(pad, pad, pad, pad)
            frame.onLongPress = { onItemLongPress(it) }
        }
    }

    private fun refreshItemView(v: View, item: HomeItem) {
        when {
            v is FolderIconView -> {
                if (!drag.isDragging) v.resetHover()
                v.iconSize = iconSizePx
                v.label = item.title.ifEmpty { "Folder" }
                v.showLabel = prefs.showLabels
                v.setLabelSizeSp(prefs.labelSize.toFloat())
                v.darkLabel = wallpaperIsLight
                v.contentDescription = "Folder ${v.label}, ${item.apps.size} apps"
                v.invalidate()
            }
            v is IconView && item.type == HomeItem.APP -> {
                if (!drag.isDragging) v.resetHover()
                apps[item.appKey]?.let { bindAppIcon(v, it, IconView.SOURCE_WORKSPACE) }
            }
            v is WidgetFrame -> v.refreshContent()
            v is StackFrame -> v.refreshAll()
        }
    }

    private fun createWidgetView(item: HomeItem): View? {
        val info = try { widgetManager.getAppWidgetInfo(item.widgetId) } catch (_: Exception) { null } ?: return null
        return try {
            val host = widgetHost.createView(this, item.widgetId, info) as FluidWidgetHostView
            host.item = item
            host.onLongPress = { onItemLongPress(it) }
            host
        } catch (_: Exception) { null }
    }

    fun createAppIcon(entry: AppEntry, source: Int): IconView = IconView(this).also { bindAppIcon(it, entry, source) }

    fun bindAppIcon(v: IconView, entry: AppEntry, source: Int) {
        v.entry = entry
        v.source = source
        v.iconSize = iconSizePx
        if (source == IconView.SOURCE_DRAWER || source == IconView.SOURCE_FOLDER) {
            // Lists never build icons on the UI thread: show what is cached, fade the rest in when ready.
            val size = iconSizePx
            val cached = icons.cachedIcon(entry, size)
            v.bitmap = cached
            if (cached == null) icons.loadIcon(entry, size) { bmp ->
                if (v.entry === entry && v.iconSize == size) {
                    v.bitmap = bmp
                    v.iconAlpha = 0f
                    Motion.animate(160, Motion.decel, update = { v.iconAlpha = it })
                }
            } else v.iconAlpha = 1f
        } else v.bitmap = icons.appIcon(entry, iconSizePx)
        val label = apps.label(entry)
        v.label = label
        v.showLabel = when (source) {
            IconView.SOURCE_DOCK -> prefs.dockLabels
            IconView.SOURCE_WORKSPACE -> prefs.showLabels
            else -> true
        }
        v.setLabelSizeSp(prefs.labelSize.toFloat())
        v.darkLabel = (source == IconView.SOURCE_WORKSPACE || source == IconView.SOURCE_DOCK) && wallpaperIsLight
        v.contentDescription = label
        v.onTap = { view, _, _ -> launchApp(entry, view, source) }
        v.onLongPress = { onItemLongPress(it) }
    }

    private fun syncDock() {
        dock.iconSize = iconSizePx
        dock.showLabels = prefs.dockLabels
        val entries = model.dock.mapNotNull { apps[it] }
        dock.bind(entries) { e ->
            createAppIcon(e, IconView.SOURCE_DOCK).also { if (e.key in revealDockKeys) it.alpha = 0f }
        }
        dock.requestLayout()
        homeLayout.requestLayout()
    }

    fun syncFolderIcon(item: HomeItem) {
        (findFolderIconView(item))?.let { refreshItemView(it, item) }
    }

    fun findFolderIconView(item: HomeItem): View? = workspace.pages.getOrNull(model.pageOf(item))?.childFor(item)

    private fun forEachHomeView(block: (View) -> Unit) {
        workspace.pages.forEach { cl -> cl.childList().forEach { v -> block(v); if (v is StackFrame) v.cardViews().forEach(block) } }
    }

    // ---- Widget stacks -------------------------------------------------------------------------------------

    private val saveModelRunnable = Runnable { model.save() }
    fun saveModelSoon() { main.removeCallbacks(saveModelRunnable); main.postDelayed(saveModelRunnable, 800) }

    private fun createStackView(item: HomeItem): View = StackFrame(this).also { frame ->
        frame.item = item
        frame.onLongPress = { onItemLongPress(it) }
        frame.setCards(item.children.map { createStackChild(it) ?: View(this) }, item.stackIndex)
    }

    /** One widget inside a stack. Its own long press is ignored: the stack handles it. */
    private fun createStackChild(child: HomeItem): View? = when (child.type) {
        HomeItem.WIDGET -> createWidgetView(child)?.also { (it as? FluidWidgetHostView)?.onLongPress = null }
        HomeItem.BUILTIN -> WidgetFrame(this).also { frame ->
            frame.item = child
            val lp = if (child.builtin == Builtins.SEARCH) flp(MATCH, dpi(58), Gravity.CENTER_VERTICAL) else flp(MATCH, MATCH)
            frame.addView(Builtins.create(this, child), lp)
            val pad = dpi(6)
            frame.setPadding(pad, pad, pad, pad)
        }
        else -> null
    }

    fun widgetTitle(item: HomeItem): String = when (item.type) {
        HomeItem.STACK -> "Widget stack"
        HomeItem.BUILTIN -> Builtins.name(item.builtin)
        else -> (try { widgetManager.getAppWidgetInfo(item.widgetId)?.loadLabel(packageManager) } catch (_: Exception) { null }) ?: "Widget"
    }

    /** Frees a widget's system id (and those of every widget in a stack) and forgets its saved look. */
    fun deleteWidgetsOf(item: HomeItem) {
        if (item.type == HomeItem.WIDGET) deleteWidgetId(item.widgetId)
        if (item.type == HomeItem.BUILTIN) { prefs.clearWidgetData(item.id); try { widgetPhotoFile(item.id).delete() } catch (_: Exception) { } }
        item.children.forEach { deleteWidgetsOf(it) }
    }

    /** Opens the widget list to add one to [target] (a stack, or a widget that becomes one). */
    fun pickWidgetForStack(target: HomeItem) {
        if (prefs.lockLayout) { toast("The layout is locked"); return }
        WidgetsSheet(this, target).show()
    }

    /** New stack with a few Fluid One widgets in it, placed like any other widget. */
    fun addStack() {
        val cols = prefs.columns
        val sx = cols; val sy = 2
        pendingWidgetPage = workspace.currentPage
        val stack = HomeItem(model.newId(), HomeItem.STACK, 0, 0, sx, sy.coerceAtMost(prefs.rows))
        listOf(Builtins.CLOCK, Builtins.CALENDAR, Builtins.OUTSIDE).forEach { b ->
            val c = HomeItem(model.newId(), HomeItem.BUILTIN, 0, 0, sx, sy, builtin = b)
            prefs.clearWidgetData(c.id)
            stack.children.add(c)
        }
        placeNewItem(stack) {}
    }

    /** Adds [child] on top of [target]; a plain widget turns into a stack holding both. */
    fun addToStack(target: HomeItem, child: HomeItem) {
        val stack = if (target.type == HomeItem.STACK) target else {
            val page = model.pages.firstOrNull { p -> p.any { it === target } } ?: return
            val s = HomeItem(model.newId(), HomeItem.STACK, target.x, target.y, target.spanX, target.spanY)
            s.children.add(target)
            page[page.indexOf(target)] = s
            s
        }
        child.spanX = stack.spanX; child.spanY = stack.spanY
        stack.children.add(child)
        stack.stackIndex = stack.children.size - 1
        model.save()
        syncAll()
        val page = model.pageOf(stack)
        if (page >= 0) {
            workspace.snapTo(page)
            workspace.pages.getOrNull(page)?.childFor(stack)?.let { v ->
                v.scaleX = 0.9f; v.scaleY = 0.9f; v.alpha = 0.4f
                val spring = Spring(0.7f, 0.4f)
                v.animate().scaleX(1f).scaleY(1f).alpha(1f).setDuration(spring.ms).setInterpolator(spring).start()
            }
        }
        haptic(rootView, HapticFeedbackConstants.CONFIRM)
    }

    fun removeFromStack(stack: HomeItem, child: HomeItem) {
        stack.children.remove(child)
        deleteWidgetsOf(child)
        val page = model.pages.firstOrNull { p -> p.any { it === stack } }
        when {
            stack.children.isEmpty() -> model.removeItem(stack)
            stack.children.size == 1 && page != null -> {
                // One widget left: it stops being a stack.
                val only = stack.children[0]
                only.x = stack.x; only.y = stack.y; only.spanX = stack.spanX; only.spanY = stack.spanY
                page[page.indexOf(stack)] = only
            }
        }
        stack.stackIndex = stack.stackIndex.coerceIn(0, (stack.children.size - 1).coerceAtLeast(0))
        model.save()
        syncAll()
    }

    /** Brings the stack's chosen widget to the front (after the stack sheet changed it). */
    fun refreshStack(stack: HomeItem) {
        workspace.pages.forEach { cl -> cl.childList().forEach { v -> if (v is StackFrame && v.item === stack) v.showIndex(stack.stackIndex) } }
        saveModelSoon()
    }

    // ---- Workspace callbacks -------------------------------------------------------------------------------

    private val restorePill = Runnable {
        if (!prefs.searchBar) return@Runnable
        indicator.animate().alpha(0f).setDuration(Motion.d(220)).start()
        searchPill.animate().alpha(1f).setDuration(Motion.d(260)).start()
    }

    private fun onWorkspaceScroll(pos: Float) {
        indicator.position = pos
        val n = workspace.pageCount
        wallpaperView.parallaxFraction = if (n > 1) (pos / (n - 1)).coerceIn(0f, 1f) else 0.5f
        if (prefs.searchBar && !isEditing && n > 1) {
            main.removeCallbacks(restorePill)
            if (indicator.alpha < 1f) indicator.alpha = min(1f, indicator.alpha + 0.2f)
            searchPill.alpha = 1f - indicator.alpha
        }
    }

    private fun onWorkspaceSettled() {
        main.removeCallbacks(restorePill)
        main.postDelayed(restorePill, 700)
        workspace.refreshHeaders()
    }

    fun canPageWorkspace(): Boolean = !drag.isDragging && overlays.isEmpty() && !isDrawerOpen && !animator.isBusy

    fun onWorkspaceDragStart() { drag.disarm() }

    fun workspacePageCount() = model.pages.size

    // ---- Drawer --------------------------------------------------------------------------------------------

    fun openDrawer(focusSearch: Boolean = false) {
        if (isEditing) return
        drawer.animateTo(true, focusSearch = focusSearch)
    }

    fun setDrawerOpen(open: Boolean) {
        drawer.animateTo(open)
    }

    fun onDrawerProgress(p: Float) {
        val s = 1f - 0.07f * p
        homeLayout.scaleX = s; homeLayout.scaleY = s
        homeLayout.pivotX = homeLayout.width / 2f
        homeLayout.pivotY = homeLayout.height * 0.6f
        homeLayout.alpha = 1f - clamp01(p * 1.3f)
        if (p > 0.001f) backdrop.set(drawer, p, p * 0.22f, blurContent = false) else backdrop.clear(drawer)
        updateSystemBars()
    }

    fun showIndexBubble(letter: String?, rawY: Float) {
        if (letter == null) { indexBubble.animate().alpha(0f).scaleX(0.6f).scaleY(0.6f).setDuration(160).withEndAction { indexBubble.visibility = View.INVISIBLE }.start(); return }
        indexBubble.text = letter
        indexBubble.background = oval(prefs.accent); indexBubble.setTextColor(inkOn(prefs.accent))
        val loc = IntArray(2); rootView.getLocationOnScreen(loc)
        indexBubble.translationX = rootView.width - dpi(120f).toFloat()
        indexBubble.translationY = rawY - loc[1] - dpi(34)
        if (indexBubble.visibility != View.VISIBLE) {
            indexBubble.visibility = View.VISIBLE
            indexBubble.alpha = 0f; indexBubble.scaleX = 0.6f; indexBubble.scaleY = 0.6f
            indexBubble.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(160).setInterpolator(Motion.decel).start()
        }
    }

    // ---- Edit mode -----------------------------------------------------------------------------------------

    fun enterEditMode() {
        if (isEditing) return
        if (isDrawerOpen) setDrawerOpen(false)
        closeAllOverlays(true)
        drag.disarm()
        isEditing = true
        workspace.refreshHeaders()
        haptic(rootView, HapticFeedbackConstants.LONG_PRESS)
        animateEdit(1f)
        updateSystemBars()
    }

    fun exitEditMode(animate: Boolean = true) {
        if (!isEditing) return
        isEditing = false
        if (workspace.currentPage >= model.pages.size) workspace.snapTo(model.pages.size - 1)
        removeEmptyPages()
        if (animate) animateEdit(0f) else { editAnim?.cancel(); applyEdit(0f) }
        updateSystemBars()
    }

    private fun animateEdit(target: Float) {
        editAnim?.cancel()
        val spring = if (target > 0f) Spring(0.84f, 0.42f) else Spring(0.92f, 0.36f)
        editAnim = android.animation.ValueAnimator.ofFloat(editProgress, target).apply {
            duration = spring.ms
            interpolator = spring
            addUpdateListener { applyEdit(it.animatedValue as Float) }
            start()
        }
    }

    private fun applyEdit(p: Float) {
        editProgress = p
        workspace.editProgress = p.coerceAtLeast(0f)
        val c = clamp01(p)
        editBar.visibility = if (c > 0.01f) View.VISIBLE else View.INVISIBLE
        editDone.visibility = editBar.visibility
        editBar.alpha = c
        editBar.translationY = (1f - c) * dp(60f)
        editDone.alpha = c
        editDone.translationY = (1f - c) * -dp(20f)
        dock.alpha = 1f - c
        dock.translationY = c * dp(80f)
        pillRow.alpha = 1f - c
        if (c > 0.001f) backdrop.set(workspace, c * 0.85f, c * 0.18f, blurContent = false) else backdrop.clear(workspace)
    }

    private fun removeEmptyPages() {
        if (model.pages.size <= 1) return
        val before = model.pages.size
        val keepIndex = workspace.currentPage
        val emptyIdx = model.pages.indices.filter { model.pages[it].isEmpty() }
        if (emptyIdx.isEmpty()) return
        for (i in emptyIdx.sortedDescending()) if (model.pages.size > 1) model.pages.removeAt(i)
        val removedBefore = emptyIdx.count { it < keepIndex }
        if (prefs.defaultPage >= model.pages.size) prefs.defaultPage = model.pages.size - 1
        model.save()
        if (before != model.pages.size) {
            syncAll()
            workspace.snapTo((keepIndex - removedBefore).coerceIn(0, model.pages.size - 1), animate = false)
        }
    }

    fun addPageFromEditMode() {
        if (model.pages.size >= LauncherModel.MAX_PAGES) { toast("You can have up to ${LauncherModel.MAX_PAGES} pages"); return }
        model.pages.add(mutableListOf())
        model.save()
        syncAll()
        haptic(rootView, HapticFeedbackConstants.CONFIRM)
        workspace.snapTo(model.pages.size - 1)
    }

    fun addEmptyPage() {
        if (model.pages.size >= LauncherModel.MAX_PAGES) return
        model.pages.add(mutableListOf())
        syncAll()
    }

    fun canAddPageDuringDrag(dragged: HomeItem?): Boolean =
        model.pages.size < LauncherModel.MAX_PAGES && model.pages.last().any { it !== dragged }

    fun setDefaultPage(index: Int) {
        prefs.defaultPage = index
        workspace.refreshHeaders()
        toast("Page ${index + 1} is now the main page")
    }

    fun requestDeletePage(index: Int) {
        if (model.pages.size <= 1) { toast("You need at least one page"); return }
        val page = model.pages.getOrNull(index) ?: return
        if (page.isEmpty()) { deletePage(index); return }
        FluidDialog(this, "Delete this page?", "Apps on this page are removed from the home screen but stay installed. Widgets on it are removed.", "Delete", destructive = true) {
            deletePage(index)
        }.show()
    }

    private fun deletePage(index: Int) {
        val page = model.pages.getOrNull(index) ?: return
        val cl = workspace.pages.getOrNull(index)
        val doDelete = {
            page.forEach { deleteWidgetsOf(it) }
            model.pages.removeAt(index)
            if (prefs.defaultPage >= model.pages.size || prefs.defaultPage == index) prefs.defaultPage = 0
            else if (prefs.defaultPage > index) prefs.defaultPage = prefs.defaultPage - 1
            model.save()
            syncAll()
            workspace.snapTo(min(index, model.pages.size - 1))
        }
        haptic(rootView, HapticFeedbackConstants.CONFIRM)
        if (cl != null) cl.animate().alpha(0f).scaleX(cl.scaleX * 0.85f).scaleY(cl.scaleY * 0.85f).setDuration(Motion.d(200)).withEndAction {
            cl.alpha = 1f
            doDelete()
        }.start() else doDelete()
    }

    // ---- Overlays ------------------------------------------------------------------------------------------

    fun showOverlay(o: Overlay) {
        overlays.add(o)
        overlayLayer.addView(o.root, flp(MATCH, MATCH))
        updateSystemBars()
    }

    fun onOverlayClosed(o: Overlay) {
        overlays.remove(o)
        updateSystemBars()
    }

    fun closeAllOverlays(animate: Boolean) {
        val closing = overlays.filter { !it.sticky }
        closing.forEach { it.close(animate) }
        if (!animate) {
            closing.forEach { o -> overlays.remove(o) }
            for (i in overlayLayer.childCount - 1 downTo 0) {
                val child = overlayLayer.getChildAt(i)
                if (overlays.none { it.root === child }) overlayLayer.removeViewAt(i)
            }
            // Sticky overlays (the welcome) never use the backdrop, so every blur and dim can go.
            backdrop.clearAll()
            updateSystemBars()
            if (isDrawerOpen) onDrawerProgress(drawer.progress)
            if (isEditing) applyEdit(editProgress)
        }
    }

    fun openSettings() {
        if (overlays.any { it is SettingsPanel }) return
        drawer.hideKeyboard()
        SettingsPanel(this).show()
    }

    /** Opens one Fluid One settings page (used by search). */
    fun openSettingsPage(page: String) {
        drawer.hideKeyboard()
        when (page) {
            "edit" -> enterEditMode()
            "widgets" -> { enterEditMode(); rootView.postDelayed({ if (isEditing) WidgetsSheet(this).show() }, 420) }
            "main" -> openSettings()
            else -> {
                overlays.filterIsInstance<SettingsPanel>().forEach { it.close(false) }
                SettingsPanel(this, page).show()
            }
        }
    }

    // ---- Long press menus ----------------------------------------------------------------------------------

    fun onItemLongPress(view: View) {
        if (drag.isDragging || animator.isBusy) return
        overlays.filterIsInstance<ItemPopup>().forEach { it.close(false) }
        val x = rootView.lastX
        val y = rootView.lastY
        when (view) {
            is FolderIconView -> folderMenu(view, x, y)
            is IconView -> appMenu(view, x, y)
            is FluidWidgetHostView -> widgetMenu(view, view.item, x, y)
            is WidgetFrame -> widgetMenu(view, view.item, x, y)
            is StackFrame -> widgetMenu(view, view.item, x, y)
        }
    }

    private fun anchorRect(v: View): RectF {
        if (v is IconView) return v.iconRectInWindow()
        val r = RectF(0f, 0f, v.width.toFloat(), v.height.toFloat())
        val m = Matrix(); v.transformMatrixToGlobal(m); m.mapRect(r)
        return r
    }

    private fun appMenu(v: IconView, x: Float, y: Float) {
        val entry = v.entry ?: return
        val actions = mutableListOf<PopupAction>()
        val locked = prefs.lockLayout
        when (v.source) {
            IconView.SOURCE_DRAWER -> {
                if (!model.isOnHome(entry.key)) actions += PopupAction(R.drawable.ic_home, "Add to home") { addToHome(entry) }
                actions += PopupAction(R.drawable.ic_edit, "Edit") { IconEditorSheet(this, entry).show() }
                actions += PopupAction(R.drawable.ic_hide, "Hide") { hideApp(entry) }
            }
            IconView.SOURCE_FOLDER -> {
                if (!locked) actions += PopupAction(R.drawable.ic_remove, "Move out") { moveOutOfFolder(v) }
                actions += PopupAction(R.drawable.ic_edit, "Edit") { IconEditorSheet(this, entry).show() }
            }
            else -> {
                actions += PopupAction(R.drawable.ic_edit, "Edit") { IconEditorSheet(this, entry).show() }
                if (!locked) actions += PopupAction(R.drawable.ic_remove, "Remove") { removeIcon(v) }
            }
        }
        if (!entry.isSystemApp) actions += PopupAction(R.drawable.ic_delete, "Uninstall", danger = true) { uninstall(entry) }
        actions += PopupAction(R.drawable.ic_info, "App info") { appInfo(entry, v) }
        val popup = ItemPopup(this, v, anchorRect(v), v.bitmap?.let { icons.forDisplay(it) }, apps.label(entry), shortcutsFor(entry), actions)
        popup.show()
        val src = when (v.source) {
            IconView.SOURCE_DOCK -> DragSource(HomeItem.APP, IconView.SOURCE_DOCK, v, appKey = entry.key, dockIndex = model.dock.indexOf(entry.key))
            IconView.SOURCE_DRAWER -> DragSource(HomeItem.APP, IconView.SOURCE_DRAWER, v, appKey = entry.key)
            IconView.SOURCE_FOLDER -> DragSource(HomeItem.APP, IconView.SOURCE_FOLDER, v, appKey = entry.key, folder = v.folder)
            else -> DragSource(HomeItem.APP, IconView.SOURCE_WORKSPACE, v, item = v.item, appKey = entry.key)
        }
        drag.arm(src, x, y, popup)
    }

    private fun folderMenu(v: FolderIconView, x: Float, y: Float) {
        val item = v.item ?: return
        val actions = mutableListOf(
            PopupAction(R.drawable.ic_edit, "Rename") {
                FluidDialog(this, "Rename folder", null, "Save", inputInitial = item.title.ifEmpty { "Folder" }) { name ->
                    item.title = name.trim().ifEmpty { "Folder" }; model.save(); syncFolderIcon(item)
                }.show()
            }
        )
        if (!prefs.lockLayout) {
            actions += PopupAction(R.drawable.ic_resize, if (item.isLargeFolder) "Small" else "Large") { toggleFolderSize(item) }
            actions += PopupAction(R.drawable.ic_apps, "Ungroup") { dissolveFolder(item) }
            actions += PopupAction(R.drawable.ic_remove, "Remove", danger = true) {
                FluidDialog(this, "Remove folder?", "The apps stay installed and remain in the app drawer.", "Remove", destructive = true) {
                    model.removeItem(item); model.save(); syncAll()
                }.show()
            }
        }
        val popup = ItemPopup(this, v, anchorRect(v), null, item.title.ifEmpty { "Folder" }, emptyList(), actions)
        popup.show()
        drag.arm(DragSource(HomeItem.FOLDER, IconView.SOURCE_WORKSPACE, v, item = item), x, y, popup)
    }

    private fun widgetMenu(v: View, item: HomeItem?, x: Float, y: Float) {
        item ?: return
        val actions = mutableListOf<PopupAction>()
        val sizes = sizeOptions(item)
        var popupRef: ItemPopup? = null
        val extra = if (sizes.size > 1 && !prefs.lockLayout) {
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER; setPadding(dpi(12), dpi(10), dpi(12), dpi(4)) }
            sizes.forEach { (sx, sy) ->
                val selected = sx == item.spanX && sy == item.spanY
                row.addView(textView("$sx×$sy", 13f, if (selected) ui.onAccent else ui.text, Fonts.medium, Gravity.CENTER).apply {
                    background = roundRect(if (selected) ui.accent else ui.chip, dp(16f))
                    isClickable = true
                    setOnClickListener { popupRef?.close(); resizeItem(item, sx, sy) }
                }, llp(0, dpi(34), 1f).apply { marginStart = dpi(3); marginEnd = dpi(3) })
            }
            row
        } else null
        if (item.type == HomeItem.WIDGET) {
            val info = widgetManager.getAppWidgetInfo(item.widgetId)
            if (info != null && (info.widgetFeatures and AppWidgetProviderInfo.WIDGET_FEATURE_RECONFIGURABLE) != 0 && info.configure != null) {
                actions += PopupAction(R.drawable.ic_tune, "Settings") {
                    try { widgetHost.startAppWidgetConfigureActivityForResult(this, item.widgetId, 0, REQ_RECONFIGURE, null) } catch (_: Exception) { toast("This widget can't be configured") }
                }
            }
        }
        if (item.type == HomeItem.BUILTIN) actions += PopupAction(R.drawable.ic_tune, "Edit") { WidgetStyleSheet(this, item).show() }
        if (item.type == HomeItem.STACK) {
            val front = item.children.getOrNull(item.stackIndex)
            if (front?.type == HomeItem.BUILTIN) actions += PopupAction(R.drawable.ic_tune, "Edit ${Builtins.name(front.builtin).lowercase()}") { WidgetStyleSheet(this, front).show() }
            actions += PopupAction(R.drawable.ic_stack, "Edit stack") { StackEditSheet(this, item).show() }
            if (!prefs.lockLayout) actions += PopupAction(R.drawable.ic_plus, "Add a widget") { pickWidgetForStack(item) }
        } else if (!prefs.lockLayout) actions += PopupAction(R.drawable.ic_stack, "Stack another widget") { pickWidgetForStack(item) }
        if (!prefs.lockLayout) actions += PopupAction(R.drawable.ic_remove, "Remove", danger = true) { removeItemAnimated(item, v) }
        val title = widgetTitle(item)
        val popup = ItemPopup(this, v, anchorRect(v), null, title, emptyList(), actions, extra)
        popupRef = popup
        popup.show()
        drag.arm(DragSource(item.type, IconView.SOURCE_WORKSPACE, v, item = item), x, y, popup)
    }

    private fun sizeOptions(item: HomeItem): List<Pair<Int, Int>> {
        val cols = prefs.columns
        val rows = prefs.rows
        if (item.type == HomeItem.BUILTIN) return Builtins.sizes(item.builtin, cols, rows)
        if (item.type == HomeItem.STACK) return listOf(2 to 2, cols to 2, cols to 3, 2 to 3).map { (x, y) -> x.coerceAtMost(cols) to y.coerceAtMost(rows) }.distinct()
        val info = widgetManager.getAppWidgetInfo(item.widgetId) ?: return emptyList()
        val (minX, minY) = widgetSpan(info, useMin = true)
        val canH = info.resizeMode and AppWidgetProviderInfo.RESIZE_HORIZONTAL != 0
        val canV = info.resizeMode and AppWidgetProviderInfo.RESIZE_VERTICAL != 0
        val out = linkedSetOf(item.spanX to item.spanY)
        val xs = if (canH) listOf(minX, 2, cols).filter { it in minX..cols } else listOf(item.spanX)
        val ys = if (canV) listOf(minY, 2, 3, 4).filter { it in minY..rows } else listOf(item.spanY)
        for (x in xs) for (y in ys) out.add(x to y)
        return out.sortedWith(Comparator { a, b ->
            val area = a.first * a.second - b.first * b.second
            if (area != 0) area else a.first - b.first
        }).take(5)
    }

    private fun resizeItem(item: HomeItem, sx: Int, sy: Int) {
        val page = model.pageOf(item)
        if (page < 0) return
        val cols = prefs.columns; val rows = prefs.rows
        val x = item.x.coerceAtMost(cols - sx)
        val y = item.y.coerceAtMost(rows - sy)
        val spot = if (model.isRegionFree(page, x, y, sx, sy, cols, rows, item)) android.graphics.Point(x, y)
                   else model.findNearestVacant(page, x, y, sx, sy, cols, rows, item)
        if (spot == null) { toast("Not enough space on this page"); return }
        item.x = spot.x; item.y = spot.y; item.spanX = sx; item.spanY = sy
        item.children.forEach { it.spanX = sx; it.spanY = sy }
        model.save()
        syncAll()
        workspace.pages[page].childFor(item)?.let { v ->
            v.scaleX = 0.92f; v.scaleY = 0.92f
            val spring = Spring(0.7f, 0.36f)
            v.animate().scaleX(1f).scaleY(1f).setDuration(spring.ms).setInterpolator(spring).start()
        }
    }

    private fun toggleFolderSize(item: HomeItem) {
        val page = model.pageOf(item)
        val cols = prefs.columns; val rows = prefs.rows
        if (item.isLargeFolder) {
            item.spanX = 1; item.spanY = 1
        } else {
            val spot = model.findNearestVacant(page, item.x, item.y, 2, 2, cols, rows, item)
                ?: run { toast("Make room for a 2 × 2 folder first"); return }
            item.x = spot.x; item.y = spot.y; item.spanX = 2; item.spanY = 2
        }
        model.save()
        syncAll()
    }

    private fun dissolveFolder(item: HomeItem) {
        val page = model.pageOf(item)
        if (page < 0) return
        val cols = prefs.columns; val rows = prefs.rows
        val keys = item.apps.toList()
        model.removeItem(item)
        val first = HomeItem(model.newId(), HomeItem.APP, item.x, item.y, appKey = keys.first())
        model.pages[page].add(first)
        keys.drop(1).forEach { k -> model.place(HomeItem(model.newId(), HomeItem.APP, appKey = k), cols, rows, page) }
        model.save()
        syncAll()
    }

    private fun moveOutOfFolder(v: IconView) {
        val folder = v.folder ?: return
        val key = v.entry?.key ?: return
        val page = model.pageOf(folder).coerceAtLeast(0)
        folder.apps.remove(key)
        model.normalizeFolders()
        model.place(HomeItem(model.newId(), HomeItem.APP, appKey = key), prefs.columns, prefs.rows, page)
        model.save()
        syncAll()
        openFolder?.refreshAfterChange()
    }

    private fun removeIcon(v: IconView) {
        val entry = v.entry ?: return
        if (v.source == IconView.SOURCE_DOCK) {
            model.dock.remove(entry.key); model.save()
            v.animate().alpha(0f).scaleX(0.6f).scaleY(0.6f).setDuration(Motion.d(180)).withEndAction { syncAll() }.start()
        } else v.item?.let { removeItemAnimated(it, v) }
    }

    private fun removeItemAnimated(item: HomeItem, v: View) {
        v.animate().alpha(0f).scaleX(0.6f).scaleY(0.6f).setDuration(Motion.d(180)).setInterpolator(Motion.accel).withEndAction {
            deleteWidgetsOf(item)
            model.removeItem(item)
            model.save()
            v.alpha = 1f; v.scaleX = 1f; v.scaleY = 1f
            syncAll()
        }.start()
    }

    private fun addToHome(entry: AppEntry) {
        val page = workspace.currentPage
        val item = HomeItem(model.newId(), HomeItem.APP, appKey = entry.key)
        val placed = model.place(item, prefs.columns, prefs.rows, page)
        if (placed < 0) { toast("No room left on the home screen"); return }
        model.save()
        syncAll()
        toast("Added to page ${placed + 1}")
    }

    private fun hideApp(entry: AppEntry) {
        prefs.hiddenApps = prefs.hiddenApps + entry.key
        drawer.reload()
        toast("${apps.label(entry)} hidden · Settings › App drawer to show it again")
    }

    private fun onFolderTap(v: FolderIconView, x: Float, y: Float) {
        val item = v.item ?: return
        val idx = v.appIndexAt(x, y)
        if (idx >= 0) {
            val entry = apps[item.apps[idx]] ?: return
            launchFromRect(entry, v.previewRectInWindow(idx), IconView.SOURCE_WORKSPACE, null, -1L)
            return
        }
        haptic(v, HapticFeedbackConstants.CONTEXT_CLICK)
        FolderOverlay(this, item, v).show()
    }

    // ---- Shortcuts, launching, app actions ----------------------------------------------------------------

    private fun shortcutsFor(entry: AppEntry): List<ShortcutInfo> = try {
        if (!launcherApps.hasShortcutHostPermission()) emptyList() else {
            val q = LauncherApps.ShortcutQuery().setPackage(entry.packageName).setActivity(entry.component)
                .setQueryFlags(LauncherApps.ShortcutQuery.FLAG_MATCH_DYNAMIC or LauncherApps.ShortcutQuery.FLAG_MATCH_MANIFEST)
            (launcherApps.getShortcuts(q, entry.user) ?: emptyList())
                .filter { it.isEnabled }
                .sortedWith(Comparator { a, b ->
                    if (a.isDeclaredInManifest != b.isDeclaredInManifest) (if (a.isDeclaredInManifest) -1 else 1) else a.rank - b.rank
                })
                .take(4)
        }
    } catch (_: Exception) { emptyList() }

    fun loadShortcutIcon(si: ShortcutInfo, target: ImageView) {
        val density = resources.displayMetrics.densityDpi
        thumbs.execute {
            val d = try { launcherApps.getShortcutIconDrawable(si, density) } catch (_: Exception) { null }
            val bmp = d?.let { icons.shapeIcon(it, dpi(26)) }
            main.post { if (bmp != null) target.setImageBitmap(bmp) }
        }
    }

    /** Every app shortcut on the phone (needs Fluid One to be the default home app). Safe off the UI thread. */
    fun allShortcuts(): List<ShortcutInfo> = try {
        if (!launcherApps.hasShortcutHostPermission()) emptyList() else {
            val q = LauncherApps.ShortcutQuery().setQueryFlags(LauncherApps.ShortcutQuery.FLAG_MATCH_DYNAMIC or LauncherApps.ShortcutQuery.FLAG_MATCH_MANIFEST)
            launcherApps.profiles.flatMap { launcherApps.getShortcuts(q, it) ?: emptyList() }.filter { it.isEnabled }
        }
    } catch (_: Exception) { emptyList() }

    fun shortcutIcon(si: ShortcutInfo, size: Int): Bitmap? = try {
        launcherApps.getShortcutIconDrawable(si, resources.displayMetrics.densityDpi)?.let { icons.shapeIcon(it, size) }
    } catch (_: Exception) { null }

    fun launchShortcut(si: ShortcutInfo, rect: RectF) {
        try {
            launcherApps.startShortcut(si, Rect(rect.left.roundToInt(), rect.top.roundToInt(), rect.right.roundToInt(), rect.bottom.roundToInt()), null)
        } catch (_: Exception) { toast("Couldn't open this shortcut") }
    }

    fun launchApp(entry: AppEntry, view: IconView?, source: Int) {
        if (isEditing && (source == IconView.SOURCE_WORKSPACE || source == IconView.SOURCE_DOCK)) {
            IconEditorSheet(this, entry).show(); return
        }
        launchFromRect(entry, view?.iconRectInWindow(), source, view, view?.folder?.id ?: -1L)
    }

    private fun launchFromRect(entry: AppEntry, rect: RectF?, source: Int, view: View?, folderId: Long) {
        if (animator.isBusy) return
        if (iconLanding.isActive) iconLanding.finish(landed = false)
        haptic(view ?: rootView, HapticFeedbackConstants.CONTEXT_CLICK)
        prefs.recordLaunch(entry.key)
        if (source == IconView.SOURCE_DRAWER) drawer.onAppLaunched(apps.label(entry))
        drawer.hideKeyboard()
        val style = effectiveLaunchStyle()
        // Fluid One's own opening needs a plain intent (for FLAG_ACTIVITY_NO_ANIMATION), which only works for apps
        // of this user; work-profile apps use the system's animation.
        val fluid = style == "fluid" && rect != null && prefs.launchAnimations && entry.user == android.os.Process.myUserHandle()
        animator.beginLaunch(entry, rect, source, view, folderId, fluid) { startEntry(entry, rect, fluid) }
    }

    /** Starts [entry]. Returns false if it couldn't be opened (a message has been shown). */
    private fun startEntry(entry: AppEntry, rect: RectF?, fluid: Boolean): Boolean {
        val bounds = rect?.let { Rect(it.left.roundToInt(), it.top.roundToInt(), it.right.roundToInt(), it.bottom.roundToInt()) }
        if (fluid) {
            val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER).setComponent(entry.component)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED or Intent.FLAG_ACTIVITY_NO_ANIMATION)
            intent.sourceBounds = bounds
            val opts = ActivityOptions.makeBasic()
            if (Build.VERSION.SDK_INT >= 33) opts.setSplashScreenStyle(android.window.SplashScreen.SPLASH_SCREEN_STYLE_ICON)
            try { startActivity(intent, opts.toBundle()); return true } catch (_: Exception) { }
        }
        val opts = launchOptions(rect)
        try {
            launcherApps.startMainActivity(entry.component, entry.user, bounds, opts?.toBundle())
            return true
        } catch (_: Exception) {
            try {
                val intent = packageManager.getLaunchIntentForPackage(entry.packageName)?.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                if (intent != null && entry.user == android.os.Process.myUserHandle()) { startActivity(intent, opts?.toBundle()); return true }
            } catch (_: Exception) { }
        }
        toast("Couldn't open ${apps.label(entry)}")
        return false
    }

    /**
     * How the app window opens. Since Android 13, launchers that aren't the system's own can't use custom window
     * animations for apps, but the system still honours "scale up from" and "reveal from" a rectangle. So the
     * app window really grows out of the icon, and it never waits for the launcher.
     */
    private fun launchOptions(rect: RectF?): ActivityOptions? {
        if (!prefs.launchAnimations) return null
        val r = rect?.let { android.graphics.Rect(it.left.roundToInt(), it.top.roundToInt(), it.right.roundToInt(), it.bottom.roundToInt()) }
        return when (effectiveLaunchStyle()) {
            "reveal" -> if (r != null) ActivityOptions.makeClipRevealAnimation(rootView, r.left, r.top, r.width(), r.height()) else null
            "system" -> null
            else -> if (r != null) ActivityOptions.makeScaleUpAnimation(rootView, r.left, r.top, r.width(), r.height()) else null
        }
    }

    /** Where a returning app should shrink back to: (view to hide/ripple, window rect). */
    fun findLaunchTarget(key: String, source: Int, folderId: Long): Pair<View?, RectF>? {
        outsideOverlay()?.let { o -> return o.iconFor(key)?.let { it to it.iconRectInWindow() } }
        if (source == IconView.SOURCE_DRAWER && isDrawerOpen) drawer.iconFor(key)?.let { return it to it.iconRectInWindow() }
        val fo = openFolder
        if (source == IconView.SOURCE_FOLDER && fo != null && fo.item.id == folderId) fo.iconFor(key)?.let { return it to it.iconRectInWindow() }
        if (source == IconView.SOURCE_DOCK) dock.iconFor(key)?.let { return it to it.iconRectInWindow() }
        val cl = workspace.pages.getOrNull(workspace.currentPage)
        if (cl != null) {
            for (child in cl.childList()) {
                if (child is FolderIconView) {
                    val item = child.item ?: continue
                    val idx = item.apps.indexOf(key)
                    if (idx < 0) continue
                    return if (child.isLarge && idx < 8) null to child.previewRectInWindow(idx) else child to child.iconRectInWindow()
                }
                if (child is IconView && child.entry?.key == key) return child to child.iconRectInWindow()
            }
        }
        dock.iconFor(key)?.let { return it to it.iconRectInWindow() }
        return null
    }

    fun entranceViews(): List<Pair<View, RectF>> {
        val out = mutableListOf<Pair<View, RectF>>()
        fun add(v: View) {
            if (v.visibility != View.VISIBLE || v.width == 0) return
            val r = RectF(0f, 0f, v.width.toFloat(), v.height.toFloat())
            val m = Matrix(); v.transformMatrixToGlobal(m); m.mapRect(r)
            out += v to r
        }
        workspace.pages.getOrNull(workspace.currentPage)?.childList()?.forEach { add(it) }
        dock.icons.forEach { add(it) }
        if (dock.plate.visibility == View.VISIBLE) add(dock.plate)
        add(pillRow)
        return out
    }

    fun uninstall(entry: AppEntry) {
        val intent = Intent(Intent.ACTION_DELETE, Uri.fromParts("package", entry.packageName, null))
            .putExtra(Intent.EXTRA_USER, entry.user)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try { startActivity(intent) } catch (_: Exception) { toast("This app can't be uninstalled") }
    }

    private fun appInfo(entry: AppEntry, v: View) {
        val r = anchorRect(v)
        try {
            launcherApps.startAppDetailsActivity(entry.component, entry.user, Rect(r.left.roundToInt(), r.top.roundToInt(), r.right.roundToInt(), r.bottom.roundToInt()), null)
        } catch (_: Exception) { toast("App info isn't available") }
    }

    fun startSafely(intent: Intent, from: View?) {
        try {
            val opts = if (from != null && from.width > 0) ActivityOptions.makeScaleUpAnimation(from, 0, 0, from.width, from.height).toBundle() else null
            startActivity(intent, opts)
        } catch (_: Exception) { toast("No app can handle this") }
    }

    // ---- Widgets -------------------------------------------------------------------------------------------

    fun widgetProviders(): List<AppWidgetProviderInfo> = try {
        launcherApps.profiles.flatMap { widgetManager.getInstalledProvidersForProfile(it) ?: emptyList() }
    } catch (_: Exception) { emptyList() }

    fun widgetSpan(info: AppWidgetProviderInfo, useMin: Boolean = false): Pair<Int, Int> {
        val cols = prefs.columns; val rows = prefs.rows
        if (!useMin && info.targetCellWidth > 0 && info.targetCellHeight > 0) {
            return info.targetCellWidth.coerceIn(1, cols) to info.targetCellHeight.coerceIn(1, rows)
        }
        val cl = workspace.pages.firstOrNull()
        val cellW = cl?.cellW?.takeIf { it > 0 } ?: dp(90f)
        val cellH = cl?.cellH?.takeIf { it > 0 } ?: dp(100f)
        val w = if (useMin && info.minResizeWidth > 0) info.minResizeWidth else info.minWidth
        val h = if (useMin && info.minResizeHeight > 0) info.minResizeHeight else info.minHeight
        val sx = ceil((w + dp(8f)) / cellW).toInt().coerceIn(1, cols)
        val sy = ceil((h + dp(8f)) / cellH).toInt().coerceIn(1, rows)
        return sx to sy
    }

    /** Remembers the widget being added across activity recreation and process death. */
    private fun setPendingWidget(id: Int, awaitingConfig: Boolean = false) {
        pendingWidgetId = id
        prefs.sp.edit().putInt("pending_widget_id", id).putInt("pending_widget_page", pendingWidgetPage)
            .putBoolean("pending_widget_config", awaitingConfig).apply()
    }

    private fun restorePendingWidget() {
        if (pendingWidgetId < 0) pendingWidgetId = prefs.sp.getInt("pending_widget_id", -1)
        pendingWidgetPage = prefs.sp.getInt("pending_widget_page", pendingWidgetPage)
    }

    private fun clearPendingWidget() {
        pendingWidgetId = -1
        prefs.sp.edit().remove("pending_widget_id").remove("pending_widget_page").remove("pending_widget_config").remove("pending_widget_stack").apply()
    }

    private var stoppedSinceConfig = true

    /**
     * Some widgets' setup screens run in their own task, so Android reports "cancelled" the moment they
     * open. Those widgets are placed when you come back from the setup screen instead of being dropped.
     */
    private fun resumePendingWidget() {
        if (!prefs.sp.getBoolean("pending_widget_config", false)) return
        if (!stoppedSinceConfig) return
        restorePendingWidget()
        val id = pendingWidgetId
        prefs.sp.edit().putBoolean("pending_widget_config", false).apply()
        if (id < 0) return
        val bound = try { widgetManager.getAppWidgetInfo(id) } catch (_: Exception) { null }
        if (bound != null && model.pages.flatten().none { it.widgetId == id }) placeWidget(id) else clearPendingWidget()
    }

    /** Adds an app widget to the home screen, or to [stackTarget] when given. */
    fun addAppWidget(info: AppWidgetProviderInfo, stackTarget: HomeItem? = null) {
        val id = try { widgetHost.allocateAppWidgetId() } catch (_: Exception) { -1 }
        if (id < 0) { toast("Couldn't add this widget"); return }
        pendingWidgetPage = workspace.currentPage
        setPendingWidget(id)
        prefs.sp.edit().putLong("pending_widget_stack", stackTarget?.id ?: -1L).apply()
        val bound = try { widgetManager.bindAppWidgetIdIfAllowed(id, info.profile, info.provider, null) } catch (_: Exception) { false }
        if (bound) configureOrPlaceWidget(id)
        else {
            val intent = Intent(AppWidgetManager.ACTION_APPWIDGET_BIND)
                .putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, id)
                .putExtra(AppWidgetManager.EXTRA_APPWIDGET_PROVIDER, info.provider)
                .putExtra(AppWidgetManager.EXTRA_APPWIDGET_PROVIDER_PROFILE, info.profile)
            try { startActivityForResult(intent, REQ_BIND_WIDGET) } catch (_: Exception) { deleteWidgetId(id); toast("Widget permission screen unavailable") }
        }
    }

    private fun configureOrPlaceWidget(id: Int) {
        val info = widgetManager.getAppWidgetInfo(id) ?: run { deleteWidgetId(id); toast("This widget isn't available"); return }
        val optional = (info.widgetFeatures and AppWidgetProviderInfo.WIDGET_FEATURE_CONFIGURATION_OPTIONAL) != 0
        if (info.configure != null && !optional) {
            try {
                stoppedSinceConfig = false
                setPendingWidget(id)
                widgetHost.startAppWidgetConfigureActivityForResult(this, id, 0, REQ_CONFIG_WIDGET, null)
                return
            } catch (_: Exception) { }
        }
        placeWidget(id)
    }

    private fun placeWidget(id: Int) {
        val stackId = prefs.sp.getLong("pending_widget_stack", -1L)
        clearPendingWidget()
        val info = try { widgetManager.getAppWidgetInfo(id) } catch (_: Exception) { null }
        if (info == null) { deleteWidgetId(id); toast("This widget isn't available"); return }
        if (stackId >= 0) {
            val target = model.pages.flatten().firstOrNull { it.id == stackId }
            if (target != null && target.isWidgetLike) { addToStack(target, HomeItem(model.newId(), HomeItem.WIDGET, 0, 0, target.spanX, target.spanY, widgetId = id)); return }
        }
        val (sx, sy) = widgetSpan(info)
        placeNewItem(HomeItem(model.newId(), HomeItem.WIDGET, 0, 0, sx, sy, widgetId = id)) { deleteWidgetId(id) }
    }

    fun addBuiltinToStack(target: HomeItem, id: String) {
        val child = HomeItem(model.newId(), HomeItem.BUILTIN, 0, 0, target.spanX, target.spanY, builtin = id)
        prefs.clearWidgetData(child.id)
        widgetPhotoFile(child.id).delete()
        addToStack(target, child)
    }

    fun addBuiltin(id: String) {
        val (sx, sy) = Builtins.defaultSpan(id, prefs.columns)
        pendingWidgetPage = workspace.currentPage
        val item = HomeItem(model.newId(), HomeItem.BUILTIN, 0, 0, sx.coerceAtMost(prefs.columns), sy.coerceAtMost(prefs.rows), builtin = id)
        // Ids can be reused after a restart: never inherit an old widget's look, note or photo.
        prefs.clearWidgetData(item.id)
        widgetPhotoFile(item.id).delete()
        placeNewItem(item) {}
    }

    /** Shared flashlight control (search quick action and the Quick toggles widget). */
    val torch: Torch by lazy { Torch(this) }

    fun widgetPhotoFile(itemId: Long): File = File(File(filesDir, "widgets").apply { mkdirs() }, "photo_$itemId.jpg")

    private var pendingPhotoItem = -1L

    fun pickWidgetPhoto(item: HomeItem) {
        pendingPhotoItem = item.id
        prefs.sp.edit().putLong("pending_photo_item", item.id).apply()
        val intent = Intent(Intent.ACTION_GET_CONTENT).setType("image/*").addCategory(Intent.CATEGORY_OPENABLE)
        try { startActivityForResult(Intent.createChooser(intent, "Choose a photo"), REQ_WIDGET_PHOTO) } catch (_: Exception) { toast("No app can pick photos") }
    }

    /** Copies a picked photo into private storage, downscaled so the widget stays light. */
    private fun importWidgetPhoto(uri: Uri, itemId: Long) {
        io.execute {
            val ok = try {
                val src = android.graphics.ImageDecoder.createSource(contentResolver, uri)
                val bmp = android.graphics.ImageDecoder.decodeBitmap(src) { decoder, info, _ ->
                    decoder.allocator = android.graphics.ImageDecoder.ALLOCATOR_SOFTWARE
                    val s = (1280f / max(info.size.width, info.size.height)).coerceAtMost(1f)
                    decoder.setTargetSize(max(1, (info.size.width * s).roundToInt()), max(1, (info.size.height * s).roundToInt()))
                }
                java.io.FileOutputStream(widgetPhotoFile(itemId)).use { bmp.compress(Bitmap.CompressFormat.JPEG, 92, it) }
                true
            } catch (_: Exception) { false }
            main.post {
                if (!ok) toast("Couldn't read that photo")
                forEachHomeView { v -> if (v is WidgetFrame && v.item?.id == itemId) (v.content as? PhotoWidget)?.reload() }
            }
        }
    }

    private fun placeNewItem(item: HomeItem, onFail: () -> Unit) {
        val page = model.place(item, prefs.columns, prefs.rows, pendingWidgetPage.coerceIn(0, model.pages.size - 1))
        if (page < 0) { onFail(); toast("No room for this widget"); return }
        model.save()
        syncAll()
        workspace.snapTo(page)
        rootView.post {
            workspace.pages.getOrNull(page)?.childFor(item)?.let { v ->
                v.alpha = 0f; v.scaleX = 0.8f; v.scaleY = 0.8f
                val spring = Spring(0.72f, 0.4f)
                v.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(spring.ms).setInterpolator(spring).start()
            }
        }
        haptic(rootView, HapticFeedbackConstants.CONFIRM)
    }

    fun deleteWidgetId(id: Int) {
        if (id < 0) return
        try { widgetHost.deleteAppWidgetId(id) } catch (_: Exception) { }
    }

    fun requestCalendarPermission() {
        requestWithPrivacy(listOf(Manifest.permission.READ_CALENDAR to "calendar"), "Show your next events on the Calendar widget and in search.") { refreshCalendarWidgets() }
    }

    private val permissionCallbacks = HashMap<Int, Pair<List<String>, (Boolean) -> Unit>>()
    private var nextPermissionRequest = REQ_PRIVATE_BASE

    fun hasPermission(permission: String) = checkSelfPermission(permission) == PackageManager.PERMISSION_GRANTED

    /**
     * Asks for runtime permissions, but always explains first that the data stays on this phone and is never
     * shared with third parties. [done] gets whether everything asked for was granted.
     */
    fun requestWithPrivacy(permissions: List<Pair<String, String>>, reason: String, done: (Boolean) -> Unit) {
        val missing = permissions.filter { !hasPermission(it.first) }
        if (missing.isEmpty()) { done(true); return }
        val names = missing.joinToString(" and ") { it.second }
        FluidDialog(this, "Your $names stay on your phone",
            "$reason\n\nFluid One reads your $names only on this phone. It has no internet access and will never share your data with third parties.\n\nYou can change this any time in Android Settings.",
            "Continue", "Not now", icon = R.drawable.ic_shield) {
            val code = nextPermissionRequest++
            permissionCallbacks[code] = missing.map { it.first } to done
            requestPermissions(missing.map { it.first }.toTypedArray(), code)
        }.show()
    }

    private fun refreshCalendarWidgets() {
        forEachHomeView { v -> if (v is WidgetFrame) (v.content as? CalendarWidget)?.refresh() }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQ_CALENDAR) refreshCalendarWidgets()
        val pending = permissionCallbacks.remove(requestCode) ?: return
        val granted = pending.first.all { hasPermission(it) }
        if (pending.first.contains(Manifest.permission.READ_CALENDAR)) refreshCalendarWidgets()
        if (!granted && pending.first.any { !hasPermission(it) && !shouldShowRequestPermissionRationale(it) } && grantResults.isNotEmpty()) {
            // Android won't ask again: offer the app's permission screen instead.
            FluidDialog(this, "Permission is off", "Turn it on in App info › Permissions. Fluid One still never shares your data with third parties.", "Open App info") {
                startSafely(Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.fromParts("package", packageName, null)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK), null)
            }.show()
        }
        pending.second(granted)
        drawer.refreshSearch()
    }

    @Deprecated("Uses framework activity results for widget binding and pickers")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        when (requestCode) {
            REQ_BIND_WIDGET -> {
                restorePendingWidget()
                val id = data?.getIntExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, pendingWidgetId) ?: pendingWidgetId
                if (resultCode == RESULT_OK && id >= 0) configureOrPlaceWidget(id) else { deleteWidgetId(id); clearPendingWidget() }
            }
            REQ_CONFIG_WIDGET -> {
                restorePendingWidget()
                val id = data?.getIntExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, pendingWidgetId) ?: pendingWidgetId
                when {
                    id < 0 -> clearPendingWidget()
                    resultCode == RESULT_OK -> placeWidget(id)
                    // "Cancelled" before we even left the home screen: the setup screen is still open in its
                    // own task. Wait for the user to come back, then add the widget.
                    !stoppedSinceConfig -> setPendingWidget(id, awaitingConfig = true)
                    else -> { deleteWidgetId(id); clearPendingWidget() }
                }
            }
            REQ_WIDGET_PHOTO -> {
                val uri = data?.data ?: return
                if (resultCode != RESULT_OK) return
                val id = if (pendingPhotoItem >= 0) pendingPhotoItem else prefs.sp.getLong("pending_photo_item", -1L)
                if (id >= 0) importWidgetPhoto(uri, id)
                pendingPhotoItem = -1
            }
            REQ_WALLPAPER -> {
                val uri = data?.data ?: return
                if (resultCode != RESULT_OK) return
                toast("Setting wallpaper…")
                val (w, h) = screenSize()
                io.execute {
                    val id = wallpaperStore.importImage(uri, w, h)
                    main.post { if (id != null) setWallpaper(id) else toast("Couldn't read that image") }
                }
            }
            REQ_ICON_IMAGE -> {
                val uri = data?.data ?: return
                val key = pendingIconKey ?: return
                if (resultCode != RESULT_OK) return
                io.execute {
                    val file = saveIconImage(uri, key)
                    main.post {
                        if (file != null) {
                            prefs.setIconOverride(key, IconOverride("image", file = file.absolutePath))
                            applyIconChange()
                            toast("Icon updated")
                        } else toast("Couldn't read that image")
                    }
                }
            }
        }
    }

    private fun saveIconImage(uri: Uri, key: String): File? = try {
        val bmp = ImageDecoder.decodeBitmap(ImageDecoder.createSource(contentResolver, uri)) { decoder, info, _ ->
            decoder.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
            val s = (512f / min(info.size.width, info.size.height)).coerceAtMost(1f)
            decoder.setTargetSize(max(1, (info.size.width * s).roundToInt()), max(1, (info.size.height * s).roundToInt()))
        }
        val side = min(bmp.width, bmp.height)
        val square = Bitmap.createBitmap(bmp, (bmp.width - side) / 2, (bmp.height - side) / 2, side, side)
        val dir = File(filesDir, "icons").apply { mkdirs() }
        val file = File(dir, "${key.hashCode().toUInt().toString(16)}.png")
        FileOutputStream(file).use { square.compress(Bitmap.CompressFormat.PNG, 100, it) }
        file
    } catch (_: Exception) { null }

    // ---- Settings application ------------------------------------------------------------------------------

    fun applyLayoutChange() {
        model.fitToGrid(prefs.columns, prefs.rows)
        model.dock.retainAll { apps.contains(it) }
        model.save()
        applyChromeVisibility()
        workspace.pages.forEach { it.cols = prefs.columns; it.rows = prefs.rows }
        icons.clear()
        scheduleIconPrewarm()
        syncAll()
        homeLayout.requestLayout()
        drawer.reload()
    }

    private val prewarmRunnable = Runnable { if (!isDestroyed) icons.prewarm(apps.drawerApps(), iconSizePx) }

    /** Builds every drawer icon in the background shortly after anything that changes icons. */
    fun scheduleIconPrewarm(delayMs: Long = 900L) {
        main.removeCallbacks(prewarmRunnable)
        main.postDelayed(prewarmRunnable, delayMs)
    }

    fun applyIconChange() {
        scheduleIconPrewarm()
        icons.clear()
        syncAll()
        drawer.refreshIcons()
        openFolder?.refreshAfterChange()
    }

    fun setIconPack(pkg: String, done: () -> Unit) {
        prefs.iconPack = pkg
        io.execute {
            if (pkg.isNotEmpty()) icons.packs.pack(pkg)
            main.post { applyIconChange(); done() }
        }
    }

    fun applyMotionSpeed() { Motion.speed = prefs.animSpeed / 100f }

    fun applyDeviceTuning() {
        try { Device.applyRefreshRate(this, brandModeOn() && prefs.highRefresh) } catch (_: Exception) { }
        applySystemAccent()
    }

    /** Material You: follow the system's accent colour (Android 12+) while the option is on. */
    private fun applySystemAccent() {
        if (!prefs.systemAccent || !brandModeOn() || Build.VERSION.SDK_INT < 31) return
        val c = try { getColor(android.R.color.system_accent1_500) } catch (_: Exception) { return }
        if (c != prefs.accent && Color.alpha(c) == 255) {
            prefs.accent = c
            if (::drawer.isInitialized) main.post { applyThemeChange() }
        }
    }

    private fun expandQuickSettings() {
        try {
            @Suppress("WrongConstant")
            val sb = getSystemService("statusbar")
            Class.forName("android.app.StatusBarManager").getMethod("expandSettingsPanel").invoke(sb)
        } catch (_: Throwable) { expandNotifications() }
    }

    fun applyEverything() {
        applyMotionSpeed()
        ui = makeTheme()
        icons.clear()
        scheduleBlurRebuild()
        applyLayoutChange()
        applyDeviceTuning()
        updateSystemBars()
    }

    fun resetLayout() {
        model.pages.flatten().forEach { deleteWidgetsOf(it) }
        // New widgets reuse ids from 1: forget every old widget's look, note and photo.
        prefs.sp.edit().apply { prefs.sp.all.keys.filter { it.startsWith("widget|") || it.startsWith("note|") }.forEach { remove(it) } }.apply()
        File(filesDir, "widgets").listFiles()?.forEach { it.delete() }
        model.clear()
        seedDefaultLayout()
        prefs.defaultPage = 0
        syncAll()
        workspace.snapTo(0, animate = false)
        animator.playEntrance("gather")
    }

    fun previewUnlock() {
        animator.primeUnlock()
        rootView.postDelayed({ animator.playUnlock() }, 140)
    }

    fun previewApps(n: Int): List<AppEntry> {
        val keys = (model.dock + model.pages.flatten().filter { it.type == HomeItem.APP }.map { it.appKey }).distinct()
        val list = keys.mapNotNull { apps[it] }.take(n)
        return if (list.size >= n) list else (list + apps.apps.filter { it !in list }).take(n)
    }

    /** Re-applies looks of the built-in Fluid One widgets (clock style, backgrounds, colours). */
    fun refreshBuiltinWidgets() {
        forEachHomeView { v -> if (v is WidgetFrame) v.refreshContent() }
    }

    // ---- Samsung mode -----------------------------------------------------------------------------------

    /** Themed styles can follow dark mode (brand modes on near-stock Android). */
    fun effectiveIconStyle(): String {
        val s = prefs.iconStyle
        if (brandModeOn() && prefs.autoThemedIcons && (s == "themed_dark" || s == "themed_light")) return if (ui.dark) "themed_dark" else "themed_light"
        return s
    }

    /** The phone's maker, for its brand mode. */
    val brand: Brand get() = Brand.current

    /** The brand mode for this phone (Samsung keeps its own switch from earlier versions). */
    fun brandModeOn() = if (brand == Brand.SAMSUNG) prefs.samsungMode else prefs.brandMode
    fun samsungOn() = brand == Brand.SAMSUNG && prefs.samsungMode
    fun s25On() = samsungOn() && prefs.s25Optimizations && Device.isS25Ultra()
    fun edgeGuardEnabled() = brandModeOn() && prefs.gestureGuard
    fun splitShadeOn() = brandModeOn() && prefs.splitShade

    /** Effects quality actually in use. Battery saver always uses Lite while battery-aware effects are on. */
    fun effectsTier(): Tier {
        if (brandModeOn() && prefs.batteryBlur && powerSaving) return Tier.LITE
        return when (prefs.effectsQuality) {
            "high" -> Tier.HIGH
            "balanced" -> Tier.BALANCED
            "lite" -> Tier.LITE
            else -> detectedTier
        }
    }
    val detectedTier: Tier by lazy { Performance.detect(this) }
    fun spenHoverEnabled() = s25On() && prefs.spenHover
    fun spenButtonEnabled() = s25On() && prefs.spenButton

    // ---- Drag hooks ----------------------------------------------------------------------------------------

    fun showRemoveBar(src: DragSource) {
        val entry = src.appKey?.let { apps[it] }
        val canUninstall = src.kind == HomeItem.APP && entry != null && !entry.isSystemApp
        removeBar.show(canRemove = src.origin != IconView.SOURCE_DRAWER, canUninstall = canUninstall)
    }

    fun hideRemoveBar() = removeBar.hide()

    fun onDragStarted() {
        if (isEditing) return
        pillRow.animate().alpha(0f).setDuration(Motion.d(160)).start()
    }

    fun onDragEnded() {
        if (!isEditing) pillRow.animate().alpha(1f).setDuration(Motion.d(220)).start()
    }

    // ---- Model seeding & maintenance -----------------------------------------------------------------------

    private fun cleanupModel() {
        if (apps.apps.isNotEmpty()) {
            model.pages.forEach { p -> p.removeAll { it.type == HomeItem.APP && !apps.contains(it.appKey) } }
            model.pages.flatten().filter { it.type == HomeItem.FOLDER }.forEach { f -> f.apps.retainAll { apps.contains(it) } }
            model.dock.retainAll { apps.contains(it) }
        }
        fun gone(it: HomeItem) = it.type == HomeItem.WIDGET && (try { widgetManager.getAppWidgetInfo(it.widgetId) } catch (_: Exception) { null }) == null
        model.pages.forEach { p -> p.removeAll { gone(it) } }
        // Stacks: drop widgets that no longer exist; an emptied stack goes, a stack of one becomes that widget.
        model.pages.forEach { p ->
            for (i in p.indices.reversed()) {
                val st = p[i]
                if (st.type != HomeItem.STACK) continue
                st.children.removeAll { gone(it) || (it.type != HomeItem.WIDGET && it.type != HomeItem.BUILTIN) }
                when (st.children.size) {
                    0 -> p.removeAt(i)
                    1 -> p[i] = st.children[0].also { c -> c.x = st.x; c.y = st.y; c.spanX = st.spanX; c.spanY = st.spanY }
                    else -> st.stackIndex = st.stackIndex.coerceIn(0, st.children.size - 1)
                }
            }
        }
        model.normalizeFolders()
        model.fitToGrid(prefs.columns, prefs.rows)
        if (model.pages.isEmpty()) model.pages.add(mutableListOf())
        model.save()
    }

    private fun seedDefaultLayout() {
        val cols = prefs.columns
        val rows = prefs.rows
        model.pages.clear(); model.dock.clear()
        val used = mutableSetOf<String>()
        fun pick(pkgs: List<String>, hints: List<String>): AppEntry? = apps.pick(pkgs, hints, used)?.also { used += it.key }

        listOf(
            pick(listOf("com.samsung.android.dialer", "com.google.android.dialer", "com.android.dialer"), listOf("phone")),
            pick(listOf("com.samsung.android.messaging", "com.google.android.apps.messaging", "com.android.mms"), listOf("messages", "messaging")),
            pick(listOf("com.sec.android.app.sbrowser", "com.android.chrome", "org.mozilla.firefox"), listOf("internet", "browser", "chrome")),
            pick(listOf("com.sec.android.app.camera", "com.google.android.GoogleCamera", "com.android.camera2"), listOf("camera"))
        ).filterNotNull().forEach { model.dock.add(it.key) }

        val page0 = mutableListOf<HomeItem>()
        page0.add(HomeItem(model.newId(), HomeItem.BUILTIN, 0, 0, cols, 2, builtin = Builtins.CLOCK))
        var row = 2
        if (rows >= 6) {
            val tools = listOfNotNull(
                pick(listOf("com.sec.android.app.popupcalculator", "com.google.android.calculator"), listOf("calculator")),
                pick(listOf("com.samsung.android.app.notes", "com.google.android.keep"), listOf("notes", "keep")),
                pick(listOf("com.sec.android.app.voicenote", "com.google.android.apps.recorder"), listOf("recorder", "voice")),
                pick(listOf("com.google.android.gm", "com.samsung.android.email.provider"), listOf("gmail", "email", "mail")),
                pick(listOf("com.samsung.android.app.contacts", "com.google.android.contacts"), listOf("contacts")),
                pick(listOf("com.google.android.apps.translate"), listOf("translat")),
                pick(listOf("com.google.android.apps.docs"), listOf("drive")),
                pick(listOf("com.samsung.android.app.reminder", "com.google.android.apps.tasks"), listOf("reminder", "tasks"))
            )
            if (tools.size >= 2) page0.add(HomeItem(model.newId(), HomeItem.FOLDER, 0, 2, 2, 2, title = "Productivity", apps = tools.map { it.key }.toMutableList()))
            else tools.forEach { used.remove(it.key) }
            page0.add(HomeItem(model.newId(), HomeItem.BUILTIN, cols - 2, 2, 2, 2, builtin = Builtins.CALENDAR))
            row = 4
        }
        val favourites = listOfNotNull(
            pick(listOf("com.samsung.android.calendar", "com.google.android.calendar"), listOf("calendar")),
            pick(listOf("com.sec.android.daemonapp", "com.google.android.apps.weather"), listOf("weather")),
            pick(listOf("com.android.settings"), listOf("settings")),
            pick(listOf("com.sec.android.app.clockpackage", "com.google.android.deskclock"), listOf("clock")),
            pick(listOf("com.sec.android.app.myfiles", "com.google.android.apps.nbu.files"), listOf("my files", "files")),
            pick(listOf("com.google.android.apps.maps"), listOf("maps")),
            pick(listOf("com.sec.android.gallery3d", "com.google.android.apps.photos"), listOf("gallery", "photos")),
            pick(listOf("com.android.vending"), listOf("play store")),
            pick(listOf("com.google.android.youtube"), listOf("youtube")),
            pick(listOf("com.sec.android.app.samsungapps"), listOf("galaxy store")),
            pick(listOf("com.samsung.android.app.spage", "com.samsung.android.oneconnect"), listOf("smartthings")),
            pick(listOf("com.spotify.music", "com.google.android.apps.youtube.music"), listOf("music"))
        ).toMutableList()
        for (y in row until rows) for (x in 0 until cols) {
            val e = favourites.removeFirstOrNull() ?: break
            page0.add(HomeItem(model.newId(), HomeItem.APP, x, y, appKey = e.key))
        }
        favourites.forEach { used.remove(it.key) }
        model.pages.add(page0)

        val rest = (favourites + apps.apps.filter { it.key !in used && !it.isWorkProfile }).distinctBy { it.key }
        val page1 = mutableListOf<HomeItem>()
        val capacity = cols * (rows - 1)
        rest.take(capacity).forEachIndexed { i, e -> page1.add(HomeItem(model.newId(), HomeItem.APP, i % cols, i / cols, appKey = e.key)) }
        if (page1.isNotEmpty()) model.pages.add(page1)
        model.save()
    }

    private fun addNewlyInstalled(pkg: String, user: UserHandle) {
        if (!prefs.addNewApps) return
        val entries = apps.forPackage(pkg).filter { it.user == user && !model.isOnHome(it.key) }
        if (entries.isEmpty()) return
        val start = (model.pages.size - 1).coerceAtLeast(0)
        entries.forEach { model.place(HomeItem(model.newId(), HomeItem.APP, appKey = it.key), prefs.columns, prefs.rows, start) }
        model.save()
    }

    private val appsCallback = object : LauncherApps.Callback() {
        override fun onPackageRemoved(packageName: String, user: UserHandle) {
            val keys = apps.forPackage(packageName).filter { it.user == user }.map { it.key }
            apps.refresh()
            keys.filter { !apps.contains(it) }.forEach { model.removeAppEverywhere(it) }
            model.save()
            icons.clear()
            syncAll(); drawer.reload(); scheduleIconPrewarm()
        }
        override fun onPackageAdded(packageName: String, user: UserHandle) {
            apps.refresh()
            addNewlyInstalled(packageName, user)
            syncAll(); drawer.reload(); scheduleIconPrewarm()
        }
        override fun onPackageChanged(packageName: String, user: UserHandle) {
            apps.refresh()
            if (packageName == prefs.iconPack) icons.packs.evict(packageName)
            icons.clear()
            syncAll(); drawer.reload(); scheduleIconPrewarm()
        }
        override fun onPackagesAvailable(packageNames: Array<out String>, user: UserHandle, replacing: Boolean) {
            apps.refresh(); icons.clear(); syncAll(); drawer.reload()
        }
        override fun onPackagesUnavailable(packageNames: Array<out String>, user: UserHandle, replacing: Boolean) {
            apps.refresh(); syncAll(); drawer.reload()
        }
    }

    // ---- Unlock detection ----------------------------------------------------------------------------------

    private val screenReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            when (intent.action) {
                Intent.ACTION_SCREEN_OFF -> {
                    if (drag.isDragging) drag.cancel()
                    if (started && !animator.isBusy) animator.primeUnlock()
                }
                Intent.ACTION_USER_PRESENT -> {
                    // A swipe that unlocked the phone must never carry on into a home gesture.
                    gestureReadyAt = SystemClock.uptimeMillis() + 500
                    if (animator.isUnlockPrimed && resumed) animator.playUnlock()
                }
            }
        }
    }

    private fun registerReceivers() {
        val filter = IntentFilter().apply { addAction(Intent.ACTION_SCREEN_OFF); addAction(Intent.ACTION_USER_PRESENT) }
        try { registerReceiver(screenReceiver, filter, Context.RECEIVER_EXPORTED) } catch (_: Exception) { }
    }

    fun isKeyguardLocked(): Boolean = try { getSystemService(KeyguardManager::class.java)?.isKeyguardLocked == true } catch (_: Exception) { false }

    // ---- Misc ----------------------------------------------------------------------------------------------

    fun haptic(v: View, constant: Int) {
        if (!prefs.haptics) return
        try { v.performHapticFeedback(constant) } catch (_: Exception) { }
    }

    fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_SHORT).show()

    fun hideKeyboard(v: View) {
        getSystemService(InputMethodManager::class.java)?.hideSoftInputFromWindow(v.windowToken, 0)
    }

    fun isDefaultLauncher(): Boolean {
        val ri = packageManager.resolveActivity(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME), PackageManager.MATCH_DEFAULT_ONLY)
        return ri?.activityInfo?.packageName == packageName
    }

    fun versionName(): String = try { packageManager.getPackageInfo(packageName, 0).versionName ?: "" } catch (_: Exception) { "" }

    private fun expandNotifications() {
        try {
            @Suppress("WrongConstant")
            val sb = getSystemService("statusbar")
            Class.forName("android.app.StatusBarManager").getMethod("expandNotificationsPanel").invoke(sb)
        } catch (_: Throwable) { }
    }

    /**
     * Swipe down only opens the notification shade for a fresh gesture on an unlocked, focused home screen.
     * This stops the shade from opening on its own when an unlock swipe or a lock-screen touch ends on home.
     */
    private fun swipeDownAllowed(ev: MotionEvent): Boolean =
        ev.downTime >= gestureReadyAt && hasWindowFocus() && resumed && !isKeyguardLocked()

    private fun canHomeGesture(): Boolean =
        overlays.isEmpty() && !isDrawerOpen && !isEditing && !drag.isDragging && !animator.isBusy && drag.armed == null

    private fun isOverAppWidget(x: Float, y: Float): Boolean {
        val cl = workspace.pages.getOrNull(workspace.currentPage) ?: return false
        for (c in cl.childList()) {
            if (c !is FluidWidgetHostView && c !is StackFrame) continue
            val r = RectF(0f, 0f, c.width.toFloat(), c.height.toFloat())
            val m = Matrix(); c.transformMatrixToGlobal(m); m.mapRect(r)
            if (r.contains(x, y)) return true
        }
        return false
    }

    /**
     * Root of the view tree. Watches every touch first so it can turn a long press into a drag and recognise
     * home gestures (swipe up for the drawer, swipe down for notifications, pinch for edit mode).
     */
    inner class LauncherRoot : FrameLayout(this@MainActivity) {
        var lastX = 0f
            private set
        var lastY = 0f
            private set
        private var downX = 0f
        private var downY = 0f
        private var mode = MODE_NONE
        private var velocity: VelocityTracker? = null
        private var startSpan = 0f
        private var fired = false
        private var downOnWidget = false
        private val slop = ViewConfiguration.get(context).scaledTouchSlop

        init { clipChildren = false }

        override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
            lastX = ev.x; lastY = ev.y
            // A drag can only be armed by a long press inside the current gesture (or the S Pen button).
            if (ev.actionMasked == MotionEvent.ACTION_DOWN && !drag.isDragging) drag.disarm()
            if (ev.actionMasked == MotionEvent.ACTION_DOWN && animator.isUnlockPrimed && !isKeyguardLocked()) animator.playUnlock()
            // A tap during a swipe-home landing ends it at once, so the icon is never left hidden.
            if (ev.actionMasked == MotionEvent.ACTION_DOWN && iconLanding.isActive) iconLanding.finish(landed = false)
            return super.dispatchTouchEvent(ev)
        }

        override fun onWindowVisibilityChanged(visibility: Int) {
            super.onWindowVisibilityChanged(visibility)
            if (visibility != View.VISIBLE && ::animator.isInitialized) animator.onWindowHidden()
        }

        override fun onInterceptTouchEvent(ev: MotionEvent): Boolean {
            if (drag.isDragging) return true
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downX = ev.x; downY = ev.y; mode = MODE_NONE; fired = false
                    velocity?.recycle(); velocity = VelocityTracker.obtain(); velocity?.addMovement(ev)
                    downOnWidget = isOverAppWidget(ev.x, ev.y)
                }
                MotionEvent.ACTION_POINTER_DOWN -> if (detectPinch(ev)) return true
                MotionEvent.ACTION_MOVE -> {
                    velocity?.addMovement(ev)
                    if (drag.armed != null) {
                        if (drag.maybeStart(ev.x, ev.y)) { startDragTracking(ev); return true }
                        return false
                    }
                    if (detectSwipe(ev)) return true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> drag.disarm()
            }
            return false
        }

        private fun detectPinch(ev: MotionEvent): Boolean {
            if (!canHomeGesture() || prefs.pinchIn != "edit" || ev.pointerCount != 2) return false
            mode = MODE_PINCH
            startSpan = span(ev)
            fired = false
            return true
        }

        private fun detectSwipe(ev: MotionEvent): Boolean {
            if (mode != MODE_NONE || !canHomeGesture() || downOnWidget) return false
            val dx = ev.x - downX
            val dy = ev.y - downY
            if (abs(dy) < slop * 1.2f || abs(dy) < abs(dx) * 1.3f) return false
            if (dy < 0 && prefs.swipeUp != "none") {
                mode = MODE_DRAWER
                downY = ev.y
                drawer.reload()
                return true
            }
            if (dy > 0 && prefs.swipeDown != "none" && swipeDownAllowed(ev)) { mode = MODE_SWIPE_DOWN; fired = false; return true }
            return false
        }

        // ---- Multi-touch while dragging: tap other apps to stack them, swipe with another finger to page ----

        private inner class ExtraPointer(var startX: Float, val startY: Float, val downTime: Long) {
            var mode = EXTRA_TAP
            var lastX = startX
            var lastTime = downTime
            var vx = 0f
        }

        private var dragPointerId = -1
        private val extras = HashMap<Int, ExtraPointer>()
        private var swipingPointer = -1

        private fun startDragTracking(ev: MotionEvent) {
            mode = MODE_DRAG
            dragPointerId = ev.getPointerId(0)
            extras.clear()
            swipingPointer = -1
        }

        private fun handleDragTouch(ev: MotionEvent) {
            if (dragPointerId == -1) dragPointerId = ev.getPointerId(0)
            val di = ev.findPointerIndex(dragPointerId).let { if (it < 0) 0 else it }
            when (ev.actionMasked) {
                MotionEvent.ACTION_MOVE -> {
                    drag.move(ev.getX(di), ev.getY(di))
                    for ((id, p) in extras) {
                        val i = ev.findPointerIndex(id)
                        if (i < 0) continue
                        val x = ev.getX(i); val y = ev.getY(i)
                        if (p.mode == EXTRA_TAP && hypot(x - p.startX, y - p.startY) > slop) {
                            if (abs(x - p.startX) > abs(y - p.startY) && swipingPointer == -1) {
                                p.mode = EXTRA_SWIPE
                                p.startX = x
                                swipingPointer = id
                                drag.beginPageSwipe()
                            } else p.mode = EXTRA_IGNORE
                        }
                        if (p.mode == EXTRA_SWIPE) {
                            val dt = (ev.eventTime - p.lastTime).coerceAtLeast(1L)
                            p.vx = 0.6f * p.vx + 0.4f * ((x - p.lastX) * 1000f / dt)
                            p.lastX = x; p.lastTime = ev.eventTime
                            drag.pageSwipe(x - p.startX)
                        }
                    }
                }
                MotionEvent.ACTION_POINTER_DOWN -> {
                    val i = ev.actionIndex
                    extras[ev.getPointerId(i)] = ExtraPointer(ev.getX(i), ev.getY(i), ev.eventTime)
                }
                MotionEvent.ACTION_POINTER_UP -> {
                    val i = ev.actionIndex
                    val id = ev.getPointerId(i)
                    if (id == dragPointerId) {
                        // The holding finger lifted first: drop where it is.
                        finishExtras()
                        drag.drop(ev.getX(i), ev.getY(i))
                        dragPointerId = -1
                    } else finishExtra(id, ev.getX(i), ev.getY(i), ev.eventTime)
                }
                MotionEvent.ACTION_UP -> {
                    val id = ev.getPointerId(0)
                    if (id == dragPointerId || dragPointerId == -1) {
                        finishExtras()
                        drag.drop(ev.x, ev.y)
                    } else finishExtra(id, ev.x, ev.y, ev.eventTime)
                    dragPointerId = -1
                    mode = MODE_NONE
                }
                MotionEvent.ACTION_CANCEL -> {
                    extras.clear(); swipingPointer = -1; dragPointerId = -1
                    drag.cancel()
                }
            }
        }

        private fun finishExtra(id: Int, x: Float, y: Float, time: Long) {
            val p = extras.remove(id) ?: return
            when (p.mode) {
                EXTRA_TAP -> if (time - p.downTime < 450L) drag.tapAt(x, y)
                EXTRA_SWIPE -> { drag.endPageSwipe(p.vx); swipingPointer = -1 }
            }
        }

        /** Forgets the other fingers. A swipe in progress is settled by the drop itself (instantly). */
        private fun finishExtras() {
            extras.clear()
            swipingPointer = -1
        }

        private fun span(ev: MotionEvent): Float =
            if (ev.pointerCount < 2) 0f else hypot(ev.getX(0) - ev.getX(1), ev.getY(0) - ev.getY(1))

        override fun onTouchEvent(ev: MotionEvent): Boolean {
            velocity?.addMovement(ev)
            if (drag.isDragging) {
                handleDragTouch(ev)
                return true
            }
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downX = ev.x; downY = ev.y; mode = MODE_NONE; fired = false
                    velocity?.recycle(); velocity = VelocityTracker.obtain(); velocity?.addMovement(ev)
                    downOnWidget = false
                    return true
                }
                MotionEvent.ACTION_POINTER_DOWN -> detectPinch(ev)
                MotionEvent.ACTION_MOVE -> {
                    if (drag.armed != null) { if (drag.maybeStart(ev.x, ev.y)) startDragTracking(ev); return true }
                    if (mode == MODE_NONE) detectSwipe(ev)
                    when (mode) {
                        MODE_DRAWER -> {
                            val p = (downY - ev.y) / (height * 0.42f)
                            drawer.setProgress(p.coerceIn(0f, 1f))
                        }
                        MODE_SWIPE_DOWN -> if (!fired && ev.y - downY > dp(56f) && swipeDownAllowed(ev)) {
                            fired = true
                            haptic(this, HapticFeedbackConstants.GESTURE_START)
                            when {
                                prefs.swipeDown != "notifications" -> openDrawer(focusSearch = true)
                                // HyperOS, ColorOS, OriginOS and MagicOS: the right side opens the control centre.
                                splitShadeOn() && downX > width * 0.58f -> expandQuickSettings()
                                else -> expandNotifications()
                            }
                        }
                        MODE_PINCH -> if (!fired && ev.pointerCount >= 2 && startSpan > 0f && span(ev) / startSpan < 0.75f) {
                            fired = true
                            enterEditMode()
                        }
                    }
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    if (mode == MODE_DRAWER) {
                        velocity?.computeCurrentVelocity(1000)
                        val vy = velocity?.yVelocity ?: 0f
                        val open = ev.actionMasked == MotionEvent.ACTION_UP &&
                            (vy < -dp(500f) || (drawer.progress > 0.28f && vy < dp(400f)))
                        drawer.animateTo(open, focusSearch = open && prefs.swipeUp == "search")
                    }
                    mode = MODE_NONE
                    velocity?.recycle(); velocity = null
                }
            }
            return true
        }
    }

    companion object {
        private const val WIDGET_HOST_ID = 2048
        private const val REQ_BIND_WIDGET = 4701
        private const val REQ_CONFIG_WIDGET = 4702
        private const val REQ_RECONFIGURE = 4703
        private const val REQ_WALLPAPER = 4704
        private const val REQ_ICON_IMAGE = 4705
        private const val REQ_CALENDAR = 4706
        private const val REQ_PRIVATE_BASE = 4800
        private const val REQ_WIDGET_PHOTO = 4707
        private const val MODE_NONE = 0
        private const val MODE_DRAWER = 1
        private const val MODE_SWIPE_DOWN = 2
        private const val MODE_PINCH = 3
        private const val MODE_DRAG = 4
        private const val EXTRA_TAP = 0
        private const val EXTRA_SWIPE = 1
        private const val EXTRA_IGNORE = 2
    }
}
