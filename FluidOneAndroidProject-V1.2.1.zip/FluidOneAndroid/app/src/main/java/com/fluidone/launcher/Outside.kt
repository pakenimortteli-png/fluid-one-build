package com.fluidone.launcher

import android.Manifest
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.provider.MediaStore
import android.view.Choreographer
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import org.json.JSONObject
import java.util.Calendar
import java.util.Locale
import java.util.Random
import java.util.TimeZone
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.acos
import kotlin.math.asin
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlin.math.tan

/*
 * Outside mode: the home screen turns into a quiet view of the outdoors that follows the real time of day, with
 * a big clock you can read in sunlight, how long you've been out, and only the four apps you pinned. Everything
 * else waits until you hold "End". Inspired by OPPO's Outdoor mode (pinned apps, readable in the sun), but built
 * around actually spending time outside.
 */

// ---- Sun --------------------------------------------------------------------------------------------------------

/** Rough sunrise and sunset for today, from the phone's time zone (no location needed). */
object SunTimes {
    private class Place(val lat: Double, val lng: Double)

    private val places = mapOf(
        "Europe/Helsinki" to Place(60.17, 24.94), "Europe/Stockholm" to Place(59.33, 18.07), "Europe/Oslo" to Place(59.91, 10.75),
        "Europe/Copenhagen" to Place(55.68, 12.57), "Europe/Tallinn" to Place(59.44, 24.75), "Europe/Riga" to Place(56.95, 24.1),
        "Europe/Vilnius" to Place(54.69, 25.28), "Europe/London" to Place(51.5, -0.13), "Europe/Dublin" to Place(53.35, -6.26),
        "Europe/Berlin" to Place(52.52, 13.4), "Europe/Amsterdam" to Place(52.37, 4.9), "Europe/Brussels" to Place(50.85, 4.35),
        "Europe/Paris" to Place(48.86, 2.35), "Europe/Zurich" to Place(47.37, 8.54), "Europe/Vienna" to Place(48.21, 16.37),
        "Europe/Prague" to Place(50.08, 14.44), "Europe/Warsaw" to Place(52.23, 21.0), "Europe/Budapest" to Place(47.5, 19.04),
        "Europe/Madrid" to Place(40.42, -3.7), "Europe/Lisbon" to Place(38.72, -9.14), "Europe/Rome" to Place(41.9, 12.5),
        "Europe/Athens" to Place(37.98, 23.73), "Europe/Istanbul" to Place(41.0, 28.98), "Europe/Kyiv" to Place(50.45, 30.52),
        "Europe/Kiev" to Place(50.45, 30.52), "Europe/Moscow" to Place(55.75, 37.62), "Atlantic/Reykjavik" to Place(64.15, -21.94),
        "America/New_York" to Place(40.71, -74.0), "America/Chicago" to Place(41.88, -87.63), "America/Denver" to Place(39.74, -104.99),
        "America/Los_Angeles" to Place(34.05, -118.24), "America/Toronto" to Place(43.65, -79.38), "America/Vancouver" to Place(49.28, -123.12),
        "America/Mexico_City" to Place(19.43, -99.13), "America/Sao_Paulo" to Place(-23.55, -46.63), "America/Argentina/Buenos_Aires" to Place(-34.6, -58.38),
        "Asia/Tokyo" to Place(35.68, 139.69), "Asia/Seoul" to Place(37.57, 126.98), "Asia/Shanghai" to Place(31.23, 121.47),
        "Asia/Hong_Kong" to Place(22.32, 114.17), "Asia/Singapore" to Place(1.35, 103.82), "Asia/Kolkata" to Place(28.61, 77.21),
        "Asia/Dubai" to Place(25.2, 55.27), "Asia/Jakarta" to Place(-6.2, 106.85), "Asia/Manila" to Place(14.6, 120.98),
        "Asia/Bangkok" to Place(13.75, 100.5), "Australia/Sydney" to Place(-33.87, 151.21), "Australia/Melbourne" to Place(-37.81, 144.96),
        "Pacific/Auckland" to Place(-36.85, 174.76), "Africa/Cairo" to Place(30.04, 31.24), "Africa/Johannesburg" to Place(-26.2, 28.05),
        "Africa/Lagos" to Place(6.52, 3.38), "Africa/Nairobi" to Place(-1.29, 36.82)
    )

    class Day(val sunrise: Double?, val sunset: Double?, val polarDay: Boolean)

    /** Sunrise and sunset in local hours (e.g. 7.5 = 07:30) for [cal]'s date. */
    fun day(cal: Calendar = Calendar.getInstance()): Day {
        val tz = cal.timeZone ?: TimeZone.getDefault()
        val offsetH = tz.getOffset(cal.timeInMillis) / 3_600_000.0
        val place = places[tz.id] ?: Place(45.0, tz.rawOffset / 3_600_000.0 * 15.0)
        val n = cal.get(Calendar.DAY_OF_YEAR)
        val g = 2 * PI / 365.0 * (n - 1)
        val eq = 229.18 * (0.000075 + 0.001868 * cos(g) - 0.032077 * sin(g) - 0.014615 * cos(2 * g) - 0.040849 * sin(2 * g))
        val decl = 0.006918 - 0.399912 * cos(g) + 0.070257 * sin(g) - 0.006758 * cos(2 * g) + 0.000907 * sin(2 * g) -
            0.002697 * cos(3 * g) + 0.00148 * sin(3 * g)
        val lat = Math.toRadians(place.lat)
        val x = cos(Math.toRadians(90.833)) / (cos(lat) * cos(decl)) - tan(lat) * tan(decl)
        if (x < -1.0) return Day(null, null, true)
        if (x > 1.0) return Day(null, null, false)
        val ha = Math.toDegrees(acos(x))
        val rise = (720 - 4 * (place.lng + ha) - eq) / 60.0 + offsetH
        val set = (720 - 4 * (place.lng - ha) - eq) / 60.0 + offsetH
        return Day(((rise % 24) + 24) % 24, ((set % 24) + 24) % 24, false)
    }

    /** The sun's height for drawing: 1 at noon, 0 at the horizon, negative at night (down to -1 at midnight). */
    fun elevation(d: Day, hour: Double): Double {
        val rise = d.sunrise; val set = d.sunset
        if (rise == null || set == null) return if (d.polarDay) 0.6 else -0.8
        return if (hour in rise..set) sin(PI * (hour - rise) / (set - rise))
        else {
            val night = 24 - (set - rise)
            val t = ((hour - set + 24) % 24) / night
            -sin(PI * t)
        }
    }

    /** Where the sun is across its day, 0 at sunrise to 1 at sunset (outside that range at night). */
    fun progress(d: Day, hour: Double): Double {
        val rise = d.sunrise ?: return 0.5
        val set = d.sunset ?: return 0.5
        return (hour - rise) / (set - rise)
    }

    fun format(hours: Double): String {
        val total = (hours * 60).roundToInt().mod(24 * 60)
        val c = Calendar.getInstance().apply { set(Calendar.HOUR_OF_DAY, total / 60); set(Calendar.MINUTE, total % 60) }
        return android.text.format.DateFormat.getTimeFormat(appContext ?: return String.format(Locale.ROOT, "%02d:%02d", total / 60, total % 60)).format(c.time)
    }

    @Volatile var appContext: Context? = null
}

// ---- Session & stats --------------------------------------------------------------------------------------------

object OutsideStats {
    private fun dayKey(c: Calendar) = String.format(Locale.ROOT, "%04d-%02d-%02d", c.get(Calendar.YEAR), c.get(Calendar.MONTH) + 1, c.get(Calendar.DAY_OF_MONTH))

    private fun log(p: LauncherPrefs): JSONObject = try { JSONObject(p.outsideLog) } catch (_: Exception) { JSONObject() }

    /** Adds a session to the per-day log (split at midnight). */
    fun add(p: LauncherPrefs, start: Long, end: Long) {
        if (end <= start) return
        val o = log(p)
        var t = start
        while (t < end) {
            val c = Calendar.getInstance().apply { timeInMillis = t }
            val next = (c.clone() as Calendar).apply { add(Calendar.DAY_OF_MONTH, 1); set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0) }.timeInMillis
            val stop = min(end, next)
            val key = dayKey(c)
            o.put(key, o.optDouble(key, 0.0) + (stop - t) / 60_000.0)
            t = stop
        }
        // Keep about two months.
        val cutoff = dayKey(Calendar.getInstance().apply { add(Calendar.DAY_OF_MONTH, -62) })
        o.keys().asSequence().toList().forEach { if (it < cutoff) o.remove(it) }
        p.outsideLog = o.toString()
        val minutes = ((end - start) / 60_000L).toInt()
        if (minutes > p.outsideLongest) p.outsideLongest = minutes
    }

    fun minutesOnDay(p: LauncherPrefs, daysAgo: Int): Double {
        val c = Calendar.getInstance().apply { add(Calendar.DAY_OF_MONTH, -daysAgo) }
        return log(p).optDouble(dayKey(c), 0.0)
    }

    fun weekMinutes(p: LauncherPrefs): Int = (0 until 7).sumOf { minutesOnDay(p, it) }.roundToInt()

    /** Days in a row with at least 10 minutes outside, counting today if it already qualifies. */
    fun streak(p: LauncherPrefs): Int {
        var n = 0
        var d = if (minutesOnDay(p, 0) >= 10) 0 else 1
        while (minutesOnDay(p, d) >= 10 && n < 400) { n++; d++ }
        return n
    }

    fun format(minutes: Int): String = when {
        minutes < 1 -> "under a minute"
        minutes < 60 -> "$minutes min"
        minutes % 60 == 0 -> "${minutes / 60} h"
        else -> "${minutes / 60} h ${minutes % 60} min"
    }
}

/** Default pinned apps: camera, maps, phone and a music app, if they're installed. */
object OutsidePins {
    fun defaults(launcher: MainActivity): List<String> {
        val pm = launcher.packageManager
        val intents = listOf(
            Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA),
            Intent(Intent.ACTION_VIEW, android.net.Uri.parse("geo:0,0?q=park")),
            Intent(Intent.ACTION_DIAL),
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_APP_MUSIC)
        )
        val out = ArrayList<String>()
        for (i in intents) {
            val pkg = try { i.resolveActivity(pm)?.packageName } catch (_: Exception) { null } ?: continue
            val e = launcher.apps.apps.firstOrNull { it.packageName == pkg && !it.isWorkProfile } ?: continue
            if (e.key !in out) out += e.key
        }
        return out
    }

    fun current(launcher: MainActivity): List<String> {
        val saved = launcher.prefs.outsidePins.split(',').filter { it.isNotBlank() && launcher.apps[it] != null }
        return if (launcher.prefs.outsidePins.isEmpty()) defaults(launcher) else saved
    }
}

// ---- The scene --------------------------------------------------------------------------------------------------

/**
 * A quiet landscape drawn on the phone: sky, sun or moon where they really are right now, soft clouds drifting
 * slowly, two mountain ranges fading into the haze, a lake that mirrors them, a far shore of pines and a meadow
 * in the wind. Tilting the phone shifts the layers a little, nearer ones more.
 */
class NatureScene(context: Context) : View(context), Choreographer.FrameCallback, SensorEventListener {
    private val density = resources.displayMetrics.density
    private val rnd = Random(7)
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val spritePaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val glowPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val linePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND }
    private var far = Path(); private var mid = Path(); private var shore = Path(); private var near = Path(); private var meadow = Path()
    private var farTop = 0f; private var midTop = 0f
    private val stars = ArrayList<FloatArray>()
    private val clouds = ArrayList<FloatArray>()
    private val cloudSprites = ArrayList<android.graphics.Bitmap>()
    private val spriteDst = RectF()
    private val grass = ArrayList<FloatArray>()
    private var running = false
    private var lastFrame = 0L
    private var t = 0f
    private var tiltX = 0f
    private var tiltTarget = 0f
    private var birdsAt = -100f
    private var birdsY = 0f
    private var sensorOn = false
    /** Fixed time for previews and tests (hours, e.g. 18.5); negative = real time. */
    var fixedHour = -1.0
    /** Extra vertical parallax used by the entrance animation. */
    var rise = 0f
        set(v) { field = v; invalidate() }
    /** Frames per second while animating: 30 full screen, fewer for small previews and widgets. */
    var fps = 30
    private val onScreen = android.graphics.Rect()

    private var horizon = 0f
    private var lakeTop = 0f
    private var lakeBottom = 0f

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        if (w == 0 || h == 0) return
        horizon = h * 0.6f
        lakeTop = h * 0.62f
        lakeBottom = h * 0.76f
        farTop = lakeTop - h * 0.2f
        midTop = lakeTop - h * 0.11f
        far = ridge(w, lakeTop + 1f, h * 0.2f, peaks = 3, rough = 0.35f, seed = 3)
        mid = ridge(w, lakeTop + 1f, h * 0.11f, peaks = 2, rough = 0.15f, seed = 11)
        shore = pines(w, lakeTop + 1.5f * density, h * 0.018f, Random(9))
        near = pines(w, lakeBottom + 2f, h * 0.075f, Random(5))
        meadow = hills(w, h * 0.83f, h * 0.03f, 17)
        stars.clear()
        repeat(160) { stars += floatArrayOf(rnd.nextFloat() * w, rnd.nextFloat() * horizon * 0.8f, 0.4f + rnd.nextFloat() * 1.2f, rnd.nextFloat() * 6.28f) }
        clouds.clear()
        // Old sprites are just dropped: the render thread may still be drawing them this frame.
        cloudSprites.clear()
        repeat(6) { k ->
            val cw = w * (0.32f + rnd.nextFloat() * 0.3f)
            cloudSprites += cloudSprite(cw, cw * (0.32f + rnd.nextFloat() * 0.12f), Random(31L + k))
            clouds += floatArrayOf(rnd.nextFloat() * w * 1.5f - w * 0.25f, h * (0.06f + rnd.nextFloat() * 0.3f), k.toFloat(), 3f + rnd.nextFloat() * 6f)
        }
        grass.clear()
        var x = -4f
        while (x < w + 8f) { grass += floatArrayOf(x, 10f + rnd.nextFloat() * 18f, rnd.nextFloat() * 6.28f); x += 4f + rnd.nextFloat() * 6f }
    }

    /**
     * A soft cloud, drawn once at a third of its size (it's all soft edges, so it scales up well): overlapping puffs
     * blurred together, lit from above and shaded underneath.
     */
    private fun cloudSprite(fullW: Float, fullH: Float, r: Random): android.graphics.Bitmap {
        val cw = fullW * SPRITE_SCALE; val ch = fullH * SPRITE_SCALE
        val pad = ch * 0.5f
        val bw = (cw + pad * 2).roundToInt().coerceAtLeast(8); val bh = (ch + pad * 2).roundToInt().coerceAtLeast(8)
        val bmp = android.graphics.Bitmap.createBitmap(bw, bh, android.graphics.Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.maskFilter = android.graphics.BlurMaskFilter(ch * 0.22f, android.graphics.BlurMaskFilter.Blur.NORMAL)
        val puffs = 7 + r.nextInt(4)
        for (k in 0 until puffs) {
            val fx = pad + cw * (0.1f + 0.8f * k / (puffs - 1)) + (r.nextFloat() - 0.5f) * cw * 0.06f
            val bump = sin(PI.toFloat() * k / (puffs - 1))
            val rr = ch * (0.28f + 0.3f * bump + r.nextFloat() * 0.12f)
            val fy = pad + ch * 0.72f - rr * 0.7f
            // Underside in grey first, then the lit top slightly higher.
            p.color = Color.argb(170, 196, 202, 214)
            c.drawCircle(fx, fy + rr * 0.22f, rr, p)
            p.color = Color.argb(235, 255, 255, 255)
            c.drawCircle(fx - rr * 0.08f, fy - rr * 0.06f, rr * 0.86f, p)
        }
        // A flat, slightly darker base.
        p.color = Color.argb(150, 190, 196, 210)
        c.drawRoundRect(pad + cw * 0.08f, pad + ch * 0.58f, pad + cw * 0.92f, pad + ch * 0.86f, ch * 0.2f, ch * 0.2f, p)
        return bmp
    }

    /** A mountain range: a few broad peaks with smaller ridges on their shoulders. */
    private fun ridge(w: Int, base: Float, tall: Float, peaks: Int, rough: Float, seed: Int): Path {
        val r = Random(seed.toLong())
        val centres = FloatArray(peaks + 2) { (it - 0.5f + r.nextFloat() * 0.6f) / peaks * w }
        val heights = FloatArray(peaks + 2) { 0.55f + r.nextFloat() * 0.45f }
        val widths = FloatArray(peaks + 2) { w / peaks * (0.55f + r.nextFloat() * 0.4f) }
        val ph = FloatArray(4) { r.nextFloat() * 6.28f }
        val p = Path()
        p.moveTo(-10f, base)
        var x = -10f
        val step = 3f * density
        while (x <= w + 10f) {
            var y = 0f
            for (k in centres.indices) {
                val d = abs(x - centres[k]) / widths[k]
                if (d < 1f) y = max(y, heights[k] * (1f - d) * (1f - d * 0.35f))
            }
            val detail = (sin(x * 0.021f + ph[0]) * 0.5f + sin(x * 0.047f + ph[1]) * 0.3f + sin(x * 0.11f + ph[2]) * 0.2f) * rough
            p.lineTo(x, base - tall * (y + detail * y).coerceAtLeast(0.04f))
            x += step
        }
        p.lineTo(w + 10f, base)
        p.close()
        return p
    }

    private fun hills(w: Int, base: Float, amp: Float, seed: Int): Path {
        val r = Random(seed.toLong())
        val a = r.nextFloat() * 6.28f; val b = r.nextFloat() * 6.28f
        val p = Path()
        p.moveTo(-10f, height + 10f)
        var x = -10f
        while (x <= w + 10f) {
            p.lineTo(x, base - amp * (sin(x / w * 5.2f + a) * 0.6f + sin(x / w * 11f + b) * 0.4f))
            x += 6f * density
        }
        p.lineTo(w + 10f, height + 10f)
        p.close()
        return p
    }

    private fun pines(w: Int, base: Float, tall: Float, r: Random): Path {
        val p = Path()
        p.moveTo(-10f, height + 10f)
        p.lineTo(-10f, base)
        var x = -10f
        while (x < w + 20f) {
            val hgt = tall * (0.45f + r.nextFloat() * 0.75f)
            val half = hgt * (0.16f + r.nextFloat() * 0.07f)
            val gap = half * (0.3f + r.nextFloat() * 1.4f)
            p.lineTo(x, base)
            // A pine: a trunk and four tiers that narrow towards the tip.
            p.lineTo(x + half * 0.9f, base)
            p.lineTo(x + half * 0.9f, base - hgt * 0.08f)
            for (k in 0 until 4) {
                val tw = half * (1f - k * 0.2f)
                p.lineTo(x + half - tw, base - hgt * (0.1f + k * 0.21f))
                p.lineTo(x + half - tw * 0.35f, base - hgt * (0.18f + k * 0.21f))
            }
            p.lineTo(x + half, base - hgt)
            for (k in 3 downTo 0) {
                val tw = half * (1f - k * 0.2f)
                p.lineTo(x + half + tw * 0.35f, base - hgt * (0.18f + k * 0.21f))
                p.lineTo(x + half + tw, base - hgt * (0.1f + k * 0.21f))
            }
            p.lineTo(x + half * 1.1f, base - hgt * 0.08f)
            p.lineTo(x + half * 1.1f, base)
            p.lineTo(x + half * 2, base)
            x += half * 2 + gap
        }
        p.lineTo(w + 20f, base)
        p.lineTo(w + 20f, height + 10f)
        p.close()
        return p
    }

    // ---- Palette --------------------------------------------------------------------------------------------

    private class Sky(val top: Int, val mid: Int, val low: Int, val sun: Int, val land: Int, val night: Float, val cloud: Int)

    private fun mix(a: Int, b: Int, f: Float) = blendColors(a, b, clamp01(f))

    private fun skyFor(elev: Double, evening: Boolean): Sky {
        val e = elev.toFloat()
        val nightTop = Color.rgb(8, 12, 28); val nightMid = Color.rgb(18, 26, 52); val nightLow = Color.rgb(34, 44, 78)
        val dawnTop = Color.rgb(52, 70, 128); val dawnMid = if (evening) Color.rgb(206, 128, 140) else Color.rgb(182, 140, 172)
        val dawnLow = if (evening) Color.rgb(255, 170, 112) else Color.rgb(255, 196, 150)
        val dayTop = Color.rgb(58, 128, 214); val dayMid = Color.rgb(126, 182, 236); val dayLow = Color.rgb(212, 230, 246)
        return when {
            e < -0.12f -> {
                val f = clamp01((e + 0.4f) / 0.28f)
                Sky(mix(nightTop, dawnTop, f * 0.35f), mix(nightMid, dawnMid, f * 0.3f), mix(nightLow, dawnLow, f * 0.35f), Color.rgb(232, 236, 250),
                    Color.rgb(16, 22, 36), 1f - f * 0.4f, Color.rgb(70, 78, 104))
            }
            e < 0.05f -> {
                val f = clamp01((e + 0.12f) / 0.17f)
                Sky(mix(mix(nightTop, dawnTop, 0.35f), dawnTop, f), mix(mix(nightMid, dawnMid, 0.3f), dawnMid, f), mix(mix(nightLow, dawnLow, 0.35f), dawnLow, f),
                    Color.rgb(255, 198, 124), mix(Color.rgb(16, 22, 36), Color.rgb(46, 46, 64), f), 0.6f * (1f - f), mix(Color.rgb(70, 78, 104), Color.rgb(255, 196, 176), f))
            }
            e < 0.3f -> {
                val f = clamp01((e - 0.05f) / 0.25f)
                Sky(mix(dawnTop, dayTop, f), mix(dawnMid, dayMid, f), mix(dawnLow, dayLow, f), mix(Color.rgb(255, 206, 136), Color.rgb(255, 248, 226), f),
                    mix(Color.rgb(46, 46, 64), Color.rgb(52, 82, 76), f), 0f, mix(Color.rgb(255, 214, 196), Color.WHITE, f))
            }
            else -> Sky(dayTop, dayMid, dayLow, Color.rgb(255, 250, 234), Color.rgb(52, 84, 76), 0f, Color.WHITE)
        }
    }

    // ---- Drawing --------------------------------------------------------------------------------------------

    private fun hourNow(): Double {
        if (fixedHour >= 0) return fixedHour
        val c = Calendar.getInstance()
        return c.get(Calendar.HOUR_OF_DAY) + c.get(Calendar.MINUTE) / 60.0 + c.get(Calendar.SECOND) / 3600.0
    }

    private fun vertical(top: Float, bottom: Float, a: Int, b: Int) = LinearGradient(0f, top, 0f, bottom, a, b, Shader.TileMode.CLAMP)

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        if (w == 0f) return
        val hour = hourNow()
        val day = SunTimes.day()
        val elev = SunTimes.elevation(day, hour)
        val prog = SunTimes.progress(day, hour)
        val sky = skyFor(elev, prog > 0.5)
        val par = tiltX * density
        val lift = rise * h

        // Sky, with a warm glow along the horizon.
        paint.shader = LinearGradient(0f, 0f, 0f, lakeTop, intArrayOf(sky.top, sky.mid, sky.low), floatArrayOf(0f, 0.62f, 1f), Shader.TileMode.CLAMP)
        canvas.drawRect(0f, 0f, w, lakeTop + 2f, paint)
        paint.shader = null

        // Stars
        if (sky.night > 0.02f) {
            for (s in stars) {
                val tw = 0.55f + 0.45f * sin(t * (0.6f + s[2]) + s[3])
                paint.color = Color.argb((sky.night * tw * 210).roundToInt().coerceIn(0, 255), 255, 255, 255)
                canvas.drawCircle(s[0] + par * 0.2f, s[1] + lift * 0.1f, s[2] * density * 0.55f, paint)
            }
        }

        // Sun or moon on its arc, staying in the upper sky.
        val up = elev > -0.08
        val arcT = if (up) prog.coerceIn(-0.05, 1.05) else {
            val rise = day.sunrise ?: 6.0; val set = day.sunset ?: 18.0
            val night = 24 - (set - rise)
            ((hour - set + 24) % 24) / night
        }
        val bodyX = (w * (0.12f + 0.76f * arcT.toFloat())) + par * 0.3f
        val height01 = if (up) elev.toFloat().coerceAtLeast(-0.08f) else (-elev).toFloat()
        val bodyY = horizon - (horizon * 0.62f) * height01 + lift * 0.15f
        val r = density * if (up) 20f else 15f
        val glowR = r * if (up) 11f else 6f
        glowPaint.shader = RadialGradient(bodyX, bodyY, glowR, intArrayOf(withAlpha(sky.sun, if (up) 0.5f else 0.2f), withAlpha(sky.sun, if (up) 0.14f else 0.05f), withAlpha(sky.sun, 0f)),
            floatArrayOf(0f, 0.35f, 1f), Shader.TileMode.CLAMP)
        canvas.drawCircle(bodyX, bodyY, glowR, glowPaint)
        glowPaint.shader = null
        if (up) {
            paint.color = sky.sun
            canvas.drawCircle(bodyX, bodyY, r, paint)
        } else {
            // A crescent moon (the dark part is simply left out, so nothing is painted over the sky).
            val moon = Path().apply { addCircle(bodyX, bodyY, r, Path.Direction.CW) }
            val shadow = Path().apply { addCircle(bodyX + r * 0.5f, bodyY - r * 0.22f, r * 0.9f, Path.Direction.CW) }
            moon.op(shadow, Path.Op.DIFFERENCE)
            paint.color = sky.sun
            canvas.drawPath(moon, paint)
        }

        // Clouds drift slowly to the right and wrap around.
        spritePaint.colorFilter = android.graphics.LightingColorFilter(sky.cloud and 0xFFFFFF, 0)
        spritePaint.alpha = if (sky.night > 0.5f) 120 else 235
        for (c in clouds) {
            val sprite = cloudSprites.getOrNull(c[2].toInt()) ?: continue
            val sw = sprite.width / SPRITE_SCALE; val sh = sprite.height / SPRITE_SCALE
            val span = w + sw * 1.2f
            val cx = ((c[0] + t * c[3] * density) % span + span) % span - sw * 0.6f + par * 0.4f
            val cy = c[1] + lift * 0.2f
            spriteDst.set(cx, cy, cx + sw, cy + sh)
            canvas.drawBitmap(sprite, null, spriteDst, spritePaint)
        }

        // Birds now and then
        if (t - birdsAt > 26f) { birdsAt = t; birdsY = h * (0.14f + rnd.nextFloat() * 0.18f) }
        val bt = (t - birdsAt) / 14f
        if (bt in 0f..1f && sky.night < 0.6f) {
            linePaint.color = withAlpha(Color.rgb(32, 36, 50), 0.65f)
            linePaint.strokeWidth = 1.5f * density
            for (k in 0 until 4) {
                val bx = -w * 0.1f + bt * w * 1.2f - k * 14f * density
                val by = birdsY + (k % 2) * 8f * density + sin(bt * 20f + k) * 3f * density
                val flap = (3f + 3f * sin(t * 9f + k * 1.3f)) * density
                canvas.drawLine(bx - 5f * density, by - flap, bx, by, linePaint)
                canvas.drawLine(bx, by, bx + 5f * density, by - flap, linePaint)
            }
        }

        // Mountains: the further away, the more they fade into the colour of the sky, and the lighter their peaks.
        val farCol = mix(mix(sky.land, sky.low, 0.62f), Color.rgb(120, 130, 172), 0.15f)
        val midCol = mix(sky.land, sky.low, 0.32f)
        canvas.save(); canvas.translate(par * 0.5f, lift * 0.35f)
        paint.shader = vertical(farTop, lakeTop, mix(farCol, sky.low, 0.15f), mix(farCol, sky.low, 0.55f))
        canvas.drawPath(far, paint)
        canvas.restore()
        canvas.save(); canvas.translate(par * 0.9f, lift * 0.5f)
        paint.shader = vertical(midTop, lakeTop, midCol, mix(midCol, sky.low, 0.45f))
        canvas.drawPath(mid, paint)
        paint.shader = null
        canvas.restore()

        // Lake: the sky and the mountains upside down, with slow ripples and the sun's path on the water.
        val lt = lakeTop + lift * 0.55f
        val lb = lakeBottom + lift * 0.55f
        paint.shader = vertical(lt, lb, mix(sky.low, sky.mid, 0.4f), mix(sky.mid, sky.top, 0.5f))
        canvas.drawRect(0f, lt, w, lb + 2f, paint)
        canvas.save()
        canvas.clipRect(0f, lt, w, lb + 2f)
        canvas.translate(par * 0.7f, 0f)
        canvas.scale(1f, -0.8f, 0f, lt)
        canvas.translate(0f, -lift * 0.55f)
        // The reflection is strongest near the shore and fades out into the open water.
        paint.shader = LinearGradient(0f, lt, 0f, lt + (lb - lt) * 1.2f, withAlpha(farCol, 0.32f), withAlpha(farCol, 0f), Shader.TileMode.CLAMP)
        canvas.drawPath(far, paint)
        paint.shader = LinearGradient(0f, lt, 0f, lt + (lb - lt) * 1.2f, withAlpha(midCol, 0.42f), withAlpha(midCol, 0f), Shader.TileMode.CLAMP)
        canvas.drawPath(mid, paint)
        paint.shader = null
        canvas.restore()
        linePaint.strokeWidth = 1f * density
        for (k in 0 until 10) {
            val y = lt + (lb - lt) * ((k + 0.5f) / 10f)
            val shift = sin(t * 0.5f + k) * 22f * density
            linePaint.color = withAlpha(Color.WHITE, 0.06f + 0.03f * (k % 3))
            canvas.drawLine(w * 0.08f + shift, y, w * 0.42f + shift, y, linePaint)
            canvas.drawLine(w * 0.58f - shift, y + 2f, w * 0.92f - shift, y + 2f, linePaint)
        }
        if (up && elev > -0.05) {
            for (k in 0 until 8) {
                val y = lt + (lb - lt) * (k / 8f) + 3f
                val half = r * (1.8f - k * 0.16f) * (0.8f + 0.3f * sin(t * 2f + k))
                linePaint.color = withAlpha(sky.sun, 0.42f - k * 0.045f)
                linePaint.strokeWidth = 2f * density
                canvas.drawLine(bodyX - half, y, bodyX + half, y, linePaint)
            }
        }
        // Morning mist over the water
        val mist = if (prog in 0.0..0.3) (1f - (prog / 0.3).toFloat()) * 0.55f else 0f
        if (mist > 0.02f) {
            paint.shader = LinearGradient(0f, lt - h * 0.07f, 0f, lt + h * 0.03f, intArrayOf(withAlpha(Color.WHITE, 0f), withAlpha(Color.WHITE, mist), withAlpha(Color.WHITE, 0f)), null, Shader.TileMode.CLAMP)
            canvas.drawRect(0f, lt - h * 0.07f, w, lt + h * 0.03f, paint)
            paint.shader = null
        }

        // The far shore: a thin line of small pines.
        canvas.save(); canvas.translate(par * 1.0f, lift * 0.55f)
        paint.color = mix(midCol, Color.rgb(10, 18, 20), 0.35f)
        canvas.drawPath(shore, paint)
        canvas.restore()

        // Pines and meadow in front.
        val pine = mix(sky.land, Color.rgb(8, 16, 18), 0.5f)
        canvas.save(); canvas.translate(par * 1.4f, lift * 0.75f)
        paint.shader = vertical(lakeBottom - h * 0.08f, lakeBottom + h * 0.1f, mix(pine, sky.low, 0.12f), pine)
        canvas.drawPath(near, paint)
        canvas.restore()
        val grassCol = mix(sky.land, Color.rgb(52, 104, 58), if (sky.night > 0.5f) 0.1f else 0.55f)
        canvas.save(); canvas.translate(par * 2f, lift)
        paint.shader = vertical(h * 0.8f, h, mix(grassCol, sky.low, 0.12f), mix(grassCol, Color.BLACK, if (sky.night > 0.5f) 0.55f else 0.3f))
        canvas.drawPath(meadow, paint)
        paint.shader = null
        // Grass sways in the wind; the tips catch the light.
        linePaint.strokeWidth = 1.3f * density
        val gy = h * 0.83f
        for (g in grass) {
            val sway = sin(t * 1.3f + g[2] + g[0] * 0.01f) * 4f * density
            linePaint.color = mix(grassCol, sky.sun, 0.18f + 0.1f * sin(g[2]))
            canvas.drawLine(g[0], gy + 16f * density, g[0] + sway, gy - g[1] * density * 0.45f + 16f * density, linePaint)
        }
        canvas.restore()

        // Shade top and bottom so text stays readable in sunlight.
        paint.shader = LinearGradient(0f, 0f, 0f, h, intArrayOf(Color.argb(80, 0, 0, 0), Color.TRANSPARENT, Color.TRANSPARENT, Color.argb(140, 0, 0, 0)),
            floatArrayOf(0f, 0.28f, 0.62f, 1f), Shader.TileMode.CLAMP)
        canvas.drawRect(0f, 0f, w, h, paint)
        paint.shader = null
    }

    // ---- Life -----------------------------------------------------------------------------------------------

    fun start() {
        if (running) return
        running = true
        lastFrame = 0L
        Choreographer.getInstance().postFrameCallback(this)
        val sm = context.getSystemService(SensorManager::class.java)
        val g = sm?.getDefaultSensor(Sensor.TYPE_GRAVITY)
        if (g != null && !sensorOn) { sensorOn = sm.registerListener(this, g, SensorManager.SENSOR_DELAY_UI) }
    }

    fun stop() {
        running = false
        Choreographer.getInstance().removeFrameCallback(this)
        if (sensorOn) { context.getSystemService(SensorManager::class.java)?.unregisterListener(this); sensorOn = false }
    }

    override fun doFrame(frameTimeNanos: Long) {
        if (!running) return
        // Clouds and grass move slowly: 30 frames a second is plenty, and nothing is drawn while off screen.
        if (lastFrame == 0L || frameTimeNanos - lastFrame >= 1_000_000_000L / fps.coerceIn(1, 60) - 2_000_000L) {
            if (!isShown || !getGlobalVisibleRect(onScreen)) { lastFrame = frameTimeNanos; Choreographer.getInstance().postFrameCallback(this); return }
            val dt = if (lastFrame == 0L) 0f else ((frameTimeNanos - lastFrame) / 1e9f).coerceAtMost(0.1f)
            lastFrame = frameTimeNanos
            t += dt
            tiltX += (tiltTarget - tiltX) * 0.08f
            invalidate()
        }
        Choreographer.getInstance().postFrameCallback(this)
    }

    /** Advances the animation by [seconds] without the frame clock (previews, tests). */
    fun advance(seconds: Float) { t += seconds; invalidate() }

    override fun onSensorChanged(event: SensorEvent) { tiltTarget = (-event.values[0] / 9.81f).coerceIn(-1f, 1f) * 10f }
    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}

    override fun onDetachedFromWindow() { stop(); cloudSprites.clear(); super.onDetachedFromWindow() }

    override fun onAttachedToWindow() { super.onAttachedToWindow(); if (cloudSprites.isEmpty() && width > 0) onSizeChanged(width, height, 0, 0) }

    companion object { private const val SPRITE_SCALE = 0.34f }
}

// ---- Hold to end ------------------------------------------------------------------------------------------------

/** "Hold to end": fills while you press it; let go early and it drains back. */
class HoldButton(context: Context, private val label: String) : View(context) {
    var onDone: (() -> Unit)? = null
    private val density = resources.displayMetrics.density
    private val bg = Paint(Paint.ANTI_ALIAS_FLAG)
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val text = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER; typeface = Fonts.semibold; textSize = 16f * resources.displayMetrics.scaledDensity }
    private val rect = RectF()
    private var progress = 0f
    private val spring = SpringValue(0f) { progress = it; invalidate() }
    private var holding = false
    private val ticker = object : Runnable {
        override fun run() {
            if (!holding) return
            if (progress >= 0.999f) { holding = false; performHapticFeedback(HapticFeedbackConstants.CONFIRM); onDone?.invoke(); return }
            postDelayed(this, 16)
        }
    }

    init { isClickable = true; contentDescription = "$label. Touch and hold." }

    override fun onDraw(canvas: Canvas) {
        rect.set(0f, 0f, width.toFloat(), height.toFloat())
        val r = height / 2f
        bg.color = Color.argb(70, 255, 255, 255)
        canvas.drawRoundRect(rect, r, r, bg)
        if (progress > 0.001f) {
            canvas.save()
            canvas.clipRect(0f, 0f, width * progress, height.toFloat())
            fill.color = Color.argb(235, 255, 255, 255)
            canvas.drawRoundRect(rect, r, r, fill)
            canvas.restore()
        }
        val label = if (holding) "Keep holding" else label
        val base = height / 2f - (text.ascent() + text.descent()) / 2f
        // The text turns dark where the fill has reached it.
        text.color = Color.WHITE
        canvas.save(); canvas.clipRect(width * progress, 0f, width.toFloat(), height.toFloat()); canvas.drawText(label, width / 2f, base, text); canvas.restore()
        text.color = Color.rgb(20, 30, 28)
        canvas.save(); canvas.clipRect(0f, 0f, width * progress, height.toFloat()); canvas.drawText(label, width / 2f, base, text); canvas.restore()
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                holding = true
                parent?.requestDisallowInterceptTouchEvent(true)
                performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
                // A slow, steady spring: about a second to fill.
                spring.animateTo(1.02f, stiffness = 40f, dampingRatio = 1f)
                removeCallbacks(ticker); post(ticker)
                invalidate()
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                if (holding) {
                    holding = false
                    spring.animateTo(0f, stiffness = 260f, dampingRatio = 0.9f)
                    invalidate()
                }
            }
        }
        return true
    }

    /** Test hook: finish the hold at once. */
    fun complete() { holding = false; progress = 1f; onDone?.invoke() }
}

// ---- The overlay ------------------------------------------------------------------------------------------------

class OutsideOverlay(launcher: MainActivity) : Overlay(launcher) {
    private val p = launcher.prefs
    val scene = NatureScene(launcher)
    private val clock = launcher.textView("", 84f, Color.WHITE, Fonts.light, Gravity.CENTER)
    private val date = launcher.textView("", 17f, Color.argb(235, 255, 255, 255), Fonts.medium, Gravity.CENTER)
    private val sunLine = launcher.textView("", 14f, Color.argb(215, 255, 255, 255), Fonts.regular, Gravity.CENTER)
    private val since = launcher.textView("", 13f, Color.argb(200, 255, 255, 255), Fonts.semibold, Gravity.CENTER).apply { letterSpacing = 0.12f }
    private val elapsed = launcher.textView("", 34f, Color.WHITE, Fonts.semibold, Gravity.CENTER)
    private val goalLine = launcher.textView("", 14f, Color.argb(215, 255, 255, 255), Fonts.medium, Gravity.CENTER)
    private val prompt = launcher.textView("", 18f, Color.WHITE, Fonts.medium, Gravity.CENTER)
    private val ring = GoalRing(launcher)
    private val pinRow = LinearLayout(launcher).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
    private val pins = ArrayList<IconView>()
    private val end = HoldButton(launcher, "Hold to end")
    private val handler = Handler(Looper.getMainLooper())
    private var promptIndex = 0
    private var lastPromptAt = 0L
    private var goalCelebrated = false
    private var steps = -1
    private var stepSensorOn = false
    private val stepListener = object : SensorEventListener {
        override fun onSensorChanged(event: SensorEvent) {
            val total = event.values[0].toLong()
            var base = p.outsideStepBase
            if (base < 0 || total < base) { base = total; p.outsideStepBase = base }
            steps = (total - base).toInt()
            updateTexts()
        }
        override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}
    }
    private val tick = object : Runnable {
        override fun run() { updateTexts(); handler.postDelayed(this, 1000L - System.currentTimeMillis() % 1000L + 5) }
    }

    override val sticky: Boolean get() = true

    init {
        root.isClickable = true
        root.setBackgroundColor(Color.BLACK)
        root.addView(scene, flp(MATCH, MATCH))
        val shadow = Color.argb(110, 0, 0, 0)
        listOf(clock, date, sunLine, elapsed, prompt, since, goalLine).forEach { it.setShadowLayer(launcher.dp(6f), 0f, launcher.dp(1f), shadow) }

        val top = LinearLayout(launcher).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL }
        top.addView(since.apply { text = "OUTSIDE" })
        top.addView(clock, llp(WRAP, WRAP).apply { topMargin = -launcher.dpi(2) })
        top.addView(date)
        top.addView(sunLine, llp(WRAP, WRAP).apply { topMargin = launcher.dpi(4) })
        root.addView(top, flp(MATCH, WRAP, Gravity.TOP).apply { topMargin = launcher.insetTop + launcher.dpi(34) })

        val middle = FrameLayout(launcher)
        middle.addView(ring, flp(launcher.dpi(196), launcher.dpi(196), Gravity.CENTER))
        val inner = LinearLayout(launcher).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER }
        inner.addView(elapsed)
        inner.addView(goalLine)
        middle.addView(inner, flp(WRAP, WRAP, Gravity.CENTER))
        root.addView(middle, flp(MATCH, launcher.dpi(200), Gravity.CENTER).apply { bottomMargin = launcher.dpi(40) })

        prompt.setPadding(launcher.dpi(32), 0, launcher.dpi(32), 0)
        prompt.breakStrategy = android.text.Layout.BREAK_STRATEGY_BALANCED
        root.addView(prompt, flp(MATCH, WRAP, Gravity.CENTER).apply { topMargin = launcher.dpi(150) })

        val bottom = LinearLayout(launcher).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL }
        pinRow.background = roundRect(Color.argb(56, 255, 255, 255), launcher.dp(30f), launcher.dpi(1), Color.argb(60, 255, 255, 255))
        pinRow.setPadding(launcher.dpi(10), launcher.dpi(10), launcher.dpi(10), launcher.dpi(6))
        bottom.addView(pinRow, llp(MATCH, WRAP).apply { marginStart = launcher.dpi(20); marginEnd = launcher.dpi(20) })
        end.onDone = { finishSession() }
        bottom.addView(end, llp(MATCH, launcher.dpi(54)).apply { topMargin = launcher.dpi(14); marginStart = launcher.dpi(40); marginEnd = launcher.dpi(40) })
        root.addView(bottom, flp(MATCH, WRAP, Gravity.BOTTOM).apply { bottomMargin = launcher.insetBottom + launcher.dpi(20) })
        buildPins()
        promptIndex = ((System.currentTimeMillis() / 60_000L) % PROMPTS.size).toInt()
        prompt.text = PROMPTS[promptIndex]
        lastPromptAt = SystemClock.uptimeMillis()
        updateTexts()
    }

    private fun buildPins() {
        pinRow.removeAllViews(); pins.clear()
        val keys = OutsidePins.current(launcher).take(4)
        if (keys.isEmpty()) { pinRow.visibility = View.GONE; return }
        pinRow.visibility = View.VISIBLE
        keys.forEach { key ->
            val e = launcher.apps[key] ?: return@forEach
            val v = launcher.createAppIcon(e, IconView.SOURCE_OUTSIDE)
            v.showLabel = true
            v.darkLabel = false
            pins += v
            pinRow.addView(v, llp(0, launcher.iconSizePx + launcher.dpi(34), 1f))
        }
    }

    /** The pinned icon for an app, so it can open from and land back in it. */
    fun iconFor(key: String): IconView? = pins.firstOrNull { it.entry?.key == key }

    private fun updateTexts() {
        val now = System.currentTimeMillis()
        val cal = Calendar.getInstance()
        clock.text = android.text.format.DateFormat.getTimeFormat(launcher).format(cal.time)
        date.text = java.text.SimpleDateFormat(android.text.format.DateFormat.getBestDateTimePattern(Locale.getDefault(), "EEEEdMMMM"), Locale.getDefault()).format(cal.time)
        val day = SunTimes.day(cal)
        val hour = cal.get(Calendar.HOUR_OF_DAY) + cal.get(Calendar.MINUTE) / 60.0
        sunLine.text = when {
            day.sunrise == null -> if (day.polarDay) "The sun stays up all day" else "No sunrise today"
            hour < day.sunrise -> "Sunrise around ${SunTimes.format(day.sunrise)}"
            hour < day.sunset!! -> {
                val left = ((day.sunset - hour) * 60).roundToInt()
                "Sunset around ${SunTimes.format(day.sunset)} · ${OutsideStats.format(left)} of daylight left"
            }
            else -> "Sunrise around ${SunTimes.format(day.sunrise)}"
        }
        val start = p.outsideActiveSince.takeIf { it > 0 } ?: now
        val mins = ((now - start) / 60_000L).toInt().coerceAtLeast(0)
        elapsed.text = if (mins < 1) "Just started" else OutsideStats.format(mins)
        val goal = p.outsideGoal
        val stepText = if (steps >= 0) " · ${String.format(Locale.getDefault(), "%,d", steps)} steps" else ""
        goalLine.text = when {
            goal <= 0 -> "outside$stepText"
            mins >= goal -> "${OutsideStats.format(goal)} done$stepText"
            else -> "of ${OutsideStats.format(goal)}$stepText"
        }
        ring.progress = if (goal > 0) ((now - start) / (goal * 60_000f)).coerceIn(0f, 1f) else -1f
        if (goal > 0 && mins >= goal && !goalCelebrated) {
            goalCelebrated = true
            if (launcher.hasWindowFocus()) root.performHapticFeedback(HapticFeedbackConstants.CONFIRM)
            ring.celebrate()
        }
        // A new line every couple of minutes, cross-faded.
        if (SystemClock.uptimeMillis() - lastPromptAt > 150_000L) {
            lastPromptAt = SystemClock.uptimeMillis()
            promptIndex = (promptIndex + 1) % PROMPTS.size
            prompt.animate().alpha(0f).translationY(-launcher.dp(6f)).setDuration(Motion.d(420)).withEndAction {
                prompt.text = PROMPTS[promptIndex]
                prompt.translationY = launcher.dp(6f)
                prompt.animate().alpha(1f).translationY(0f).setDuration(Motion.d(520)).setInterpolator(Motion.decel).start()
            }.start()
        }
    }

    fun show() {
        launcher.showOverlay(this)
        onHostResumed()
        // Arrival: the landscape rises into place, then the text and buttons follow.
        root.alpha = 0f
        root.animate().alpha(1f).setDuration(Motion.d(420)).setInterpolator(Motion.decel).start()
        scene.rise = 0.08f
        val sceneSpring = Spring(1f, 0.9f)
        Motion.animate(sceneSpring.durationMs, sceneSpring, update = { scene.rise = 0.08f * (1f - it) })
        val views = listOf<View>(since, clock, date, sunLine, ring, elapsed, goalLine, prompt, pinRow, end)
        views.forEachIndexed { i, v ->
            v.alpha = 0f; v.translationY = launcher.dp(18f)
            val s = Spring(0.85f, 0.55f)
            v.animate().alpha(1f).translationY(0f).setStartDelay(Motion.d(160L + i * 45L)).setDuration(s.ms).setInterpolator(s).start()
        }
    }

    override fun onHostResumed() {
        scene.start()
        handler.removeCallbacks(tick); handler.post(tick)
        applyBrightness(true)
        startSteps()
    }

    override fun onHostPaused() {
        scene.stop()
        handler.removeCallbacks(tick)
        stopSteps()
    }

    private fun applyBrightness(on: Boolean) {
        val w = launcher.window ?: return
        val lp = w.attributes
        lp.screenBrightness = if (on && p.outsideBright) 1f else WindowManager.LayoutParams.BRIGHTNESS_OVERRIDE_NONE
        w.attributes = lp
    }

    private fun startSteps() {
        if (!p.outsideSteps || stepSensorOn || !launcher.hasPermission(Manifest.permission.ACTIVITY_RECOGNITION)) return
        val sm = launcher.getSystemService(SensorManager::class.java) ?: return
        val s = sm.getDefaultSensor(Sensor.TYPE_STEP_COUNTER) ?: return
        stepSensorOn = sm.registerListener(stepListener, s, SensorManager.SENSOR_DELAY_UI)
    }

    private fun stopSteps() {
        if (!stepSensorOn) return
        launcher.getSystemService(SensorManager::class.java)?.unregisterListener(stepListener)
        stepSensorOn = false
    }

    override fun onBack(): Boolean {
        end.animate().translationX(launcher.dp(8f)).setDuration(60).withEndAction {
            end.animate().translationX(0f).setDuration(Motion.d(260)).setInterpolator(Spring(0.3f, 0.3f)).start()
        }.start()
        launcher.toast("To finish, touch and hold the button at the bottom")
        return true
    }

    private fun finishSession() {
        val start = p.outsideActiveSince
        val now = System.currentTimeMillis()
        val minutes = if (start > 0) ((now - start) / 60_000L).toInt() else 0
        OutsideMode.stop(launcher)
        OutsideSummary(launcher, minutes, steps).show()
        close(true)
    }

    override fun close(animate: Boolean) {
        if (closing) return
        closing = true
        onHostPaused()
        applyBrightness(false)
        if (!animate) { finish(); return }
        root.animate().alpha(0f).scaleX(1.04f).scaleY(1.04f).setDuration(Motion.d(360)).setInterpolator(Motion.accel).withEndAction { finish() }.start()
    }

    companion object {
        val PROMPTS = listOf(
            "Look up for a bit.",
            "Listen. What can you hear?",
            "Take the long way round.",
            "Find something green and really look at it.",
            "Nothing on your phone needs you right now.",
            "Breathe out slowly. Then once more.",
            "Notice the light.",
            "Walk a little slower than usual.",
            "Feel the air. Warm, cold, windy?",
            "Go somewhere you haven't been this week."
        )
    }
}

/** The progress ring around the time spent outside (hidden without a goal). */
class GoalRing(context: Context) : View(context) {
    var progress = -1f
        set(v) { if (field != v) { field = v; invalidate() } }
    private val density = resources.displayMetrics.density
    private val track = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND; color = Color.argb(60, 255, 255, 255) }
    private val arc = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND; color = Color.WHITE }
    private val rect = RectF()
    private var pulse = 0f

    override fun onDraw(canvas: Canvas) {
        if (progress < 0f) return
        val sw = 6f * density
        track.strokeWidth = sw; arc.strokeWidth = sw * (1f + 0.5f * pulse)
        rect.set(sw, sw, width - sw, height - sw)
        canvas.drawArc(rect, 0f, 360f, false, track)
        if (progress > 0.001f) canvas.drawArc(rect, -90f, 360f * progress, false, arc)
    }

    /** A soft pulse when the goal is reached. */
    fun celebrate() {
        val s = Spring(0.4f, 0.5f)
        Motion.animate(s.durationMs, s, update = { pulse = 1f - it; invalidate() })
    }
}

/** Shown after Outside mode ends: how long you were out, and how that adds up. */
class OutsideSummary(launcher: MainActivity, minutes: Int, steps: Int) : BottomSheet(launcher, "Back inside", dimBackground = true) {
    init {
        val p = launcher.prefs
        val col = LinearLayout(launcher).apply { orientation = LinearLayout.VERTICAL; setPadding(launcher.dpi(20), launcher.dpi(4), launcher.dpi(20), launcher.dpi(12)) }
        val big = launcher.textView(if (minutes < 1) "Under a minute" else OutsideStats.format(minutes), 40f, ui.text, Fonts.bold)
        col.addView(big)
        val lines = ArrayList<String>()
        lines += "outside this time" + if (steps > 0) ", ${String.format(Locale.getDefault(), "%,d", steps)} steps" else ""
        lines += "This week: ${OutsideStats.format(OutsideStats.weekMinutes(p))}"
        val streak = OutsideStats.streak(p)
        if (streak >= 2) lines += "$streak days in a row with at least 10 minutes out"
        lines.forEach { col.addView(launcher.textView(it, 15f, ui.textSecondary).apply { setPadding(0, launcher.dpi(4), 0, 0) }) }
        val done = launcher.textView("Done", 16f, ui.onAccent, Fonts.semibold, Gravity.CENTER).apply {
            background = pressable(roundRect(ui.accent, launcher.dp(24f)), ui.cardPressed, launcher.dp(24f))
            isClickable = true
            setOnClickListener { close() }
        }
        col.addView(done, llp(MATCH, launcher.dpi(50)).apply { topMargin = launcher.dpi(18) })
        body.addView(col)
        big.alpha = 0f; big.scaleX = 0.9f; big.scaleY = 0.9f
        val s = Spring(0.6f, 0.45f)
        big.animate().alpha(1f).scaleX(1f).scaleY(1f).setStartDelay(Motion.d(160)).setDuration(s.ms).setInterpolator(s).start()
    }
}

/** Starting and stopping Outside mode, and the system settings it borrows (Do Not Disturb). */
object OutsideMode {
    fun isActive(p: LauncherPrefs) = p.outsideActiveSince > 0L

    fun start(launcher: MainActivity) {
        val p = launcher.prefs
        if (!isActive(p)) {
            p.outsideActiveSince = System.currentTimeMillis()
            p.outsideStepBase = -1L
            if (p.outsideSilence) silence(launcher, true)
        }
        if (launcher.overlays.none { it is OutsideOverlay }) {
            launcher.closeAllOverlays(true)
            OutsideOverlay(launcher).show()
        }
    }

    fun stop(launcher: MainActivity) {
        val p = launcher.prefs
        val start = p.outsideActiveSince
        if (start > 0) OutsideStats.add(p, start, System.currentTimeMillis())
        p.outsideActiveSince = 0L
        if (p.outsideSilenced) silence(launcher, false)
    }

    /** Turns Do Not Disturb (priority only) on for the session and back off afterwards, if Fluid One may. */
    fun silence(launcher: MainActivity, on: Boolean) {
        val nm = launcher.getSystemService(NotificationManager::class.java) ?: return
        val p = launcher.prefs
        try {
            if (!nm.isNotificationPolicyAccessGranted) return
            if (on) {
                if (nm.currentInterruptionFilter == NotificationManager.INTERRUPTION_FILTER_ALL) {
                    nm.setInterruptionFilter(NotificationManager.INTERRUPTION_FILTER_PRIORITY)
                    p.outsideSilenced = true
                }
            } else {
                // Only undo it if it's still what we set.
                if (nm.currentInterruptionFilter == NotificationManager.INTERRUPTION_FILTER_PRIORITY) nm.setInterruptionFilter(NotificationManager.INTERRUPTION_FILTER_ALL)
                p.outsideSilenced = false
            }
        } catch (_: Exception) { }
    }

    fun canSilence(context: Context): Boolean = try {
        context.getSystemService(NotificationManager::class.java)?.isNotificationPolicyAccessGranted == true
    } catch (_: Exception) { false }
}

/** Choose up to four apps for Outside mode. */
class OutsidePinSheet(launcher: MainActivity, private val onDone: () -> Unit) : BottomSheet(launcher, "Pinned apps", dimBackground = true) {
    private val chosen = ArrayList(OutsidePins.current(launcher))
    private val list = LinearLayout(launcher).apply { orientation = LinearLayout.VERTICAL; setPadding(launcher.dpi(12), 0, launcher.dpi(12), launcher.dpi(12)) }

    init {
        body.addView(launcher.textView("Pick up to four. They sit at the bottom of Outside mode.", 14f, ui.textSecondary).apply {
            setPadding(launcher.dpi(26), 0, launcher.dpi(26), launcher.dpi(10))
        })
        body.addView(list)
        build()
    }

    private fun build() {
        list.removeAllViews()
        val apps = launcher.apps.drawerApps().filter { !it.isWorkProfile }
        val ordered = chosen.mapNotNull { launcher.apps[it] } + apps.filter { it.key !in chosen }
        ordered.forEach { e ->
            val on = e.key in chosen
            val row = LinearLayout(launcher).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(launcher.dpi(12), launcher.dpi(6), launcher.dpi(12), launcher.dpi(6))
                background = pressable(null, ui.cardPressed, launcher.dp(14f))
                isClickable = true
                contentDescription = launcher.apps.label(e)
                setOnClickListener {
                    launcher.haptic(it, HapticFeedbackConstants.CONTEXT_CLICK)
                    if (on) chosen.remove(e.key)
                    else if (chosen.size >= 4) { launcher.toast("Up to four apps"); return@setOnClickListener }
                    else chosen.add(e.key)
                    launcher.prefs.outsidePins = chosen.joinToString(",").ifEmpty { "," }
                    build()
                }
            }
            val img = android.widget.ImageView(launcher).apply { setImageBitmap(launcher.icons.appIconForDisplay(e, launcher.dpi(40))) }
            row.addView(img, llp(launcher.dpi(40), launcher.dpi(40)).apply { marginEnd = launcher.dpi(14) })
            row.addView(launcher.textView(launcher.apps.label(e), 16f, ui.text, if (on) Fonts.semibold else Fonts.regular, maxLines = 1), llp(0, WRAP, 1f))
            if (on) row.addView(launcher.iconImage(R.drawable.ic_check, ui.accent, 2), llp(launcher.dpi(24), launcher.dpi(24)))
            list.addView(row, llp(MATCH, launcher.dpi(56)))
        }
    }

    override fun close(animate: Boolean) {
        val wasClosing = closing
        super.close(animate)
        if (!wasClosing) onDone()
    }
}
