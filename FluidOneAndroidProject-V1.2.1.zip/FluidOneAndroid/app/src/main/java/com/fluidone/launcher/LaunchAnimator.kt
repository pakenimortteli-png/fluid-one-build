package com.fluidone.launcher

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.os.SystemClock
import android.view.View
import android.view.ViewGroup
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.roundToInt

/** The card that grows out of an icon when an app opens (and shrinks back if it can't). */
class MorphView(context: Context) : View(context) {
    val rect = RectF()
    var radius = 0f
    var color = Color.WHITE
    /** The icon's own plate colour; the card starts in it and turns into the app's splash colour. */
    var iconColor = Color.WHITE
    var bgAlpha = 0f
    var icon: Bitmap? = null
    var iconSize = 0f
    var iconAlpha = 1f
    /** 0..1: how much shadow the card casts while it is still small. */
    var elevationShadow = 0f
    private val bg = Paint(Paint.ANTI_ALIAS_FLAG)
    private val shadow = Paint(Paint.ANTI_ALIAS_FLAG)
    private val ip = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val dst = RectF()
    private val shadowRect = RectF()
    private var shadowBlur = 0f

    override fun onDraw(canvas: Canvas) {
        if (rect.isEmpty || width == 0) return
        val grown = ((rect.width() - 1f) / width).coerceIn(0f, 1f)
        if (bgAlpha > 0f) {
            val sh = elevationShadow * (1f - grown) * bgAlpha
            if (sh > 0.01f) {
                val blur = resources.displayMetrics.density * 16f
                if (blur != shadowBlur) { shadowBlur = blur; shadow.maskFilter = android.graphics.BlurMaskFilter(blur, android.graphics.BlurMaskFilter.Blur.NORMAL) }
                shadow.color = Color.argb((sh * 80).roundToInt().coerceIn(0, 255), 0, 0, 0)
                shadowRect.set(rect); shadowRect.offset(0f, resources.displayMetrics.density * 6f)
                canvas.drawRoundRect(shadowRect, radius, radius, shadow)
            }
            // The card starts in the icon's colour and turns into the app's splash colour as it grows.
            bg.color = blendColors(iconColor, color, clamp01(grown * 1.6f))
            bg.alpha = (bgAlpha * 255).roundToInt().coerceIn(0, 255)
            canvas.drawRoundRect(rect, radius, radius, bg)
        }
        val b = icon ?: return
        if (iconAlpha <= 0f) return
        ip.alpha = (iconAlpha * 255).roundToInt().coerceIn(0, 255)
        val cx = rect.centerX(); val cy = rect.centerY()
        dst.set(cx - iconSize / 2f, cy - iconSize / 2f, cx + iconSize / 2f, cy + iconSize / 2f)
        canvas.drawBitmap(b, null, dst, ip)
    }
}

/**
 * App open/close and unlock choreography.
 *
 * Opening ("Fluid One" style): the icon grows into a card in the app's splash colour while the home screen
 * zooms past and the wallpaper blurs. Just before the card fills the screen, the app is started without a
 * system animation, so its splash screen takes over from a card that already looks like it. This works the same
 * on every phone, because no other app's window has to be animated. If a phone plays its own animation anyway,
 * that is noticed from how long the launcher stays visible, and Fluid One switches to the phone's animation.
 *
 * Closing: with gestures, the app flies into its icon through the gesture nav contract (see [IconLanding]).
 * Otherwise the home screen eases back in towards the icon, which grows into place as if the app landed there.
 */
class LaunchAnimator(private val launcher: MainActivity) {
    private enum class State { IDLE, OPENING, HANDED_OFF, AWAY, RETURNING }

    private class Record(val key: String, val source: Int, val time: Long, val folderId: Long)

    private val morph get() = launcher.morphView
    private var state = State.IDLE
    private var record: Record? = null
    private var anim: ValueAnimator? = null
    private var homeAnim: ValueAnimator? = null
    private var hiddenSource: View? = null
    private var waitingIcon: IconView? = null
    private var unlockPrimed = false
    private var fluidHandoffAt = 0L
    private var pendingStart: (() -> Boolean)? = null
    private val handoff = Runnable { doHandoff() }
    /** Paused but never stopped after the app started: it is see-through (a dialog-style app), so clear the card. */
    private val coverCheck = Runnable { if (state == State.HANDED_OFF || state == State.OPENING) settleWithoutApp() }

    val isBusy get() = state == State.OPENING || state == State.RETURNING

    // ---- App launch ----------------------------------------------------------------------------------------

    /**
     * Starts the opening. [fluid] plays Fluid One's own card and calls [start] when the card is about to fill
     * the screen; otherwise [start] runs right away and the system animates the app window. [start] returns
     * false if the app could not be opened.
     */
    fun beginLaunch(entry: AppEntry?, iconRect: RectF?, source: Int, sourceView: View?, folderId: Long, fluid: Boolean, start: () -> Boolean) {
        cancelAll()
        val pivotX = iconRect?.centerX() ?: launcher.rootView.width / 2f
        val pivotY = iconRect?.centerY() ?: launcher.rootView.height / 2f
        record = entry?.let { Record(it.key, source, SystemClock.uptimeMillis(), folderId) }
        val home = launcher.contentLayer
        home.pivotX = pivotX
        home.pivotY = pivotY
        state = State.OPENING
        fluidHandoffAt = 0L
        if (!launcher.prefs.launchAnimations) {
            morph.visibility = View.GONE
            state = State.HANDED_OFF
            if (!start()) launchFailed()
            return
        }
        if (fluid && iconRect != null && entry != null) {
            val icon = launcher.icons.appIconForDisplay(entry, maxOf(launcher.iconSizePx, launcher.dpi(108)))
            val fallback = edgeColor(icon)
            val color = SplashColors.colorFor(launcher, entry.component, launcher.ui.dark) ?: fallback
            hiddenSource = sourceView
            (sourceView as? IconView)?.landingHidden = true
            if (sourceView !is IconView) sourceView?.alpha = 0f
            val end = RectF(0f, 0f, launcher.rootView.width.toFloat(), launcher.rootView.height.toFloat())
            val startRadius = iconRect.width() * IconShapes.cornerFraction(launcher.prefs.iconShape).coerceAtLeast(0.2f)
            val endRadius = Device.screenCornerRadius(launcher.rootView)
            val splashIcon = launcher.dp(108f)
            morph.icon = icon
            morph.color = color
            morph.iconColor = fallback
            morph.visibility = View.VISIBLE
            morph.elevationShadow = 1f
            pendingStart = start
            val spring = Spring(0.94f, 0.34f)
            anim = ValueAnimator.ofFloat(0f, 1f).apply {
                duration = spring.ms
                interpolator = spring
                addUpdateListener {
                    val p = it.animatedValue as Float
                    val q = clamp01(p)
                    lerpRect(morph.rect, iconRect, end, p)
                    morph.radius = lerp(startRadius, endRadius, q)
                    // The icon's own plate becomes the card: colour floods in from the icon outward.
                    morph.bgAlpha = clamp01(q * 3.2f)
                    morph.iconSize = lerp(iconRect.width(), splashIcon, q)
                    morph.iconAlpha = 1f
                    morph.invalidate()
                    applyHome(1f + 0.16f * p, 1f - clamp01(q * 1.6f), q)
                }
                addListener(endListener { if (state == State.OPENING) doHandoff() })
                start()
            }
            launcher.rootView.removeCallbacks(handoff)
            launcher.rootView.postDelayed(handoff, Motion.d(180))
        } else {
            // The system grows the app window out of the icon; the home screen eases back behind it, centred on
            // the icon, so both move as one.
            morph.visibility = View.GONE
            state = State.HANDED_OFF
            animateHome(Motion.d(300), Motion.decel) { p -> applyHome(1f + 0.08f * p, 1f - 0.4f * p, 0.6f * p) }
            if (!start()) launchFailed()
        }
    }

    private fun doHandoff() {
        launcher.rootView.removeCallbacks(handoff)
        val s = pendingStart ?: return
        pendingStart = null
        state = State.HANDED_OFF
        fluidHandoffAt = SystemClock.uptimeMillis()
        if (!s()) { fluidHandoffAt = 0L; launchFailed() }
    }

    /** The app could not be started: run the opening backwards right away. */
    fun launchFailed() {
        pendingStart = null
        launcher.rootView.removeCallbacks(handoff)
        playReturn(force = true)
    }

    fun onPaused() {
        if (state == State.HANDED_OFF || state == State.OPENING) {
            launcher.rootView.removeCallbacks(coverCheck)
            launcher.rootView.postDelayed(coverCheck, 1500)
        }
    }

    /**
     * The launcher's window was hidden. With Fluid One's opening, that happens when the system's transition ends:
     * almost at once if the phone honoured "no animation", or after its own animation if it didn't.
     */
    fun onWindowHidden() {
        if (state != State.HANDED_OFF || fluidHandoffAt <= 0L) return
        launcher.onFluidLaunchTiming(SystemClock.uptimeMillis() - fluidHandoffAt)
        fluidHandoffAt = 0L
    }

    fun onStopped() {
        launcher.rootView.removeCallbacks(coverCheck)
        // Left before the app was started (Home pressed during the opening): don't open it after all.
        if (state == State.OPENING) { cancelAll(); return }
        if (state == State.HANDED_OFF) {
            fluidHandoffAt = 0L
            anim?.cancel(); homeAnim?.cancel()
            // The app now covers the screen. Get the home screen ready for the way back: slightly zoomed in,
            // with the icon missing so the app can land in its place.
            morph.visibility = View.GONE
            morph.rect.setEmpty()
            morph.icon = null
            restoreSource()
            state = State.AWAY
            val target = currentTarget()
            target?.second?.let { launcher.contentLayer.pivotX = it.centerX(); launcher.contentLayer.pivotY = it.centerY() }
            applyHome(1.05f, 1f, 0f)
            if (launcher.prefs.launchAnimations && launcher.prefs.returnAnim) {
                (target?.first as? IconView)?.let { it.landingHidden = true; waitingIcon = it }
            }
        }
    }

    /** The launcher is visible again. */
    fun onResumed() {
        launcher.rootView.removeCallbacks(coverCheck)
        if (unlockPrimed && !launcher.isKeyguardLocked()) { revealWaitingIcon(false); playUnlock(); return }
        if (state == State.AWAY || state == State.HANDED_OFF || state == State.OPENING) playReturn()
        else revealWaitingIcon(false)
    }

    /** Puts the home screen at rest so the icon's real position can be measured for a swipe-home landing. */
    fun prepareForLanding() {
        anim?.cancel(); homeAnim?.cancel()
        launcher.contentLayer.scaleX = 1f; launcher.contentLayer.scaleY = 1f
    }

    /**
     * Swipe-home answered through the gesture nav contract: the system flies the app into [view]. Settle the home
     * screen around it; the icon itself comes back when the app has landed ([onLanded]).
     */
    fun onGestureLanding(view: View?, rect: RectF) {
        anim?.cancel(); homeAnim?.cancel()
        morph.visibility = View.GONE
        restoreSource()
        if (waitingIcon !== view) revealWaitingIcon(false)
        waitingIcon = null
        launcher.contentLayer.pivotX = rect.centerX()
        launcher.contentLayer.pivotY = rect.centerY()
        state = State.RETURNING
        // The icon is the pivot, so the home screen can ease in around it without moving the landing spot.
        val fromScale = 1.05f
        val spring = Spring(0.9f, 0.46f)
        animateHome(spring.ms, spring) { p -> applyHome(lerp(fromScale, 1f, p), 1f, 0f) }
        launcher.rootView.postDelayed({ if (state == State.RETURNING) finishReturn() }, spring.ms + 20)
    }

    /** The app has landed on its icon: a soft squash, like something set down. */
    fun onLanded(view: View?) {
        val v = view ?: return
        if (!launcher.prefs.launchAnimations) return
        v.scaleX = 0.92f; v.scaleY = 0.92f
        val s = Spring(0.55f, 0.32f)
        v.animate().scaleX(1f).scaleY(1f).setDuration(s.ms).setInterpolator(s).start()
        ripple(v, 0.96f)
    }

    /** Translucent app or failed launch: no stop happened, so quietly restore the home screen. */
    private fun settleWithoutApp() {
        anim?.cancel()
        pendingStart = null
        val from = morph.bgAlpha
        val fromIcon = morph.iconAlpha
        val fromScale = launcher.contentLayer.scaleX
        val fromAlpha = launcher.contentLayer.alpha
        anim = Motion.animate(260, Motion.decel, update = { p ->
            morph.bgAlpha = from * (1 - p); morph.iconAlpha = fromIcon * (1 - p); morph.invalidate()
            applyHome(lerp(fromScale, 1f, p), lerp(fromAlpha, 1f, p), 1 - p)
        }, end = { finishReturn() })
        state = State.RETURNING
    }

    private fun currentTarget(): Pair<View?, RectF>? {
        val rec = record ?: return null
        if (SystemClock.uptimeMillis() - rec.time > 6 * 3600_000L) return null
        return launcher.findLaunchTarget(rec.key, rec.source, rec.folderId)
    }

    private fun playReturn(force: Boolean = false) {
        anim?.cancel()
        launcher.rootView.removeCallbacks(handoff)
        if (launcher.iconLanding.isActive) return   // the system is flying the app into its icon
        val wasOpening = morph.visibility == View.VISIBLE && !morph.rect.isEmpty
        state = State.RETURNING
        val target = currentTarget()
        val targetRect = target?.second
        if (wasOpening && force && targetRect != null) {
            // The app never opened: the card shrinks straight back into the icon.
            val start = RectF(morph.rect)
            val startRadius = morph.radius
            val endRadius = targetRect.width() * IconShapes.cornerFraction(launcher.prefs.iconShape).coerceAtLeast(0.2f)
            val startIcon = morph.iconSize
            val fromScale = launcher.contentLayer.scaleX
            val fromAlpha = launcher.contentLayer.alpha
            val spring = Spring(0.86f, 0.36f)
            anim = ValueAnimator.ofFloat(0f, 1f).apply {
                duration = spring.ms
                interpolator = spring
                addUpdateListener {
                    val p = it.animatedValue as Float
                    lerpRect(morph.rect, start, targetRect, p)
                    morph.radius = lerp(startRadius, endRadius, clamp01(p))
                    morph.bgAlpha = 1f - clamp01(p * 1.4f)
                    morph.iconSize = lerp(startIcon, targetRect.width(), p)
                    morph.invalidate()
                    applyHome(lerp(fromScale, 1f, p), lerp(fromAlpha, 1f, clamp01(p * 1.6f)), 1f - clamp01(p * 1.3f))
                }
                addListener(endListener { finishReturn() })
                start()
            }
            return
        }
        morph.visibility = View.GONE
        restoreSource()
        if (!launcher.prefs.launchAnimations && !force) { revealWaitingIcon(false); finishReturn(); return }
        // Closing: the home screen eases back in towards the icon the app came from, and the icon grows into
        // place as if the app had just landed there. Its neighbours make room with a small ripple.
        targetRect?.let { launcher.contentLayer.pivotX = it.centerX(); launcher.contentLayer.pivotY = it.centerY() }
        val fromAlpha = launcher.contentLayer.alpha.coerceAtMost(1f)
        val fromScale = launcher.contentLayer.scaleX.takeIf { it > 1.001f } ?: 1.05f
        val spring = Spring(0.9f, 0.42f)
        animateHome(spring.ms, spring) { p ->
            applyHome(lerp(fromScale, 1f, p), lerp(fromAlpha, 1f, clamp01(p * 1.5f)), (1f - p) * 0.25f * (fromScale - 1f) * 20f)
        }
        val icon = target?.first
        if (launcher.prefs.returnAnim && icon != null) {
            if (icon is IconView) icon.landingHidden = false
            if (icon === waitingIcon || icon is IconView) {
                icon.scaleX = 0.4f; icon.scaleY = 0.4f; icon.alpha = 0f
                val pop = Spring(0.62f, 0.38f)
                icon.animate().scaleX(1f).scaleY(1f).alpha(1f).setStartDelay(Motion.d(40)).setDuration(pop.ms).setInterpolator(pop)
                    .withEndAction { icon.scaleX = 1f; icon.scaleY = 1f; icon.alpha = 1f }.start()
            }
            ripple(icon, 0.92f)
        }
        revealWaitingIcon(false)
        launcher.rootView.postDelayed({ if (state == State.RETURNING) finishReturn() }, spring.ms + 20)
    }

    private fun revealWaitingIcon(animate: Boolean) {
        val v = waitingIcon ?: return
        waitingIcon = null
        v.landingHidden = false
        if (!animate) { v.alpha = 1f }
    }

    private fun restoreSource() {
        (hiddenSource as? IconView)?.landingHidden = false
        hiddenSource?.alpha = 1f
        hiddenSource = null
    }

    private fun finishReturn() {
        morph.visibility = View.GONE
        morph.rect.setEmpty()
        morph.icon = null
        restoreSource()
        revealWaitingIcon(false)
        applyHome(1f, 1f, 0f)
        state = State.IDLE
        record = null
    }

    private fun ripple(center: View?, from: Float) {
        if (center == null || launcher.prefs.animSpeed <= 0) return
        val parent = center.parent as? ViewGroup ?: return
        val cx = center.left + center.width / 2f
        val cy = center.top + center.height / 2f
        val maxD = hypot(parent.width.toFloat(), parent.height.toFloat()).coerceAtLeast(1f)
        for (i in 0 until parent.childCount) {
            val v = parent.getChildAt(i)
            if (v === center || v.visibility != View.VISIBLE) continue
            val d = hypot(v.left + v.width / 2f - cx, v.top + v.height / 2f - cy)
            // Closer neighbours are pushed a little more, and move first.
            val k = 1f - (d / maxD).coerceIn(0f, 1f)
            val s = 1f - (1f - from) * (0.4f + 0.6f * k)
            v.scaleX = s; v.scaleY = s
            val spring = Spring(0.66f, 0.42f)
            v.animate().scaleX(1f).scaleY(1f).setStartDelay(Motion.d((d / maxD * 140).toLong()))
                .setDuration(spring.ms).setInterpolator(spring).start()
        }
    }

    private fun applyHome(scale: Float, alpha: Float, blur: Float) {
        val home = launcher.contentLayer
        home.scaleX = scale; home.scaleY = scale
        home.alpha = alpha.coerceIn(0f, 1f)
        launcher.wallpaperView.zoom = 1f + (scale - 1f) * 0.45f
        if (blur > 0.002f) launcher.backdrop.set(this, (blur * 0.7f).coerceAtMost(0.7f), blur * 0.12f) else launcher.backdrop.clear(this)
    }

    private fun animateHome(ms: Long, interp: android.animation.TimeInterpolator, update: (Float) -> Unit) {
        homeAnim?.cancel()
        homeAnim = Motion.animate(ms, interp, update = update)
    }

    fun cancelAll() {
        anim?.cancel(); homeAnim?.cancel()
        pendingStart = null
        launcher.rootView.removeCallbacks(coverCheck)
        launcher.rootView.removeCallbacks(handoff)
        if (state != State.IDLE) finishReturn()
        revealWaitingIcon(false)
    }

    /** Called when another app covered the launcher by other means (e.g. Home pressed while opening). */
    fun reset() = cancelAll()

    // ---- Unlock --------------------------------------------------------------------------------------------

    /** The screen turned off while home was showing: hide the content so the unlock can reveal it. */
    fun primeUnlock() {
        if (launcher.prefs.unlockAnim == "off" || state != State.IDLE || launcher.isDrawerOpen || launcher.isEditing) return
        unlockPrimed = true
        launcher.contentLayer.alpha = 0f
        launcher.wallpaperView.zoom = 1.12f
    }

    val isUnlockPrimed get() = unlockPrimed

    fun playUnlock() {
        if (!unlockPrimed || !launcher.wallpaperView.hasWallpaper) return
        unlockPrimed = false
        playEntrance(launcher.prefs.unlockAnim)
    }

    /** Entrance used for unlock and first start. */
    fun playEntrance(style: String) {
        val home = launcher.contentLayer
        homeAnim?.cancel()
        home.scaleX = 1f; home.scaleY = 1f
        if (style == "off") { home.alpha = 1f; launcher.wallpaperView.zoom = 1f; launcher.backdrop.clear(this); return }
        val wall = launcher.wallpaperView
        val startZoom = max(wall.zoom, 1.1f)
        Motion.animate(680, Motion.emphasized, update = { p -> wall.zoom = lerp(startZoom, 1f, p) })
        val blurSpring = Spring(1f, 0.34f)
        Motion.animate(blurSpring.durationMs, blurSpring, update = { p ->
            if (p >= 0.999f) launcher.backdrop.clear(this) else launcher.backdrop.set(this, (1 - p) * 0.8f, 0f)
        })
        val views = launcher.entranceViews()
        val w = launcher.rootView.width.toFloat()
        val h = launcher.rootView.height.toFloat()
        val cx = w / 2f
        val cy = h * 0.45f
        val maxD = hypot(w, h) / 2f
        when (style) {
            "oneui" -> {
                // One UI: the whole home screen settles in from slightly larger, quickly and together.
                home.alpha = 0f
                home.pivotX = cx; home.pivotY = h * 0.5f
                val spring = Spring(0.95f, 0.36f)
                Motion.animate(spring.durationMs, spring, update = { p ->
                    val s = lerp(1.08f, 1f, p)
                    home.scaleX = s; home.scaleY = s
                    home.alpha = clamp01(p * 2.2f)
                })
            }
            "coloros" -> {
                // ColorOS: icons float up from a little below while growing from 82%, nearest to the middle first.
                home.alpha = 1f
                views.forEach { (v, r) ->
                    val d = hypot(r.centerX() - cx, r.centerY() - cy) / maxD
                    v.alpha = 0f; v.translationY = launcher.dp(28f); v.scaleX = 0.82f; v.scaleY = 0.82f
                    val spring = Spring(0.82f, 0.46f)
                    v.animate().alpha(1f).translationY(0f).scaleX(1f).scaleY(1f).setStartDelay(Motion.d((d * 120).toLong()))
                        .setDuration(spring.ms).setInterpolator(spring)
                        .withEndAction { v.alpha = 1f; v.translationY = 0f; v.scaleX = 1f; v.scaleY = 1f }.start()
                }
            }
            "hyperos" -> {
                // HyperOS: icons drop in from above, row by row, with a soft bounce.
                home.alpha = 1f
                views.forEach { (v, r) ->
                    val row = r.centerY() / h
                    v.alpha = 0f; v.translationY = -launcher.dp(56f)
                    val spring = Spring(0.62f, 0.5f)
                    v.animate().alpha(1f).translationY(0f).setStartDelay(Motion.d((row * 160).toLong()))
                        .setDuration(spring.ms).setInterpolator(spring)
                        .withEndAction { v.alpha = 1f; v.translationY = 0f }.start()
                }
            }
            "ripple" -> {
                // Ripple: icons pop up in a wave that spreads from the middle of the screen.
                home.alpha = 1f
                views.forEach { (v, r) ->
                    val d = hypot(r.centerX() - cx, r.centerY() - cy) / maxD
                    v.alpha = 0f; v.scaleX = 0.4f; v.scaleY = 0.4f
                    val spring = Spring(0.58f, 0.42f)
                    v.animate().alpha(1f).scaleX(1f).scaleY(1f).setStartDelay(Motion.d((d * 240).toLong()))
                        .setDuration(spring.ms).setInterpolator(spring)
                        .withEndAction { v.alpha = 1f; v.scaleX = 1f; v.scaleY = 1f }.start()
                }
            }
            "zoom" -> {
                home.alpha = 0f
                home.pivotX = cx; home.pivotY = cy
                val spring = Spring(0.85f, 0.5f)
                Motion.animate(spring.durationMs, spring, update = { p ->
                    val s = lerp(1.18f, 1f, p)
                    home.scaleX = s; home.scaleY = s
                    home.alpha = clamp01(p * 2f)
                })
            }
            "rise" -> {
                home.alpha = 1f
                views.forEach { (v, r) ->
                    v.alpha = 0f
                    v.translationY = launcher.dp(70f)
                    val row = (r.centerY() / h)
                    val spring = Spring(0.8f, 0.5f)
                    v.animate().alpha(1f).translationY(0f).setStartDelay(Motion.d((row * 140).toLong()))
                        .setDuration(spring.ms).setInterpolator(spring).start()
                }
            }
            else -> { // gather
                home.alpha = 1f
                views.forEach { (v, r) ->
                    val dx = r.centerX() - cx
                    val dy = r.centerY() - cy
                    val d = hypot(dx, dy) / maxD
                    v.alpha = 0f
                    v.translationX = dx * 0.42f
                    v.translationY = dy * 0.42f
                    v.scaleX = 1.36f; v.scaleY = 1.36f
                    val spring = Spring(0.8f, 0.52f)
                    v.animate().alpha(1f).translationX(0f).translationY(0f).scaleX(1f).scaleY(1f)
                        .setStartDelay(Motion.d((d * 90).toLong()))
                        .setDuration(spring.ms).setInterpolator(spring)
                        .withEndAction { v.alpha = 1f; v.translationX = 0f; v.translationY = 0f; v.scaleX = 1f; v.scaleY = 1f }
                        .start()
                }
            }
        }
    }

    fun cancelUnlockPrime() {
        if (!unlockPrimed) return
        unlockPrimed = false
        launcher.contentLayer.alpha = 1f
        launcher.wallpaperView.zoom = 1f
    }

    companion object {
        fun lerpRect(out: RectF, a: RectF, b: RectF, t: Float) {
            out.set(lerp(a.left, b.left, t), lerp(a.top, b.top, t), lerp(a.right, b.right, t), lerp(a.bottom, b.bottom, t))
        }

        /** Colour of an icon's background layer, sampled just inside its left edge. */
        fun edgeColor(icon: Bitmap): Int {
            val x = (icon.width * 0.16f).roundToInt().coerceIn(0, icon.width - 1)
            val y = (icon.height * 0.5f).roundToInt().coerceIn(0, icon.height - 1)
            val c = icon.getPixel(x, y)
            return if (Color.alpha(c) < 200) IconFactory.averageColor(icon) else c or 0xFF000000.toInt()
        }

        private fun endListener(block: () -> Unit) = object : android.animation.AnimatorListenerAdapter() {
            private var cancelled = false
            override fun onAnimationCancel(animation: android.animation.Animator) { cancelled = true }
            override fun onAnimationEnd(animation: android.animation.Animator) { if (!cancelled) block() }
        }
    }
}
