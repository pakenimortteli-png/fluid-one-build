package com.fluidone.launcher

import android.animation.ValueAnimator
import android.app.ActivityManager
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.os.Build
import android.os.Environment
import android.os.StatFs
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.widget.LinearLayout
import java.util.Locale
import kotlin.math.cos
import kotlin.math.roundToInt
import kotlin.math.sin

/**
 * The banner at the top of About, in the style of ColorOS's "About device": a big rounded card with soft colour
 * light drifting behind large, glossy version numbers. Tap it for a sweep of light.
 */
class AboutBanner(private val launcher: MainActivity) : View(launcher) {
    private val version = launcher.versionName().substringBefore('-')
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val text = Paint(Paint.ANTI_ALIAS_FLAG).apply { typeface = Fonts.bold }
    private val card = RectF()
    private val clip = Path()
    private var t = 0f
    private var sheen = -1f
    private var taps = 0
    private val drift = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = 16000; repeatCount = ValueAnimator.INFINITE; interpolator = null
        addUpdateListener { t = it.animatedValue as Float; invalidate() }
    }

    init {
        isClickable = true
        contentDescription = "Fluid One $version"
    }

    override fun onAttachedToWindow() { super.onAttachedToWindow(); if (ValueAnimator.areAnimatorsEnabled()) drift.start() }
    override fun onDetachedFromWindow() { drift.cancel(); super.onDetachedFromWindow() }

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        val d = resources.displayMetrics.density
        card.set(0f, 0f, w, h)
        val r = 28f * d
        clip.reset(); clip.addRoundRect(card, r, r, Path.Direction.CW)
        canvas.save()
        canvas.clipPath(clip)
        val dark = launcher.ui.dark
        // A soft base, then three colour lights slowly circling.
        paint.shader = LinearGradient(0f, 0f, w, h,
            if (dark) intArrayOf(Color.rgb(20, 28, 52), Color.rgb(16, 22, 40)) else intArrayOf(Color.rgb(226, 238, 255), Color.rgb(240, 236, 252)), null, Shader.TileMode.CLAMP)
        canvas.drawRect(card, paint)
        val a = t * 2f * Math.PI.toFloat()
        val lights = listOf(
            Triple(0.25f + 0.08f * cos(a), 0.3f + 0.1f * sin(a), Color.rgb(90, 160, 255)),
            Triple(0.75f + 0.08f * sin(a), 0.35f + 0.12f * cos(a), Color.rgb(120, 220, 200)),
            Triple(0.55f + 0.12f * cos(a + 2f), 0.85f + 0.08f * sin(a + 1f), Color.rgb(255, 170, 140))
        )
        for ((fx, fy, col) in lights) {
            val cx = fx * w; val cy = fy * h; val rad = h * 0.95f
            paint.shader = RadialGradient(cx, cy, rad, intArrayOf(withAlpha(col, if (dark) 0.55f else 0.6f), withAlpha(col, 0f)), null, Shader.TileMode.CLAMP)
            canvas.drawCircle(cx, cy, rad, paint)
        }
        // The version, big and glossy.
        val ink = if (dark) Color.WHITE else Color.rgb(24, 34, 64)
        text.textAlign = Paint.Align.LEFT
        text.textSize = 15f * d
        text.shader = null
        text.color = withAlpha(ink, 0.75f)
        text.letterSpacing = 0.08f
        canvas.drawText("FLUID ONE", 24f * d, 40f * d, text)
        text.letterSpacing = -0.02f
        text.textSize = h * 0.52f
        val baseline = h - 28f * d
        val top = baseline + text.ascent() * 0.72f
        // Soft shadow, then the numbers in a top-to-bottom gloss.
        text.color = withAlpha(if (dark) Color.BLACK else Color.rgb(60, 90, 160), 0.18f)
        canvas.drawText(version, 22f * d, baseline + 4f * d, text)
        text.color = Color.WHITE
        text.shader = LinearGradient(0f, top, 0f, baseline,
            if (dark) intArrayOf(Color.WHITE, Color.rgb(170, 200, 255)) else intArrayOf(Color.rgb(40, 70, 160), Color.rgb(90, 140, 230)), null, Shader.TileMode.CLAMP)
        canvas.drawText(version, 22f * d, baseline, text)
        text.shader = null
        text.letterSpacing = 0f
        // A sweep of light after a tap.
        if (sheen > -1f && sheen < 2f) {
            val cx = sheen * w
            paint.shader = LinearGradient(cx - w * 0.25f, 0f, cx + w * 0.25f, h,
                intArrayOf(Color.TRANSPARENT, Color.argb(90, 255, 255, 255), Color.TRANSPARENT), null, Shader.TileMode.CLAMP)
            canvas.drawRect(card, paint)
        }
        paint.shader = null
        canvas.restore()
        paint.style = Paint.Style.STROKE; paint.strokeWidth = d
        paint.color = if (dark) Color.argb(40, 255, 255, 255) else Color.argb(90, 255, 255, 255)
        canvas.drawRoundRect(card.left + d / 2, card.top + d / 2, card.right - d / 2, card.bottom - d / 2, r, r, paint)
        paint.style = Paint.Style.FILL
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> animate().scaleX(0.97f).scaleY(0.97f).setDuration(Motion.d(120)).start()
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                val s = Spring(0.5f, 0.4f)
                animate().scaleX(1f).scaleY(1f).setDuration(s.ms).setInterpolator(s).start()
                if (event.actionMasked == MotionEvent.ACTION_UP) {
                    performHapticFeedback(HapticFeedbackConstants.CONTEXT_CLICK)
                    Motion.animate(900, Motion.emphasized, update = { sheen = -0.3f + 1.6f * it; invalidate() }, end = { sheen = -1f; invalidate() })
                    if (++taps == 7) { taps = 0; launcher.toast("You found the glass. Nothing else here, promise.") }
                }
            }
        }
        return true
    }
}

/** One device fact on a card, optionally with a usage ring (storage, memory). */
class InfoTile(private val launcher: MainActivity, private val title: String, private val value: String, private val detail: String, private val used: Float = -1f) : View(launcher) {
    private val ui = launcher.ui
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val text = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rect = RectF()
    private var shown = 0f

    init {
        contentDescription = "$title: $value, $detail"
        if (used >= 0f) Motion.animate(900, Motion.emphasized, update = { shown = it * used; invalidate() })
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        setMeasuredDimension(MeasureSpec.getSize(widthMeasureSpec), (96 * resources.displayMetrics.density).roundToInt())
    }

    override fun onDraw(canvas: Canvas) {
        val d = resources.displayMetrics.density
        rect.set(0f, 0f, width.toFloat(), height.toFloat())
        paint.color = ui.card
        canvas.drawRoundRect(rect, 20f * d, 20f * d, paint)
        val pad = 16f * d
        text.typeface = Fonts.medium; text.textSize = 12.5f * d; text.color = ui.textSecondary
        canvas.drawText(title, pad, pad + 10f * d, text)
        text.typeface = Fonts.semibold; text.textSize = 19f * d; text.color = ui.text
        val maxW = width - pad * 2 - if (used >= 0f) 44f * d else 0f
        canvas.drawText(ellipsize(value, maxW), pad, pad + 40f * d, text)
        text.typeface = Fonts.regular; text.textSize = 12f * d; text.color = ui.textSecondary
        canvas.drawText(ellipsize(detail, width - pad * 2), pad, pad + 62f * d, text)
        if (used >= 0f) {
            val cx = width - pad - 18f * d; val cy = pad + 30f * d; val rr = 16f * d
            paint.style = Paint.Style.STROKE; paint.strokeWidth = 5f * d; paint.strokeCap = Paint.Cap.ROUND
            paint.color = ui.chip
            canvas.drawCircle(cx, cy, rr, paint)
            paint.color = if (used > 0.9f) ui.danger else ui.accent
            canvas.drawArc(cx - rr, cy - rr, cx + rr, cy + rr, -90f, 360f * shown, false, paint)
            paint.style = Paint.Style.FILL
        }
    }

    private fun ellipsize(s: String, max: Float): String {
        if (text.measureText(s) <= max) return s
        var e = s
        while (e.length > 1 && text.measureText("$e…") > max) e = e.dropLast(1)
        return "$e…"
    }
}

object DeviceInfo {
    private fun gb(bytes: Long) = String.format(Locale.getDefault(), if (bytes >= 10L * 1024 * 1024 * 1024) "%.0f GB" else "%.1f GB", bytes / 1_073_741_824.0)

    /** The About page's grid: device, Android, storage, memory, processor, display. */
    fun tiles(launcher: MainActivity): View {
        val col = LinearLayout(launcher).apply { orientation = LinearLayout.VERTICAL }
        val list = ArrayList<View>()
        val name = Build.MODEL.orEmpty().let { m -> if (m.startsWith(Build.MANUFACTURER.orEmpty(), ignoreCase = true)) m else "${Build.MANUFACTURER.orEmpty().replaceFirstChar { it.uppercase() }} $m" }
        list += InfoTile(launcher, "Device", name.trim().ifEmpty { "Android phone" }, launcher.brand.system)
        list += InfoTile(launcher, "Android", "Android ${Build.VERSION.RELEASE}", "Security patch ${Build.VERSION.SECURITY_PATCH}")
        val stat = try { StatFs(Environment.getDataDirectory().path) } catch (_: Exception) { null }
        if (stat != null) {
            val total = stat.totalBytes; val free = stat.availableBytes
            list += InfoTile(launcher, "Storage", gb(total - free), "used of ${gb(total)}", ((total - free).toFloat() / total.coerceAtLeast(1)).coerceIn(0f, 1f))
        }
        val mi = ActivityManager.MemoryInfo().also { launcher.getSystemService(ActivityManager::class.java)?.getMemoryInfo(it) }
        if (mi.totalMem > 0) list += InfoTile(launcher, "Memory", gb(mi.totalMem - mi.availMem), "in use of ${gb(mi.totalMem)}", ((mi.totalMem - mi.availMem).toFloat() / mi.totalMem).coerceIn(0f, 1f))
        val soc = if (Build.VERSION.SDK_INT >= 31) Build.SOC_MODEL.orEmpty().takeIf { it.isNotBlank() && it != "unknown" } else null
        list += InfoTile(launcher, "Processor", soc ?: Build.HARDWARE.orEmpty().ifEmpty { "Unknown" }, "${Runtime.getRuntime().availableProcessors()} cores")
        val dm = launcher.resources.displayMetrics
        val hz = Device.maxRefreshRate(launcher).roundToInt()
        list += InfoTile(launcher, "Display", "${maxOf(dm.widthPixels, dm.heightPixels)} × ${minOf(dm.widthPixels, dm.heightPixels)}", "Up to $hz Hz")
        list.chunked(2).forEach { pair ->
            val row = LinearLayout(launcher).apply { orientation = LinearLayout.HORIZONTAL }
            pair.forEachIndexed { i, v -> row.addView(v, llp(0, WRAP, 1f).apply { if (i == 0) marginEnd = launcher.dpi(10) }) }
            if (pair.size == 1) row.addView(View(launcher), llp(0, 1, 1f))
            col.addView(row, llp(MATCH, WRAP).apply { bottomMargin = launcher.dpi(10) })
        }
        return col
    }
}
