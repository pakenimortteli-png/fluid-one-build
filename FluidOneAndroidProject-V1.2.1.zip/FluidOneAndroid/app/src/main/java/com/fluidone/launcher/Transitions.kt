package com.fluidone.launcher

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.PorterDuff
import android.graphics.RectF
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.Message
import android.os.Messenger
import android.os.UserHandle
import android.view.Gravity
import android.view.SurfaceHolder
import android.view.SurfaceView
import android.view.ViewGroup
import android.widget.FrameLayout
import kotlin.math.roundToInt

/*
 * How app open and close animations work for a home app that isn't the phone's built-in launcher.
 *
 * Opening: since Android 12, only the built-in launcher may animate another app's window (custom task animations
 * need a system permission). So Fluid One draws the opening itself: the icon grows into a card in the app's own
 * splash colour, and the app is started with FLAG_ACTIVITY_NO_ANIMATION just as the card fills the screen. The
 * app's splash screen then takes over from a card that already looks like it.
 *
 * Closing with gestures: the swipe-home gesture is run by the built-in launcher's gesture code even when another
 * home app is set (AOSP's FallbackSwipeHandler, which Pixel, LineageOS and One UI Home all use). It sends the home
 * app a "gesture nav contract": which app is closing, plus a reply address. If the home app answers with the icon's
 * position and a surface that shows the icon, the closing window springs into that icon. Without an answer the
 * window shrinks towards the bottom of the screen and fades out, which is what Fluid One 1.2 did.
 */

/** The gesture nav contract (AOSP Launcher3's GestureNavContract, protocol v1). */
class GestureContract private constructor(
    val component: ComponentName,
    val user: UserHandle,
    private val callback: Message
) {
    /** Tells the gesture handler where the app should land and which surface to move along with it. */
    fun reply(position: RectF, surface: android.view.SurfaceControl?, onFinish: Message) {
        val data = Bundle()
        data.putParcelable(EXTRA_ICON_POSITION, position)
        data.putParcelable(EXTRA_ICON_SURFACE, surface)
        data.putParcelable(EXTRA_ON_FINISH_CALLBACK, onFinish)
        val msg = Message.obtain()
        msg.copyFrom(callback)
        msg.data = data
        try { callback.replyTo.send(msg) } catch (_: Exception) { }
    }

    companion object {
        const val EXTRA_GESTURE_CONTRACT = "gesture_nav_contract_v1"
        const val EXTRA_ICON_POSITION = "gesture_nav_contract_icon_position"
        const val EXTRA_ICON_SURFACE = "gesture_nav_contract_surface_control"
        const val EXTRA_REMOTE_CALLBACK = "android.intent.extra.REMOTE_CALLBACK"
        const val EXTRA_ON_FINISH_CALLBACK = "gesture_nav_contract_finish_callback"

        /** Reads and removes the contract from a home intent, or returns null if there is none. */
        @Suppress("DEPRECATION")
        fun from(intent: Intent?): GestureContract? {
            if (intent == null) return null
            return try {
                val extras = intent.getBundleExtra(EXTRA_GESTURE_CONTRACT) ?: return null
                intent.removeExtra(EXTRA_GESTURE_CONTRACT)
                val component = extras.getParcelable<ComponentName>(Intent.EXTRA_COMPONENT_NAME)
                val user = extras.getParcelable<UserHandle>(Intent.EXTRA_USER)
                val callback = extras.getParcelable<Message>(EXTRA_REMOTE_CALLBACK)
                if (component != null && user != null && callback?.replyTo != null) GestureContract(component, user, callback) else null
            } catch (_: Exception) { null }
        }
    }
}

/** Where a closing app lands: a rectangle on screen, how to draw what is there, and how to hide the real thing. */
class LandingTarget(
    val rect: RectF,
    val draw: (Canvas, Int, Int) -> Unit,
    val setHidden: (Boolean) -> Unit,
    val view: android.view.View?
)

/**
 * Answers the gesture nav contract: puts a small surface showing the icon exactly over it, hides the real icon,
 * and sends the icon's position. The gesture handler moves the surface with the shrinking app window, so the
 * window turns into the icon as it lands. When the handler says it is done, the real icon comes back.
 */
class IconLanding(private val launcher: MainActivity) : SurfaceHolder.Callback {
    private val main = Handler(Looper.getMainLooper())
    private val messenger = Messenger(Handler(Looper.getMainLooper()) { msg ->
        if (msg.what == MSG_FINISHED) { android.util.Log.i("FluidOne", "Landing finished"); finish(landed = true); true } else false
    })
    private var contract: GestureContract? = null
    private var target: LandingTarget? = null
    private var surfaceView: SurfaceView? = null
    private val timeout = Runnable { finish(landed = true) }

    /** True while an app is flying into its icon. */
    val isActive: Boolean get() = contract != null

    /** Number of contracts answered (shown in Settings › Animations so you can tell it works on your phone). */
    var answered = 0
        private set

    /** Returns true if the contract was answered (an icon for the app is on screen). */
    fun handle(c: GestureContract): Boolean {
        finish(landed = false)
        val t = launcher.findCloseTarget(c.component, c.user)
        android.util.Log.i("FluidOne", "Swipe home from ${c.component.flattenToShortString()}: " + if (t != null) "landing at ${t.rect.toShortString()}" else "icon not on screen")
        if (t == null) return false
        if (t.rect.width() < 2f || t.rect.height() < 2f) return false
        contract = c
        target = t
        launcher.animator.onGestureLanding(t.view, t.rect)
        val loc = IntArray(2)
        launcher.rootView.getLocationOnScreen(loc)
        val sv = SurfaceView(launcher)
        sv.setZOrderOnTop(true)
        sv.holder.setFormat(PixelFormat.TRANSLUCENT)
        sv.holder.addCallback(this)
        val lp = FrameLayout.LayoutParams(t.rect.width().roundToInt().coerceAtLeast(1), t.rect.height().roundToInt().coerceAtLeast(1))
        lp.gravity = Gravity.TOP or Gravity.START
        lp.leftMargin = (t.rect.left - loc[0]).roundToInt()
        lp.topMargin = (t.rect.top - loc[1]).roundToInt()
        surfaceView = sv
        launcher.rootView.addView(sv, lp)
        t.setHidden(true)
        main.removeCallbacks(timeout)
        main.postDelayed(timeout, 1600)
        answered++
        return true
    }

    override fun surfaceCreated(holder: SurfaceHolder) { drawSurface(holder); send() }
    override fun surfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) { drawSurface(holder) }
    override fun surfaceDestroyed(holder: SurfaceHolder) {}

    private fun drawSurface(holder: SurfaceHolder) {
        val t = target ?: return
        val c = try { holder.lockHardwareCanvas() } catch (_: Exception) { null } ?: return
        try {
            c.drawColor(Color.TRANSPARENT, PorterDuff.Mode.CLEAR)
            t.draw(c, c.width, c.height)
        } catch (_: Exception) {
        } finally {
            try { holder.unlockCanvasAndPost(c) } catch (_: Exception) { }
        }
    }

    private fun send() {
        val c = contract ?: return
        val sv = surfaceView ?: return
        val t = target ?: return
        val done = Message.obtain()
        done.what = MSG_FINISHED
        done.replyTo = messenger
        c.reply(RectF(t.rect), sv.surfaceControl, done)
    }

    /** Ends the landing: shows the real icon again and removes the surface a frame later (no flicker). */
    fun finish(landed: Boolean) {
        main.removeCallbacks(timeout)
        val t = target
        val sv = surfaceView
        contract = null
        target = null
        surfaceView = null
        t?.setHidden(false)
        if (landed && t != null) launcher.animator.onLanded(t.view)
        if (sv != null) main.postDelayed({ (sv.parent as? ViewGroup)?.removeView(sv) }, 34)
    }

    companion object {
        private const val MSG_FINISHED = 0
    }
}

/** The colour of an app's splash screen, read from its theme, so the opening card matches what comes next. */
object SplashColors {
    private val cache = HashMap<String, Int>()

    fun colorFor(context: Context, component: ComponentName, dark: Boolean): Int? {
        val key = "${component.flattenToShortString()}|$dark"
        synchronized(cache) { cache[key]?.let { return if (it == 0) null else it } }
        val c = try { resolve(context, component) } catch (_: Throwable) { null }
        synchronized(cache) { cache[key] = c ?: 0 }
        return c
    }

    fun clear() = synchronized(cache) { cache.clear() }

    private fun attrColor(ctx: Context, attr: Int): Int? {
        val ta = ctx.obtainStyledAttributes(intArrayOf(attr))
        return try { if (ta.hasValue(0)) ta.getColor(0, 0).takeIf { Color.alpha(it) > 200 } else null } catch (_: Exception) { null } finally { ta.recycle() }
    }

    private fun resolve(context: Context, component: ComponentName): Int? {
        val pm = context.packageManager
        val info = pm.getActivityInfo(component, 0)
        val theme = info.themeResource
        val pc = context.createPackageContext(component.packageName, Context.CONTEXT_RESTRICTED)
        if (theme != 0) pc.setTheme(theme)
        attrColor(pc, android.R.attr.windowSplashScreenBackground)?.let { return it or 0xFF000000.toInt() }
        // The window background, but only when it is a plain colour: never decode another app's images here.
        val ta = pc.obtainStyledAttributes(intArrayOf(android.R.attr.windowBackground))
        try {
            val tv = android.util.TypedValue()
            if (ta.getValue(0, tv)) {
                if (tv.type >= android.util.TypedValue.TYPE_FIRST_COLOR_INT && tv.type <= android.util.TypedValue.TYPE_LAST_COLOR_INT) {
                    if (Color.alpha(tv.data) > 200) return tv.data or 0xFF000000.toInt()
                } else if (tv.resourceId != 0 && pc.resources.getResourceTypeName(tv.resourceId) == "color") {
                    val col = pc.resources.getColor(tv.resourceId, pc.theme)
                    if (Color.alpha(col) > 200) return col or 0xFF000000.toInt()
                }
            }
        } catch (_: Exception) {
        } finally { ta.recycle() }
        return attrColor(pc, android.R.attr.colorBackground)?.let { it or 0xFF000000.toInt() }
    }
}

object NavMode {
    /** True when the phone uses swipe gestures instead of the button bar. */
    fun isGesture(context: Context): Boolean = try {
        val cr = context.contentResolver
        android.provider.Settings.Secure.getInt(cr, "navigation_mode", 0) == 2 ||
            android.provider.Settings.Global.getInt(cr, "navigation_bar_gesture_while_hidden", 0) == 1
    } catch (_: Exception) { false }

    /** The system "Transition animation scale" (0 when animations are off). */
    fun transitionScale(context: Context): Float = try {
        android.provider.Settings.Global.getFloat(context.contentResolver, android.provider.Settings.Global.TRANSITION_ANIMATION_SCALE, 1f)
    } catch (_: Exception) { 1f }
}
