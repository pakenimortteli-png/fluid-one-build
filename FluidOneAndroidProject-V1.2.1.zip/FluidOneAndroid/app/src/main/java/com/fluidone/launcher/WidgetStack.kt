package com.fluidone.launcher

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.os.Bundle
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.VelocityTracker
import android.view.View
import android.view.ViewConfiguration
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.FrameLayout
import android.widget.LinearLayout
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.roundToInt

/**
 * A widget stack: several widgets in one spot. Swipe up or down on it to flip to the next one. The card you
 * swipe away slides back and shrinks a little while the next one rises in from the other side, and the dots on
 * the edge show where you are. Long-press for the stack's menu (add, edit, remove).
 */
class StackFrame(private val launcher: MainActivity) : FrameLayout(launcher) {
    var item: HomeItem? = null
    var onLongPress: ((View) -> Unit)? = null
    private val cards = ArrayList<View>()
    private var index = 0
    /** Drag progress in cards: +1 = one card further (swiped up), -1 = one back. */
    private var offset = 0f
    private var committing = false
    private val spring: SpringValue = SpringValue(0f) { v -> offset = v; layoutCards(); if (!springRunning()) commit() }
    private var dots = 0f
    private val dotsSpring = SpringValue(0f) { dots = it; invalidate() }
    private val hideDots = Runnable { dotsSpring.animateTo(0f, 160f, 1f) }
    private val detector = LongPressDetector(this) { onLongPress?.invoke(this) }
    private val slop = ViewConfiguration.get(launcher).scaledTouchSlop
    private var downX = 0f
    private var downY = 0f
    private var dragging = false
    private var startOffset = 0f
    private var tracker: VelocityTracker? = null
    private val dotPaint = Paint(Paint.ANTI_ALIAS_FLAG)

    init {
        clipChildren = false
        clipToPadding = false
        isChildrenDrawingOrderEnabled = true
        importantForAccessibility = IMPORTANT_FOR_ACCESSIBILITY_YES
    }

    private fun springRunning(): Boolean = spring.isRunning

    /** Shows [views] (one per widget in the stack), starting at [start]. */
    fun setCards(views: List<View>, start: Int) {
        cards.forEach { removeView(it) }
        cards.clear()
        views.forEach { v -> cards += v; addView(v, LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT)) }
        index = if (cards.isEmpty()) 0 else start.mod(cards.size)
        offset = 0f
        spring.snapTo(0f)
        layoutCards()
        contentDescription = "Widget stack, ${cards.size} widgets. Swipe up or down to switch."
    }

    fun cardViews(): List<View> = cards.toList()

    /** Re-applies every built-in widget's look and brings the stack's chosen widget to the front. */
    fun refreshAll() {
        cards.forEach { (it as? WidgetFrame)?.refreshContent() }
        item?.let { if (cards.isNotEmpty() && it.stackIndex.mod(cards.size) != index) showIndex(it.stackIndex) }
    }

    /** Flips to card [i] with the usual motion (the shorter way round). */
    fun showIndex(i: Int) {
        if (cards.isEmpty()) return
        val n = cards.size
        val target = i.mod(n)
        if (target == index) return
        var d = target - index
        if (d > n / 2) d -= n
        if (d < -n / 2) d += n
        if (abs(d) == 1 && ValueAnimatorCompat.enabled() && isAttachedToWindow) { flip(d > 0); return }
        index = target
        offset = 0f
        spring.snapTo(0f)
        layoutCards()
    }

    val currentIndex: Int get() = index
    val count: Int get() = cards.size
    fun currentCard(): View? = cards.getOrNull(index)

    /** Where card [i] sits relative to the front (0) for the current drag. */
    private fun rel(i: Int): Float {
        val n = cards.size
        if (n <= 1) return (i - index).toFloat() - offset
        val r = (i - index).mod(n).toFloat()
        val a = r - offset
        val b = r - n - offset
        return if (abs(a) <= abs(b)) a else b
    }

    private fun layoutCards() {
        val h = max(height, 1).toFloat()
        cards.forEachIndexed { i, v ->
            val p = rel(i)
            val a = abs(p)
            if (a >= 1f) { v.alpha = 0f; v.visibility = INVISIBLE; return@forEachIndexed }
            v.visibility = VISIBLE
            // Leaving cards slide back and shrink; the arriving card rises in from the other side.
            v.translationY = p * h * 0.38f
            val s = 1f - 0.12f * a
            v.scaleX = s; v.scaleY = s
            v.alpha = clamp01(1f - a * 1.25f)
            v.pivotY = if (p < 0f) h else 0f
        }
        invalidate()
    }

    override fun getChildDrawingOrder(childCount: Int, drawingPosition: Int): Int {
        // Draw the card nearest the front last, so it is on top.
        val order = (0 until childCount).sortedByDescending { c ->
            val idx = cards.indexOf(getChildAt(c))
            if (idx < 0) -1f else abs(rel(idx))
        }
        return order[drawingPosition]
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) { super.onSizeChanged(w, h, oldw, oldh); layoutCards() }

    // ---- Touch -----------------------------------------------------------------------------------------------

    override fun onInterceptTouchEvent(ev: MotionEvent): Boolean {
        if (detector.handle(ev)) return true
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downX = ev.rawX; downY = ev.rawY; dragging = false
                tracker?.recycle(); tracker = VelocityTracker.obtain(); tracker?.addMovement(ev)
                if (cards.size > 1) showDots()
            }
            MotionEvent.ACTION_MOVE -> {
                tracker?.addMovement(ev)
                val dx = ev.rawX - downX; val dy = ev.rawY - downY
                if (cards.size > 1 && abs(dy) > slop && abs(dy) > abs(dx) * 1.2f) {
                    startDrag(ev)
                    return true
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> scheduleHideDots()
        }
        return false
    }

    private fun startDrag(ev: MotionEvent) {
        dragging = true
        detector.cancel()
        parent?.requestDisallowInterceptTouchEvent(true)
        spring.stop()
        startOffset = offset
        downY = ev.rawY
        showDots()
    }

    override fun onTouchEvent(ev: MotionEvent): Boolean {
        detector.handle(ev)
        tracker?.addMovement(ev)
        when (ev.actionMasked) {
            MotionEvent.ACTION_MOVE -> {
                if (!dragging) {
                    val dx = ev.rawX - downX; val dy = ev.rawY - downY
                    if (cards.size > 1 && abs(dy) > slop && abs(dy) > abs(dx) * 1.2f) startDrag(ev) else return true
                }
                val h = max(height, 1).toFloat()
                // Swiping up brings the next widget; follows the finger, a little heavier past one card.
                var o = startOffset + (downY - ev.rawY) / (h * 0.9f)
                if (abs(o) > 1f) o = (if (o > 0) 1f else -1f) + (o - (if (o > 0) 1f else -1f)) * 0.25f
                offset = o
                layoutCards()
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                if (dragging) {
                    tracker?.computeCurrentVelocity(1000)
                    val vy = -(tracker?.yVelocity ?: 0f) / max(height, 1)
                    val target = when {
                        vy > 1.6f -> 1f
                        vy < -1.6f -> -1f
                        offset > 0.3f -> 1f
                        offset < -0.3f -> -1f
                        else -> 0f
                    }.coerceIn(-1f, 1f)
                    if (target != 0f) performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)
                    spring.animateTo(target, 230f, 0.82f)
                    if (!ValueAnimatorCompat.enabled()) commit()
                }
                dragging = false
                tracker?.recycle(); tracker = null
                scheduleHideDots()
            }
        }
        return true
    }

    /** The flip has settled: make the card in front the current one. */
    private fun commit() {
        if (committing) return
        val n = cards.size
        if (n == 0) return
        val whole = offset.roundToInt()
        if (whole == 0 || abs(offset - whole) > 0.001f) return
        committing = true
        index = (index + whole).mod(n)
        offset = 0f
        spring.snapTo(0f)
        committing = false
        layoutCards()
        item?.let { it.stackIndex = index; launcher.saveModelSoon() }
        sendAccessibilityEvent(android.view.accessibility.AccessibilityEvent.TYPE_VIEW_SCROLLED)
    }

    /** Flips to the next (or previous) widget, as if swiped. */
    fun flip(forward: Boolean) {
        if (cards.size < 2) return
        showDots()
        spring.animateTo(if (forward) 1f else -1f, 230f, 0.82f)
        if (!ValueAnimatorCompat.enabled()) { offset = if (forward) 1f else -1f; commit() }
        scheduleHideDots()
    }

    private fun showDots() { removeCallbacks(hideDots); dotsSpring.animateTo(1f, 300f, 0.9f) }
    private fun scheduleHideDots() { removeCallbacks(hideDots); postDelayed(hideDots, 1400) }

    override fun dispatchDraw(canvas: Canvas) {
        super.dispatchDraw(canvas)
        val n = cards.size
        if (n < 2 || dots <= 0.01f) return
        // Dots on the right edge: the one for the widget in front is longer and brighter.
        val d = resources.displayMetrics.density
        val gap = 9f * d
        val x = width - 3.5f * d
        val top = height / 2f - (n - 1) * gap / 2f
        val pos = (index + offset).mod(n.toFloat())
        for (i in 0 until n) {
            var dist = abs(pos - i)
            dist = minOf(dist, n - dist)
            val near = clamp01(1f - dist)
            dotPaint.color = Color.argb(((0.4f + 0.6f * near) * 230 * dots).roundToInt().coerceIn(0, 255), 255, 255, 255)
            val half = (2f + 3f * near) * d
            val y = top + i * gap
            canvas.drawRoundRect(x - 2f * d, y - half, x + 2f * d, y + half, 2f * d, 2f * d, dotPaint)
        }
    }

    override fun onDetachedFromWindow() { detector.cancel(); spring.stop(); dotsSpring.stop(); super.onDetachedFromWindow() }

    // Accessibility: scroll forward/back flips the stack.
    override fun onInitializeAccessibilityNodeInfo(info: AccessibilityNodeInfo) {
        super.onInitializeAccessibilityNodeInfo(info)
        if (cards.size > 1) {
            info.addAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_SCROLL_FORWARD)
            info.addAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_SCROLL_BACKWARD)
            info.isScrollable = true
        }
    }

    override fun performAccessibilityAction(action: Int, arguments: Bundle?): Boolean = when (action) {
        AccessibilityNodeInfo.ACTION_SCROLL_FORWARD -> { flip(true); true }
        AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD -> { flip(false); true }
        else -> super.performAccessibilityAction(action, arguments)
    }
}

object ValueAnimatorCompat {
    fun enabled(): Boolean = android.animation.ValueAnimator.areAnimatorsEnabled()
}

/** Edit a stack: tap a widget to bring it to the front, or remove it. */
class StackEditSheet(launcher: MainActivity, private val stack: HomeItem) : BottomSheet(launcher, "Widget stack", dimBackground = true) {
    private val list = LinearLayout(launcher).apply { orientation = LinearLayout.VERTICAL; setPadding(launcher.dpi(12), 0, launcher.dpi(12), launcher.dpi(12)) }

    init {
        body.addView(launcher.textView("Swipe up or down on the stack to switch widgets.", 14f, ui.textSecondary).apply {
            setPadding(launcher.dpi(26), 0, launcher.dpi(26), launcher.dpi(10))
        })
        body.addView(list)
        build()
    }

    private fun build() {
        list.removeAllViews()
        stack.children.forEachIndexed { i, child ->
            val row = LinearLayout(launcher).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(launcher.dpi(14), 0, launcher.dpi(6), 0)
                background = pressable(null, ui.cardPressed, launcher.dp(14f))
                isClickable = true
                setOnClickListener {
                    launcher.haptic(it, HapticFeedbackConstants.CONTEXT_CLICK)
                    stack.stackIndex = i
                    launcher.refreshStack(stack)
                    build()
                }
            }
            val chip = FrameLayout(launcher).apply { background = roundRect(if (i == stack.stackIndex) ui.accent else ui.chip, launcher.dp(10f)) }
            chip.addView(launcher.iconImage(R.drawable.ic_widgets, if (i == stack.stackIndex) ui.onAccent else ui.text, 7), flp(MATCH, MATCH))
            row.addView(chip, llp(launcher.dpi(36), launcher.dpi(36)).apply { marginEnd = launcher.dpi(14) })
            row.addView(launcher.textView(launcher.widgetTitle(child), 16f, ui.text, if (i == stack.stackIndex) Fonts.semibold else Fonts.regular, maxLines = 1), llp(0, WRAP, 1f))
            val remove = launcher.iconImage(R.drawable.ic_close, ui.textSecondary, 10).apply {
                background = pressable(null, ui.cardPressed, launcher.dp(20f))
                isClickable = true
                contentDescription = "Remove ${launcher.widgetTitle(child)} from the stack"
                setOnClickListener {
                    launcher.haptic(it, HapticFeedbackConstants.CONTEXT_CLICK)
                    launcher.removeFromStack(stack, child)
                    if (stack.children.size < 2) close() else build()
                }
            }
            row.addView(remove, llp(launcher.dpi(44), launcher.dpi(44)))
            list.addView(row, llp(MATCH, launcher.dpi(58)))
        }
        val add = launcher.textView("Add a widget", 16f, ui.accent, Fonts.medium, Gravity.CENTER).apply {
            background = pressable(roundRect(withAlpha(ui.accent, 0.12f), launcher.dp(16f)), ui.cardPressed, launcher.dp(16f))
            isClickable = true
            setOnClickListener { close(); launcher.pickWidgetForStack(stack) }
        }
        list.addView(add, llp(MATCH, launcher.dpi(52)).apply { topMargin = launcher.dpi(10) })
    }
}
