# Fluid One 2.1 — ColorOS 17–style home screen for Android

A native Kotlin launcher for Android 12+ that follows the look and motion of ColorOS 17, tuned for the
Galaxy S25 Ultra. It uses only the Android framework (no third-party libraries).

## Install

1. Install `FluidOne-v2.1.0.apk` (debug-signed) on the phone. It updates 2.0 in place and keeps your layout.
2. Press Home and choose **Fluid One** → **Always**, or go to Settings › Apps › Choose default apps › Home app.
3. Being the default home app also turns on app shortcuts in the long-press menu.

## What's in it

**Home screen**
- Fixed pages with no scrolling inside them; finger-following page swipes with ColorOS deceleration, edge rubber-banding and wallpaper parallax.
- Default layout modelled on ColorOS 17: big date and gradient time, a large 2×2 folder, a calendar card, a search capsule and a four-app dock.
- The dock sizes itself to the apps it holds and lines up with the grid columns. Styles: Clear (default), Glass, Hidden.
- Page transitions: Slide, Depth, Cube, Fade, Carousel.

**Blur that works on the S25 Ultra**
- Glass (dock, search capsule, folders, menus, sheets) samples a pre-blurred copy of the wallpaper aligned to its exact screen position, so it keeps working when One UI's own window blur is off (power saving, "Reduce transparency and blur").
- Behind menus and folders the home screen also gets a live GPU blur (RenderEffect) plus a dimming scrim; strength and tint are adjustable.

**Motion**
- App open: the icon grows into a full-screen card with the display's corner radius while the home screen zooms past and the wallpaper blurs; the app fades in on top.
- App close: the card waits under the closing app and shrinks back into its icon while neighbouring icons ripple.
- Unlock: the wallpaper zooms out and icons gather in from the edges (Gather / Zoom / Rise / Off).
- Spring physics throughout, plus a global speed setting.

**Editing and customization**
- Long-press an app: the background blurs, the icon lifts and a frosted menu shows app shortcuts plus Edit / Remove / Uninstall / App info. Move your finger to drag instead.
- Drag anything anywhere: free placement, push-reorder of neighbours, hover on an app to make a folder, hover at the screen edge to change page (or create one), drop in the dock, Remove/Uninstall targets at the top.
- Move many apps at once: while holding an app, tap other apps (home or dock) with another finger. Each one lifts and flies into a stack behind your finger; the stacked apps trail a few milliseconds behind as you move and hide behind the top app when you hold still, with a count badge. While holding, swipe sideways with another finger to change pages. Release to drop: the apps land in the following cells (spilling onto the next page), or all go into a folder, the dock, or Remove.
- Long-press empty space (or pinch in): the home zooms out into page cards over a blurred wallpaper. Swipe between pages, add or delete pages, set the main page, and open the Wallpapers, Widgets, Icons, Layout and Settings sheets.
- Icons: 6 shapes; styles Original / Themed dark / Themed light / Accent / Glass (themed styles use Android 13 monochrome icons); ADW/Nova icon packs; per-app icon from a pack (searchable), a gallery image or a generated style; rename apps.
- Folders: small or large (2×2, tap the tiles to launch directly), rename in place, reorder, drag out.
- Widgets: built-in Clock, Calendar and Battery plus every Android app widget, with previews and resizing.
- 10 built-in abstract wallpapers rendered on the phone at native resolution (no download), your own photo, optional lock-screen sync.
- ColorOS-style settings with large titles, grouped cards, spring toggles, sliders and segmented controls, in light and dark.

**Samsung mode** (on automatically on Galaxy devices)
- For every Galaxy: One UI themed-icon fix (Dark / Light / Accent / Glass styles show the app's symbol instead of a plain square), highest refresh rate on home, edge-safe dragging (One UI's back gesture can't grab a dragged icon), battery-aware blur, and a diagnostics card.
- Galaxy S25 Ultra optimizations (only on SM-S938*): S Pen hover lift, S Pen button opens an icon's menu, and a recommended 4×6 layout.

## Limits

- Android does not let a third-party launcher drive another app's own window animation. The open/close morph is drawn by the launcher around the system transition, so on some One UI versions you may also see Samsung's own window animation.
- If One UI's "Remove animations" is on (animator scale 0), Android skips all animations; Settings › Animations warns about this.
- Swipe-down-for-notifications uses a widely used but unofficial Android call; if a future One UI blocks it, the gesture does nothing.
- Recents is provided by One UI, not by the launcher.

## Build

Requirements: Android Studio (or JDK 17 + Android SDK Platform 35 / Build Tools 35).

```bash
./gradlew assembleDebug
```

The APK is written to `app/build/outputs/apk/debug/app-debug.apk`. The GitHub Actions workflow in
`.github/workflows/build-apk.yml` builds it, runs the tests and uploads both the APK and test screenshots.

## Tests

`app/src/test` holds Robolectric UI tests that boot the launcher with 32 fake apps and drive it with real
touch events: page swipes, the drawer, long-press menus, drag & drop (free placement, push-reorder, folder
creation, dock ⇄ home, drawer → home, out of a folder across pages, remove), edit mode and every sheet,
every settings page and toggle, theme changes, icon styles, grid changes, widget resizing, page deletion,
page effects, app launch/return, unlock and activity recreation. Screenshots go to `app/build/screenshots`.

```bash
./gradlew testDebugUnitTest
```
