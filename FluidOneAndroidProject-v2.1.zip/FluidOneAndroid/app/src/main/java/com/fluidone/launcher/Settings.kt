package com.fluidone.launcher

import android.content.Intent
import android.graphics.Color
import android.provider.Settings
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.View
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import kotlin.math.roundToInt

/** Builds ColorOS-style grouped settings rows into a container. Shared by the settings screen and sheets. */
class SettingsBuilder(
    val launcher: MainActivity,
    val ui: UiTheme,
    val container: LinearLayout,
    private val cardColor: Int = ui.card,
    private val sidePadding: Int = launcher.dpi(16)
) {
    fun label(text: String) {
        container.addView(launcher.textView(text, 13f, ui.textSecondary, Fonts.medium).apply {
            setPadding(sidePadding + launcher.dpi(12), launcher.dpi(18), sidePadding, launcher.dpi(8))
        })
    }

    fun group(title: String? = null, footer: String? = null, block: Group.() -> Unit) {
        if (title != null) label(title)
        else container.addView(View(launcher), llp(MATCH, launcher.dpi(12)))
        val box = LinearLayout(launcher).apply {
            orientation = LinearLayout.VERTICAL
            background = roundRect(cardColor, launcher.dp(18f))
            clipToOutline = true
        }
        container.addView(box, llp(MATCH, WRAP).apply { marginStart = sidePadding; marginEnd = sidePadding })
        Group(box).block()
        if (footer != null) container.addView(launcher.textView(footer, 12f, ui.textSecondary).apply {
            setLineSpacing(launcher.dp(2f), 1f)
            setPadding(sidePadding + launcher.dpi(12), launcher.dpi(8), sidePadding + launcher.dpi(12), 0)
        })
    }

    fun view(v: View, marginTop: Int = 12) {
        container.addView(v, llp(MATCH, WRAP).apply { marginStart = sidePadding; marginEnd = sidePadding; topMargin = launcher.dpi(marginTop) })
    }

    inner class Group(val box: LinearLayout) {
        private var rows = 0

        private fun addRow(v: View, hasIcon: Boolean) {
            if (rows > 0) box.addView(View(launcher).apply { setBackgroundColor(ui.divider) }, llp(MATCH, 1).apply {
                marginStart = launcher.dpi(if (hasIcon) 60 else 16); marginEnd = launcher.dpi(16)
            })
            box.addView(v, llp(MATCH, WRAP))
            rows++
        }

        private fun row(icon: Int?, iconBg: Int?, title: String, summary: String?, clickable: Boolean): Pair<LinearLayout, LinearLayout> {
            val row = LinearLayout(launcher).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                minimumHeight = launcher.dpi(if (summary != null) 66 else 54)
                setPadding(launcher.dpi(16), launcher.dpi(10), launcher.dpi(14), launcher.dpi(10))
                if (clickable) { background = pressable(null, ui.cardPressed, 0f); isClickable = true }
            }
            if (icon != null) {
                val chip = FrameLayout(launcher).apply { background = roundRect(iconBg ?: ui.accent, launcher.dp(9f)) }
                chip.addView(launcher.iconImage(icon, Color.WHITE, 6), flp(MATCH, MATCH))
                row.addView(chip, llp(launcher.dpi(30), launcher.dpi(30)).apply { marginEnd = launcher.dpi(14) })
            }
            val texts = LinearLayout(launcher).apply { orientation = LinearLayout.VERTICAL }
            texts.addView(launcher.textView(title, 16f, ui.text, Fonts.regular))
            if (summary != null) texts.addView(launcher.textView(summary, 12.5f, ui.textSecondary).apply {
                setPadding(0, launcher.dpi(3), 0, 0); setLineSpacing(launcher.dp(1.5f), 1f)
            })
            row.addView(texts, llp(0, WRAP, 1f))
            return row to texts
        }

        fun nav(title: String, summary: String? = null, value: String? = null, icon: Int? = null, iconBg: Int? = null, onClick: () -> Unit): TextView? {
            val (row, _) = row(icon, iconBg, title, summary, true)
            var valueView: TextView? = null
            if (value != null) {
                valueView = launcher.textView(value, 14f, ui.textSecondary, maxLines = 1)
                row.addView(valueView, llp(WRAP, WRAP).apply { marginStart = launcher.dpi(8) })
            }
            row.addView(launcher.iconImage(R.drawable.ic_chevron, ui.textTertiary, 0), llp(launcher.dpi(18), launcher.dpi(18)).apply { marginStart = launcher.dpi(4) })
            row.setOnClickListener { launcher.haptic(it, HapticFeedbackConstants.CONTEXT_CLICK); onClick() }
            addRow(row, icon != null)
            return valueView
        }

        fun toggle(title: String, summary: String? = null, icon: Int? = null, iconBg: Int? = null, get: () -> Boolean, set: (Boolean) -> Unit): ColorSwitch {
            val (row, _) = row(icon, iconBg, title, summary, true)
            val sw = ColorSwitch(launcher, ui)
            sw.setChecked(get())
            sw.contentDescription = title
            sw.onChange = { set(it) }
            row.addView(sw, llp(WRAP, WRAP).apply { marginStart = launcher.dpi(10) })
            row.setOnClickListener { sw.setChecked(!sw.isChecked, animate = true, fromUser = true) }
            addRow(row, icon != null)
            return sw
        }

        fun slider(title: String, min: Int, max: Int, get: () -> Int, format: (Int) -> String, summary: String? = null, onChange: ((Int) -> Unit)? = null, onCommit: (Int) -> Unit): FluidSlider {
            val col = LinearLayout(launcher).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(launcher.dpi(16), launcher.dpi(12), launcher.dpi(16), launcher.dpi(6))
            }
            val head = LinearLayout(launcher).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
            head.addView(launcher.textView(title, 16f, ui.text), llp(0, WRAP, 1f))
            val value = launcher.textView(format(get()), 14f, ui.accent, Fonts.medium)
            head.addView(value)
            col.addView(head)
            if (summary != null) col.addView(launcher.textView(summary, 12.5f, ui.textSecondary).apply { setPadding(0, launcher.dpi(3), 0, 0) })
            val slider = FluidSlider(launcher, ui, min, max, get())
            slider.contentDescription = title
            slider.onChange = { value.text = format(it); onChange?.invoke(it) }
            slider.onCommit = { onCommit(it) }
            col.addView(slider, llp(MATCH, WRAP).apply { topMargin = launcher.dpi(4) })
            addRow(col, false)
            return slider
        }

        fun segmented(title: String?, labels: List<String>, selected: Int, summary: String? = null, onSelect: (Int) -> Unit): SegmentedControl {
            val col = LinearLayout(launcher).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(launcher.dpi(16), launcher.dpi(12), launcher.dpi(16), launcher.dpi(14))
            }
            if (title != null) col.addView(launcher.textView(title, 16f, ui.text))
            if (summary != null) col.addView(launcher.textView(summary, 12.5f, ui.textSecondary).apply { setPadding(0, launcher.dpi(3), 0, 0) })
            val seg = SegmentedControl(launcher, ui, labels, selected)
            seg.contentDescription = title
            seg.onSelect = onSelect
            col.addView(seg, llp(MATCH, WRAP).apply { topMargin = launcher.dpi(if (title != null) 10 else 0) })
            addRow(col, false)
            return seg
        }

        fun choice(title: String, options: List<Pair<String, String>>, current: () -> String, icon: Int? = null, iconBg: Int? = null, onPick: (String) -> Unit) {
            var valueView: TextView? = null
            valueView = nav(title, null, options.firstOrNull { it.first == current() }?.second ?: "", icon, iconBg) {
                ChoiceSheet(launcher, title, options, current()) { picked ->
                    onPick(picked)
                    valueView?.text = options.firstOrNull { it.first == picked }?.second ?: ""
                }.show()
            }
        }

        fun info(text: String) {
            val t = launcher.textView(text, 13f, ui.textSecondary).apply {
                setLineSpacing(launcher.dp(3f), 1f)
                setPadding(launcher.dpi(16), launcher.dpi(14), launcher.dpi(16), launcher.dpi(14))
            }
            addRow(t, false)
        }

        fun button(title: String, color: Int = ui.accent, onClick: () -> Unit) {
            val t = launcher.textView(title, 16f, color, Fonts.medium, Gravity.CENTER).apply {
                minHeight = launcher.dpi(54)
                background = pressable(null, ui.cardPressed, 0f)
                isClickable = true
                setOnClickListener { launcher.haptic(it, HapticFeedbackConstants.CONTEXT_CLICK); onClick() }
            }
            addRow(t, false)
        }

        fun custom(v: View) = addRow(v, false)
    }
}

/** Radio list in a bottom sheet. */
class ChoiceSheet(launcher: MainActivity, title: String, options: List<Pair<String, String>>, current: String, onPick: (String) -> Unit) :
    BottomSheet(launcher, title) {
    init {
        val box = LinearLayout(launcher).apply { orientation = LinearLayout.VERTICAL; setPadding(launcher.dpi(12), 0, launcher.dpi(12), launcher.dpi(12)) }
        options.forEach { (value, label) ->
            val row = LinearLayout(launcher).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(launcher.dpi(14), 0, launcher.dpi(14), 0)
                background = pressable(null, ui.cardPressed, launcher.dp(14f))
                isClickable = true
                setOnClickListener {
                    launcher.haptic(it, HapticFeedbackConstants.CONTEXT_CLICK)
                    close()
                    onPick(value)
                }
            }
            row.addView(launcher.textView(label, 16f, if (value == current) ui.accent else ui.text, if (value == current) Fonts.medium else Fonts.regular), llp(0, WRAP, 1f))
            if (value == current) row.addView(launcher.iconImage(R.drawable.ic_check, ui.accent, 0), llp(launcher.dpi(20), launcher.dpi(20)))
            box.addView(row, llp(MATCH, launcher.dpi(54)))
        }
        body.addView(box)
    }
}

/**
 * Full-screen launcher settings in the ColorOS style: large titles that collapse into the toolbar, grouped
 * rounded cards, and pages that slide in from the right.
 */
class SettingsPanel(launcher: MainActivity, private val initialPage: String? = null) : Overlay(launcher) {
    private val ui = launcher.ui
    private val stack = mutableListOf<View>()
    private val pagesHost = FrameLayout(launcher)

    init {
        root.setBackgroundColor(ui.background)
        root.isClickable = true
        root.addView(pagesHost, flp(MATCH, MATCH))
    }

    fun show() {
        launcher.showOverlay(this)
        push(page("Settings", ::mainPage), animate = false)
        when (initialPage) {
            "theme" -> push(page("Theme & accent colour", ::themePage), animate = false)
        }
        root.alpha = 0f
        root.scaleX = 0.94f; root.scaleY = 0.94f
        val spring = Spring(0.9f, 0.4f)
        root.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(spring.ms).setInterpolator(spring).start()
    }

    private fun page(title: String, build: SettingsBuilder.() -> Unit): View {
        val frame = FrameLayout(launcher).apply { setBackgroundColor(ui.background); isClickable = true }
        val scroll = ScrollView(launcher).apply { isVerticalScrollBarEnabled = false; overScrollMode = View.OVER_SCROLL_IF_CONTENT_SCROLLS }
        val content = LinearLayout(launcher).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, launcher.insetTop + launcher.dpi(56), 0, launcher.insetBottom + launcher.dpi(32))
        }
        val big = launcher.textView(title, 32f, ui.text, Fonts.bold).apply { setPadding(launcher.dpi(28), launcher.dpi(8), launcher.dpi(24), launcher.dpi(4)) }
        content.addView(big)
        SettingsBuilder(launcher, ui, content).build()
        scroll.addView(content, flp(MATCH, WRAP))
        frame.addView(scroll, flp(MATCH, MATCH))
        // Toolbar with a small title that fades in once the large title scrolls away.
        val bar = LinearLayout(launcher).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(launcher.dpi(8), launcher.insetTop, launcher.dpi(16), 0)
            setBackgroundColor(Color.TRANSPARENT)
        }
        val back = launcher.iconImage(R.drawable.ic_back, ui.text, 12).apply {
            background = pressable(null, ui.cardPressed, launcher.dp(24f))
            isClickable = true
            contentDescription = "Back"
            setOnClickListener { onBack() }
        }
        bar.addView(back, llp(launcher.dpi(48), launcher.dpi(48)))
        val small = launcher.textView(title, 18f, ui.text, Fonts.semibold).apply { alpha = 0f }
        bar.addView(small, llp(0, WRAP, 1f).apply { marginStart = launcher.dpi(4) })
        frame.addView(bar, flp(MATCH, launcher.insetTop + launcher.dpi(56)))
        scroll.setOnScrollChangeListener { _, _, y, _, _ ->
            val t = clamp01((y - launcher.dp(20f)) / launcher.dp(40f))
            small.alpha = t
            bar.setBackgroundColor(withAlpha(ui.background, t))
            big.alpha = 1f - t
        }
        return frame
    }

    private fun push(v: View, animate: Boolean = true) {
        val prev = stack.lastOrNull()
        stack.add(v)
        pagesHost.addView(v, flp(MATCH, MATCH))
        if (!animate) return
        val w = root.width.toFloat().takeIf { it > 0f } ?: launcher.rootView.width.toFloat()
        v.translationX = w
        v.elevation = launcher.dp(6f)
        v.animate().translationX(0f).setDuration(Motion.d(380)).setInterpolator(Motion.move).start()
        prev?.animate()?.translationX(-w * 0.28f)?.alpha(0.6f)?.setDuration(Motion.d(380))?.setInterpolator(Motion.move)?.start()
    }

    private fun pop() {
        val top = stack.removeAt(stack.lastIndex)
        val prev = stack.lastOrNull()
        val w = root.width.toFloat()
        top.animate().translationX(w).setDuration(Motion.d(320)).setInterpolator(Motion.move).withEndAction { top.removeFromParent() }.start()
        prev?.animate()?.translationX(0f)?.alpha(1f)?.setDuration(Motion.d(320))?.setInterpolator(Motion.move)?.start()
    }

    override fun onBack(): Boolean {
        if (stack.size > 1) pop() else close()
        return true
    }

    override fun close(animate: Boolean) {
        if (closing) return
        closing = true
        if (!animate) { finish(); return }
        root.animate().alpha(0f).scaleX(0.96f).scaleY(0.96f).setDuration(Motion.d(200)).setInterpolator(Motion.accel).withEndAction { finish() }.start()
    }

    private fun open(title: String, build: SettingsBuilder.() -> Unit) = push(page(title, build))

    // ---- Pages ---------------------------------------------------------------------------------------------

    private fun mainPage(b: SettingsBuilder) = with(b) {
        if (!launcher.isDefaultLauncher()) {
            group {
                nav("Set Fluid One as default home", "Required for app shortcuts and the full experience", icon = R.drawable.ic_home, iconBg = ui.accent) {
                    launcher.startSafely(Intent(Settings.ACTION_HOME_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK), root)
                }
            }
        }
        group("Home screen") {
            nav("Layout", "${launcher.prefs.columns} × ${launcher.prefs.rows} grid · icon size · page effect", icon = R.drawable.ic_grid, iconBg = Color.rgb(64, 132, 255)) { open("Layout", ::layoutPage) }
            nav("Dock & search bar", icon = R.drawable.ic_dock, iconBg = Color.rgb(0, 168, 160)) { open("Dock & search bar", ::dockPage) }
            nav("Edit home screen", "Pages, widgets and wallpapers", icon = R.drawable.ic_widgets, iconBg = Color.rgb(255, 140, 40)) { close(); launcher.enterEditMode() }
        }
        group("Personalization") {
            nav("Wallpapers", icon = R.drawable.ic_wallpaper, iconBg = Color.rgb(146, 92, 255)) { open("Wallpapers", ::wallpaperPage) }
            nav("Icons", "Shape, style, icon packs", icon = R.drawable.ic_palette, iconBg = Color.rgb(242, 80, 128)) { open("Icons", ::iconsPage) }
            nav("Theme & accent colour", icon = R.drawable.ic_tune, iconBg = Color.rgb(90, 98, 120)) { open("Theme & accent colour", ::themePage) }
        }
        group("Effects") {
            nav("Blur & glass", "Real wallpaper blur for dock, folders and menus", icon = R.drawable.ic_blur, iconBg = Color.rgb(32, 160, 230)) { open("Blur & glass", ::blurPage) }
            nav("Animations", "App open & close, unlock, speed", icon = R.drawable.ic_animation, iconBg = Color.rgb(255, 98, 72)) { open("Animations", ::motionPage) }
        }
        group("Navigation") {
            nav("Gestures", icon = R.drawable.ic_gesture, iconBg = Color.rgb(52, 186, 110)) { open("Gestures", ::gesturePage) }
            nav("App drawer", icon = R.drawable.ic_apps, iconBg = Color.rgb(70, 110, 240)) { open("App drawer", ::drawerPage) }
        }
        group("Device") {
            nav("Samsung mode", when {
                !launcher.prefs.samsungMode -> "Off"
                launcher.s25On() -> "On · S25 Ultra optimizations on"
                else -> "On"
            }, icon = R.drawable.ic_device, iconBg = Color.rgb(20, 40, 160)) { open("Samsung mode", ::samsungPage) }
            nav("About Fluid One", icon = R.drawable.ic_info, iconBg = Color.rgb(120, 126, 140)) { open("About", ::aboutPage) }
        }
    }

    private fun layoutPage(b: SettingsBuilder) = with(b) {
        val p = launcher.prefs
        group("Grid") {
            segmented("Columns", listOf("4", "5"), if (p.columns >= 5) 1 else 0) { p.columns = if (it == 1) 5 else 4; launcher.applyLayoutChange() }
            segmented("Rows", listOf("5", "6", "7"), (p.rows - 5).coerceIn(0, 2)) { p.rows = 5 + it; launcher.applyLayoutChange() }
        }
        group("Icons") {
            slider("Icon size", 70, 130, { p.iconScale }, { "$it%" }) { p.iconScale = it; launcher.applyLayoutChange() }
            toggle("Show app names", get = { p.showLabels }) { p.showLabels = it; launcher.applyLayoutChange() }
            slider("Name size", 10, 15, { p.labelSize }, { "${it}sp" }) { p.labelSize = it; launcher.applyLayoutChange() }
        }
        group("Pages") {
            choice("Page transition", listOf("slide" to "Slide", "depth" to "Depth", "cube" to "Cube", "fade" to "Fade", "carousel" to "Carousel"), { p.pageEffect }) {
                p.pageEffect = it; launcher.applyLayoutChange()
            }
            toggle("Lock home screen layout", "Prevents icons and widgets from being moved or removed", get = { p.lockLayout }) { p.lockLayout = it }
            toggle("Add new apps to home screen", get = { p.addNewApps }) { p.addNewApps = it }
        }
    }

    private fun dockPage(b: SettingsBuilder) = with(b) {
        val p = launcher.prefs
        group("Dock", "The dock always sizes itself to the apps you put in it.") {
            segmented("Style", listOf("Clear", "Glass", "Hidden"), listOf("clear", "glass", "off").indexOf(p.dockStyle).coerceAtLeast(0)) {
                p.dockStyle = listOf("clear", "glass", "off")[it]; launcher.applyLayoutChange()
            }
            toggle("Show app names in dock", get = { p.dockLabels }) { p.dockLabels = it; launcher.applyLayoutChange() }
        }
        group("Search bar") {
            toggle("Search capsule above dock", "Shows page dots while you swipe between pages", get = { p.searchBar }) { p.searchBar = it; launcher.applyLayoutChange() }
        }
    }

    private fun wallpaperPage(b: SettingsBuilder) = with(b) {
        view(WallpaperPicker(launcher, ui).view, 8)
        group {
            toggle("Also use on lock screen", "Matching wallpapers make the unlock zoom seamless", get = { launcher.prefs.lockWallpaper }) {
                launcher.prefs.lockWallpaper = it
                if (it) launcher.applyLockWallpaper()
            }
            toggle("Wallpaper parallax", "Wallpaper drifts gently as you change pages", get = { launcher.prefs.parallax }) {
                launcher.prefs.parallax = it; launcher.applyLayoutChange()
            }
        }
    }

    private fun iconsPage(b: SettingsBuilder) = with(b) { IconSettings.build(launcher, this) }

    private fun themePage(b: SettingsBuilder) = with(b) {
        val p = launcher.prefs
        group("Appearance", "Menus, folders and settings follow this theme.") {
            segmented(null, listOf("System", "Light", "Dark"), listOf("system", "light", "dark").indexOf(p.theme).coerceAtLeast(0)) {
                p.theme = listOf("system", "light", "dark")[it]
                launcher.applyThemeChange()
            }
        }
        group("Accent colour") {
            val row = LinearLayout(launcher).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(launcher.dpi(12), launcher.dpi(16), launcher.dpi(12), launcher.dpi(16))
            }
            LauncherPrefs.ACCENTS.forEach { (name, color) ->
                val selected = p.accent == color
                val dot = FrameLayout(launcher).apply {
                    background = oval(color)
                    contentDescription = name
                    isClickable = true
                    setOnClickListener {
                        p.accent = color
                        launcher.haptic(it, HapticFeedbackConstants.CONTEXT_CLICK)
                        launcher.applyThemeChange()
                    }
                }
                if (selected) dot.addView(launcher.iconImage(R.drawable.ic_check, Color.WHITE, 6), flp(MATCH, MATCH))
                row.addView(dot, llp(0, launcher.dpi(36), 1f).apply { marginStart = launcher.dpi(5); marginEnd = launcher.dpi(5) })
            }
            custom(row)
        }
    }

    private fun blurPage(b: SettingsBuilder) = with(b) {
        val p = launcher.prefs
        view(BlurPreview(launcher), 8)
        group("Glass", "Fluid One blurs the wallpaper itself, so glass works even when One UI's system blur is off (power saving, Reduce transparency).") {
            slider("Blur strength", 0, 100, { p.blurStrength }, { "$it" }, onChange = { p.blurStrength = it; launcher.scheduleBlurRebuild() }) {
                p.blurStrength = it; launcher.scheduleBlurRebuild()
            }
            slider("Glass tint", 0, 100, { p.glassTint }, { "$it%" }, onChange = { p.glassTint = it; launcher.invalidateGlass() }) {
                p.glassTint = it; launcher.invalidateGlass()
            }
        }
        group("Live blur") {
            toggle("Blur home behind menus", "GPU blur of icons and widgets behind folders, menus and the drawer", get = { p.liveBlur }) { p.liveBlur = it }
        }
        if (Device.samsungReduceTransparency(launcher)) group {
            info("One UI's \"Reduce transparency and blur\" is on. Fluid One's own blur still works; live blur of icons is reduced to keep things smooth.")
        }
    }

    private fun motionPage(b: SettingsBuilder) = with(b) {
        val p = launcher.prefs
        group("Opening & closing apps") {
            choice("App open animation", listOf("morph" to "ColorOS morph", "zoom" to "Window zoom", "fade" to "Fade"), { p.launchAnim }) { p.launchAnim = it }
            toggle("Shrink back into icon", "When you return home the app collapses into its icon", get = { p.returnAnim }) { p.returnAnim = it }
        }
        group("Unlock") {
            choice("Unlock animation", listOf("gather" to "Gather", "zoom" to "Zoom", "rise" to "Rise", "off" to "Off"), { p.unlockAnim }) { p.unlockAnim = it }
            button("Preview unlock animation") { close(); launcher.rootView.postDelayed({ launcher.previewUnlock() }, 260) }
        }
        group("Speed") {
            slider("Animation speed", 60, 160, { (10000 / p.animSpeed.coerceAtLeast(1)).coerceIn(60, 160) }, { "${it}%" }, summary = "100% matches ColorOS timing. Higher is faster.") {
                p.animSpeed = (10000 / it).coerceIn(62, 167); launcher.applyMotionSpeed()
            }
        }
        val scale = Device.animatorScale(launcher)
        if (scale != 1f) group {
            info(if (scale == 0f) "System animations are turned off (Remove animations / animator scale 0×). Fluid One's animations can't play until they're turned back on."
                 else "System animator scale is ${scale}×, which changes every animation's speed.")
            button("Open accessibility settings") { launcher.startSafely(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK), root) }
        }
    }

    private fun gesturePage(b: SettingsBuilder) = with(b) {
        val p = launcher.prefs
        group {
            choice("Swipe up", listOf("drawer" to "App drawer", "search" to "Search", "none" to "Nothing"), { p.swipeUp }) { p.swipeUp = it }
            choice("Swipe down", listOf("notifications" to "Notifications", "search" to "Search", "none" to "Nothing"), { p.swipeDown }) { p.swipeDown = it }
            choice("Pinch in", listOf("edit" to "Edit home screen", "none" to "Nothing"), { p.pinchIn }) { p.pinchIn = it }
        }
        group {
            toggle("Haptic feedback", get = { p.haptics }) { p.haptics = it }
        }
    }

    private fun drawerPage(b: SettingsBuilder) = with(b) {
        val p = launcher.prefs
        group {
            segmented("Columns", listOf("4", "5"), if (p.drawerColumns >= 5) 1 else 0) { p.drawerColumns = if (it == 1) 5 else 4; launcher.drawer.reload() }
            toggle("Open keyboard automatically", get = { p.drawerKeyboard }) { p.drawerKeyboard = it }
        }
        group {
            nav("Hidden apps", "${p.hiddenApps.size} hidden") { open("Hidden apps", ::hiddenPage) }
        }
    }

    private fun hiddenPage(b: SettingsBuilder) = with(b) {
        group(footer = "Hidden apps disappear from the app drawer and search. They stay installed.") {
            launcher.apps.apps.forEach { entry ->
                val (row, _) = run {
                    val r = LinearLayout(launcher).apply {
                        orientation = LinearLayout.HORIZONTAL
                        gravity = Gravity.CENTER_VERTICAL
                        setPadding(launcher.dpi(16), launcher.dpi(8), launcher.dpi(14), launcher.dpi(8))
                    }
                    val icon = ImageView(launcher).apply { setImageBitmap(launcher.icons.appIcon(entry, launcher.dpi(36))) }
                    r.addView(icon, llp(launcher.dpi(36), launcher.dpi(36)).apply { marginEnd = launcher.dpi(14) })
                    r.addView(launcher.textView(launcher.apps.label(entry), 16f, ui.text, maxLines = 1), llp(0, WRAP, 1f))
                    r to icon
                }
                val sw = ColorSwitch(launcher, ui)
                sw.setChecked(entry.key in launcher.prefs.hiddenApps)
                sw.onChange = { hide ->
                    val set = launcher.prefs.hiddenApps.toMutableSet()
                    if (hide) set.add(entry.key) else set.remove(entry.key)
                    launcher.prefs.hiddenApps = set
                    launcher.drawer.reload()
                }
                row.addView(sw)
                row.isClickable = true
                row.setOnClickListener { sw.setChecked(!sw.isChecked, animate = true, fromUser = true) }
                custom(row)
            }
        }
    }

    private fun samsungPage(b: SettingsBuilder) = with(b) {
        val p = launcher.prefs
        val isSamsung = Device.isSamsung()
        val isS25 = Device.isS25Ultra()
        var samsungGroup: View? = null
        var s25Master: View? = null
        var s25Group: View? = null

        fun refresh(animate: Boolean) {
            val samsungOn = p.samsungMode
            val s25Available = samsungOn && isS25
            val s25On = s25Available && p.s25Optimizations
            listOf(samsungGroup to samsungOn, s25Master to s25Available, s25Group to s25On).forEach { (v, on) ->
                v ?: return@forEach
                setEnabledDeep(v, on)
                if (animate) v.animate().alpha(if (on) 1f else 0.4f).setDuration(180).start() else v.alpha = if (on) 1f else 0.4f
            }
        }

        group(footer = when {
            isS25 -> "Galaxy S25 Ultra detected: Samsung and S25 Ultra optimizations are both available."
            isSamsung -> "Samsung Galaxy detected. S25 Ultra optimizations need a Galaxy S25 Ultra."
            else -> "This phone isn't a Samsung. Samsung mode is safe to use but is designed for One UI."
        }) {
            toggle("Samsung mode", "Optimizations for One UI on every Galaxy device", get = { p.samsungMode }) {
                p.samsungMode = it
                launcher.applyDeviceTuning()
                launcher.applyIconChange()
                refresh(true)
            }
        }
        group("All Galaxy devices") {
            samsungGroup = box
            toggle("One UI themed icons fix", "Rebuilds Dark, Light, Accent and Glass icons from One UI's wrapped icons so they show the app's symbol, not a plain square",
                get = { p.oneUiIcons }) { p.oneUiIcons = it; launcher.applyIconChange() }
            toggle("High refresh rate on home", "Requests the panel's top refresh rate (up to ${Device.maxRefreshRate(launcher).roundToInt()} Hz) while the home screen is open",
                get = { p.highRefresh }) { p.highRefresh = it; launcher.applyDeviceTuning() }
            toggle("Edge-safe dragging", "Stops One UI's back gesture from grabbing icons dragged near the screen edges",
                get = { p.gestureGuard }) { p.gestureGuard = it }
            toggle("Battery-aware blur", "Turns off live icon blur while One UI power saving is on; wallpaper glass stays",
                get = { p.batteryBlur }) { p.batteryBlur = it }
        }
        group("Galaxy S25 Ultra") {
            s25Master = box
            toggle("S25 Ultra optimizations", if (isS25) "Extra tuning for the S25 Ultra's S Pen and display" else "Only available on a Galaxy S25 Ultra",
                get = { p.s25Optimizations && isS25 }) { p.s25Optimizations = it; refresh(true) }
        }
        group {
            s25Group = box
            toggle("S Pen hover", "Icons lift when the S Pen hovers over them", get = { p.spenHover }) { p.spenHover = it }
            toggle("S Pen button menus", "Press the S Pen button while hovering an icon to open its menu", get = { p.spenButton }) { p.spenButton = it }
            button("Apply S25 Ultra layout (4 × 6, 100% icons)") {
                p.columns = 4; p.rows = 6; p.iconScale = 100; p.labelSize = 12
                launcher.applyLayoutChange()
                launcher.toast("Layout applied")
            }
        }
        refresh(false)
        group("Diagnostics") { info(Device.description(launcher)) }
    }

    private fun aboutPage(b: SettingsBuilder) = with(b) {
        group {
            info("Fluid One ${launcher.versionName()}\nA ColorOS-inspired home screen for Android 12 and newer, tuned for Samsung Galaxy phones and the Galaxy S25 Ultra.")
        }
        group {
            nav("Default home app", if (launcher.isDefaultLauncher()) "Fluid One" else "Not set") {
                launcher.startSafely(Intent(Settings.ACTION_HOME_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK), root)
            }
        }
        group {
            button("Reset home screen layout", ui.danger) {
                FluidDialog(launcher, "Reset layout?", "Your pages, folders, dock and widgets go back to the default layout. Apps stay installed.", "Reset", destructive = true) {
                    close(); launcher.resetLayout()
                }.show()
            }
            button("Reset appearance settings", ui.danger) {
                FluidDialog(launcher, "Reset appearance?", "Blur, icons, animations and layout settings return to their defaults.", "Reset", destructive = true) {
                    launcher.prefs.resetAppearance(); close(); launcher.applyEverything()
                }.show()
            }
        }
    }
}

private fun setEnabledDeep(v: View, enabled: Boolean) {
    v.isEnabled = enabled
    if (v is android.view.ViewGroup) for (i in 0 until v.childCount) setEnabledDeep(v.getChildAt(i), enabled)
}

/** A live sample of the glass effect on the blur settings page. */
class BlurPreview(launcher: MainActivity) : FrameLayout(launcher) {
    init {
        val glass = GlassView(launcher, launcher.dp(22f), GlassView.Style.HOME)
        val row = LinearLayout(launcher).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        launcher.apps.apps.take(4).forEach { e ->
            row.addView(ImageView(launcher).apply { setImageBitmap(launcher.icons.appIcon(e, launcher.dpi(48))) }, llp(launcher.dpi(48), launcher.dpi(48)).apply {
                marginStart = launcher.dpi(10); marginEnd = launcher.dpi(10)
            })
        }
        glass.addView(row, flp(MATCH, MATCH))
        addView(glass, flp(MATCH, launcher.dpi(96)))
    }
}
