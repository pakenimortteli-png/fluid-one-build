package com.fluidone.launcher

import android.content.Context
import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.LinearLayout
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * The dock sizes itself to the apps it holds: each icon gets one grid column's width and the row is centred,
 * so four apps under a four-column grid line up exactly with the icons above (as in ColorOS 17).
 */
class DockView(context: Context, private val launcher: MainActivity) : ViewGroup(context) {
    val plate = GlassView(context, dp(28f), GlassView.Style.HOME)
    val icons = mutableListOf<IconView>()
    var slotWidth = dpi(84)
        set(v) { if (field != v) { field = v; requestLayout() } }
    var iconSize = dpi(56)
    var showLabels = false
    var style = "clear"
        set(v) { field = v; plate.visibility = if (v == "glass") VISIBLE else GONE; requestLayout() }
    /** Index where a dragged icon would be inserted, or -1. */
    private var gap = -1
    private val vPad get() = dpi(12)
    private val hPad get() = dpi(10)

    init {
        clipChildren = false
        clipToPadding = false
        addView(plate)
        plate.visibility = GONE
    }

    fun bind(entries: List<AppEntry>, factory: (AppEntry) -> IconView) {
        icons.forEach { removeView(it) }
        icons.clear()
        for (e in entries) {
            val v = factory(e)
            icons.add(v)
            addView(v)
        }
        gap = -1
        requestLayout()
    }

    fun contentHeight(): Int {
        val label = if (showLabels) dpi(22) else 0
        return iconSize + label + 2 * vPad
    }

    private fun slots(): Int = icons.count { it.visibility != GONE } + if (gap >= 0) 1 else 0

    private fun effectiveSlot(): Int {
        val n = max(1, slots())
        val maxW = width - 2 * hPad - dpi(16)
        return if (n * slotWidth > maxW && n > 0) maxW / n else slotWidth
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val w = MeasureSpec.getSize(widthMeasureSpec)
        val h = contentHeight()
        setMeasuredDimension(w, h)
        val slot = run {
            val n = max(1, slots())
            val maxW = w - 2 * hPad - dpi(16)
            if (n * slotWidth > maxW) maxW / n else slotWidth
        }
        for (v in icons) v.measure(MeasureSpec.makeMeasureSpec(slot, MeasureSpec.EXACTLY), MeasureSpec.makeMeasureSpec(h - 2 * vPad, MeasureSpec.EXACTLY))
        val bgW = slots() * slot + 2 * hPad
        plate.measure(MeasureSpec.makeMeasureSpec(max(0, bgW), MeasureSpec.EXACTLY), MeasureSpec.makeMeasureSpec(h, MeasureSpec.EXACTLY))
    }

    override fun onLayout(changed: Boolean, l: Int, t: Int, r: Int, b: Int) {
        val slot = effectiveSlot()
        val n = slots()
        val left0 = (width - n * slot) / 2
        var s = 0
        for (v in icons) {
            if (v.visibility == GONE) continue
            if (s == gap) s++
            val x = left0 + s * slot
            v.layout(x, vPad, x + v.measuredWidth, vPad + v.measuredHeight)
            s++
        }
        val bgW = plate.measuredWidth
        val bx = (width - bgW) / 2
        plate.layout(bx, 0, bx + bgW, height)
    }

    /** Animates icons apart to show where a dragged app will land. Pass -1 to close the gap. */
    fun setGap(index: Int) {
        if (index == gap) return
        gap = index
        relayoutAnimated()
    }

    /** Re-lays out immediately and animates every icon from where it was drawn before. */
    fun relayoutAnimated() {
        if (width == 0) { requestLayout(); return }
        val before = icons.associateWith { it.left + it.translationX }
        val bgBefore = plate.width
        measure(MeasureSpec.makeMeasureSpec(width, MeasureSpec.EXACTLY), MeasureSpec.makeMeasureSpec(height, MeasureSpec.EXACTLY))
        layout(left, top, right, bottom)
        for (v in icons) {
            val old = before[v] ?: continue
            v.translationX = old - v.left
            v.animate().translationX(0f).setDuration(Motion.d(260)).setInterpolator(Motion.move).start()
        }
        if (bgBefore > 0 && plate.width != bgBefore) {
            plate.scaleX = bgBefore / plate.width.toFloat()
            plate.animate().scaleX(1f).setDuration(Motion.d(260)).setInterpolator(Motion.move).start()
        }
    }

    /** Insertion index for a window x coordinate. */
    fun insertionIndex(windowX: Float): Int {
        val loc = IntArray(2); getLocationInWindow(loc)
        val x = windowX - loc[0]
        val visible = icons.filter { it.visibility != GONE }
        val slot = effectiveSlot()
        val n = visible.size + 1
        val left0 = (width - n * slot) / 2f
        return ((x - left0) / slot).toInt().coerceIn(0, visible.size)
    }

    /** Window-space centre of the slot a drop at [index] will occupy. */
    fun slotRectInWindow(index: Int): android.graphics.RectF {
        val loc = IntArray(2); getLocationInWindow(loc)
        val slot = effectiveSlot()
        val n = slots()
        val left0 = (width - n * slot) / 2f
        val cx = loc[0] + left0 + (index + 0.5f) * slot
        val cy = loc[1] + vPad + iconSize / 2f
        return android.graphics.RectF(cx - iconSize / 2f, cy - iconSize / 2f, cx + iconSize / 2f, cy + iconSize / 2f)
    }

    fun iconFor(key: String): IconView? = icons.firstOrNull { it.entry?.key == key }

    fun capacity(columns: Int): Int = max(4, min(6, columns + 1))
}

/** The pill above the dock (like ColorOS 17's search capsule). Shows page dots while the pages move. */
class SearchPill(context: Context, launcher: MainActivity) : FrameLayout(context) {
    val glass = GlassView(context, dp(18f), GlassView.Style.HOME)
    private val label = context.textView("Search", 13f, Color.WHITE, Fonts.medium)
    private val icon = context.iconImage(R.drawable.ic_search, Color.WHITE, 0)

    init {
        val row = LinearLayout(context).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        row.addView(icon, llp(dpi(16), dpi(16)).apply { marginEnd = dpi(7) })
        row.addView(label)
        glass.addView(row, flp(MATCH, MATCH))
        glass.setPadding(dpi(16), 0, dpi(18), 0)
        addView(glass, flp(WRAP, dpi(36), Gravity.CENTER))
        glass.isClickable = true
        glass.contentDescription = "Search apps"
        glass.setOnClickListener {
            launcher.haptic(it, android.view.HapticFeedbackConstants.CONTEXT_CLICK)
            launcher.openDrawer(focusSearch = true)
        }
    }

    fun setDark(dark: Boolean) {
        val c = if (dark) Color.argb(220, 20, 20, 24) else Color.WHITE
        label.setTextColor(c)
        icon.imageTintList = android.content.res.ColorStateList.valueOf(c)
    }
}

/**
 * Lays out the home screen vertically: pages, then the pill/indicator row, then the dock, respecting the
 * status bar, camera cutout and navigation insets.
 */
class HomeLayout(context: Context, private val launcher: MainActivity) : FrameLayout(context) {
    lateinit var workspace: Workspace
    lateinit var pillRow: FrameLayout
    lateinit var dock: DockView
    var insetTop = 0
    var insetBottom = 0

    init {
        clipChildren = false
        clipToPadding = false
    }

    fun pillRowHeight() = dpi(44)

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val w = MeasureSpec.getSize(widthMeasureSpec)
        val h = MeasureSpec.getSize(heightMeasureSpec)
        setMeasuredDimension(w, h)
        val dockH = if (dock.visibility == GONE) 0 else dock.contentHeight()
        val bottomGap = insetBottom + dpi(if (dock.visibility == GONE) 18 else 8)
        dock.measure(MeasureSpec.makeMeasureSpec(w, MeasureSpec.EXACTLY), MeasureSpec.makeMeasureSpec(dockH, MeasureSpec.EXACTLY))
        pillRow.measure(MeasureSpec.makeMeasureSpec(w, MeasureSpec.EXACTLY), MeasureSpec.makeMeasureSpec(pillRowHeight(), MeasureSpec.EXACTLY))
        val wsTop = insetTop + dpi(6)
        val wsBottom = h - bottomGap - dockH - pillRowHeight() - dpi(2)
        workspace.measure(MeasureSpec.makeMeasureSpec(w, MeasureSpec.EXACTLY), MeasureSpec.makeMeasureSpec(max(0, wsBottom - wsTop), MeasureSpec.EXACTLY))
        for (i in 0 until childCount) {
            val c = getChildAt(i)
            if (c === dock || c === pillRow || c === workspace) continue
            measureChild(c, widthMeasureSpec, heightMeasureSpec)
        }
    }

    override fun onLayout(changed: Boolean, left: Int, top: Int, right: Int, bottom: Int) {
        val w = right - left
        val h = bottom - top
        val dockH = dock.measuredHeight
        val bottomGap = insetBottom + dpi(if (dock.visibility == GONE) 18 else 8)
        val dockTop = h - bottomGap - dockH
        dock.layout(0, dockTop, w, dockTop + dockH)
        val pillTop = dockTop - pillRowHeight()
        pillRow.layout(0, pillTop, w, pillTop + pillRowHeight())
        val wsTop = insetTop + dpi(6)
        workspace.layout(0, wsTop, w, wsTop + workspace.measuredHeight)
        for (i in 0 until childCount) {
            val c = getChildAt(i)
            if (c === dock || c === pillRow || c === workspace) continue
            val lp = c.layoutParams as LayoutParams
            val cw = c.measuredWidth; val ch = c.measuredHeight
            val x = when (lp.gravity and Gravity.HORIZONTAL_GRAVITY_MASK) {
                Gravity.CENTER_HORIZONTAL -> (w - cw) / 2
                Gravity.END, Gravity.RIGHT -> w - cw - lp.rightMargin
                else -> lp.leftMargin
            }
            val y = when (lp.gravity and Gravity.VERTICAL_GRAVITY_MASK) {
                Gravity.BOTTOM -> h - ch - lp.bottomMargin - insetBottom
                Gravity.CENTER_VERTICAL -> (h - ch) / 2
                else -> lp.topMargin + insetTop
            }
            c.layout(x, y, x + cw, y + ch)
        }
        launcher.onHomeLayout()
    }
}

fun View.setVisible(visible: Boolean) { visibility = if (visible) View.VISIBLE else View.GONE }
