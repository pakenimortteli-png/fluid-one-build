package com.fluidone.launcher

import android.animation.ValueAnimator
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.net.Uri
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.VelocityTracker
import android.view.View
import android.view.ViewConfiguration
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.AbsListView
import android.widget.BaseAdapter
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.GridView
import android.widget.LinearLayout
import java.util.Locale
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.roundToInt

/**
 * App drawer. Opens by following the finger from the home screen; the home content zooms back and the
 * wallpaper blurs behind it. Pull down at the top of the list to close.
 */
class AppDrawer(private val launcher: MainActivity) : FrameLayout(launcher) {
    var progress = 0f
        private set
    private var anim: ValueAnimator? = null
    private val searchGlass = GlassView(launcher, launcher.dp(22f), GlassView.Style.HOME)
    val search = EditText(launcher)
    val grid = GridView(launcher)
    private val index = AlphabetIndex(launcher)
    private val empty = LinearLayout(launcher)
    private val emptyText = launcher.textView("", 15f, Color.WHITE, Fonts.medium, Gravity.CENTER)
    private val adapter = AppsAdapter()
    private var all: List<AppEntry> = emptyList()
    private var shown: List<AppEntry> = emptyList()
    private var query = ""
    private val slop = ViewConfiguration.get(launcher).scaledTouchSlop
    private var downX = 0f
    private var downY = 0f
    private var pulling = false
    private var velocity: VelocityTracker? = null
    private val header = LinearLayout(launcher)

    init {
        visibility = INVISIBLE
        // Clip the grid to its own bounds so scrolled rows never paint over the search bar.
        clipChildren = true
        header.orientation = LinearLayout.HORIZONTAL
        header.gravity = Gravity.CENTER_VERTICAL
        val searchRow = LinearLayout(launcher).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        searchRow.addView(launcher.iconImage(R.drawable.ic_search, Color.argb(220, 255, 255, 255), 0), llp(launcher.dpi(19), launcher.dpi(19)).apply { marginEnd = launcher.dpi(10) })
        search.apply {
            hint = "Search apps"
            setHintTextColor(Color.argb(160, 255, 255, 255))
            setTextColor(Color.WHITE)
            textSize = 16f
            background = transparentDrawable
            setSingleLine(true)
            imeOptions = EditorInfo.IME_ACTION_SEARCH or EditorInfo.IME_FLAG_NO_EXTRACT_UI
            setPadding(0, 0, 0, 0)
            addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
                override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { filter(s?.toString().orEmpty()) }
                override fun afterTextChanged(s: Editable?) {}
            })
            setOnEditorActionListener { _, id, _ ->
                if (id == EditorInfo.IME_ACTION_SEARCH) {
                    shown.firstOrNull()?.let { e -> launcher.launchApp(e, grid.getChildAt(0) as? IconView, IconView.SOURCE_DRAWER) }
                        ?: openStore()
                    true
                } else false
            }
        }
        searchRow.addView(search, llp(0, MATCH, 1f))
        searchGlass.setPadding(launcher.dpi(16), 0, launcher.dpi(16), 0)
        searchGlass.addView(searchRow, flp(MATCH, MATCH))
        header.addView(searchGlass, llp(0, launcher.dpi(46), 1f))
        val settings = FrameLayout(launcher).apply {
            background = oval(Color.argb(46, 255, 255, 255))
            isClickable = true
            contentDescription = "Launcher settings"
            setOnClickListener { launcher.haptic(it, HapticFeedbackConstants.CONTEXT_CLICK); launcher.openSettings() }
        }
        settings.addView(launcher.iconImage(R.drawable.ic_settings, Color.WHITE, 11), flp(MATCH, MATCH))
        header.addView(settings, llp(launcher.dpi(46), launcher.dpi(46)).apply { marginStart = launcher.dpi(10) })
        addView(header, flp(MATCH, WRAP))

        grid.apply {
            adapter = this@AppDrawer.adapter
            stretchMode = GridView.STRETCH_COLUMN_WIDTH
            verticalSpacing = launcher.dpi(6)
            isVerticalScrollBarEnabled = false
            selector = transparentDrawable
            cacheColorHint = Color.TRANSPARENT
            clipToPadding = false
            overScrollMode = OVER_SCROLL_IF_CONTENT_SCROLLS
            isVerticalFadingEdgeEnabled = true
            setFadingEdgeLength(launcher.dpi(18))
            setOnScrollListener(object : AbsListView.OnScrollListener {
                override fun onScrollStateChanged(view: AbsListView?, scrollState: Int) {
                    if (scrollState == AbsListView.OnScrollListener.SCROLL_STATE_TOUCH_SCROLL) hideKeyboard()
                }
                override fun onScroll(view: AbsListView?, first: Int, visible: Int, total: Int) {
                    shown.getOrNull(first)?.let { index.setActive(launcher.apps.sectionOf(it)) }
                }
            })
        }
        addView(grid, flp(MATCH, MATCH))
        index.onPick = { letter ->
            val pos = shown.indexOfFirst { launcher.apps.sectionOf(it) == letter }
            if (pos >= 0) grid.setSelection(pos)
        }
        addView(index, flp(launcher.dpi(22), WRAP, Gravity.END or Gravity.CENTER_VERTICAL))

        empty.orientation = LinearLayout.VERTICAL
        empty.gravity = Gravity.CENTER_HORIZONTAL
        empty.addView(emptyText, llp(MATCH, WRAP))
        val store = launcher.textView("Search Play Store", 14f, Color.WHITE, Fonts.medium, Gravity.CENTER).apply {
            background = roundRect(Color.argb(50, 255, 255, 255), launcher.dp(20f))
            setPadding(launcher.dpi(18), launcher.dpi(10), launcher.dpi(18), launcher.dpi(10))
            isClickable = true
            setOnClickListener { openStore() }
        }
        empty.addView(store, llp(WRAP, WRAP).apply { topMargin = launcher.dpi(16) })
        empty.visibility = GONE
        addView(empty, flp(MATCH, WRAP, Gravity.TOP))
        header.bringToFront()
    }

    fun applyInsets(top: Int, bottom: Int) {
        (header.layoutParams as LayoutParams).apply { topMargin = top + launcher.dpi(14); leftMargin = launcher.dpi(18); rightMargin = launcher.dpi(18) }
        (grid.layoutParams as LayoutParams).apply { topMargin = top + launcher.dpi(74); leftMargin = launcher.dpi(8); rightMargin = launcher.dpi(20) }
        grid.setPadding(0, launcher.dpi(8), 0, bottom + launcher.dpi(24))
        (empty.layoutParams as LayoutParams).topMargin = top + launcher.dpi(150)
        (index.layoutParams as LayoutParams).apply { topMargin = top + launcher.dpi(40); rightMargin = launcher.dpi(2) }
        requestLayout()
    }

    fun reload() {
        all = launcher.apps.drawerApps()
        grid.numColumns = launcher.prefs.drawerColumns.coerceIn(3, 6)
        index.setLetters(all.map { launcher.apps.sectionOf(it) }.distinct())
        filter(query)
    }

    private fun filter(q: String) {
        query = q.trim()
        shown = if (query.isEmpty()) all else {
            val lower = query.lowercase(Locale.getDefault())
            val starts = all.filter { launcher.apps.label(it).lowercase(Locale.getDefault()).startsWith(lower) }
            val contains = all.filter { it !in starts && (launcher.apps.label(it).lowercase(Locale.getDefault()).contains(lower) || it.packageName.contains(lower)) }
            starts + contains
        }
        adapter.notifyDataSetChanged()
        index.visibility = if (query.isEmpty() && shown.size > 20) VISIBLE else GONE
        empty.visibility = if (shown.isEmpty()) VISIBLE else GONE
        emptyText.text = "No apps match \"$query\""
    }

    private fun openStore() {
        if (query.isEmpty()) return
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse("market://search?q=" + Uri.encode(query))).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        launcher.startSafely(intent, search)
    }

    fun setProgress(p: Float) {
        progress = p.coerceIn(0f, 1f)
        visibility = if (progress > 0.001f) VISIBLE else INVISIBLE
        alpha = clamp01(progress * 1.25f)
        translationY = (1f - progress) * launcher.dp(110f)
        val s = 0.96f + 0.04f * progress
        scaleX = s; scaleY = s
        launcher.onDrawerProgress(progress)
    }

    val isOpen get() = progress > 0.5f

    fun animateTo(open: Boolean, velocityY: Float = 0f, focusSearch: Boolean = false, end: (() -> Unit)? = null) {
        anim?.cancel()
        if (open) {
            if (all.isEmpty() || grid.adapter == null) reload()
            grid.numColumns = launcher.prefs.drawerColumns.coerceIn(3, 6)
        }
        val spring = if (open) Spring(0.9f, 0.4f) else Spring(1f, 0.28f)
        anim = ValueAnimator.ofFloat(progress, if (open) 1f else 0f).apply {
            duration = spring.ms
            interpolator = spring
            addUpdateListener { setProgress(it.animatedValue as Float) }
            addListener(object : android.animation.AnimatorListenerAdapter() {
                private var cancelled = false
                override fun onAnimationCancel(animation: android.animation.Animator) { cancelled = true }
                override fun onAnimationEnd(animation: android.animation.Animator) {
                    if (cancelled) return
                    if (!open) resetState()
                    end?.invoke()
                }
            })
            start()
        }
        if (open && (focusSearch || launcher.prefs.drawerKeyboard)) {
            search.requestFocus()
            search.postDelayed({ launcher.getSystemService(InputMethodManager::class.java)?.showSoftInput(search, 0) }, 140)
        }
        if (!open) hideKeyboard()
    }

    fun resetState() {
        if (search.text.isNotEmpty()) search.setText("")
        search.clearFocus()
        grid.setSelection(0)
    }

    fun hideKeyboard() {
        launcher.getSystemService(InputMethodManager::class.java)?.hideSoftInputFromWindow(search.windowToken, 0)
    }

    override fun onInterceptTouchEvent(ev: MotionEvent): Boolean {
        if (launcher.drag.isDragging) return false
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downX = ev.x; downY = ev.y; pulling = false
                velocity?.recycle(); velocity = VelocityTracker.obtain(); velocity?.addMovement(ev)
            }
            MotionEvent.ACTION_MOVE -> {
                velocity?.addMovement(ev)
                val dy = ev.y - downY
                if (!pulling && dy > slop * 1.5f && dy > abs(ev.x - downX) * 1.3f && !grid.canScrollVertically(-1) && launcher.drag.armed == null) {
                    pulling = true
                    downY = ev.y
                    anim?.cancel()
                    hideKeyboard()
                    return true
                }
            }
        }
        return pulling
    }

    override fun onTouchEvent(ev: MotionEvent): Boolean {
        if (!pulling) return true
        velocity?.addMovement(ev)
        when (ev.actionMasked) {
            MotionEvent.ACTION_MOVE -> setProgress(1f - max(0f, ev.y - downY) / (height * 0.5f))
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                velocity?.computeCurrentVelocity(1000)
                val vy = velocity?.yVelocity ?: 0f
                pulling = false
                val close = vy > launcher.dp(700f) || (progress < 0.72f && vy > -launcher.dp(300f))
                launcher.setDrawerOpen(!close)
                velocity?.recycle(); velocity = null
            }
        }
        return true
    }

    fun iconFor(key: String): IconView? {
        for (i in 0 until grid.childCount) {
            val v = grid.getChildAt(i) as? IconView ?: continue
            if (v.entry?.key == key && v.isAttachedToWindow) return v
        }
        return null
    }

    fun refreshIcons() { adapter.notifyDataSetChanged() }

    private inner class AppsAdapter : BaseAdapter() {
        override fun getCount() = shown.size
        override fun getItem(position: Int) = shown[position]
        override fun getItemId(position: Int) = shown[position].key.hashCode().toLong()
        override fun hasStableIds() = true

        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
            val entry = shown[position]
            val v = (convertView as? IconView) ?: launcher.createAppIcon(entry, IconView.SOURCE_DRAWER)
            launcher.bindAppIcon(v, entry, IconView.SOURCE_DRAWER)
            v.darkLabel = false
            v.layoutParams = AbsListView.LayoutParams(MATCH, launcher.iconSizePx + launcher.dpi(42))
            return v
        }
    }
}

/** Vertical A–Z index for the drawer with a magnified bubble while scrubbing. */
class AlphabetIndex(private val launcher: MainActivity) : View(launcher) {
    private var letters: List<String> = emptyList()
    private var active = ""
    private var touching = -1
    var onPick: ((String) -> Unit)? = null
    private val paint = android.text.TextPaint(Paint.ANTI_ALIAS_FLAG).apply { typeface = Fonts.semibold; textAlign = Paint.Align.CENTER }
    private val bubble = Paint(Paint.ANTI_ALIAS_FLAG)

    fun setLetters(l: List<String>) { letters = l; requestLayout(); invalidate() }
    fun setActive(l: String) { if (l != active) { active = l; invalidate() } }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        setMeasuredDimension(launcher.dpi(22), (letters.size * launcher.dp(17f)).roundToInt() + launcher.dpi(8))
    }

    override fun onDraw(canvas: Canvas) {
        if (letters.isEmpty()) return
        val step = (height - dp(8f)) / letters.size
        paint.textSize = dp(10.5f)
        letters.forEachIndexed { i, l ->
            val y = dp(4f) + step * (i + 0.5f) - (paint.ascent() + paint.descent()) / 2f
            paint.color = if (l == active || i == touching) Color.WHITE else Color.argb(150, 255, 255, 255)
            canvas.drawText(l, width / 2f, y, paint)
        }
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        if (letters.isEmpty()) return false
        val step = (height - dp(8f)) / letters.size
        val i = ((event.y - dp(4f)) / step).toInt().coerceIn(0, letters.size - 1)
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_MOVE -> {
                parent?.requestDisallowInterceptTouchEvent(true)
                if (i != touching) {
                    touching = i
                    performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)
                    onPick?.invoke(letters[i])
                    launcher.showIndexBubble(letters[i], event.rawY)
                    invalidate()
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                touching = -1
                launcher.showIndexBubble(null, 0f)
                invalidate()
            }
        }
        return true
    }
}
