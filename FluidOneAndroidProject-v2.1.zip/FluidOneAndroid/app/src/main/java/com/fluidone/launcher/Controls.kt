package com.fluidone.launcher

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.accessibility.AccessibilityNodeInfo
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.roundToInt

/**
 * ColorOS-style toggle: a pill track that fills with the accent colour and a white thumb that glides on a
 * spring and stretches toward its destination while pressed.
 */
class ColorSwitch(context: Context, private val theme: UiTheme) : View(context) {
    var isChecked = false
        private set
    var onChange: ((Boolean) -> Unit)? = null

    private var progress = 0f
    private var pressAmount = 0f
    private var anim: ValueAnimator? = null
    private var pressAnim: ValueAnimator? = null
    private val track = Paint(Paint.ANTI_ALIAS_FLAG)
    private val thumb = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }
    private val shadow = Paint(Paint.ANTI_ALIAS_FLAG)
    private val r = RectF()

    init {
        isClickable = true
        isFocusable = true
        setOnClickListener { setChecked(!isChecked, animate = true, fromUser = true) }
        importantForAccessibility = IMPORTANT_FOR_ACCESSIBILITY_YES
    }

    fun setChecked(value: Boolean, animate: Boolean = false, fromUser: Boolean = false) {
        if (value == isChecked && !animate) { progress = if (value) 1f else 0f; invalidate(); return }
        isChecked = value
        anim?.cancel()
        if (!animate) { progress = if (value) 1f else 0f; invalidate() }
        else {
            val spring = Spring(0.7f, 0.34f)
            anim = ValueAnimator.ofFloat(progress, if (value) 1f else 0f).apply {
                duration = spring.durationMs
                interpolator = spring
                addUpdateListener { progress = it.animatedValue as Float; invalidate() }
                start()
            }
        }
        if (fromUser) {
            performHapticFeedback(if (value) HapticFeedbackConstants.CONFIRM else HapticFeedbackConstants.CLOCK_TICK)
            onChange?.invoke(value)
        }
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) =
        setMeasuredDimension(dpi(52), dpi(32))

    override fun onTouchEvent(event: MotionEvent): Boolean {
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> animatePress(1f)
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> animatePress(0f)
        }
        return super.onTouchEvent(event)
    }

    private fun animatePress(to: Float) {
        pressAnim?.cancel()
        pressAnim = ValueAnimator.ofFloat(pressAmount, to).apply {
            duration = if (to > 0f) 120 else 260
            interpolator = Motion.decel
            addUpdateListener { pressAmount = it.animatedValue as Float; invalidate() }
            start()
        }
    }

    override fun onDraw(canvas: Canvas) {
        val h = dp(28f)
        val w = dp(48f)
        val left = (width - w) / 2f
        val top = (height - h) / 2f
        r.set(left, top, left + w, top + h)
        track.color = blendColors(theme.switchOff, theme.accent, progress)
        canvas.drawRoundRect(r, h / 2f, h / 2f, track)
        val inset = dp(3f)
        val d = h - 2 * inset
        val stretch = dp(7f) * pressAmount
        val travel = w - 2 * inset - d
        val x0 = left + inset + travel * progress
        // Stretch toward the side the thumb will travel to.
        val tl = x0 - stretch * progress
        val tr = x0 + d + stretch * (1f - progress)
        r.set(tl, top + inset, tr, top + inset + d)
        shadow.color = Color.argb(40, 0, 0, 0)
        canvas.drawRoundRect(r.left, r.top + dp(1f), r.right, r.bottom + dp(1f), d / 2f, d / 2f, shadow)
        canvas.drawRoundRect(r, d / 2f, d / 2f, thumb)
    }

    override fun onInitializeAccessibilityNodeInfo(info: AccessibilityNodeInfo) {
        super.onInitializeAccessibilityNodeInfo(info)
        info.className = "android.widget.Switch"
        info.isCheckable = true
        info.isChecked = isChecked
    }
}

/** Thick rounded slider with a white thumb that grows while dragged. */
class FluidSlider(context: Context, private val theme: UiTheme, val min: Int, val max: Int, initial: Int) : View(context) {
    var value = initial.coerceIn(min, max)
        private set
    var onChange: ((Int) -> Unit)? = null
    var onCommit: ((Int) -> Unit)? = null

    private var active = 0f
    private var activeAnim: ValueAnimator? = null
    private val trackPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val thumbPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }
    private val shadow = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(46, 0, 0, 0) }
    private val r = RectF()
    private var lastTick = 0L
    private var downX = 0f
    private var dragging = false
    private val slop = ViewConfiguration.get(context).scaledTouchSlop

    init { isClickable = true; isFocusable = true }

    fun setValue(v: Int) { value = v.coerceIn(min, max); invalidate() }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) =
        setMeasuredDimension(MeasureSpec.getSize(widthMeasureSpec), dpi(40))

    private fun fraction() = if (max == min) 0f else (value - min) / (max - min).toFloat()

    override fun onDraw(canvas: Canvas) {
        val thumbR = dp(11f) * (1f + 0.18f * active)
        val trackH = dp(6f) + dp(2f) * active
        val left = dp(12f)
        val right = width - dp(12f)
        val cy = height / 2f
        r.set(left, cy - trackH / 2f, right, cy + trackH / 2f)
        trackPaint.color = theme.switchOff
        canvas.drawRoundRect(r, trackH / 2f, trackH / 2f, trackPaint)
        val x = left + (right - left) * fraction()
        r.set(left, cy - trackH / 2f, x, cy + trackH / 2f)
        fillPaint.color = theme.accent
        canvas.drawRoundRect(r, trackH / 2f, trackH / 2f, fillPaint)
        canvas.drawCircle(x, cy + dp(1f), thumbR, shadow)
        canvas.drawCircle(x, cy, thumbR, thumbPaint)
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downX = event.x
                dragging = false
                animateActive(1f)
            }
            MotionEvent.ACTION_MOVE -> {
                if (!dragging && abs(event.x - downX) > slop) {
                    dragging = true
                    parent?.requestDisallowInterceptTouchEvent(true)
                }
                if (dragging) update(event.x)
            }
            MotionEvent.ACTION_UP -> {
                if (!dragging) update(event.x)
                animateActive(0f)
                onCommit?.invoke(value)
                parent?.requestDisallowInterceptTouchEvent(false)
            }
            MotionEvent.ACTION_CANCEL -> {
                animateActive(0f)
                if (dragging) onCommit?.invoke(value)
            }
        }
        return true
    }

    private fun update(x: Float) {
        val left = dp(12f)
        val right = width - dp(12f)
        val f = ((x - left) / max(1f, right - left)).coerceIn(0f, 1f)
        val v = (min + f * (max - min)).roundToInt()
        if (v != value) {
            value = v
            val now = System.currentTimeMillis()
            if (now - lastTick > 45) { performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK); lastTick = now }
            onChange?.invoke(v)
            invalidate()
        }
    }

    private fun animateActive(to: Float) {
        activeAnim?.cancel()
        activeAnim = ValueAnimator.ofFloat(active, to).apply {
            duration = 180; interpolator = Motion.decel
            addUpdateListener { active = it.animatedValue as Float; invalidate() }
            start()
        }
    }
}

/** Pill segmented control with a sliding highlight. */
class SegmentedControl(
    context: Context,
    private val theme: UiTheme,
    private val labels: List<String>,
    selected: Int
) : View(context) {
    var selected = selected.coerceIn(0, labels.size - 1)
        private set
    var onSelect: ((Int) -> Unit)? = null
    private var highlight = this.selected.toFloat()
    private var anim: ValueAnimator? = null
    private val bg = Paint(Paint.ANTI_ALIAS_FLAG)
    private val hl = Paint(Paint.ANTI_ALIAS_FLAG)
    private val text = android.text.TextPaint(Paint.ANTI_ALIAS_FLAG).apply { typeface = Fonts.medium; textSize = dp(13f) }
    private val r = RectF()

    init { isClickable = true }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) =
        setMeasuredDimension(MeasureSpec.getSize(widthMeasureSpec), dpi(38))

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        r.set(0f, 0f, w, h)
        bg.color = theme.chip
        canvas.drawRoundRect(r, h / 2f, h / 2f, bg)
        val seg = w / labels.size
        val inset = dp(3f)
        r.set(highlight * seg + inset, inset, (highlight + 1) * seg - inset, h - inset)
        hl.color = if (theme.dark) Color.argb(255, 70, 70, 76) else Color.WHITE
        canvas.drawRoundRect(r, (h - 2 * inset) / 2f, (h - 2 * inset) / 2f, hl)
        labels.forEachIndexed { i, label ->
            val t = (1f - abs(highlight - i)).coerceIn(0f, 1f)
            text.color = blendColors(theme.textSecondary, theme.text, t)
            val ellipsized = android.text.TextUtils.ellipsize(label, text, seg - dp(8f), android.text.TextUtils.TruncateAt.END)
            val tw = text.measureText(ellipsized, 0, ellipsized.length)
            canvas.drawText(ellipsized, 0, ellipsized.length, i * seg + (seg - tw) / 2f, h / 2f - (text.ascent() + text.descent()) / 2f, text)
        }
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        if (event.actionMasked == MotionEvent.ACTION_UP) {
            val i = (event.x / (width / labels.size.toFloat())).toInt().coerceIn(0, labels.size - 1)
            select(i, fromUser = true)
        }
        return true
    }

    fun select(i: Int, fromUser: Boolean) {
        if (i == selected) return
        selected = i
        anim?.cancel()
        val spring = Spring(0.82f, 0.32f)
        anim = ValueAnimator.ofFloat(highlight, i.toFloat()).apply {
            duration = spring.durationMs; interpolator = spring
            addUpdateListener { highlight = it.animatedValue as Float; invalidate() }
            start()
        }
        if (fromUser) {
            performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)
            onSelect?.invoke(i)
        }
    }
}
