package com.fluidone.launcher

import android.animation.TimeAnimator
import android.animation.ValueAnimator
import android.content.pm.ApplicationInfo
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Point
import android.graphics.Rect
import android.graphics.RectF
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.View
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.roundToInt
import kotlin.math.PI
import kotlin.math.min
import kotlin.math.sin

/** What is being dragged and where it came from. */
class DragSource(
    val kind: Int,
    val origin: Int,
    val view: View,
    val item: HomeItem? = null,
    val appKey: String? = null,
    val folder: HomeItem? = null,
    val dockIndex: Int = -1
) {
    val spanX get() = item?.spanX ?: 1
    val spanY get() = item?.spanY ?: 1
}

/**
 * Drag and drop for everything on the home screen: free placement on the grid, push-reorder of neighbours,
 * folder creation by hovering on an icon, dock insertion, page switching at the edges, removing and
 * uninstalling. A long press arms a drag; moving past the touch slop starts it.
 */
class DragController(private val launcher: MainActivity) {
    companion object {
        /** How far behind the held icon each stacked app follows its path. */
        const val STACK_DELAY_MS = 42f
    }

    var armed: DragSource? = null
        private set
    private var armX = 0f
    private var armY = 0f
    var popup: ItemPopup? = null
    private var s: Session? = null
    val isDragging get() = s != null
    private val handler = Handler(Looper.getMainLooper())
    private val edgeHandler = Handler(Looper.getMainLooper())
    private val folderToken = Any()
    private val reorderToken = Any()
    // Smaller than the system touch slop so the drag wins over lists that would start scrolling.
    private val slop get() = launcher.dp(6f)

    private enum class Zone { NONE, REMOVE, UNINSTALL, DOCK, WORKSPACE, FOLDER }

    /** An app picked up with a second finger while dragging; it rides in the stack behind the held icon. */
    private inner class Follower(
        val view: IconView,
        val key: String,
        val item: HomeItem?,
        val origin: Int,
        val origPage: Int,
        val origX: Int,
        val origY: Int,
        val dockIndex: Int,
        val iv: ImageView
    ) {
        var joinP = 0f
        var joined = false
        var startX = 0f
        var startY = 0f
        var startScale = 1f
        var joinAnim: ValueAnimator? = null
        var placedItem: HomeItem? = null
        var placedDockKey: String? = null
    }

    private inner class Session(val src: DragSource, val dv: ImageView, val start: RectF, val offX: Float, val offY: Float) {
        val followers = mutableListOf<Follower>()
        val history = ArrayDeque<FloatArray>()
        var ticker: TimeAnimator? = null
        var badge: TextView? = null
        var tilt = 0f
        var pageSwiping = false
        /** True once the stacked apps have been dealt with, so a later cancel leaves them alone. */
        var followersSettled = false
        var zone = Zone.NONE
        var page = -1
        var dropCell: Point? = null
        var dropValid = false
        var folderTarget: HomeItem? = null
        var folderTargetView: IconView? = null
        var pendingHoverItem: HomeItem? = null
        var preview: Map<HomeItem, Point> = emptyMap()
        var previewPage = -1
        var previewCell: Point? = null
        var pendingReorderCell: Point? = null
        var reorderPending = false
        var edgeDir = 0
        var dockGap = -1
        var folderGap = -1
        var x = 0f
        var y = 0f
    }

    fun arm(src: DragSource, x: Float, y: Float, popup: ItemPopup?) {
        if (launcher.prefs.lockLayout && src.origin != IconView.SOURCE_DRAWER) { this.popup = popup; armed = null; return }
        armed = src
        armX = x; armY = y
        this.popup = popup
    }

    fun disarm() { armed = null }

    /** Called by the root on every MOVE while armed; returns true when the drag begins. */
    fun maybeStart(x: Float, y: Float): Boolean {
        if (armed == null || s != null) return false
        if (hypot(x - armX, y - armY) < slop) return false
        start(x, y)
        return true
    }

    private fun start(x: Float, y: Float) {
        val src = armed ?: return
        armed = null
        popup?.handOffToDrag()
        popup = null
        val rect = visualRect(src.view)
        val bmp = snapshot(src.view) ?: run { src.view.alpha = 1f; return }
        val dv = ImageView(launcher).apply {
            setImageBitmap(bmp)
            scaleType = ImageView.ScaleType.FIT_XY
            elevation = launcher.dp(8f)
        }
        launcher.dragLayer.addView(dv, FrameLayout.LayoutParams(rect.width().roundToInt().coerceAtLeast(1), rect.height().roundToInt().coerceAtLeast(1)))
        dv.translationX = rect.left
        dv.translationY = rect.top
        val session = Session(src, dv, RectF(rect), x - rect.left, y - rect.top)
        s = session
        if (src.origin != IconView.SOURCE_DRAWER) src.view.alpha = 0f
        when (src.origin) {
            IconView.SOURCE_DRAWER -> launcher.setDrawerOpen(false)
            IconView.SOURCE_DOCK -> {
                launcher.model.dock.remove(src.appKey)
                src.view.visibility = View.GONE
                launcher.dock.relayoutAnimated()
            }
            IconView.SOURCE_FOLDER -> {
                // Take the icon out of the folder grid so the gap logic counts only the other apps.
                src.view.visibility = View.GONE
                launcher.openFolder?.setDragGap(-1)
            }
        }
        dv.animate().scaleX(1.1f).scaleY(1.1f).setDuration(Motion.d(160)).setInterpolator(Motion.decel).start()
        session.ticker = TimeAnimator().apply { setTimeListener { _, total, _ -> tick(session, total) }; start() }
        launcher.showRemoveBar(src)
        launcher.onDragStarted()
        move(x, y)
    }

    fun move(x: Float, y: Float) {
        val st = s ?: return
        st.x = x; st.y = y
        st.dv.translationX = x - st.offX
        st.dv.translationY = y - st.offY
        if (st.pageSwiping) return
        Device.guardEdges(launcher.rootView, y, launcher.edgeGuardEnabled())
        val zone = zoneAt(st, x, y)
        if (zone != st.zone) leaveZone(st, st.zone)
        st.zone = zone
        launcher.removeBar.highlight(if (zone == Zone.REMOVE) 0 else if (zone == Zone.UNINSTALL) 1 else -1)
        when (zone) {
            Zone.DOCK -> {
                val idx = launcher.dock.insertionIndex(x)
                if (idx != st.dockGap) { st.dockGap = idx; launcher.dock.setGap(idx) }
            }
            Zone.FOLDER -> {
                val fo = launcher.openFolder ?: return
                val idx = fo.indexAtWindow(x, y, st.src.folder?.apps?.size ?: 0)
                if (idx != st.folderGap) { st.folderGap = idx; fo.setDragGap(idx) }
            }
            Zone.WORKSPACE -> overWorkspace(st, x, y)
            else -> {}
        }
    }

    private fun zoneAt(st: Session, x: Float, y: Float): Zone {
        val bar = launcher.removeBar
        if (bar.isShown && y < bar.bottom + launcher.dp(14f)) {
            return when {
                bar.removeVisible && bar.uninstallVisible -> if (x > launcher.rootView.width / 2f) Zone.UNINSTALL else Zone.REMOVE
                bar.uninstallVisible -> Zone.UNINSTALL
                bar.removeVisible -> Zone.REMOVE
                else -> Zone.WORKSPACE
            }
        }
        val fo = launcher.openFolder
        if (fo != null && st.src.origin == IconView.SOURCE_FOLDER && !fo.closing) {
            // A small margin only: the panel is nearly full width, so a large one would trap the icon inside.
            val r = fo.panelRectInWindow(); r.inset(-launcher.dp(6f), -launcher.dp(24f))
            if (r.contains(x, y)) return Zone.FOLDER
            fo.closeForDrag()
        }
        if (launcher.dock.visibility == View.VISIBLE && !launcher.isEditing) {
            val loc = IntArray(2); launcher.dock.getLocationInWindow(loc)
            if (y >= loc[1] - launcher.dp(10f)) return if (dockAccepts(st.src)) Zone.DOCK else Zone.NONE
        }
        return Zone.WORKSPACE
    }

    private fun dockAccepts(src: DragSource): Boolean {
        if (src.kind != HomeItem.APP || launcher.isEditing || launcher.dock.visibility != View.VISIBLE) return false
        val capacity = launcher.dock.capacity(launcher.prefs.columns)
        return launcher.model.dock.size < capacity
    }

    private fun leaveZone(st: Session, zone: Zone) {
        when (zone) {
            Zone.DOCK -> { st.dockGap = -1; launcher.dock.setGap(-1) }
            Zone.FOLDER -> { st.folderGap = -1; launcher.openFolder?.setDragGap(-1) }
            Zone.WORKSPACE -> clearWorkspaceFeedback(st, revert = true)
            else -> {}
        }
    }

    private fun clearWorkspaceFeedback(st: Session, revert: Boolean) {
        handler.removeCallbacksAndMessages(null)
        edgeHandler.removeCallbacks(edgeRunnable)
        st.pendingHoverItem = null
        st.pendingReorderCell = null
        st.reorderPending = false
        st.edgeDir = 0
        clearFolderHover(st)
        launcher.workspace.pages.getOrNull(st.page)?.setDropHint(null)
        if (revert) revertPreview(st)
        st.dropCell = null
        st.dropValid = false
    }

    private fun toLocal(v: View, x: Float, y: Float): FloatArray {
        val m = Matrix(); v.transformMatrixToGlobal(m)
        val inv = Matrix(); m.invert(inv)
        val pts = floatArrayOf(x, y); inv.mapPoints(pts)
        return pts
    }

    private fun overWorkspace(st: Session, x: Float, y: Float) {
        val ws = launcher.workspace
        handleEdges(st, x)
        if (ws.isSettling) return
        val p = ws.pageAtWindowPoint(x, y)
        if (p != st.page) {
            launcher.workspace.pages.getOrNull(st.page)?.setDropHint(null)
            clearFolderHover(st)
            revertPreview(st)
            st.page = p
        }
        val cl = ws.pages.getOrNull(p) ?: return
        val local = toLocal(cl, x, y)
        val cols = launcher.prefs.columns
        val rows = launcher.prefs.rows
        val sx = st.src.spanX
        val sy = st.src.spanY
        if (sx == 1 && sy == 1) {
            val cell = cl.cellAt(local[0], local[1])
            val target = itemAtPreview(st, p, cell.x, cell.y)
            when {
                target == null -> {
                    cancelHover(st)
                    if (st.preview.isNotEmpty() && st.previewCell != cell && launcher.model.itemAt(p, cell.x, cell.y, st.src.item) == null) revertPreview(st)
                    setDrop(st, cl, p, cell, true)
                }
                st.src.kind == HomeItem.APP && (target.type == HomeItem.APP || target.type == HomeItem.FOLDER) && nearCenter(cl, target, local) -> {
                    // Hovering on an icon's centre: folder creation wins over reordering.
                    handler.removeCallbacksAndMessages(reorderToken)
                    st.pendingReorderCell = null
                    cl.setDropHint(null)
                    st.dropCell = null
                    if (st.folderTarget !== target && st.pendingHoverItem !== target) {
                        clearFolderHover(st)
                        st.pendingHoverItem = target
                        handler.removeCallbacksAndMessages(folderToken)
                        handler.postDelayed({ beginFolderHover(st, cl, target) }, folderToken, 200)
                    }
                }
                target.spanX == 1 && target.spanY == 1 -> {
                    handler.removeCallbacksAndMessages(folderToken)
                    st.pendingHoverItem = null
                    clearFolderHover(st)
                    if (st.pendingReorderCell != cell || (!st.reorderPending && st.previewCell != cell && st.dropCell != cell)) {
                        st.pendingReorderCell = cell
                        st.reorderPending = true
                        handler.removeCallbacksAndMessages(reorderToken)
                        handler.postDelayed({ st.reorderPending = false; applyReorder(st, cl, p, cell) }, reorderToken, 160)
                    }
                }
                else -> {
                    cancelHover(st)
                    val near = launcher.model.findNearestVacant(p, cell.x, cell.y, 1, 1, cols, rows, st.src.item)
                    if (near != null) setDrop(st, cl, p, near, true) else setDrop(st, cl, p, cell, false)
                }
            }
        } else {
            cancelHover(st)
            val o = cl.spanOrigin(local[0], local[1], sx, sy)
            val free = launcher.model.isRegionFree(p, o.x, o.y, sx, sy, cols, rows, st.src.item)
            val spot = if (free) o else launcher.model.findNearestVacant(p, o.x, o.y, sx, sy, cols, rows, st.src.item)
            if (spot != null) setDrop(st, cl, p, spot, true) else setDrop(st, cl, p, o, false)
        }
    }

    private fun cancelHover(st: Session) {
        handler.removeCallbacksAndMessages(null)
        st.pendingHoverItem = null
        st.pendingReorderCell = null
        st.reorderPending = false
        clearFolderHover(st)
    }

    private fun itemAtPreview(st: Session, page: Int, x: Int, y: Int): HomeItem? {
        val items = launcher.model.pages.getOrNull(page) ?: return null
        for (item in items) {
            if (item === st.src.item) continue
            val pos = if (st.previewPage == page) st.preview[item] else null
            val ix = pos?.x ?: item.x
            val iy = pos?.y ?: item.y
            if (x >= ix && x < ix + item.spanX && y >= iy && y < iy + item.spanY) return item
        }
        return null
    }

    private fun nearCenter(cl: CellLayout, target: HomeItem, local: FloatArray): Boolean {
        val v = cl.childFor(target) as? IconView ?: return false
        val r = RectF(); v.computeIconRect(r)
        r.offset(v.left + v.translationX, v.top + v.translationY)
        val radius = r.width() * if (target.isLargeFolder) 0.5f else 0.42f
        return hypot(local[0] - r.centerX(), local[1] - r.centerY()) < radius
    }

    private fun beginFolderHover(st: Session, cl: CellLayout, target: HomeItem) {
        if (s !== st || st.pendingHoverItem !== target) return
        st.pendingHoverItem = null
        revertPreview(st)
        val v = cl.childFor(target) as? IconView ?: return
        st.folderTarget = target
        st.folderTargetView = v
        launcher.haptic(v, HapticFeedbackConstants.CLOCK_TICK)
        Motion.spring(Spring(0.7f, 0.32f), update = { v.hoverPlate = it; v.hoverScale = 1f + 0.06f * it })
    }

    private fun clearFolderHover(st: Session) {
        val v = st.folderTargetView
        st.folderTarget = null
        st.folderTargetView = null
        if (v != null) {
            val from = v.hoverPlate
            Motion.animate(180, Motion.decel, update = { v.hoverPlate = from * (1 - it); v.hoverScale = 1f + 0.06f * from * (1 - it) })
        }
    }

    private fun applyReorder(st: Session, cl: CellLayout, page: Int, cell: Point) {
        if (s !== st) return
        val cols = launcher.prefs.columns
        val rows = launcher.prefs.rows
        val push = launcher.model.computePush(page, cols, rows, cell.x, cell.y, st.src.item)
        if (push == null) { setDrop(st, cl, page, cell, false); return }
        // Animate the difference between the current preview and the new one.
        val old = if (st.previewPage == page) st.preview else emptyMap()
        for ((item, _) in old) if (item !in push) cl.childFor(item)?.let { cl.animateChildTo(it, item.x, item.y) }
        var i = 0
        for ((item, pos) in push) {
            val cur = old[item] ?: Point(item.x, item.y)
            if (cur != pos) cl.childFor(item)?.let { cl.animateChildTo(it, pos.x, pos.y, (i++ * 12L)) }
        }
        st.preview = push
        st.previewPage = page
        st.previewCell = cell
        setDrop(st, cl, page, cell, true)
    }

    private fun revertPreview(st: Session) {
        if (st.preview.isEmpty()) return
        val cl = launcher.workspace.pages.getOrNull(st.previewPage)
        if (cl != null) for ((item, _) in st.preview) cl.childFor(item)?.let { cl.animateChildTo(it, item.x, item.y) }
        st.preview = emptyMap()
        st.previewPage = -1
        st.previewCell = null
    }

    private fun setDrop(st: Session, cl: CellLayout, page: Int, cell: Point, valid: Boolean) {
        st.page = page
        st.dropCell = cell
        st.dropValid = valid
        cl.setDropHint(Rect(cell.x, cell.y, cell.x + st.src.spanX, cell.y + st.src.spanY), valid)
    }

    private val edgeRunnable = object : Runnable {
        override fun run() {
            val st = s ?: return
            if (st.edgeDir == 0) return
            val ws = launcher.workspace
            val target = ws.currentPage + st.edgeDir
            val lastIndex = ws.pageCount - 1
            if (target in 0..lastIndex) {
                clearWorkspaceFeedback(st, revert = true)
                st.edgeDir = if (st.x < launcher.dp(26f)) -1 else if (st.x > launcher.rootView.width - launcher.dp(26f)) 1 else 0
                ws.snapTo(target)
                launcher.haptic(ws, HapticFeedbackConstants.CLOCK_TICK)
            } else if (st.edgeDir > 0 && target == lastIndex + 1 && launcher.canAddPageDuringDrag(st.src.item)) {
                clearWorkspaceFeedback(st, revert = true)
                st.edgeDir = 1
                launcher.addEmptyPage()
                ws.snapTo(target)
                launcher.haptic(ws, HapticFeedbackConstants.CLOCK_TICK)
            }
            if (st.edgeDir != 0) edgeHandler.postDelayed(this, 750)
        }
    }

    private fun handleEdges(st: Session, x: Float) {
        val edge = launcher.dp(26f)
        val dir = if (x < edge) -1 else if (x > launcher.rootView.width - edge) 1 else 0
        if (dir != st.edgeDir) {
            edgeHandler.removeCallbacks(edgeRunnable)
            st.edgeDir = dir
            if (dir != 0) edgeHandler.postDelayed(edgeRunnable, 480)
        }
    }

    // ---- Stack: pick up more apps with another finger ----------------------------------------------------

    val stackSize: Int get() = s?.let { 1 + it.followers.size } ?: 0

    /** A quick tap by another finger while dragging: adds the app under it to the stack. */
    fun tapAt(x: Float, y: Float): Boolean {
        val st = s ?: return false
        if (st.src.kind != HomeItem.APP || st.pageSwiping || launcher.openFolder != null) return false
        val v = stackableIconAt(x, y) ?: return false
        if (v === st.src.view || st.followers.any { it.view === v }) return false
        val key = v.entry?.key ?: return false
        clearWorkspaceFeedback(st, revert = true)
        val rect = v.iconRectInWindow()
        val w0 = st.dv.layoutParams.width.coerceAtLeast(1)
        val h0 = st.dv.layoutParams.height.coerceAtLeast(1)
        val iv = ImageView(launcher).apply {
            setImageBitmap(v.bitmap)
            scaleType = ImageView.ScaleType.FIT_XY
            elevation = launcher.dp(7f)
        }
        val f: Follower
        if (v.source == IconView.SOURCE_DOCK) {
            val idx = launcher.model.dock.indexOf(key)
            launcher.model.dock.remove(key)
            f = Follower(v, key, null, IconView.SOURCE_DOCK, -1, 0, 0, idx, iv)
            v.alpha = 0f
            v.visibility = View.GONE
            launcher.dock.relayoutAnimated()
        } else {
            val item = v.item ?: return false
            val page = launcher.model.pageOf(item)
            launcher.model.removeItem(item)
            f = Follower(v, key, item, IconView.SOURCE_WORKSPACE, page, item.x, item.y, -1, iv)
            v.alpha = 0f
        }
        f.startScale = rect.width() / w0
        f.startX = rect.centerX() - w0 / 2f
        f.startY = rect.centerY() - h0 / 2f
        launcher.dragLayer.addView(iv, 0, FrameLayout.LayoutParams(w0, h0))
        iv.translationX = f.startX; iv.translationY = f.startY
        iv.scaleX = f.startScale; iv.scaleY = f.startScale
        st.followers.add(f)
        val spring = Spring(0.74f, 0.36f)
        f.joinAnim = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = spring.ms
            interpolator = spring
            addUpdateListener { f.joinP = it.animatedValue as Float }
            addListener(object : android.animation.AnimatorListenerAdapter() {
                override fun onAnimationEnd(animation: android.animation.Animator) { f.joinP = 1f; f.joined = true }
            })
            start()
        }
        updateBadge(st, pop = true)
        launcher.removeBar.setTargets(canRemove = true, canUninstall = false)
        launcher.haptic(launcher.rootView, HapticFeedbackConstants.CLOCK_TICK)
        if (!st.pageSwiping) move(st.x, st.y)
        return true
    }

    private fun stackableIconAt(x: Float, y: Float): IconView? {
        val candidates = mutableListOf<IconView>()
        if (launcher.dock.visibility == View.VISIBLE && !launcher.isEditing) candidates += launcher.dock.icons
        launcher.workspace.pages.getOrNull(launcher.workspace.currentPage)?.childList()?.forEach { c ->
            if (c is IconView && c !is FolderIconView && c.item?.type == HomeItem.APP) candidates += c
        }
        return candidates.firstOrNull { v ->
            v.isShown && v.alpha > 0.5f && v.entry != null && visualBounds(v).contains(x, y)
        }
    }

    private fun visualBounds(v: View): RectF {
        val r = RectF(0f, 0f, v.width.toFloat(), v.height.toFloat())
        val m = Matrix(); v.transformMatrixToGlobal(m); m.mapRect(r)
        return r
    }

    /** Another finger started swiping sideways: the pages follow it while the stack stays put. */
    fun beginPageSwipe() {
        val st = s ?: return
        clearWorkspaceFeedback(st, revert = true)
        launcher.dock.setGap(-1)
        st.dockGap = -1
        st.zone = Zone.NONE
        st.pageSwiping = true
        launcher.workspace.beginExternalDrag()
    }

    fun pageSwipe(dxPx: Float) {
        if (s?.pageSwiping == true) launcher.workspace.externalDrag(dxPx)
    }

    fun endPageSwipe(vx: Float) {
        val st = s ?: return
        if (!st.pageSwiping) return
        launcher.workspace.endExternalDrag(vx) {
            if (s === st) { st.pageSwiping = false; move(st.x, st.y) }
        }
        // Allow drops even before the page settles; the next move re-evaluates the target.
        st.pageSwiping = false
        st.zone = Zone.NONE
    }

    /** Per frame: tilt the held icon with its speed and let each stacked app replay its path slightly later. */
    private fun tick(st: Session, totalMs: Long) {
        if (s !== st) return
        val now = totalMs.toFloat()
        val dv = st.dv
        st.history.addLast(floatArrayOf(now, dv.translationX, dv.translationY, dv.rotation))
        while (st.history.size > 2 && now - st.history.first()[0] > 900f) st.history.removeFirst()
        val past = sample(st, now - 70f)
        val vx = (dv.translationX - past[1]) / 70f
        val targetTilt = (vx * 7f).coerceIn(-7f, 7f)
        st.tilt += (targetTilt - st.tilt) * 0.22f
        dv.rotation = st.tilt
        val w0 = dv.layoutParams.width.coerceAtLeast(1)
        val h0 = dv.layoutParams.height.coerceAtLeast(1)
        st.followers.forEachIndexed { i, f ->
            val depth = min(i + 1, 3)
            val h = sample(st, now - depth * STACK_DELAY_MS)
            val targetScale = dv.scaleX * (1f - 0.035f * depth)
            val iv = f.iv
            if (!f.joined) {
                val p = f.joinP
                iv.translationX = lerp(f.startX, h[1], p)
                iv.translationY = lerp(f.startY, h[2], p) - sin(PI.toFloat() * p.coerceIn(0f, 1f)) * launcher.dp(30f)
                val sc = lerp(f.startScale, targetScale, p) + 0.14f * sin(PI.toFloat() * p.coerceIn(0f, 1f))
                iv.scaleX = sc; iv.scaleY = sc
                iv.rotation = lerp(0f, h[3], p)
                iv.visibility = View.VISIBLE
            } else {
                iv.translationX = h[1]; iv.translationY = h[2]
                iv.scaleX = targetScale; iv.scaleY = targetScale
                iv.rotation = h[3]
                // Deeper apps sit exactly behind the third one; no need to draw them.
                iv.visibility = if (i >= 3) View.INVISIBLE else View.VISIBLE
            }
        }
        st.badge?.let { b ->
            val half = w0 / 2f * dv.scaleX
            b.translationX = dv.translationX + w0 / 2f + half - b.width * 0.62f
            b.translationY = dv.translationY + h0 / 2f - half - b.height * 0.38f
            b.rotation = dv.rotation
        }
    }

    /** The held icon's position [t] ms into the drag, interpolated from the recorded path. */
    private fun sample(st: Session, t: Float): FloatArray {
        val h = st.history
        if (h.isEmpty()) return floatArrayOf(t, st.dv.translationX, st.dv.translationY, st.dv.rotation)
        if (t <= h.first()[0]) return h.first()
        for (i in h.size - 1 downTo 1) {
            val b = h[i]; val a = h[i - 1]
            if (t >= a[0]) {
                val f = if (b[0] > a[0]) ((t - a[0]) / (b[0] - a[0])).coerceIn(0f, 1f) else 1f
                return floatArrayOf(t, lerp(a[1], b[1], f), lerp(a[2], b[2], f), lerp(a[3], b[3], f))
            }
        }
        return h.last()
    }

    private fun updateBadge(st: Session, pop: Boolean) {
        if (st.followers.isEmpty()) { st.badge?.removeFromParent(); st.badge = null; return }
        val badge = st.badge ?: launcher.textView("", 13f, launcher.ui.onAccent, Fonts.bold, Gravity.CENTER).apply {
            background = oval(launcher.prefs.accent)
            elevation = launcher.dp(10f)
            minWidth = launcher.dpi(26)
            setPadding(launcher.dpi(6), 0, launcher.dpi(6), 0)
            launcher.dragLayer.addView(this, FrameLayout.LayoutParams(WRAP, launcher.dpi(26)))
            st.badge = this
        }
        badge.text = (st.followers.size + 1).toString()
        badge.contentDescription = "${st.followers.size + 1} apps"
        if (pop) {
            badge.scaleX = 0.4f; badge.scaleY = 0.4f
            val spring = Spring(0.55f, 0.32f)
            badge.animate().scaleX(1f).scaleY(1f).setDuration(spring.ms).setInterpolator(spring).start()
        }
    }

    private fun stopStack(st: Session) {
        st.ticker?.cancel()
        st.ticker = null
        st.followers.forEach { f -> f.joinAnim?.cancel(); f.joined = true; f.joinP = 1f }
        st.badge?.animate()?.alpha(0f)?.scaleX(0.5f)?.scaleY(0.5f)?.setDuration(Motion.d(140))?.start()
    }

    /** Lays the stacked apps out after the held icon on [page], spilling onto the following pages. */
    private fun placeFollowersOnPage(st: Session, page: Int, after: Point?) {
        val model = launcher.model
        val cols = launcher.prefs.columns
        val rows = launcher.prefs.rows
        var idx = if (after == null) 0 else after.y * cols + after.x + 1
        for (f in st.followers) {
            val item = f.item?.also { it.spanX = 1; it.spanY = 1 } ?: HomeItem(model.newId(), HomeItem.APP, appKey = f.key)
            var placed = false
            while (page in model.pages.indices && idx < cols * rows) {
                val x = idx % cols; val y = idx / cols
                idx++
                if (model.isRegionFree(page, x, y, 1, 1, cols, rows)) {
                    item.x = x; item.y = y; model.pages[page].add(item); placed = true; break
                }
            }
            if (!placed && model.place(item, cols, rows, (page + 1).coerceAtMost(model.pages.size)) < 0) {
                launcher.toast("The home screen is full; some apps stay in the app drawer")
                continue
            }
            f.placedItem = item
        }
    }

    private fun placeFollowersInDock(st: Session, startIndex: Int) {
        val model = launcher.model
        val capacity = launcher.dock.capacity(launcher.prefs.columns)
        var i = startIndex
        val overflow = mutableListOf<Follower>()
        for (f in st.followers) {
            if (model.dock.size < capacity && f.key !in model.dock) {
                model.dock.add(i.coerceIn(0, model.dock.size), f.key)
                i++
                f.placedDockKey = f.key
            } else overflow += f
        }
        if (overflow.isNotEmpty()) {
            val cols = launcher.prefs.columns; val rows = launcher.prefs.rows
            for (f in overflow) {
                val item = f.item?.also { it.spanX = 1; it.spanY = 1 } ?: HomeItem(model.newId(), HomeItem.APP, appKey = f.key)
                if (model.place(item, cols, rows, launcher.workspace.currentPage) >= 0) f.placedItem = item
            }
        }
    }

    /** Puts every stacked app back where it was picked up. */
    private fun restoreFollowers(st: Session) {
        val model = launcher.model
        val cols = launcher.prefs.columns; val rows = launcher.prefs.rows
        st.followers.filter { it.origin == IconView.SOURCE_DOCK }.sortedBy { it.dockIndex }.forEach { f ->
            if (f.key !in model.dock) model.dock.add(f.dockIndex.coerceIn(0, model.dock.size), f.key)
            f.placedDockKey = f.key
        }
        st.followers.filter { it.origin == IconView.SOURCE_WORKSPACE }.forEach { f ->
            val item = f.item ?: return@forEach
            item.x = f.origX; item.y = f.origY
            if (f.origPage in model.pages.indices && model.isRegionFree(f.origPage, f.origX, f.origY, 1, 1, cols, rows)) model.pages[f.origPage].add(item)
            else model.place(item, cols, rows, f.origPage.coerceAtLeast(0))
            f.placedItem = item
        }
    }

    /** Flies each stacked app to where it landed (or into [into] and fades), one after another. */
    private fun flyFollowers(st: Session, into: RectF? = null) {
        if (st.followers.isEmpty()) return
        launcher.rootView.post {
            st.followers.forEachIndexed { i, f ->
                val iv = f.iv
                val w = iv.layoutParams.width.coerceAtLeast(1)
                val h = iv.layoutParams.height.coerceAtLeast(1)
                val target: View? = f.placedItem?.let { item ->
                    launcher.workspace.pages.getOrNull(launcher.model.pageOf(item))?.childFor(item)
                } ?: f.placedDockKey?.let { launcher.dock.iconFor(it) }
                val rect: RectF
                val fade: Boolean
                when {
                    target is IconView -> { rect = target.iconRectInWindow(); fade = false }
                    target != null -> { rect = visualBounds(target); fade = false }
                    else -> {
                        val base = into ?: RectF(iv.translationX, iv.translationY, iv.translationX + w, iv.translationY + h)
                        rect = RectF(base.centerX() - base.width() * 0.18f, base.centerY() - base.height() * 0.18f,
                            base.centerX() + base.width() * 0.18f, base.centerY() + base.height() * 0.18f)
                        fade = true
                    }
                }
                iv.visibility = View.VISIBLE
                val spring = Spring(0.84f, 0.34f)
                iv.animate().cancel()
                iv.animate()
                    .translationX(rect.centerX() - w / 2f).translationY(rect.centerY() - h / 2f)
                    .scaleX(rect.width() / w).scaleY(rect.height() / h)
                    .rotation(0f).alpha(if (fade) 0f else 1f)
                    .setStartDelay(Motion.d(45L * (i + 1)))
                    .setDuration(spring.ms).setInterpolator(spring)
                    .withEndAction {
                        target?.alpha = 1f
                        target?.visibility = View.VISIBLE
                        launcher.revealDone(f.placedItem, f.placedDockKey)
                        iv.removeFromParent()
                    }
                    .start()
            }
        }
    }

    fun drop(x: Float, y: Float) {
        val st = s ?: return
        if (st.pageSwiping) {
            // The holding finger lifted mid-swipe: settle on the nearest page right away, then drop there.
            st.pageSwiping = false
            launcher.workspace.snapTo(launcher.workspace.scrollPos.roundToInt(), animate = false)
        }
        stopStack(st)
        move(x, y)
        handler.removeCallbacksAndMessages(null)
        edgeHandler.removeCallbacksAndMessages(null)
        launcher.hideRemoveBar()
        Device.guardEdges(launcher.rootView, 0f, false)
        val src = st.src
        val key = src.appKey
        when (st.zone) {
            Zone.REMOVE -> {
                if (src.origin == IconView.SOURCE_DRAWER) {
                    // The held app came from the drawer; only the stacked home-screen apps are removed.
                    flyFollowers(st)
                    st.followersSettled = true
                    launcher.model.save()
                    cancel(); return
                }
                flyFollowers(st)
                removeFromOrigin(st)
                src.item?.let { if (it.type == HomeItem.WIDGET) launcher.deleteWidgetId(it.widgetId) }
                launcher.model.save()
                launcher.syncAll()
                launcher.haptic(launcher.rootView, HapticFeedbackConstants.CONFIRM)
                release(st)
                st.dv.animate().scaleX(0.4f).scaleY(0.4f).alpha(0f).setDuration(Motion.d(200)).setInterpolator(Motion.accel)
                    .withEndAction { end(st) }.start()
            }
            Zone.UNINSTALL -> {
                val entry = key?.let { launcher.apps[it] }
                val single = st.followers.isEmpty()
                cancel()
                if (entry != null && single) launcher.uninstall(entry)
            }
            Zone.FOLDER -> {
                val fo = launcher.openFolder
                val folder = src.folder
                if (fo == null || folder == null || key == null) { cancel(); return }
                if (st.followers.isNotEmpty()) {
                    restoreFollowers(st)
                    launcher.syncAll(revealItems = st.followers.mapNotNull { it.placedItem }, revealKeys = st.followers.mapNotNull { it.placedDockKey })
                    flyFollowers(st)
                }
                val idx = st.folderGap.coerceIn(0, max(0, folder.apps.size - 1))
                folder.apps.remove(key)
                folder.apps.add(idx.coerceAtMost(folder.apps.size), key)
                launcher.model.save()
                fo.refreshAfterChange()
                launcher.syncFolderIcon(folder)
                fo.root.post {
                    val r = fo.slotRect(folder.apps.indexOf(key))
                    val icon = fo.iconFor(key)
                    icon?.alpha = 0f
                    flyTo(st, r) { icon?.alpha = 1f; end(st) }
                }
            }
            Zone.DOCK -> {
                if (key == null) { cancel(); return }
                val idx = st.dockGap.coerceIn(0, launcher.model.dock.size)
                val rect = launcher.dock.slotRectInWindow(idx)
                removeFromOrigin(st)
                launcher.model.dock.remove(key)
                launcher.model.dock.add(idx, key)
                placeFollowersInDock(st, idx + 1)
                launcher.model.save()
                launcher.syncAll(revealDockKey = key, revealItems = st.followers.mapNotNull { it.placedItem }, revealKeys = st.followers.mapNotNull { it.placedDockKey })
                flyFollowers(st)
                flyTo(st, rect) { launcher.dock.iconFor(key)?.alpha = 1f; end(st) }
            }
            Zone.WORKSPACE -> dropOnWorkspace(st)
            Zone.NONE -> cancel()
        }
    }

    private fun dropOnWorkspace(st: Session) {
        val src = st.src
        val page = st.page
        val cl = launcher.workspace.pages.getOrNull(page)
        val folderTarget = st.folderTarget
        val key = src.appKey
        if (cl == null) { cancel(); return }
        if (folderTarget != null && key != null) {
            val targetView = st.folderTargetView
            val rect = targetView?.iconRectInWindow() ?: st.start
            clearFolderHover(st)
            removeFromOrigin(st)
            val stacked = st.followers.map { it.key }.filter { it != key && it != folderTarget.appKey }
            if (folderTarget.type == HomeItem.APP) {
                val pageItems = launcher.model.pages[page]
                val all = (listOf(folderTarget.appKey, key) + stacked).distinct()
                val folder = HomeItem(launcher.model.newId(), HomeItem.FOLDER, folderTarget.x, folderTarget.y, 1, 1,
                    title = suggestFolderName(all), apps = all.toMutableList())
                val at = pageItems.indexOf(folderTarget)
                pageItems.remove(folderTarget)
                pageItems.add(if (at >= 0) at else pageItems.size, folder)
            } else {
                if (key !in folderTarget.apps) folderTarget.apps.add(key)
                stacked.forEach { if (it !in folderTarget.apps) folderTarget.apps.add(it) }
            }
            launcher.model.save()
            launcher.syncAll()
            flyFollowers(st, into = rect)
            launcher.haptic(cl, HapticFeedbackConstants.CONFIRM)
            val shrink = RectF(rect.centerX() - rect.width() * 0.18f, rect.centerY() - rect.height() * 0.18f, rect.centerX() + rect.width() * 0.18f, rect.centerY() + rect.height() * 0.18f)
            flyTo(st, shrink, fade = true) { end(st) }
            return
        }
        val cell = st.dropCell
        if (cell == null || !st.dropValid) { cancel(); return }
        val cols = launcher.prefs.columns
        val rows = launcher.prefs.rows
        // Commit pushed neighbours.
        if (st.previewPage == page) for ((item, pos) in st.preview) { item.x = pos.x; item.y = pos.y }
        st.preview = emptyMap()
        val item: HomeItem
        if (src.item != null && src.origin == IconView.SOURCE_WORKSPACE) {
            item = src.item
            launcher.model.removeItem(item)
            item.x = cell.x; item.y = cell.y
            launcher.model.pages[page].add(item)
        } else {
            item = HomeItem(launcher.model.newId(), HomeItem.APP, cell.x, cell.y, appKey = key ?: run { cancel(); return })
            removeFromOrigin(st)
            launcher.model.pages[page].add(item)
        }
        if (!launcher.model.isRegionFree(page, item.x, item.y, item.spanX, item.spanY, cols, rows, item)) {
            // Should not happen, but never leave overlapping items behind.
            launcher.model.removeItem(item)
            launcher.model.place(item, cols, rows, page)
        }
        cl.setDropHint(null)
        placeFollowersOnPage(st, launcher.model.pageOf(item), Point(item.x, item.y))
        launcher.model.save()
        launcher.syncAll(revealItem = item, revealItems = st.followers.mapNotNull { it.placedItem })
        flyFollowers(st)
        val targetPage = launcher.model.pageOf(item)
        val targetCl = launcher.workspace.pages.getOrNull(targetPage) ?: cl
        targetCl.post {
            val v = targetCl.childFor(item)
            val rect = when (v) {
                is IconView -> v.iconRectInWindow()
                null -> st.start
                else -> RectF(0f, 0f, v.width.toFloat(), v.height.toFloat()).also { r ->
                    val m = Matrix(); v.transformMatrixToGlobal(m); m.mapRect(r)
                }
            }
            flyTo(st, rect) { v?.alpha = 1f; launcher.revealDone(); end(st) }
        }
        launcher.haptic(cl, HapticFeedbackConstants.GESTURE_END)
    }

    private fun removeFromOrigin(st: Session) {
        val src = st.src
        when (src.origin) {
            IconView.SOURCE_WORKSPACE -> src.item?.let { launcher.model.removeItem(it) }
            IconView.SOURCE_FOLDER -> {
                val folder = src.folder ?: return
                folder.apps.remove(src.appKey)
                launcher.model.normalizeFolders()
                launcher.openFolder?.let { if (it.item === folder && !it.closing) it.refreshAfterChange() }
            }
            else -> {}
        }
    }

    /** Releases the drag and animates it home. */
    fun cancel() {
        val st = s ?: return
        handler.removeCallbacksAndMessages(null)
        edgeHandler.removeCallbacksAndMessages(null)
        clearWorkspaceFeedback(st, revert = true)
        launcher.dock.setGap(-1)
        launcher.openFolder?.setDragGap(-1)
        launcher.hideRemoveBar()
        Device.guardEdges(launcher.rootView, 0f, false)
        val src = st.src
        stopStack(st)
        if (st.pageSwiping) { st.pageSwiping = false; launcher.workspace.snapTo(launcher.workspace.scrollPos.roundToInt()) }
        if (src.origin == IconView.SOURCE_DOCK && src.appKey != null && src.appKey !in launcher.model.dock) {
            launcher.model.dock.add(src.dockIndex.coerceIn(0, launcher.model.dock.size), src.appKey)
        }
        val restore = st.followers.isNotEmpty() && !st.followersSettled
        if (restore) restoreFollowers(st)
        launcher.syncAll(
            revealDockKey = if (src.origin == IconView.SOURCE_DOCK) src.appKey else null,
            revealItems = if (restore) st.followers.mapNotNull { it.placedItem } else emptyList(),
            revealKeys = if (restore) st.followers.mapNotNull { it.placedDockKey } else emptyList()
        )
        if (restore) flyFollowers(st)
        release(st)
        launcher.rootView.post {
            val target = when {
                src.origin == IconView.SOURCE_DOCK -> src.appKey?.let { launcher.dock.iconFor(it) }
                src.origin == IconView.SOURCE_DRAWER -> null
                src.view.isAttachedToWindow -> src.view
                else -> null
            }
            val rect = when {
                target is IconView -> target.iconRectInWindow()
                target != null -> visualRect(target)
                else -> st.start
            }
            flyTo(st, rect, fade = target == null) {
                target?.alpha = 1f
                target?.visibility = View.VISIBLE
                src.view.alpha = 1f
                launcher.revealDone()
                end(st)
            }
        }
    }

    private fun flyTo(st: Session, r: RectF, fade: Boolean = false, end: () -> Unit) {
        val dv = st.dv
        val w = dv.width.coerceAtLeast(1)
        val h = dv.height.coerceAtLeast(1)
        val spring = Spring(0.86f, 0.32f)
        dv.animate().cancel()
        dv.animate()
            .translationX(r.centerX() - w / 2f)
            .translationY(r.centerY() - h / 2f)
            .scaleX(r.width() / w).scaleY(r.height() / h)
            .rotation(0f)
            .alpha(if (fade) 0f else 1f)
            .setDuration(spring.ms).setInterpolator(spring)
            .withEndAction(end)
            .start()
        release(st)
    }

    /** Ends the interactive part of a drag; the drag view may still be settling. */
    private fun release(st: Session) {
        st.ticker?.cancel()
        st.ticker = null
        if (s === st) {
            s = null
            launcher.onDragEnded()
        }
    }

    private fun end(st: Session) {
        st.dv.removeFromParent()
        st.badge?.removeFromParent()
        // The source view may be reused (drawer, moved icon); never leave it hidden.
        st.src.view.alpha = 1f
        st.src.view.visibility = View.VISIBLE
        if (s === st) s = null
    }

    private fun visualRect(v: View): RectF {
        if (v is IconView) return v.iconRectInWindow()
        val r = RectF(0f, 0f, v.width.toFloat(), v.height.toFloat())
        val m = Matrix(); v.transformMatrixToGlobal(m); m.mapRect(r)
        return r
    }

    private fun snapshot(v: View): Bitmap? = try {
        if (v is IconView && v !is FolderIconView) v.bitmap
        else {
            val w = max(1, v.width); val h = max(1, v.height)
            val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
            val prevAlpha = v.alpha
            v.alpha = 1f
            v.draw(Canvas(bmp))
            v.alpha = prevAlpha
            bmp
        }
    } catch (_: Throwable) { null }

    private fun suggestFolderName(keys: List<String>): String {
        val cats = keys.mapNotNull { launcher.apps[it]?.info?.applicationInfo?.category }.distinct()
        if (cats.size == 1) return when (cats[0]) {
            ApplicationInfo.CATEGORY_GAME -> "Games"
            ApplicationInfo.CATEGORY_SOCIAL -> "Social"
            ApplicationInfo.CATEGORY_PRODUCTIVITY -> "Productivity"
            ApplicationInfo.CATEGORY_AUDIO -> "Music"
            ApplicationInfo.CATEGORY_VIDEO -> "Video"
            ApplicationInfo.CATEGORY_IMAGE -> "Photos"
            ApplicationInfo.CATEGORY_NEWS -> "News"
            ApplicationInfo.CATEGORY_MAPS -> "Travel"
            else -> "Folder"
        }
        return "Folder"
    }
}

/** "Remove" / "Uninstall" targets that slide down from the top while dragging. */
class RemoveBar(private val launcher: MainActivity) : LinearLayout(launcher) {
    private val remove = target(R.drawable.ic_remove, "Remove")
    private val uninstall = target(R.drawable.ic_delete, "Uninstall")
    var uninstallVisible = false
        private set
    var removeVisible = true
        private set
    private var highlighted = -1

    init {
        orientation = HORIZONTAL
        gravity = Gravity.CENTER
        addView(remove, llp(0, launcher.dpi(48), 1f).apply { marginEnd = launcher.dpi(10) })
        addView(uninstall, llp(0, launcher.dpi(48), 1f))
        visibility = INVISIBLE
    }

    private fun target(icon: Int, label: String): GlassView = GlassView(launcher, launcher.dp(24f), GlassView.Style.HOME).apply {
        val row = LinearLayout(launcher).apply { orientation = HORIZONTAL; gravity = Gravity.CENTER }
        row.addView(launcher.iconImage(icon, Color.WHITE, 0), llp(launcher.dpi(20), launcher.dpi(20)).apply { marginEnd = launcher.dpi(8) })
        row.addView(launcher.textView(label, 14f, Color.WHITE, Fonts.medium))
        addView(row, flp(MATCH, MATCH))
    }

    fun show(canRemove: Boolean, canUninstall: Boolean) {
        uninstallVisible = canUninstall
        removeVisible = canRemove
        if (!canRemove && !canUninstall) { visibility = INVISIBLE; return }
        uninstall.visibility = if (canUninstall) VISIBLE else GONE
        remove.visibility = if (canRemove) VISIBLE else GONE
        highlighted = -1
        remove.tintOverride = null; uninstall.tintOverride = null
        remove.scaleX = 1f; remove.scaleY = 1f; uninstall.scaleX = 1f; uninstall.scaleY = 1f
        visibility = VISIBLE
        alpha = 0f
        translationY = -launcher.dp(24f)
        animate().alpha(1f).translationY(0f).setDuration(Motion.d(220)).setInterpolator(Motion.decel).start()
    }

    fun hide() {
        if (visibility != VISIBLE) return
        animate().alpha(0f).translationY(-launcher.dp(16f)).setDuration(Motion.d(160)).setInterpolator(Motion.accel)
            .withEndAction { visibility = INVISIBLE }.start()
    }

    /** Updates which targets are offered without replaying the entrance animation. */
    fun setTargets(canRemove: Boolean, canUninstall: Boolean) {
        removeVisible = canRemove
        uninstallVisible = canUninstall
        remove.visibility = if (canRemove) VISIBLE else GONE
        uninstall.visibility = if (canUninstall) VISIBLE else GONE
        if (!canRemove && !canUninstall) visibility = INVISIBLE
    }

    fun highlight(index: Int) {
        if (index == highlighted) return
        highlighted = index
        listOf(remove, uninstall).forEachIndexed { i, v ->
            val on = i == index
            v.tintOverride = if (on) Color.argb(200, 230, 60, 60) else null
            v.animate().scaleX(if (on) 1.06f else 1f).scaleY(if (on) 1.06f else 1f).setDuration(140).start()
        }
        if (index >= 0) launcher.haptic(this, HapticFeedbackConstants.CLOCK_TICK)
    }
}

