package com.fluidone.launcher

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Outline
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import android.view.View
import android.view.ViewOutlineProvider
import android.widget.FrameLayout

/**
 * Real frosted glass: draws the pre-blurred wallpaper region that is exactly behind this view, a tint, and a
 * subtle light edge. Because the blur comes from [WallpaperView], it keeps working on One UI even when the
 * system's own window blur is disabled.
 */
open class GlassView(context: Context, cornerRadiusPx: Float, var style: Style = Style.HOME) : FrameLayout(context) {
    enum class Style { HOME, MENU, CARD_LIGHT }

    var cornerRadius = cornerRadiusPx
        set(v) { field = v; invalidateOutline(); invalidate() }
    /** Overrides the computed tint when non-null. */
    var tintOverride: Int? = null
        set(v) { field = v; invalidate() }
    var glassAlpha = 1f
        set(v) { field = v.coerceIn(0f, 1f); invalidate() }
    var drawStroke = true
    var heavyBlur = false

    private val path = Path()
    private val rect = RectF()
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private var strokeShaderHeight = -1

    init {
        setWillNotDraw(false)
        clipChildren = true
        outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(view: View, outline: Outline) {
                outline.setRoundRect(0, 0, view.width, view.height, cornerRadius)
            }
        }
        clipToOutline = true
    }

    private val launcher: MainActivity? get() = context as? MainActivity

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        launcher?.registerGlass(this)
    }

    override fun onDetachedFromWindow() {
        launcher?.unregisterGlass(this)
        super.onDetachedFromWindow()
    }

    fun tintColor(): Int {
        tintOverride?.let { return it }
        val l = launcher ?: return Color.argb(120, 20, 20, 24)
        val strength = l.prefs.glassTint / 100f
        return when (style) {
            Style.HOME -> if (l.wallpaperIsLight) Color.argb((40 + 120 * strength).toInt(), 255, 255, 255)
                          else Color.argb((24 + 150 * strength).toInt(), 18, 18, 26)
            Style.MENU -> l.ui.glassTint
            Style.CARD_LIGHT -> Color.argb(214, 252, 252, 255)
        }
    }

    override fun onDraw(canvas: Canvas) {
        if (width == 0 || height == 0 || glassAlpha <= 0f) return
        rect.set(0f, 0f, width.toFloat(), height.toFloat())
        path.reset()
        path.addRoundRect(rect, cornerRadius, cornerRadius, Path.Direction.CW)
        val save = canvas.save()
        canvas.clipPath(path)
        val layer = if (glassAlpha < 1f) canvas.saveLayerAlpha(rect, (glassAlpha * 255).toInt()) else -1
        val drewWallpaper = launcher?.wallpaperView?.drawGlass(canvas, this, heavyBlur) == true
        if (!drewWallpaper) canvas.drawColor(Color.argb(200, 26, 26, 34))
        fill.color = tintColor()
        canvas.drawRect(rect, fill)
        if (layer >= 0) canvas.restoreToCount(layer)
        canvas.restoreToCount(save)
        if (drawStroke) {
            if (strokeShaderHeight != height) {
                strokeShaderHeight = height
                val light = style == Style.CARD_LIGHT
                stroke.shader = LinearGradient(0f, 0f, 0f, height.toFloat(),
                    intArrayOf(Color.argb(if (light) 140 else 70, 255, 255, 255), Color.argb(if (light) 60 else 18, 255, 255, 255)),
                    null, Shader.TileMode.CLAMP)
            }
            stroke.strokeWidth = dp(1f)
            stroke.alpha = (glassAlpha * 255).toInt()
            val half = stroke.strokeWidth / 2f
            rect.inset(half, half)
            canvas.drawRoundRect(rect, cornerRadius - half, cornerRadius - half, stroke)
        }
    }
}
