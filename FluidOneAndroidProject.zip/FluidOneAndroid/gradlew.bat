@echo off
setlocal
set "GRADLE_VERSION=8.9"
set "EXPECTED_SHA256=d725d707bfabd4dfdc958c624003b3c80accc03f7037b5122c4b1d0ef15cecab"
set "CACHE_DIR=%USERPROFILE%\.gradle\wrapper\dists\gradle-%GRADLE_VERSION%-bin\fluid-one-bootstrap"
set "GRADLE_HOME_LOCAL=%CACHE_DIR%\gradle-%GRADLE_VERSION%"
set "ZIP_FILE=%CACHE_DIR%\gradle-%GRADLE_VERSION%-bin.zip"
if not exist "%GRADLE_HOME_LOCAL%\bin\gradle.bat" (
  powershell -NoLogo -NoProfile -ExecutionPolicy Bypass -Command "$ErrorActionPreference='Stop'; $dest='%CACHE_DIR%'; $zip='%ZIP_FILE%'; $url='https://services.gradle.org/distributions/gradle-%GRADLE_VERSION%-bin.zip'; $expected='%EXPECTED_SHA256%'; New-Item -ItemType Directory -Force -Path $dest | Out-Null; if (Test-Path $zip) { $hash=(Get-FileHash -LiteralPath $zip -Algorithm SHA256).Hash.ToLowerInvariant(); if ($hash -ne $expected) { Remove-Item -LiteralPath $zip -Force } }; if (-not (Test-Path $zip)) { Invoke-WebRequest -Uri $url -OutFile $zip }; $hash=(Get-FileHash -LiteralPath $zip -Algorithm SHA256).Hash.ToLowerInvariant(); if ($hash -ne $expected) { Remove-Item -LiteralPath $zip -Force; throw 'Gradle checksum verification failed; download removed.' }; Expand-Archive -LiteralPath $zip -DestinationPath $dest -Force"
  if errorlevel 1 exit /b %errorlevel%
)
call "%GRADLE_HOME_LOCAL%\bin\gradle.bat" %*
exit /b %errorlevel%
