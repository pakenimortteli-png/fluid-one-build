# Fluid One — native Android launcher

Fluid One is a native Kotlin launcher project intended for a Galaxy S25 Ultra running One UI 9.0. It registers as a real Android home app (`MAIN` + `HOME` + `DEFAULT`), discovers installed app activities through `LauncherApps`, and gets each app's real label and icon from Android. It does not bundle or redistribute a ColorOS icon pack.

## Features included in the source

- Real home-launcher activity and installed-app discovery/search.
- Multiple home pages: horizontal fling, page dots, add-page control, move shortcuts between pages, pin apps from the drawer, and remove pinned shortcuts.
- Native app icons from installed apps; no emoji icons or generated logo substitutes.
- Dock and widget cards with a glass surface that samples and blurs the selected wallpaper behind it. Default idle app icons remain sharp.
- Staggered foreground entrance: tiles originate from different offsets and scales, use per-tile start times/durations, and clear the blur quickly. App launch uses Android's clip-reveal launch animation; returning from apps has a reverse staggered settle animation.
- Long-press home editing menu; folder creation, folder rename/removal, and a blurred folder dialog.
- Actual Android widget picker/host via `AppWidgetHost` and `AppWidgetManager`; provider widgets are attached to the current home page.
- Wallpaper picker with four real abstract photographs from Unsplash, local image import, cached downloads, and source credits.
- Simple settings plus hidden Advanced tuning for blur, glass tint, icon size, animation blur, stagger spacing, animation duration, idle icon blur, and folder-window blur.
- Uses Android density-independent units and current display metrics. It detects Galaxy S25 Ultra model variants (`SM-S938*`) and applies a five-column, large-icon compatibility preset that can be turned off.
- Haptic feedback uses Android `performHapticFeedback` and respects the launcher's haptic toggle/system behavior; no vibration permission is requested.
- Does not implement a custom control center; the Samsung system shade remains the system's responsibility.

## Important limits

- The app's source is supplied, but this environment did not have Android SDK / Gradle and could not reach the Android dependency servers. **No APK was compiled or device-tested in this workspace.** Do not treat this source ZIP as an APK.
- The Unsplash wallpapers are downloaded at first use and cached locally. An internet connection is required for their first load; an imported image can be local.
- The app uses Android's public launch animation APIs. It cannot override how every third-party app animates its own exit transition, although the launcher animates its home elements when it regains focus.
- `AppWidgetHost` behavior and provider-specific resizing/configuration should be tested on the actual One UI 9.0 device; some providers have Samsung-specific constraints.
- No Android launcher can guarantee a fixed 120 FPS in every system state. Blur and motion have tunable controls, and reduced-motion mode is included.

## Build in Android Studio

1. Install Android Studio, Android SDK Platform 35 + Build Tools 35.0.0, and JDK 17.
2. Open this `FluidOneAndroid` directory as an existing Gradle project. The included `gradlew` / `gradlew.bat` bootstraps the official Gradle 8.9 binary distribution over HTTPS and verifies its SHA-256 checksum before running it. Gradle and Android Gradle Plugin / Kotlin dependencies still need internet access on the build machine.
3. Allow Android Studio to finish Gradle sync, then choose **Build → Build APK(s)**. The installable debug APK is generated at:

   `app/build/outputs/apk/debug/app-debug.apk`

4. Install it on the S25 Ultra. Press Home and select **Fluid One** as the default launcher (choose **Always** to make it the main home app).
5. On the first run, connect to the internet to load and cache the default Unsplash abstract wallpaper.

For a command line build after the Android SDK Platform 35 + Build Tools 35.0.0 are installed:

```bash
./gradlew --no-daemon assembleDebug
```

On Windows, use `gradlew.bat --no-daemon assembleDebug`.

## Build automatically in GitHub Actions

The included workflow at `.github/workflows/build-apk.yml` installs Java and Android SDK components, builds the debug APK, and uploads it as an artifact. It can be used after this project is put into a GitHub repository.

## Technical stack

- Kotlin, Android framework Views, `LauncherApps`, `AppWidgetHost`, `RenderEffect`, `ActivityOptions`, framework haptics, and platform storage APIs.
- Minimum SDK: Android 12 / API 31 (for per-view blur and system window background blur).
- Compile/target SDK: API 35.
- Package: `com.fluidone.launcher`.
