package com.fluidone.launcher

import android.app.Activity
import android.app.AlertDialog
import android.app.Dialog
import android.appwidget.AppWidgetHost
import android.appwidget.AppWidgetManager
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.LauncherActivityInfo
import android.content.pm.LauncherApps
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.RenderEffect
import android.graphics.Shader
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.view.WindowManager
import android.view.animation.DecelerateInterpolator
import android.view.animation.PathInterpolator
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.GridLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Space
import android.widget.Switch
import android.widget.TextClock
import android.widget.TextView
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID
import java.util.concurrent.Executors
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt
import kotlin.random.Random

/**
 * Fluid One — native Android launcher.
 * Built from framework APIs so the launcher itself doesn't depend on a third-party icon pack.
 * Real icon drawables and labels are always sourced from installed Android applications.
 */
class MainActivity : Activity() {
    private lateinit var root: FrameLayout
    private lateinit var content: FrameLayout
    private lateinit var wallpaperView: ImageView
    private lateinit var prefs: SharedPreferences
    private lateinit var launcherApps: LauncherApps
    private lateinit var widgetHost: AppWidgetHost
    private lateinit var widgetManager: AppWidgetManager

    private var installedApps: List<LauncherActivityInfo> = emptyList()
    private val appByKey = linkedMapOf<String, LauncherActivityInfo>()
    private var pages = mutableListOf<MutableList<String>>()
    private var folders = linkedMapOf<String, FolderModel>()
    private var currentPage = 0
    private var screen = Screen.HOME
    private var expandedAdvanced = false
    private var appLaunchInProgress = false
    private var firstResume = true
    private var lastHomeAnimationAt = 0L
    private var wallpaperBitmap: Bitmap? = null
    private var wallpaperSource = DEFAULT_WALLPAPER
    private var appDrawerGrid: GridLayout? = null
    private var appDrawerQuery = ""
    private var pendingWidgetId = AppWidgetManager.INVALID_APPWIDGET_ID
    private var pendingWidgetPage = 0
    private val wallpaperExecutor = Executors.newSingleThreadExecutor()
    private val mainHandler = android.os.Handler(android.os.Looper.getMainLooper())
    private val animatedViews = mutableListOf<View>()

    private enum class Screen { HOME, DRAWER, SETTINGS, WALLPAPERS }
    private data class FolderModel(val id: String, var name: String, val apps: MutableList<String>)
    private data class WallpaperChoice(val name: String, val url: String, val credit: String)

    private val wallpaperChoices = listOf(
        WallpaperChoice("Blue glass macro", "https://images.unsplash.com/photo-1706101299176-292d8c5e470e?fm=jpg&fit=crop&w=1800&q=88", "Unsplash · glass macro photograph"),
        WallpaperChoice("Blue liquid", "https://images.unsplash.com/photo-1568738316679-d70218ff7f34?fm=jpg&fit=crop&w=1800&q=88", "Pawel Czerwinski · Unsplash"),
        WallpaperChoice("Midnight fluid", "https://images.unsplash.com/photo-1550353127-b0da3aeaa0ca?fm=jpg&fit=crop&w=1800&q=88", "Unsplash · blue abstract photograph"),
        WallpaperChoice("Water texture", "https://images.unsplash.com/photo-1594671581654-cc7ed83167bb?fm=jpg&fit=crop&w=1800&q=88", "Pawel Czerwinski · Unsplash")
    )

    private val accentOptions = listOf(
        "Ice blue" to Color.rgb(155, 199, 232),
        "Silver" to Color.rgb(212, 221, 231),
        "Sage" to Color.rgb(166, 196, 171),
        "Sand" to Color.rgb(214, 192, 160),
        "Lavender grey" to Color.rgb(185, 183, 210)
    )

    private val gestureDetector by lazy {
        android.view.GestureDetector(this, object : android.view.GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent): Boolean = true
            override fun onFling(e1: MotionEvent?, e2: MotionEvent, velocityX: Float, velocityY: Float): Boolean {
                if (e1 == null) return false
                val dx = e2.x - e1.x
                val dy = e2.y - e1.y
                if (screen == Screen.DRAWER && dy > dp(78) && abs(dy) > abs(dx) * 1.2f) {
                    mainHandler.post { buildHome(false) }
                    return true
                }
                if (screen != Screen.HOME) return false
                if (abs(dx) > dp(64) && abs(dx) > abs(dy) * 1.12f) {
                    mainHandler.post { changePage(if (dx < 0) 1 else -1) }
                    return true
                }
                if (dy < -dp(78) && abs(dy) > abs(dx) * 1.2f) {
                    mainHandler.post {
                        performHapticFeedbackOn(root, HapticFeedbackConstants.CONTEXT_CLICK)
                        showDrawer()
                    }
                    return true
                }
                return false
            }
        })
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("fluid_one", Context.MODE_PRIVATE)
        launcherApps = getSystemService(LauncherApps::class.java)
        widgetManager = getSystemService(AppWidgetManager::class.java)
        widgetHost = AppWidgetHost(this, WIDGET_HOST_ID)
        setupSystemBars()
        createBaseViews()
        refreshApps()
        loadFolders()
        loadOrSeedPages()
        currentPage = prefs.getInt("current_page", 0).coerceIn(0, max(0, pages.lastIndex))
        wallpaperSource = prefs.getString(KEY_WALLPAPER, DEFAULT_WALLPAPER) ?: DEFAULT_WALLPAPER
        loadWallpaper(wallpaperSource, false)
        buildHome(animate = true)
        firstResume = false
    }

    private fun setupSystemBars() {
        window.statusBarColor = Color.TRANSPARENT
        window.navigationBarColor = Color.TRANSPARENT
        if (Build.VERSION.SDK_INT >= 29) {
            window.isNavigationBarContrastEnforced = false
            window.isStatusBarContrastEnforced = false
        }
        @Suppress("DEPRECATION")
        window.decorView.systemUiVisibility = (
            View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
                View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
                View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
            )
    }

    private fun createBaseViews() {
        root = FrameLayout(this).apply {
            setBackgroundColor(Color.rgb(10, 16, 24))
            clipChildren = false
            clipToPadding = false
        }
        wallpaperView = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            setBackgroundColor(Color.rgb(10, 16, 24))
            contentDescription = "Selected abstract wallpaper"
        }
        root.addView(wallpaperView, FrameLayout.LayoutParams(-1, -1))

        val scrim = View(this).apply {
            background = GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(0x1C05080D, 0x08050A11, 0x58050A10.toInt())
            )
            isClickable = false
        }
        root.addView(scrim, FrameLayout.LayoutParams(-1, -1))
        content = FrameLayout(this).apply {
            clipChildren = false
            clipToPadding = false
        }
        root.addView(content, FrameLayout.LayoutParams(-1, -1))
        content.setOnApplyWindowInsetsListener { v, insets ->
            val topInset: Int
            val bottomInset: Int
            if (Build.VERSION.SDK_INT >= 30) {
                val systemInsets = insets.getInsets(android.view.WindowInsets.Type.statusBars() or android.view.WindowInsets.Type.navigationBars())
                topInset = systemInsets.top
                bottomInset = systemInsets.bottom
            } else {
                @Suppress("DEPRECATION")
                val pair = insets.systemWindowInsetTop to insets.systemWindowInsetBottom
                topInset = pair.first
                bottomInset = pair.second
            }
            v.setPadding(dp(18), topInset + dp(12), dp(18), bottomInset + dp(10))
            insets
        }
        setContentView(root)
        root.requestApplyInsets()
    }

    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        if (::root.isInitialized && screen == Screen.HOME) gestureDetector.onTouchEvent(ev)
        return super.dispatchTouchEvent(ev)
    }

    override fun onStart() {
        super.onStart()
        try { widgetHost.startListening() } catch (_: Exception) { }
    }

    override fun onStop() {
        try { widgetHost.stopListening() } catch (_: Exception) { }
        super.onStop()
    }

    private var wasKeyguardShowing = false

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (!::root.isInitialized) return
        val keyguard = getSystemService(android.app.KeyguardManager::class.java)
        if (!hasFocus) {
            wasKeyguardShowing = try { keyguard?.isKeyguardLocked == true } catch (_: Exception) { false }
        } else if (wasKeyguardShowing && screen == Screen.HOME) {
            val stillLocked = try { keyguard?.isKeyguardLocked == true } catch (_: Exception) { false }
            if (!stillLocked) {
                wasKeyguardShowing = false
                mainHandler.postDelayed({ if (screen == Screen.HOME) runUnlockEntrance(animatedViews.toList()) }, 95L)
            }
        }
    }

    override fun onResume() {
        super.onResume()
        if (!firstResume && ::launcherApps.isInitialized) {
            val oldKeys = appByKey.keys.toSet()
            refreshApps()
            if (screen == Screen.HOME && oldKeys != appByKey.keys) buildHome(animate = false)
            if (screen == Screen.HOME && appLaunchInProgress) {
                appLaunchInProgress = false
                mainHandler.postDelayed({ animateHomeReturn() }, 85L)
            }
        }
    }

    override fun onBackPressed() {
        when (screen) {
            Screen.DRAWER -> buildHome(animate = false)
            Screen.SETTINGS -> buildHome(animate = false)
            Screen.WALLPAPERS -> buildSettings()
            Screen.HOME -> { /* The home activity stays active, like a standard launcher. */ }
        }
    }

    private fun appKey(app: LauncherActivityInfo): String = "${app.user.hashCode()}|${app.componentName.flattenToString()}"

    private fun refreshApps() {
        val found = try {
            launcherApps.profiles.flatMap { profile -> launcherApps.getActivityList(null, profile) }
                .filterNot { it.componentName.packageName == packageName }
                .distinctBy { appKey(it) }
                .sortedBy { it.label?.toString()?.lowercase(Locale.getDefault()) ?: "" }
        } catch (_: Exception) {
            emptyList()
        }
        installedApps = found
        appByKey.clear()
        found.forEach { appByKey[appKey(it)] = it }
    }

    private fun loadOrSeedPages() {
        val serialized = prefs.getString(KEY_PAGES, null)
        if (!serialized.isNullOrBlank()) {
            try {
                val json = JSONArray(serialized)
                pages = MutableList(json.length()) { index ->
                    val array = json.getJSONArray(index)
                    MutableList(array.length()) { array.getString(it) }
                }
                if (pages.isEmpty()) pages.add(mutableListOf())
                return
            } catch (_: Exception) { }
        }
        val preferredHints = listOf(
            "phone", "dialer", "message", "camera", "gallery", "chrome", "browser", "setting",
            "calendar", "clock", "play store", "youtube", "maps", "photos", "file", "spotify",
            "music", "calculator", "notes", "samsung internet", "gmail", "outlook"
        )
        val remaining = installedApps.toMutableList()
        val prioritized = mutableListOf<LauncherActivityInfo>()
        preferredHints.forEach { hint ->
            val next = remaining.firstOrNull { app ->
                val label = app.label?.toString()?.lowercase(Locale.getDefault()).orEmpty()
                label.contains(hint)
            }
            if (next != null) {
                prioritized.add(next)
                remaining.remove(next)
            }
        }
        prioritized.addAll(remaining)
        val pinned = prioritized.take(18).map { appKey(it) }
        pages = pinned.chunked(10).map { it.toMutableList() }.toMutableList()
        if (pages.isEmpty()) pages.add(mutableListOf())
        savePages()
    }

    private fun savePages() {
        val json = JSONArray()
        pages.forEach { page ->
            val array = JSONArray()
            page.forEach { array.put(it) }
            json.put(array)
        }
        prefs.edit().putString(KEY_PAGES, json.toString()).putInt("current_page", currentPage).apply()
    }

    private fun loadFolders() {
        folders.clear()
        try {
            val json = JSONObject(prefs.getString(KEY_FOLDERS, "{}") ?: "{}")
            val keys = json.keys()
            while (keys.hasNext()) {
                val id = keys.next()
                val item = json.getJSONObject(id)
                val list = item.getJSONArray("apps")
                val keysList = MutableList(list.length()) { list.getString(it) }
                folders[id] = FolderModel(id, item.optString("name", "Folder"), keysList)
            }
        } catch (_: Exception) { }
    }

    private fun saveFolders() {
        val json = JSONObject()
        folders.values.forEach { folder ->
            val apps = JSONArray()
            folder.apps.forEach { apps.put(it) }
            json.put(folder.id, JSONObject().put("name", folder.name).put("apps", apps))
        }
        prefs.edit().putString(KEY_FOLDERS, json.toString()).apply()
    }

    private fun buildHome(animate: Boolean) {
        screen = Screen.HOME
        content.removeAllViews()
        animatedViews.clear()
        val pageRoot = FrameLayout(this).apply { setBackgroundColor(Color.TRANSPARENT) }
        content.addView(pageRoot, FrameLayout.LayoutParams(-1, -1))
        val column = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            clipChildren = false
            clipToPadding = false
        }
        pageRoot.addView(column, FrameLayout.LayoutParams(-1, -1))
        column.setOnLongClickListener {
            performHapticFeedbackOn(it, HapticFeedbackConstants.LONG_PRESS)
            showHomeEditMenu()
            true
        }

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(2), dp(1), dp(1), dp(5))
        }
        val brand = text("FLUID ONE", 12f, Color.argb(220, 245, 249, 255), Typeface.BOLD).apply {
            letterSpacing = 0.15f
        }
        header.addView(brand, LinearLayout.LayoutParams(0, dp(38), 1f))
        val appSearchButton = iconButton(R.drawable.ic_search, "Search apps") {
            performHapticFeedbackOn(it, HapticFeedbackConstants.CONTEXT_CLICK)
            showDrawer()
        }
        header.addView(appSearchButton, LinearLayout.LayoutParams(dp(40), dp(40)))
        val settingsButton = iconButton(R.drawable.ic_settings, "Fluid One settings") {
            performHapticFeedbackOn(it, HapticFeedbackConstants.CONTEXT_CLICK)
            buildSettings()
        }
        header.addView(settingsButton, LinearLayout.LayoutParams(dp(40), dp(40)).apply { leftMargin = dp(7) })
        column.addView(header)

        val clockBlock = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(3), dp(25), dp(3), dp(11))
            clipChildren = false
            clipToPadding = false
        }
        val clock = TextClock(this).apply {
            format12Hour = "h:mm"
            format24Hour = "HH:mm"
            textSize = 64f
            setTextColor(Color.WHITE)
            letterSpacing = -0.055f
            typeface = Typeface.create("sans-serif-light", Typeface.NORMAL)
            includeFontPadding = false
            setShadowLayer(dp(14).toFloat(), 0f, dp(2).toFloat(), 0x33000000)
            contentDescription = "Current time"
        }
        clockBlock.addView(clock, LinearLayout.LayoutParams(-1, dp(76)))
        val date = text(SimpleDateFormat("EEEE, d MMMM", Locale.getDefault()).format(Date()), 13f, 0xDCEAF6FF.toInt(), Typeface.create("sans-serif-medium", Typeface.NORMAL))
        date.setPadding(dp(3), dp(3), 0, 0)
        clockBlock.addView(date)
        column.addView(clockBlock)
        animatedViews.add(clockBlock)

        val widgetArea = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            clipChildren = false
            clipToPadding = false
        }
        val defaultWidgets = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            clipChildren = false
            clipToPadding = false
        }
        val dateWidget = GlassPanel(this, 22f).apply { setPadding(dp(14), dp(11), dp(12), dp(10)) }
        val dateWidgetContent = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        dateWidgetContent.addView(text(SimpleDateFormat("EEE", Locale.getDefault()).format(Date()).uppercase(Locale.getDefault()), 10f, 0xCFE1EEFF.toInt(), Typeface.BOLD))
        dateWidgetContent.addView(text(SimpleDateFormat("d", Locale.getDefault()).format(Date()), 29f, Color.WHITE, Typeface.NORMAL).apply { setPadding(0, dp(2), 0, 0) })
        dateWidgetContent.addView(text(SimpleDateFormat("MMMM yyyy", Locale.getDefault()).format(Date()), 10f, 0xB9D0E2FF.toInt(), Typeface.NORMAL).apply { setPadding(0, dp(1), 0, 0) })
        dateWidget.addView(dateWidgetContent, FrameLayout.LayoutParams(-1, -2))
        defaultWidgets.addView(dateWidget, LinearLayout.LayoutParams(0, dp(112), 1.0f).apply { rightMargin = dp(7) })
        animatedViews.add(dateWidget)

        val addWidgetCard = GlassPanel(this, 22f).apply {
            isClickable = true
            isFocusable = true
            setPadding(dp(12), dp(12), dp(12), dp(12))
            setOnClickListener { startWidgetPicker() }
            setOnLongClickListener { showHomeEditMenu(); true }
        }
        val addWidgetColumn = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
        }
        val plusBubble = FrameLayout(this).apply {
            background = roundBackground(accent(), 50f)
            foregroundGravity = Gravity.CENTER
        }
        val plus = ImageView(this).apply { setImageResource(R.drawable.ic_plus); imageTintList = android.content.res.ColorStateList.valueOf(Color.rgb(16, 28, 40)); scaleType = ImageView.ScaleType.CENTER_INSIDE; setPadding(dp(6), dp(6), dp(6), dp(6)) }
        plusBubble.addView(plus, FrameLayout.LayoutParams(dp(29), dp(29), Gravity.CENTER))
        addWidgetColumn.addView(plusBubble, LinearLayout.LayoutParams(dp(38), dp(38)))
        addWidgetColumn.addView(text("Add widgets", 10f, 0xE8F1F9FF.toInt(), Typeface.create("sans-serif-medium", Typeface.NORMAL)).apply { gravity = Gravity.CENTER; setPadding(0, dp(9), 0, 0) })
        addWidgetCard.addView(addWidgetColumn, FrameLayout.LayoutParams(-1, -1))
        defaultWidgets.addView(addWidgetCard, LinearLayout.LayoutParams(0, dp(112), 1f))
        animatedViews.add(addWidgetCard)
        widgetArea.addView(defaultWidgets)

        val persistedWidgets = getSavedWidgetIds(currentPage)
        if (persistedWidgets.isNotEmpty()) {
            persistedWidgets.forEach { widgetIdValue ->
                try {
                    val widgetId = widgetIdValue.toIntOrNull() ?: return@forEach
                    val info = widgetManager.getAppWidgetInfo(widgetId) ?: return@forEach
                    val view = widgetHost.createView(this, widgetId, info)
                    view.setOnLongClickListener { showWidgetOptions(widgetId); true }
                    val frame = GlassPanel(this, 20f).apply { setPadding(dp(5), dp(5), dp(5), dp(5)) }
                    frame.addView(view, FrameLayout.LayoutParams(-1, -2))
                    val widgetHeightDp = (info.minHeight + 24).coerceIn(140, 420)
                    frame.minimumHeight = dp(info.minHeight.coerceAtLeast(90))
                    widgetArea.addView(frame, LinearLayout.LayoutParams(-1, dp(widgetHeightDp)).apply { topMargin = dp(8) })
                    animatedViews.add(frame)
                } catch (_: Exception) { }
            }
        }
        column.addView(widgetArea, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(10) })

        val gridWrap = FrameLayout(this).apply { clipChildren = false; clipToPadding = false }
        val gridScroll = ScrollView(this).apply {
            isFillViewport = false
            clipToPadding = false
            overScrollMode = View.OVER_SCROLL_NEVER
            setPadding(0, dp(15), 0, dp(5))
            background = ColorDrawable(Color.TRANSPARENT)
            setOnLongClickListener { performHapticFeedbackOn(gridWrap, HapticFeedbackConstants.LONG_PRESS); showHomeEditMenu(); true }
        }
        val homeGrid = GridLayout(this).apply {
            columnCount = homeColumns()
            alignmentMode = GridLayout.ALIGN_BOUNDS
            useDefaultMargins = false
            clipChildren = false
            clipToPadding = false
        }
        val pageKeys = pages.getOrNull(currentPage) ?: mutableListOf()
        pageKeys.forEachIndexed { index, key ->
            val item = createHomeItem(key)
            val params = GridLayout.LayoutParams(
                GridLayout.spec(index / homeColumns()),
                GridLayout.spec(index % homeColumns(), 1f)
            ).apply {
                width = 0
                height = -2
                setMargins(dp(2), dp(7), dp(2), dp(12))
            }
            homeGrid.addView(item, params)
            animatedViews.add(item)
        }
        gridScroll.addView(homeGrid, FrameLayout.LayoutParams(-1, -2))
        gridWrap.addView(gridScroll, FrameLayout.LayoutParams(-1, -1))
        gridWrap.setOnLongClickListener { performHapticFeedbackOn(gridWrap, HapticFeedbackConstants.LONG_PRESS); showHomeEditMenu(); true }
        column.addView(gridWrap, LinearLayout.LayoutParams(-1, 0, 1f))

        if (pageKeys.isEmpty()) {
            val empty = text("Long-press an empty area to add apps, widgets or a page.", 12f, 0xCBE1EEFF.toInt(), Typeface.NORMAL).apply {
                gravity = Gravity.CENTER
                setPadding(dp(25), dp(30), dp(25), dp(30))
                setOnClickListener { showHomeEditMenu() }
            }
            gridWrap.addView(empty, FrameLayout.LayoutParams(-1, -1))
        }

        val bottom = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            clipChildren = false
        }
        val pageControl = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(0, dp(3), 0, dp(11))
        }
        pages.forEachIndexed { index, _ ->
            val dot = View(this).apply {
                background = roundBackground(if (index == currentPage) accent() else 0x6FFFFFFF, 50f)
                isClickable = true
                contentDescription = "Home page ${index + 1}"
                setOnClickListener { jumpToPage(index) }
            }
            val dotWidth = if (index == currentPage) dp(18) else dp(6)
            pageControl.addView(dot, LinearLayout.LayoutParams(dotWidth, dp(6)).apply { leftMargin = dp(4); rightMargin = dp(4) })
        }
        val addPage = ImageView(this).apply {
            setImageResource(R.drawable.ic_plus)
            imageTintList = android.content.res.ColorStateList.valueOf(0xFFEDF4FC.toInt())
            background = roundBackground(0x332B3646, 30f)
            setPadding(dp(3), dp(3), dp(3), dp(3))
            isClickable = true
            contentDescription = "Add home page"
            setOnClickListener { addHomePage() }
        }
        pageControl.addView(addPage, LinearLayout.LayoutParams(dp(23), dp(23)).apply { leftMargin = dp(9) })
        bottom.addView(pageControl)

        val dock = GlassPanel(this, 24f).apply {
            setPadding(dp(9), dp(10), dp(9), dp(10))
            clipChildren = false
            clipToPadding = false
        }
        val dockGrid = GridLayout(this).apply { columnCount = 5; alignmentMode = GridLayout.ALIGN_BOUNDS; useDefaultMargins = false }
        getDockApps().forEachIndexed { index, app ->
            val item = createDockItem(app)
            val params = GridLayout.LayoutParams(GridLayout.spec(0), GridLayout.spec(index, 1f)).apply {
                width = 0
                height = dp(iconSize() + 3)
                setMargins(dp(1), 0, dp(1), 0)
            }
            dockGrid.addView(item, params)
            animatedViews.add(item)
        }
        dock.addView(dockGrid, FrameLayout.LayoutParams(-1, -2))
        bottom.addView(dock, LinearLayout.LayoutParams(-1, -2))
        animatedViews.add(dock)
        column.addView(bottom, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(3) })

        pageRoot.setOnLongClickListener {
            performHapticFeedbackOn(it, HapticFeedbackConstants.LONG_PRESS)
            showHomeEditMenu()
            true
        }
        if (animate) {
            runUnlockEntrance(animatedViews)
        } else {
            animatedViews.forEach { it.alpha = 1f; it.translationX = 0f; it.translationY = 0f; it.scaleX = 1f; it.scaleY = 1f; if (Build.VERSION.SDK_INT >= 31) it.setRenderEffect(null) }
        }
    }

    private fun createHomeItem(key: String): View {
        if (key.startsWith(FOLDER_PREFIX)) return createFolderTile(key.removePrefix(FOLDER_PREFIX))
        val app = appByKey[key] ?: return Space(this).apply { layoutParams = ViewGroup.LayoutParams(-1, dp(4)) }
        val tile = createAppTile(app, iconSize(), true)
        tile.setOnClickListener { launchApp(app, tile.findViewWithTag<ImageView>(ICON_TAG)) }
        tile.setOnLongClickListener {
            performHapticFeedbackOn(it, HapticFeedbackConstants.LONG_PRESS)
            showHomeAppMenu(app)
            true
        }
        tile.tag = key
        return tile
    }

    private fun createDockItem(app: LauncherActivityInfo): View {
        val tile = createAppTile(app, max(dp(42), iconSize() - dp(8)), false)
        tile.setOnClickListener { launchApp(app, tile.findViewWithTag<ImageView>(ICON_TAG)) }
        tile.setOnLongClickListener { showHomeAppMenu(app); true }
        return tile
    }

    private fun createAppTile(app: LauncherActivityInfo, sizePx: Int, labelVisible: Boolean): LinearLayout {
        val tile = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            isClickable = true
            isFocusable = true
            setPadding(dp(1), dp(2), dp(1), dp(1))
            clipChildren = false
            clipToPadding = false
        }
        val iconFrame = FrameLayout(this).apply {
            background = roundBackground(0x16FFFFFF, 16f)
            clipToOutline = true
            outlineProvider = ViewOutlineProvider.BACKGROUND
        }
        val image = ImageView(this).apply {
            scaleType = ImageView.ScaleType.FIT_CENTER
            tag = ICON_TAG
            contentDescription = app.label?.toString()
            try { setImageDrawable(app.getBadgedIcon(resources.displayMetrics.densityDpi)) } catch (_: Exception) {
                try { setImageDrawable(packageManager.getApplicationIcon(app.applicationInfo)) } catch (_: Exception) { }
            }
            if (prefs.getBoolean(KEY_IDLE_ICON_BLUR, false) && Build.VERSION.SDK_INT >= 31) {
                setRenderEffect(RenderEffect.createBlurEffect(dp(4).toFloat(), dp(4).toFloat(), Shader.TileMode.CLAMP))
            }
        }
        iconFrame.addView(image, FrameLayout.LayoutParams(-1, -1))
        tile.addView(iconFrame, LinearLayout.LayoutParams(sizePx, sizePx))
        if (labelVisible) {
            val label = text(app.label?.toString().orEmpty(), 10f, Color.WHITE, Typeface.create("sans-serif-medium", Typeface.NORMAL)).apply {
                gravity = Gravity.CENTER
                maxLines = 1
                ellipsize = android.text.TextUtils.TruncateAt.END
                setShadowLayer(dp(6).toFloat(), 0f, dp(1).toFloat(), 0x88000000.toInt())
                setPadding(0, dp(6), 0, 0)
            }
            tile.addView(label, LinearLayout.LayoutParams(-1, -2))
        }
        tile.contentDescription = app.label?.toString()
        return tile
    }

    private fun createFolderTile(id: String): View {
        val folder = folders[id] ?: return Space(this)
        val tile = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            isClickable = true
            isFocusable = true
            setPadding(dp(1), dp(2), dp(1), dp(1))
        }
        val glass = GlassPanel(this, 16f).apply {
            setPadding(dp(4), dp(4), dp(4), dp(4))
            isClickable = true
            setOnClickListener { openFolder(id) }
            setOnLongClickListener { showFolderOptions(id); true }
        }
        val miniGrid = GridLayout(this).apply { columnCount = 2; rowCount = 2; alignmentMode = GridLayout.ALIGN_BOUNDS }
        folder.apps.take(4).forEachIndexed { index, appKey ->
            val app = appByKey[appKey] ?: return@forEachIndexed
            val img = ImageView(this).apply {
                scaleType = ImageView.ScaleType.FIT_CENTER
                try { setImageDrawable(app.getBadgedIcon(resources.displayMetrics.densityDpi)) } catch (_: Exception) { }
            }
            miniGrid.addView(img, GridLayout.LayoutParams(GridLayout.spec(index / 2), GridLayout.spec(index % 2, 1f)).apply { width = 0; height = dp(24); setMargins(dp(1), dp(1), dp(1), dp(1)) })
        }
        glass.addView(miniGrid, FrameLayout.LayoutParams(-1, -1))
        tile.addView(glass, LinearLayout.LayoutParams(iconSize(), iconSize()))
        tile.addView(text(folder.name, 10f, Color.WHITE, Typeface.create("sans-serif-medium", Typeface.NORMAL)).apply {
            gravity = Gravity.CENTER
            maxLines = 1
            ellipsize = android.text.TextUtils.TruncateAt.END
            setPadding(0, dp(6), 0, 0)
            setShadowLayer(dp(6).toFloat(), 0f, dp(1).toFloat(), 0x88000000.toInt())
        }, LinearLayout.LayoutParams(-1, -2))
        tile.setOnClickListener { openFolder(id) }
        tile.setOnLongClickListener { showFolderOptions(id); true }
        return tile
    }

    private fun getDockApps(): List<LauncherActivityInfo> {
        val hints = listOf("phone", "message", "chrome", "browser", "internet", "camera", "gallery", "photos")
        val selected = mutableListOf<LauncherActivityInfo>()
        hints.forEach { hint ->
            val found = installedApps.firstOrNull { app ->
                app.label?.toString()?.lowercase(Locale.getDefault())?.contains(hint) == true && selected.none { appKey(it) == appKey(app) }
            }
            if (found != null && selected.size < 5) selected.add(found)
        }
        installedApps.forEach { candidate ->
            if (selected.size < 5 && selected.none { selectedApp -> appKey(selectedApp) == appKey(candidate) }) selected.add(candidate)
        }
        val unique = selected.distinctBy { appKey(it) }.toMutableList()
        while (unique.size < 5) {
            val candidate = installedApps.firstOrNull { info -> unique.none { appKey(it) == appKey(info) } } ?: break
            unique.add(candidate)
        }
        return unique.take(5)
    }

    private fun homeColumns(): Int {
        if (prefs.getBoolean(KEY_COMPAT, isS25Ultra())) return if (resources.configuration.screenWidthDp >= 400) 5 else 4
        return prefs.getInt(KEY_HOME_COLUMNS, if (resources.configuration.screenWidthDp >= 440) 5 else 4).coerceIn(3, 7)
    }

    private fun iconSize(): Int {
        val default = if (prefs.getBoolean(KEY_COMPAT, isS25Ultra())) 54 else if (resources.configuration.screenWidthDp >= 440) 54 else 50
        return dp(prefs.getInt(KEY_ICON_SIZE, default).coerceIn(40, 72))
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density + 0.5f).toInt()
    private fun accent(): Int = prefs.getInt(KEY_ACCENT, accentOptions[0].second)

    private fun text(value: String, size: Float, color: Int, style: Int = Typeface.NORMAL): TextView = TextView(this).apply {
        text = value
        textSize = size
        setTextColor(color)
        typeface = Typeface.create("sans-serif", style)
        includeFontPadding = false
    }

    private fun roundBackground(color: Int, radiusDp: Float, strokeColor: Int = 0x24FFFFFF): GradientDrawable = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(radiusDp.toInt()).toFloat()
        setStroke(dp(1), strokeColor)
    }

    private fun dp(value: Float): Int = (value * resources.displayMetrics.density + 0.5f).toInt()

    private fun iconButton(icon: Int, description: String, action: (View) -> Unit): FrameLayout {
        val container = FrameLayout(this).apply {
            background = roundBackground(0x46212B3A, 50f, 0x34FFFFFF)
            isClickable = true
            isFocusable = true
            contentDescription = description
            setOnClickListener { view -> action(view) }
        }
        val image = ImageView(this).apply {
            setImageResource(icon)
            imageTintList = android.content.res.ColorStateList.valueOf(0xFFF0F5FB.toInt())
            scaleType = ImageView.ScaleType.CENTER_INSIDE
            setPadding(dp(9), dp(9), dp(9), dp(9))
        }
        container.addView(image, FrameLayout.LayoutParams(-1, -1))
        return container
    }

    private inner class GlassPanel(context: Context, private val cornerDp: Float) : FrameLayout(context) {
        init {
            setWillNotDraw(false)
            background = GradientDrawable().apply {
                setColor(Color.TRANSPARENT)
                cornerRadius = dp(cornerDp).toFloat()
            }
            clipToOutline = true
            outlineProvider = ViewOutlineProvider.BACKGROUND
            elevation = dp(1).toFloat()
            setLayerType(View.LAYER_TYPE_HARDWARE, null)
        }

        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            val radius = dp(cornerDp).toFloat()
            val area = RectF(0f, 0f, width.toFloat(), height.toFloat())
            val path = Path().apply { addRoundRect(area, radius, radius, Path.Direction.CW) }
            canvas.save()
            canvas.clipPath(path)
            val bitmap = wallpaperBitmap
            if (bitmap != null && !bitmap.isRecycled && width > 0 && height > 0) {
                val rootW = max(1, root.width).toFloat()
                val rootH = max(1, root.height).toFloat()
                val scale = max(rootW / bitmap.width, rootH / bitmap.height)
                val drawnW = bitmap.width * scale
                val drawnH = bitmap.height * scale
                val offX = (rootW - drawnW) / 2f
                val offY = (rootH - drawnH) / 2f
                val base = IntArray(2)
                val own = IntArray(2)
                try {
                    root.getLocationInWindow(base)
                    getLocationInWindow(own)
                } catch (_: Exception) { }
                val x = (own[0] - base[0]).toFloat()
                val y = (own[1] - base[1]).toFloat()
                val left = ((x - offX) / scale).coerceIn(0f, bitmap.width - 1f)
                val top = ((y - offY) / scale).coerceIn(0f, bitmap.height - 1f)
                val right = ((x + width - offX) / scale).coerceIn(left + 1f, bitmap.width.toFloat())
                val bottom = ((y + height - offY) / scale).coerceIn(top + 1f, bitmap.height.toFloat())
                val sourceRect = Rect(left.toInt(), top.toInt(), right.toInt(), bottom.toInt())
                val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
                val blur = prefs.getInt(KEY_GLASS_BLUR, if (isS25Ultra()) 17 else 15).coerceIn(0, 32)
                if (blur > 0 && Build.VERSION.SDK_INT >= 31) {
                    // Paint does not support RenderEffect; the panel retains its translucent glass tint.
                }
                canvas.drawBitmap(bitmap, sourceRect, Rect(0, 0, width, height), paint)
            } else {
                canvas.drawColor(0xFF121C2A.toInt())
            }
            val tintAlpha = prefs.getInt(KEY_GLASS_TINT, 116).coerceIn(35, 205)
            val tint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(tintAlpha, 12, 20, 32) }
            canvas.drawRoundRect(area, radius, radius, tint)
            val highlight = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                style = Paint.Style.STROKE
                strokeWidth = dp(1).toFloat()
                color = 0x29FFFFFF
            }
            canvas.drawRoundRect(RectF(dp(0.5f).toFloat(), dp(0.5f).toFloat(), (width - dp(0.5f)).toFloat(), (height - dp(0.5f)).toFloat()), radius, radius, highlight)
            val topLine = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                strokeWidth = dp(1).toFloat()
                color = 0x18FFFFFF
            }
            canvas.drawLine(radius, dp(1).toFloat(), width - radius, dp(1).toFloat(), topLine)
            canvas.restore()
        }
    }

    private fun runUnlockEntrance(views: List<View>) {
        val now = System.currentTimeMillis()
        if (now - lastHomeAnimationAt < 800L) return
        lastHomeAnimationAt = now
        val reduced = prefs.getBoolean(KEY_REDUCED_MOTION, false) || !prefs.getBoolean(KEY_ANIMATIONS, true)
        if (reduced) {
            views.forEach { it.alpha = 1f; it.scaleX = 1f; it.scaleY = 1f; it.translationX = 0f; it.translationY = 0f }
            return
        }
        val seed = (System.nanoTime() xor System.currentTimeMillis()).toInt()
        val rng = Random(seed)
        val maxBlur = prefs.getInt(KEY_UNLOCK_BLUR, 17).coerceIn(0, 30)
        val stagger = prefs.getInt(KEY_STAGGER, 19).coerceIn(4, 38)
        val durationMultiplier = prefs.getInt(KEY_DURATION, 100).coerceIn(65, 145) / 100f
        views.forEachIndexed { index, view ->
            view.animate().cancel()
            val targetX = view.translationX
            val targetY = view.translationY
            view.alpha = 0f
            view.scaleX = 0.22f + rng.nextFloat() * 0.24f
            view.scaleY = view.scaleX
            val dx = (rng.nextFloat() * 2f - 1f) * dp(140 + rng.nextInt(40))
            val dy = (rng.nextFloat() * 2f - 1f) * dp(150 + rng.nextInt(90))
            view.translationX = dx
            view.translationY = dy
            if (Build.VERSION.SDK_INT >= 31 && maxBlur > 0) {
                view.setRenderEffect(RenderEffect.createBlurEffect(dp(maxBlur).toFloat(), dp(maxBlur).toFloat(), Shader.TileMode.CLAMP))
            }
            val rawDuration = if (index % 4 == 0) 410L + rng.nextLong(100L) else 485L + rng.nextLong(220L)
            val duration = (rawDuration * durationMultiplier).toLong()
            val delay = (index * stagger.toLong() + rng.nextLong(0L, 95L)).coerceAtMost(420L)
            view.animate()
                .alpha(1f).scaleX(1f).scaleY(1f).translationX(targetX).translationY(targetY)
                .setStartDelay(delay).setDuration(duration)
                .setInterpolator(PathInterpolator(0.18f, 0.72f, 0.2f, 1f))
                .withEndAction { if (Build.VERSION.SDK_INT >= 31) view.setRenderEffect(null) }
                .start()
            if (Build.VERSION.SDK_INT >= 31 && maxBlur > 0) {
                val blurAnimator = android.animation.ValueAnimator.ofFloat(maxBlur.toFloat(), 0f).apply {
                    setStartDelay(delay)
                    setDuration(min(320L, duration - 80L).coerceAtLeast(150L))
                    addUpdateListener { animator ->
                        val radius = animator.animatedValue as Float
                        view.setRenderEffect(if (radius <= 0.3f) null else RenderEffect.createBlurEffect(dp(radius).toFloat(), dp(radius).toFloat(), Shader.TileMode.CLAMP))
                    }
                }
                blurAnimator.start()
            }
        }
    }

    private fun animateHomeReturn() {
        if (screen != Screen.HOME || !prefs.getBoolean(KEY_ANIMATIONS, true)) return
        val all = animatedViews.toList()
        all.forEachIndexed { index, view ->
            view.animate().cancel()
            view.alpha = 0f
            view.scaleX = 0.93f
            view.scaleY = 0.93f
            view.translationX = (if (index % 2 == 0) -1 else 1) * dp(10 + index % 4 * 4).toFloat()
            view.translationY = dp(if (index % 3 == 0) -8 else 6).toFloat()
            if (Build.VERSION.SDK_INT >= 31) view.setRenderEffect(RenderEffect.createBlurEffect(dp(9).toFloat(), dp(9).toFloat(), Shader.TileMode.CLAMP))
            view.animate().alpha(1f).scaleX(1f).scaleY(1f).translationX(0f).translationY(0f)
                .setStartDelay(index * 13L).setDuration(220L + index % 4 * 30L)
                .setInterpolator(DecelerateInterpolator(1.4f))
                .withEndAction { if (Build.VERSION.SDK_INT >= 31) view.setRenderEffect(null) }
                .start()
        }
    }

    private fun performHapticFeedbackOn(view: View, constant: Int) {
        if (::prefs.isInitialized && !prefs.getBoolean(KEY_HAPTICS, true)) return
        try { view.performHapticFeedback(constant) } catch (_: Exception) { }
    }

    private fun launchApp(app: LauncherActivityInfo, iconView: View? = null) {
        try {
            performHapticFeedbackOn(iconView ?: root, HapticFeedbackConstants.CONTEXT_CLICK)
            appLaunchInProgress = true
            val motionEnabled = prefs.getBoolean(KEY_ANIMATIONS, true) && !prefs.getBoolean(KEY_REDUCED_MOTION, false)
            val options = if (motionEnabled && iconView != null && iconView.width > 0 && iconView.height > 0) {
                android.app.ActivityOptions.makeClipRevealAnimation(iconView, 0, 0, iconView.width, iconView.height)
            } else {
                android.app.ActivityOptions.makeCustomAnimation(this, android.R.anim.fade_in, android.R.anim.fade_out)
            }
            launcherApps.startMainActivity(app.componentName, app.user, null, options.toBundle())
        } catch (e: Exception) {
            appLaunchInProgress = false
            try {
                val intent = packageManager.getLaunchIntentForPackage(app.componentName.packageName)
                if (intent != null) startActivity(intent, android.app.ActivityOptions.makeCustomAnimation(this, android.R.anim.fade_in, android.R.anim.fade_out).toBundle())
                else toast("This app cannot be opened from Fluid One.")
            } catch (_: Exception) { toast("Couldn't open ${app.label}.") }
        }
    }

    private fun showDrawer() {
        screen = Screen.DRAWER
        appDrawerQuery = ""
        content.removeAllViews()
        val column = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; clipChildren = false; clipToPadding = false }
        content.addView(column, FrameLayout.LayoutParams(-1, -1))
        val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val titleBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        titleBox.addView(text("Applications", 24f, Color.WHITE, Typeface.create("sans-serif-medium", Typeface.NORMAL)))
        titleBox.addView(text("${installedApps.size} installed apps", 11f, 0xBFE0EBF8.toInt()).apply { setPadding(0, dp(5), 0, 0) })
        header.addView(titleBox, LinearLayout.LayoutParams(0, -2, 1f))
        header.addView(iconButton(R.drawable.ic_settings, "Settings") { buildSettings() }, LinearLayout.LayoutParams(dp(40), dp(40)))
        column.addView(header, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(17) })

        val searchGlass = GlassPanel(this, 18f).apply { setPadding(dp(13), dp(2), dp(11), dp(2)) }
        val searchRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val searchIcon = ImageView(this).apply { setImageResource(R.drawable.ic_search); imageTintList = android.content.res.ColorStateList.valueOf(0xDCE9F5FF.toInt()); setPadding(dp(2), dp(2), dp(2), dp(2)) }
        searchRow.addView(searchIcon, LinearLayout.LayoutParams(dp(27), dp(27)))
        val search = EditText(this).apply {
            hint = "Search apps"
            setHintTextColor(0x8DDCE6F4.toInt())
            setTextColor(Color.WHITE)
            textSize = 14f
            background = ColorDrawable(Color.TRANSPARENT)
            setSingleLine(true)
            imeOptions = android.view.inputmethod.EditorInfo.IME_ACTION_SEARCH
            setPadding(dp(8), dp(8), dp(4), dp(8))
        }
        searchRow.addView(search, LinearLayout.LayoutParams(0, dp(48), 1f))
        searchGlass.addView(searchRow, FrameLayout.LayoutParams(-1, -2))
        column.addView(searchGlass, LinearLayout.LayoutParams(-1, -2))

        val meta = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(2), dp(14), dp(2), dp(11)) }
        meta.addView(text("ALL APPS", 10f, 0x9DCEDCEB.toInt(), Typeface.BOLD).apply { letterSpacing = .13f }, LinearLayout.LayoutParams(0, -2, 1f))
        meta.addView(text("Long-press to pin", 10f, 0xA7C2D4E8.toInt()))
        column.addView(meta)

        val scroll = ScrollView(this).apply { clipToPadding = false; isFillViewport = false; overScrollMode = View.OVER_SCROLL_NEVER }
        val grid = GridLayout(this).apply { columnCount = drawerColumns(); alignmentMode = GridLayout.ALIGN_BOUNDS; useDefaultMargins = false; clipChildren = false }
        appDrawerGrid = grid
        fillDrawerGrid(grid, installedApps)
        scroll.addView(grid, FrameLayout.LayoutParams(-1, -2))
        column.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        val nav = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER; setPadding(0, dp(10), 0, dp(2)) }
        nav.addView(iconButton(R.drawable.ic_back, "Home") { buildHome(false) }, LinearLayout.LayoutParams(dp(42), dp(42)))
        nav.addView(text("Swipe down or tap back to return", 10f, 0x91DAE8F6.toInt()).apply { gravity = Gravity.CENTER }, LinearLayout.LayoutParams(0, dp(42), 1f))
        column.addView(nav)
        search.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) { }
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                appDrawerQuery = s?.toString().orEmpty()
                fillDrawerGrid(grid, installedApps.filter { it.label?.toString()?.contains(appDrawerQuery, true) == true })
            }
            override fun afterTextChanged(s: Editable?) { }
        })
    }

    private fun drawerColumns(): Int = if (resources.configuration.screenWidthDp >= 440) 5 else 4

    private fun fillDrawerGrid(grid: GridLayout, list: List<LauncherActivityInfo>) {
        grid.removeAllViews()
        grid.columnCount = drawerColumns()
        if (list.isEmpty()) {
            val empty = text("No matching apps", 13f, 0xDCE9F5FF.toInt()).apply { gravity = Gravity.CENTER; setPadding(0, dp(30), 0, dp(30)) }
            grid.addView(empty, GridLayout.LayoutParams(GridLayout.spec(0), GridLayout.spec(0, grid.columnCount.toFloat())).apply { width = -1; height = -2 })
            return
        }
        list.forEachIndexed { index, app ->
            val tile = createAppTile(app, iconSize(), true)
            tile.setOnClickListener { launchApp(app, tile.findViewWithTag<ImageView>(ICON_TAG)) }
            tile.setOnLongClickListener {
                performHapticFeedbackOn(it, HapticFeedbackConstants.LONG_PRESS)
                showDrawerAppMenu(app)
                true
            }
            grid.addView(tile, GridLayout.LayoutParams(GridLayout.spec(index / grid.columnCount), GridLayout.spec(index % grid.columnCount, 1f)).apply {
                width = 0
                height = -2
                setMargins(dp(1), dp(7), dp(1), dp(13))
            })
        }
    }

    private fun changePage(delta: Int) {
        if (pages.size <= 1) return
        val next = (currentPage + delta).coerceIn(0, pages.lastIndex)
        if (next == currentPage) return
        performHapticFeedbackOn(root, HapticFeedbackConstants.CLOCK_TICK)
        val old = currentPage
        currentPage = next
        prefs.edit().putInt("current_page", currentPage).apply()
        buildHome(animate = false)
        if (!prefs.getBoolean(KEY_ANIMATIONS, true) || prefs.getBoolean(KEY_REDUCED_MOTION, false)) return
        val dX = if (next > old) dp(28).toFloat() else -dp(28).toFloat()
        animatedViews.forEachIndexed { index, view ->
            view.alpha = 0f
            view.translationX = dX
            view.animate().alpha(1f).translationX(0f).setStartDelay(index * 9L).setDuration(230L)
                .setInterpolator(DecelerateInterpolator(1.4f)).start()
        }
    }

    private fun jumpToPage(index: Int) {
        if (index !in pages.indices || index == currentPage) return
        val direction = if (index > currentPage) 1 else -1
        currentPage = index
        prefs.edit().putInt("current_page", currentPage).apply()
        buildHome(false)
        if (!prefs.getBoolean(KEY_ANIMATIONS, true) || prefs.getBoolean(KEY_REDUCED_MOTION, false)) return
        animatedViews.forEachIndexed { i, view ->
            view.alpha = 0f
            view.translationX = dp(18 * direction).toFloat()
            view.animate().alpha(1f).translationX(0f).setStartDelay(i * 9L).setDuration(230L).start()
        }
    }

    private fun addHomePage() {
        if (pages.size >= MAX_HOME_PAGES) { toast("You can have up to $MAX_HOME_PAGES pages."); return }
        pages.add(mutableListOf())
        currentPage = pages.lastIndex
        savePages()
        performHapticFeedbackOn(root, HapticFeedbackConstants.CONFIRM)
        buildHome(false)
        toast("Page ${currentPage + 1} added")
    }

    private fun removeCurrentPage() {
        if (pages.size <= 1) {
            toast("Keep at least one home page.")
            return
        }
        AlertDialog.Builder(this)
            .setTitle("Remove page ${currentPage + 1}?")
            .setMessage("Apps on this page will be removed from the home screen, but remain in the app drawer. Widgets on this page will be removed too.")
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Remove page") { _, _ ->
                val removedIndex = currentPage
                val oldWidgetPages = (0 until pages.size).map { getSavedWidgetIds(it) }
                oldWidgetPages.getOrNull(removedIndex).orEmpty().forEach { id ->
                    id.toIntOrNull()?.let { widgetId -> try { widgetHost.deleteAppWidgetId(widgetId) } catch (_: Exception) { } }
                }
                val editor = prefs.edit()
                for (index in pages.indices) editor.remove("widgets_$index")
                editor.apply()
                pages.removeAt(removedIndex)
                oldWidgetPages.forEachIndexed { oldIndex, ids ->
                    if (oldIndex == removedIndex) return@forEachIndexed
                    val newIndex = if (oldIndex < removedIndex) oldIndex else oldIndex - 1
                    saveWidgetIds(newIndex, ids)
                }
                currentPage = currentPage.coerceAtMost(pages.lastIndex)
                val usedFolders = pages.flatten().filter { it.startsWith(FOLDER_PREFIX) }.map { it.removePrefix(FOLDER_PREFIX) }.toSet()
                folders.keys.filter { it !in usedFolders }.toList().forEach { folders.remove(it) }
                saveFolders()
                savePages()
                buildHome(false)
            }
            .show()
    }

    private fun showHomeEditMenu() {
        val choices = arrayOf("Add apps", "Add widget", "Add home page", "Remove current page", "Choose wallpaper", "Launcher settings", "Home grid and icon layout")
        AlertDialog.Builder(this)
            .setTitle("Customize home screen")
            .setItems(choices) { _, which ->
                when (which) {
                    0 -> showDrawer()
                    1 -> startWidgetPicker()
                    2 -> addHomePage()
                    3 -> removeCurrentPage()
                    4 -> buildWallpaperPicker()
                    5 -> buildSettings()
                    6 -> showGridDialog()
                }
            }
            .setNegativeButton("Close", null)
            .show()
    }

    private fun showGridDialog() {
        val columns = intArrayOf(3, 4, 5, 6, 7)
        val labels = columns.map { "$it columns" }.toTypedArray()
        AlertDialog.Builder(this).setTitle("Home screen columns")
            .setSingleChoiceItems(labels, columns.indexOf(homeColumns())) { dialog, index ->
                prefs.edit().putInt(KEY_HOME_COLUMNS, columns[index]).putBoolean(KEY_COMPAT, false).apply()
                dialog.dismiss()
                buildHome(false)
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun showHomeAppMenu(app: LauncherActivityInfo) {
        val key = appKey(app)
        val inPage = pages.getOrNull(currentPage)?.contains(key) == true
        val items = if (inPage) arrayOf("Move to page…", "Create folder with apps…", "Remove from home", "App info") else arrayOf("Add to current page", "Create folder with apps…", "App info")
        AlertDialog.Builder(this).setTitle(app.label?.toString() ?: "Application").setItems(items) { _, index ->
            if (inPage) {
                when (index) {
                    0 -> chooseMovePage(key)
                    1 -> createFolderDialog(key)
                    2 -> { pages[currentPage].remove(key); savePages(); buildHome(false) }
                    3 -> openAppInfo(app)
                }
            } else {
                when (index) {
                    0 -> { if (pages.none { it.contains(key) }) pages[currentPage].add(key); savePages(); buildHome(false) }
                    1 -> createFolderDialog(key)
                    2 -> openAppInfo(app)
                }
            }
        }.show()
    }

    private fun showDrawerAppMenu(app: LauncherActivityInfo) {
        val key = appKey(app)
        val alreadyPinned = pages.any { it.contains(key) } || folders.values.any { it.apps.contains(key) }
        val items = if (alreadyPinned) arrayOf("Open app", "App info") else arrayOf("Open app", "Add to current page", "App info")
        AlertDialog.Builder(this).setTitle(app.label?.toString() ?: "Application").setItems(items) { _, which ->
            if (alreadyPinned) {
                if (which == 0) launchApp(app) else openAppInfo(app)
            } else {
                when (which) {
                    0 -> launchApp(app)
                    1 -> { pages[currentPage].add(key); savePages(); buildHome(false); toast("Added to page ${currentPage + 1}") }
                    2 -> openAppInfo(app)
                }
            }
        }.show()
    }

    private fun chooseMovePage(key: String) {
        val entries = (pages.indices.map { "Page ${it + 1}${if (it == currentPage) " (current)" else ""}" } + "New page").toTypedArray()
        AlertDialog.Builder(this).setTitle("Move app to").setItems(entries) { _, which ->
            var target = which
            if (which == pages.size) {
                if (pages.size >= MAX_HOME_PAGES) { toast("Maximum page count reached."); return@setItems }
                pages.add(mutableListOf())
                target = pages.lastIndex
            }
            pages.forEach { it.remove(key) }
            pages[target].add(key)
            currentPage = target
            savePages()
            buildHome(false)
        }.show()
    }

    private fun createFolderDialog(firstKey: String) {
        val apps = installedApps
        if (apps.size < 2) { toast("Install another app before creating a folder."); return }
        val labels = apps.map { it.label?.toString() ?: it.componentName.packageName }.toTypedArray()
        val keys = apps.map { appKey(it) }
        val checked = BooleanArray(apps.size) { keys[it] == firstKey }
        AlertDialog.Builder(this)
            .setTitle("Choose apps for folder")
            .setMultiChoiceItems(labels, checked) { _, which, isChecked -> checked[which] = isChecked }
            .setPositiveButton("Next") { _, _ ->
                val selected = keys.filterIndexed { index, _ -> checked[index] }.toMutableList()
                if (selected.isEmpty()) { toast("Select at least one app."); return@setPositiveButton }
                val input = EditText(this).apply { setText("Folder"); setSelection(text.length); setSingleLine(true) }
                AlertDialog.Builder(this).setTitle("Folder name").setView(input)
                    .setPositiveButton("Create") { _, _ ->
                        val id = UUID.randomUUID().toString().take(8)
                        folders[id] = FolderModel(id, input.text.toString().trim().ifBlank { "Folder" }, selected)
                        pages.forEach { page -> selected.forEach { page.remove(it) } }
                        pages[currentPage].add(FOLDER_PREFIX + id)
                        saveFolders(); savePages(); buildHome(false)
                    }.setNegativeButton("Cancel", null).show()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun openFolder(id: String) {
        val folder = folders[id] ?: return
        val dialog = Dialog(this)
        val panel = GlassPanel(this, 28f).apply { setPadding(dp(16), dp(15), dp(16), dp(16)) }
        val body = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val title = text(folder.name, 20f, Color.WHITE, Typeface.create("sans-serif-medium", Typeface.NORMAL))
        header.addView(title, LinearLayout.LayoutParams(0, dp(43), 1f))
        header.addView(iconButton(R.drawable.ic_close, "Close folder") { dialog.dismiss() }, LinearLayout.LayoutParams(dp(36), dp(36)))
        body.addView(header)
        val grid = GridLayout(this).apply { columnCount = 4; alignmentMode = GridLayout.ALIGN_BOUNDS }
        val appItems = folder.apps.mapNotNull { appByKey[it] }
        appItems.forEachIndexed { index, app ->
            val tile = createAppTile(app, dp(49), true)
            tile.setOnClickListener { dialog.dismiss(); launchApp(app, tile.findViewWithTag<ImageView>(ICON_TAG)) }
            tile.setOnLongClickListener { showFolderAppMenu(id, app, dialog); true }
            grid.addView(tile, GridLayout.LayoutParams(GridLayout.spec(index / 4), GridLayout.spec(index % 4, 1f)).apply {
                width = 0; height = -2; setMargins(dp(3), dp(8), dp(3), dp(12))
            })
        }
        body.addView(grid, LinearLayout.LayoutParams(-1, -2))
        body.addView(text("Long-press an app to remove it from this folder.", 10f, 0xB9D0E2FF.toInt()).apply { setPadding(dp(2), dp(8), dp(2), dp(2)) })
        panel.addView(body, FrameLayout.LayoutParams(-1, -2))
        dialog.setContentView(panel)
        dialog.window?.let { win ->
            win.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            win.addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND or WindowManager.LayoutParams.FLAG_BLUR_BEHIND)
            win.setDimAmount(0.42f)
            if (Build.VERSION.SDK_INT >= 31 && prefs.getBoolean(KEY_FOLDER_BLUR, true)) win.setBackgroundBlurRadius(dp(24))
            win.setLayout((resources.displayMetrics.widthPixels - dp(34)).coerceAtMost(dp(520)), -2)
        }
        dialog.show()
        dialog.window?.setLayout((resources.displayMetrics.widthPixels - dp(34)).coerceAtMost(dp(520)), -2)
    }

    private fun showFolderOptions(id: String) {
        val folder = folders[id] ?: return
        AlertDialog.Builder(this).setTitle(folder.name).setItems(arrayOf("Open folder", "Rename folder", "Move to page…", "Delete folder")) { _, choice ->
            when (choice) {
                0 -> openFolder(id)
                1 -> {
                    val input = EditText(this).apply { setText(folder.name); setSelection(text.length); setSingleLine(true) }
                    AlertDialog.Builder(this).setTitle("Rename folder").setView(input).setPositiveButton("Save") { _, _ -> folder.name = input.text.toString().trim().ifBlank { "Folder" }; saveFolders(); buildHome(false) }.setNegativeButton("Cancel", null).show()
                }
                2 -> chooseMovePage(FOLDER_PREFIX + id)
                3 -> { pages.forEach { it.remove(FOLDER_PREFIX + id) }; folders.remove(id); saveFolders(); savePages(); buildHome(false) }
            }
        }.show()
    }

    private fun showFolderAppMenu(id: String, app: LauncherActivityInfo, parentDialog: Dialog) {
        AlertDialog.Builder(this).setTitle(app.label?.toString() ?: "Application")
            .setItems(arrayOf("Open app", "Remove from folder", "App info")) { _, choice ->
                when (choice) {
                    0 -> { parentDialog.dismiss(); launchApp(app) }
                    1 -> {
                        folders[id]?.apps?.remove(appKey(app))
                        saveFolders()
                        parentDialog.dismiss()
                        openFolder(id)
                    }
                    2 -> { parentDialog.dismiss(); openAppInfo(app) }
                }
            }.show()
    }

    private fun openAppInfo(app: LauncherActivityInfo) {
        try {
            startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${app.componentName.packageName}")))
        } catch (_: Exception) { toast("App info is not available.") }
    }

    private fun showWidgetOptions(widgetId: Int) {
        AlertDialog.Builder(this).setTitle("Home widget").setItems(arrayOf("Remove widget", "Configure widget")) { _, choice ->
            when (choice) {
                0 -> {
                    val ids = getSavedWidgetIds(currentPage).toMutableSet()
                    ids.remove(widgetId.toString())
                    saveWidgetIds(currentPage, ids)
                    try { widgetHost.deleteAppWidgetId(widgetId) } catch (_: Exception) { }
                    buildHome(false)
                }
                1 -> {
                    val info = widgetManager.getAppWidgetInfo(widgetId)
                    if (info?.configure != null) {
                        val intent = Intent(AppWidgetManager.ACTION_APPWIDGET_CONFIGURE).setComponent(info.configure).putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, widgetId)
                        try { startActivity(intent) } catch (_: Exception) { toast("This widget has no configuration screen.") }
                    } else toast("This widget has no configuration screen.")
                }
            }
        }.show()
    }

    private fun startWidgetPicker() {
        pendingWidgetPage = currentPage
        pendingWidgetId = try { widgetHost.allocateAppWidgetId() } catch (_: Exception) { AppWidgetManager.INVALID_APPWIDGET_ID }
        if (pendingWidgetId == AppWidgetManager.INVALID_APPWIDGET_ID) { toast("Couldn't reserve a widget slot."); return }
        val intent = Intent(AppWidgetManager.ACTION_APPWIDGET_PICK).putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, pendingWidgetId)
        try {
            startActivityForResult(intent, REQUEST_PICK_WIDGET)
        } catch (_: ActivityNotFoundException) {
            try { widgetHost.deleteAppWidgetId(pendingWidgetId) } catch (_: Exception) { }
            pendingWidgetId = AppWidgetManager.INVALID_APPWIDGET_ID
            toast("This Android build doesn't expose the system widget picker.")
        } catch (_: Exception) {
            try { widgetHost.deleteAppWidgetId(pendingWidgetId) } catch (_: Exception) { }
            pendingWidgetId = AppWidgetManager.INVALID_APPWIDGET_ID
            toast("Couldn't open the widget picker.")
        }
    }

    @Deprecated("Framework activity result used for AppWidgetHost compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_PICK_WIDGET) {
            val id = data?.getIntExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, pendingWidgetId) ?: pendingWidgetId
            if (resultCode == RESULT_OK && id != AppWidgetManager.INVALID_APPWIDGET_ID) {
                val info = widgetManager.getAppWidgetInfo(id)
                if (info == null) {
                    try { widgetHost.deleteAppWidgetId(id) } catch (_: Exception) { }
                    toast("The system didn't return a usable widget.")
                } else if (info.configure != null) {
                    val configure = Intent(AppWidgetManager.ACTION_APPWIDGET_CONFIGURE)
                        .setComponent(info.configure)
                        .putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, id)
                    try { startActivityForResult(configure, REQUEST_CONFIG_WIDGET) }
                    catch (_: Exception) { commitWidget(id, false) }
                    return
                } else commitWidget(id, true)
            } else {
                if (id != AppWidgetManager.INVALID_APPWIDGET_ID) try { widgetHost.deleteAppWidgetId(id) } catch (_: Exception) { }
            }
            pendingWidgetId = AppWidgetManager.INVALID_APPWIDGET_ID
        } else if (requestCode == REQUEST_CONFIG_WIDGET) {
            val id = data?.getIntExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, pendingWidgetId) ?: pendingWidgetId
            commitWidget(id, resultCode == RESULT_OK)
        } else if (requestCode == REQUEST_PICK_WALLPAPER && resultCode == RESULT_OK) {
            val uri = data?.data ?: return
            try { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) { }
            wallpaperSource = uri.toString()
            prefs.edit().putString(KEY_WALLPAPER, wallpaperSource).apply()
            loadWallpaper(wallpaperSource, true)
            buildWallpaperPicker()
        }
    }

    private fun commitWidget(widgetId: Int, success: Boolean) {
        if (widgetId == AppWidgetManager.INVALID_APPWIDGET_ID) {
            pendingWidgetId = AppWidgetManager.INVALID_APPWIDGET_ID
            return
        }
        if (success) {
            val ids = getSavedWidgetIds(pendingWidgetPage).toMutableSet()
            ids.add(widgetId.toString())
            saveWidgetIds(pendingWidgetPage, ids)
            currentPage = pendingWidgetPage
            savePages()
            try { widgetHost.startListening() } catch (_: Exception) { }
            buildHome(false)
            toast("Widget added")
        } else {
            try { widgetHost.deleteAppWidgetId(widgetId) } catch (_: Exception) { }
        }
        pendingWidgetId = AppWidgetManager.INVALID_APPWIDGET_ID
    }

    private fun getSavedWidgetIds(page: Int): Set<String> = prefs.getStringSet("widgets_$page", emptySet())?.toSet() ?: emptySet()
    private fun saveWidgetIds(page: Int, ids: Set<String>) { prefs.edit().putStringSet("widgets_$page", ids).apply() }

    private fun buildSettings() {
        screen = Screen.SETTINGS
        content.removeAllViews()
        val column = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; clipChildren = false; clipToPadding = false }
        content.addView(column, FrameLayout.LayoutParams(-1, -1))
        val header = pageHeader("Settings", "Fluid One · personal launcher", R.drawable.ic_back) { buildHome(false) }
        column.addView(header, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(13) })
        val scroll = ScrollView(this).apply { isFillViewport = false; clipToPadding = false; overScrollMode = View.OVER_SCROLL_NEVER; setPadding(0, 0, 0, dp(12)) }
        val body = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; clipChildren = false }
        scroll.addView(body, FrameLayout.LayoutParams(-1, -2))

        body.addView(sectionLabel("PERSONALIZATION"))
        body.addView(actionRow(R.drawable.ic_wallpaper, "Wallpaper", "Choose real abstract photo wallpapers or import your own image.") { buildWallpaperPicker() })
        body.addView(actionRow(R.drawable.ic_grid, "Home layout", "${homeColumns()} columns · ${pages.size} pages · ${iconSize() / resources.displayMetrics.density.toInt().coerceAtLeast(1)} dp icons") { showGridDialog() })
        body.addView(accentSetting())

        body.addView(sectionLabel("APPEARANCE"))
        body.addView(sliderCard("Glass blur", "Blur behind widgets, dock and glass panels", KEY_GLASS_BLUR,
            if (isS25Ultra()) 17 else 15, 0, 28, "dp"))
        body.addView(sliderCard("Glass tint", "Darkness of translucent glass surfaces", KEY_GLASS_TINT, 116, 35, 205, ""))
        body.addView(sliderCard("Icon size", "Scales with your screen density", KEY_ICON_SIZE, if (isS25Ultra()) 54 else 50, 40, 72, "dp"))
        body.addView(switchCard("Blur idle app icons", "Off by default; icons stay crisp after transitions", KEY_IDLE_ICON_BLUR, false) {
            buildHome(false)
        })

        body.addView(sectionLabel("MOTION & FEEDBACK"))
        body.addView(switchCard("Fluid transitions", "Staggered focus-in, app launch reveal and page motion", KEY_ANIMATIONS, true) { buildHome(false) })
        body.addView(switchCard("Reduce motion", "Shortens or skips large movement and blur", KEY_REDUCED_MOTION, false) { buildHome(false) })
        body.addView(switchCard("Haptic feedback", "Uses Android's haptic settings; no extra vibration permission", KEY_HAPTICS, true) { })

        body.addView(sectionLabel("DEVICE COMPATIBILITY"))
        body.addView(switchCard("Galaxy S25 Ultra mode", "Tuned grid, icon sizes and blur for SM-S938 devices", KEY_COMPAT, isS25Ultra()) { buildHome(false) })
        body.addView(infoCard(deviceInfo()))

        val advanced = TextView(this).apply {
            text = if (expandedAdvanced) "Advanced tuning  −" else "Advanced tuning  +"
            textSize = 13f
            setTextColor(Color.WHITE)
            typeface = Typeface.create("sans-serif-medium", Typeface.create("sans-serif-medium", Typeface.NORMAL))
            setPadding(dp(15), dp(16), dp(15), dp(16))
            background = roundBackground(0x29233140, 18f, 0x4C9BC7E8)
            isClickable = true
            setOnClickListener { expandedAdvanced = !expandedAdvanced; buildSettings() }
        }
        body.addView(advanced, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(15); bottomMargin = dp(8) })
        if (expandedAdvanced) {
            body.addView(sectionLabel("ADVANCED · USE WITH CARE"))
            body.addView(sliderCard("Unlock blur peak", "Initial blur strength before icons sharpen", KEY_UNLOCK_BLUR, 17, 0, 30, "dp"))
            body.addView(sliderCard("Stagger spread", "How much later icons start relative to each other", KEY_STAGGER, 19, 4, 38, "ms"))
            body.addView(sliderCard("Animation duration", "Global animation time multiplier", KEY_DURATION, 100, 65, 145, "%"))
            body.addView(switchCard("Glass blur on folder windows", "Use the system's background-blur API where supported", KEY_FOLDER_BLUR, true) { })
            body.addView(actionRow(R.drawable.ic_tune, "Reset appearance", "Return style and motion controls to balanced defaults.") {
                prefs.edit().remove(KEY_GLASS_BLUR).remove(KEY_GLASS_TINT).remove(KEY_ICON_SIZE).remove(KEY_IDLE_ICON_BLUR)
                    .remove(KEY_ANIMATIONS).remove(KEY_REDUCED_MOTION).remove(KEY_HAPTICS).remove(KEY_UNLOCK_BLUR)
                    .remove(KEY_STAGGER).remove(KEY_DURATION).remove(KEY_FOLDER_BLUR).apply()
                buildSettings()
            })
        }
        body.addView(text("Fluid One is a home-screen replacement. Samsung's One UI notification shade and control center remain untouched.", 10f, 0xA8C6D8EA.toInt()).apply { setPadding(dp(3), dp(14), dp(3), dp(9)) })
        column.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
    }

    private fun pageHeader(title: String, subtitle: String, icon: Int, back: () -> Unit): LinearLayout {
        val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        header.addView(iconButton(icon, "Back") { back() }, LinearLayout.LayoutParams(dp(40), dp(40)).apply { rightMargin = dp(12) })
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        box.addView(text(title, 22f, Color.WHITE, Typeface.create("sans-serif-medium", Typeface.NORMAL)))
        box.addView(text(subtitle, 10f, 0xB9D0E2FF.toInt()).apply { setPadding(0, dp(4), 0, 0) })
        header.addView(box, LinearLayout.LayoutParams(0, -2, 1f))
        return header
    }

    private fun sectionLabel(label: String): TextView = text(label, 9f, 0x9BC6D9EC.toInt(), Typeface.BOLD).apply {
        letterSpacing = 0.14f
        setPadding(dp(4), dp(18), dp(4), dp(9))
    }

    private fun actionRow(iconRes: Int, title: String, summary: String, click: () -> Unit): View {
        val row = GlassPanel(this, 17f).apply {
            setPadding(dp(12), dp(10), dp(12), dp(10))
            isClickable = true
            setOnClickListener { performHapticFeedbackOn(this, HapticFeedbackConstants.CONTEXT_CLICK); click() }
        }
        val horizontal = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val iconContainer = FrameLayout(this).apply { background = roundBackground(0x25FFFFFF, 12f, 0x20FFFFFF) }
        val icon = ImageView(this).apply { setImageResource(iconRes); imageTintList = android.content.res.ColorStateList.valueOf(accent()); setPadding(dp(7), dp(7), dp(7), dp(7)) }
        iconContainer.addView(icon, FrameLayout.LayoutParams(-1, -1))
        horizontal.addView(iconContainer, LinearLayout.LayoutParams(dp(36), dp(36)).apply { rightMargin = dp(12) })
        val copy = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        copy.addView(text(title, 12f, Color.WHITE, Typeface.create("sans-serif-medium", Typeface.NORMAL)))
        copy.addView(text(summary, 9f, 0xAFD2E2F2.toInt()).apply { setPadding(0, dp(4), 0, 0) })
        horizontal.addView(copy, LinearLayout.LayoutParams(0, -2, 1f))
        horizontal.addView(text("›", 25f, 0xB8D7E7F7.toInt()).apply { gravity = Gravity.CENTER })
        row.addView(horizontal, FrameLayout.LayoutParams(-1, -2))
        return row.apply { layoutParams = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(7) } }
    }

    private fun accentSetting(): View {
        val card = GlassPanel(this, 17f).apply { setPadding(dp(13), dp(12), dp(13), dp(12)) }
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(text("Accent color", 12f, Color.WHITE, Typeface.create("sans-serif-medium", Typeface.NORMAL)))
        col.addView(text("Muted colors designed for dark glass", 9f, 0xAFC8D9EA.toInt()).apply { setPadding(0, dp(4), 0, dp(11)) })
        val swatches = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        accentOptions.forEach { (name, color) ->
            val swatch = View(this).apply {
                background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(color); setStroke(dp(if (accent() == color) 2 else 1), if (accent() == color) Color.WHITE else 0x66FFFFFF) }
                contentDescription = name
                isClickable = true
                setOnClickListener {
                    prefs.edit().putInt(KEY_ACCENT, color).apply()
                    performHapticFeedbackOn(this, HapticFeedbackConstants.CONTEXT_CLICK)
                    buildSettings()
                }
            }
            swatches.addView(swatch, LinearLayout.LayoutParams(dp(30), dp(30)).apply { rightMargin = dp(11) })
        }
        col.addView(swatches)
        card.addView(col, FrameLayout.LayoutParams(-1, -2))
        return card.apply { layoutParams = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(7) } }
    }

    private fun sliderCard(title: String, summary: String, key: String, default: Int, minValue: Int, maxValue: Int, suffix: String): View {
        val card = GlassPanel(this, 17f).apply { setPadding(dp(13), dp(12), dp(13), dp(11)) }
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        header.addView(text(title, 12f, Color.WHITE, Typeface.create("sans-serif-medium", Typeface.NORMAL)), LinearLayout.LayoutParams(0, -2, 1f))
        val initial = prefs.getInt(key, default).coerceIn(minValue, maxValue)
        val valueText = text("$initial$suffix", 11f, accent(), Typeface.create("sans-serif-medium", Typeface.NORMAL))
        header.addView(valueText)
        col.addView(header)
        col.addView(text(summary, 9f, 0xAFC8D9EA.toInt()).apply { setPadding(0, dp(4), 0, dp(4)) })
        val seek = SeekBar(this).apply {
            max = maxValue - minValue
            progress = initial - minValue
            progressTintList = android.content.res.ColorStateList.valueOf(accent())
            thumbTintList = android.content.res.ColorStateList.valueOf(0xFFEAF4FE.toInt())
        }
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(bar: SeekBar?, progress: Int, fromUser: Boolean) {
                val value = progress + minValue
                valueText.text = "$value$suffix"
                if (fromUser) {
                    prefs.edit().putInt(key, value).apply()
                    root.invalidate()
                }
            }
            override fun onStartTrackingTouch(bar: SeekBar?) { }
            override fun onStopTrackingTouch(bar: SeekBar?) {
                if (key == KEY_ICON_SIZE || key == KEY_GLASS_BLUR || key == KEY_GLASS_TINT) buildSettings()
            }
        })
        col.addView(seek, LinearLayout.LayoutParams(-1, dp(36)).apply { topMargin = dp(1) })
        card.addView(col, FrameLayout.LayoutParams(-1, -2))
        return card.apply { layoutParams = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(7) } }
    }

    private fun switchCard(title: String, summary: String, key: String, default: Boolean, changed: () -> Unit): View {
        val card = GlassPanel(this, 17f).apply { setPadding(dp(13), dp(10), dp(10), dp(10)) }
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val copy = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        copy.addView(text(title, 12f, Color.WHITE, Typeface.create("sans-serif-medium", Typeface.NORMAL)))
        copy.addView(text(summary, 9f, 0xAFC8D9EA.toInt()).apply { setPadding(0, dp(4), dp(3), 0) })
        row.addView(copy, LinearLayout.LayoutParams(0, -2, 1f))
        val switch = Switch(this).apply {
            isChecked = prefs.getBoolean(key, default)
            buttonTintListCompat(this, accent())
            contentDescription = title
            setOnCheckedChangeListener { _, isChecked ->
                prefs.edit().putBoolean(key, isChecked).apply()
                performHapticFeedbackOn(this, HapticFeedbackConstants.CONTEXT_CLICK)
                changed()
            }
        }
        row.addView(switch, LinearLayout.LayoutParams(-2, -2).apply { leftMargin = dp(8) })
        card.addView(row, FrameLayout.LayoutParams(-1, -2))
        return card.apply { layoutParams = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(7) } }
    }

    private fun buttonTintListCompat(switch: Switch, color: Int) {
        try {
            switch.thumbTintList = android.content.res.ColorStateList.valueOf(color)
            switch.trackTintList = android.content.res.ColorStateList.valueOf((color and 0x00FFFFFF) or 0x66000000)
        } catch (_: Exception) { }
    }

    private fun infoCard(contentText: String): View {
        val card = GlassPanel(this, 17f).apply { setPadding(dp(13), dp(12), dp(13), dp(12)) }
        card.addView(text(contentText, 10f, 0xC5D9E9F7.toInt()).apply { setLineSpacing(dp(3).toFloat(), 1f) }, FrameLayout.LayoutParams(-1, -2))
        return card.apply { layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(7) } }
    }

    private fun deviceInfo(): String {
        val metrics = resources.displayMetrics
        val ppi = sqrt(max(1f, metrics.xdpi) * max(1f, metrics.ydpi))
        val compatibility = prefs.getBoolean(KEY_COMPAT, isS25Ultra())
        return "Detected device: ${Build.MANUFACTURER} ${Build.MODEL}\n" +
            "App display: ${metrics.widthPixels} × ${metrics.heightPixels} px\n" +
            "Density: ${metrics.densityDpi} dpi · estimated physical density: ${ppi.toInt()} ppi\n" +
            "S25 Ultra compatibility: ${if (compatibility) "enabled" else "automatic layout"}\n" +
            "Sizing uses Android dp units, not hard-coded pixels."
    }

    private fun isS25Ultra(): Boolean {
        val model = Build.MODEL.orEmpty().uppercase(Locale.ROOT)
        val device = Build.DEVICE.orEmpty().lowercase(Locale.ROOT)
        return Build.MANUFACTURER.equals("samsung", true) && (model.startsWith("SM-S938") || device.startsWith("pa3q"))
    }

    private fun buildWallpaperPicker() {
        screen = Screen.WALLPAPERS
        content.removeAllViews()
        val column = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; clipChildren = false }
        content.addView(column, FrameLayout.LayoutParams(-1, -1))
        column.addView(pageHeader("Wallpapers", "Real abstract photography · Unsplash", R.drawable.ic_back) { buildSettings() }, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(12) })
        val scroll = ScrollView(this).apply { clipToPadding = false; overScrollMode = View.OVER_SCROLL_NEVER }
        val body = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(body, FrameLayout.LayoutParams(-1, -2))
        wallpaperChoices.forEach { choice ->
            val card = GlassPanel(this, 20f).apply { setPadding(dp(9), dp(9), dp(10), dp(9)); isClickable = true }
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
            val thumb = ImageView(this).apply { scaleType = ImageView.ScaleType.CENTER_CROP; background = roundBackground(0xFF152235.toInt(), 15f); clipToOutline = true; outlineProvider = ViewOutlineProvider.BACKGROUND }
            row.addView(thumb, LinearLayout.LayoutParams(dp(102), dp(126)).apply { rightMargin = dp(12) })
            val description = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            description.addView(text(choice.name, 13f, Color.WHITE, Typeface.create("sans-serif-medium", Typeface.NORMAL)))
            description.addView(text(choice.credit, 9f, 0xAEC8D9E9.toInt()).apply { setPadding(0, dp(5), 0, dp(11)) })
            description.addView(text(if (wallpaperSource == choice.url) "Currently selected" else "Use wallpaper", 10f, accent(), Typeface.create("sans-serif-medium", Typeface.NORMAL)))
            row.addView(description, LinearLayout.LayoutParams(0, -2, 1f))
            card.addView(row, FrameLayout.LayoutParams(-1, -2))
            card.setOnClickListener {
                wallpaperSource = choice.url
                prefs.edit().putString(KEY_WALLPAPER, wallpaperSource).apply()
                loadWallpaper(wallpaperSource, true)
                performHapticFeedbackOn(card, HapticFeedbackConstants.CONTEXT_CLICK)
                buildWallpaperPicker()
            }
            body.addView(card, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(9) })
            loadThumbnail(choice.url, thumb)
        }
        val import = actionRow(R.drawable.ic_plus, "Import an image", "Pick a wallpaper from your device. Access stays local.") {
            val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE)
                type = "image/*"
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
            }
            try { startActivityForResult(intent, REQUEST_PICK_WALLPAPER) } catch (_: Exception) { toast("No image picker was found.") }
        }
        body.addView(import)
        body.addView(text("Wallpaper photos are fetched from Unsplash when online and cached locally after the first successful load.", 10f, 0xA8C4D7E8.toInt()).apply { setPadding(dp(3), dp(13), dp(3), dp(18)) })
        column.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
    }

    private fun loadThumbnail(source: String, target: ImageView) {
        val cached = cachedWallpaperFile(source)
        if (cached.exists()) {
            try { target.setImageBitmap(BitmapFactory.decodeFile(cached.absolutePath)); return } catch (_: Exception) { }
        }
        wallpaperExecutor.execute {
            val bmp = fetchBitmap(source, cached)
            if (bmp != null) runOnUiThread { if (target.isAttachedToWindow) target.setImageBitmap(bmp) }
        }
    }

    private fun loadWallpaper(source: String, animated: Boolean) {
        wallpaperSource = source
        val cached = cachedWallpaperFile(source)
        if (source.startsWith("content://")) {
            wallpaperExecutor.execute {
                val bitmap = try { contentResolver.openInputStream(Uri.parse(source))?.use { BitmapFactory.decodeStream(it) } } catch (_: Exception) { null }
                if (bitmap != null) runOnUiThread { setWallpaperBitmap(bitmap, animated) }
            }
            return
        }
        if (cached.exists()) {
            val bitmap = try { BitmapFactory.decodeFile(cached.absolutePath) } catch (_: Exception) { null }
            if (bitmap != null) { setWallpaperBitmap(bitmap, animated); return }
        }
        wallpaperExecutor.execute {
            val bitmap = fetchBitmap(source, cached)
            if (bitmap != null) runOnUiThread { setWallpaperBitmap(bitmap, animated) }
        }
    }

    private fun cachedWallpaperFile(source: String): File {
        val index = wallpaperChoices.indexOfFirst { it.url == source }
        val key = if (index >= 0) "wallpaper_$index" else "wallpaper_${source.hashCode().toUInt().toString(16)}"
        return File(filesDir, "$key.jpg")
    }

    private fun fetchBitmap(source: String, cacheFile: File): Bitmap? {
        var connection: HttpURLConnection? = null
        return try {
            connection = URL(source).openConnection() as HttpURLConnection
            connection.connectTimeout = 12000
            connection.readTimeout = 16000
            connection.instanceFollowRedirects = true
            connection.setRequestProperty("User-Agent", "FluidOneLauncher/1.0 (Android wallpaper loader)")
            connection.connect()
            if (connection.responseCode !in 200..299) return null
            val bytes = connection.inputStream.use { it.readBytes() }
            cacheFile.parentFile?.mkdirs()
            FileOutputStream(cacheFile).use { it.write(bytes) }
            BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
        } catch (_: Exception) {
            null
        } finally { connection?.disconnect() }
    }

    private fun setWallpaperBitmap(bitmap: Bitmap, animated: Boolean) {
        if (bitmap.isRecycled) return
        wallpaperBitmap = bitmap
        wallpaperView.setImageBitmap(bitmap)
        root.invalidate()
        if (animated) {
            wallpaperView.alpha = 0.6f
            wallpaperView.animate().alpha(1f).setDuration(280L).setInterpolator(DecelerateInterpolator()).start()
        }
    }

    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_SHORT).show()

    companion object {
        private const val WIDGET_HOST_ID = 2048
        private const val REQUEST_PICK_WIDGET = 4701
        private const val REQUEST_PICK_WALLPAPER = 4702
        private const val REQUEST_CONFIG_WIDGET = 4703
        private const val MAX_HOME_PAGES = 9
        private const val KEY_PAGES = "home_pages_json"
        private const val KEY_FOLDERS = "folders_json"
        private const val KEY_WALLPAPER = "wallpaper_source"
        private const val KEY_GLASS_BLUR = "glass_blur"
        private const val KEY_GLASS_TINT = "glass_tint"
        private const val KEY_ICON_SIZE = "icon_size_dp"
        private const val KEY_ACCENT = "accent_color"
        private const val KEY_IDLE_ICON_BLUR = "idle_icon_blur"
        private const val KEY_ANIMATIONS = "animations"
        private const val KEY_REDUCED_MOTION = "reduced_motion"
        private const val KEY_HAPTICS = "haptics"
        private const val KEY_COMPAT = "s25_compat"
        private const val KEY_HOME_COLUMNS = "home_columns"
        private const val KEY_UNLOCK_BLUR = "unlock_blur"
        private const val KEY_STAGGER = "stagger_spread"
        private const val KEY_DURATION = "duration_percent"
        private const val KEY_FOLDER_BLUR = "folder_blur"
        private const val ICON_TAG = "fluid_icon_view"
        private const val FOLDER_PREFIX = "folder:"
        private const val DEFAULT_WALLPAPER = "https://images.unsplash.com/photo-1706101299176-292d8c5e470e?fm=jpg&fit=crop&w=1800&q=88"
    }
}
