# Fluid One 1.2 — ColorOS 17–style home screen for Android

A native Kotlin launcher for Android 12+ that follows the look and motion of ColorOS 17. It is tuned for the Galaxy S25 Ultra
and now also for Xiaomi, Nothing, Pixel, OnePlus, OPPO, realme, Motorola, vivo, HONOR, HUAWEI, Xperia and ASUS phones.
It uses only the Android framework (no third-party libraries).

## Install

1. Install `FluidOne-V1.2.apk` on the phone. It installs over Fluid One 1.1 (same signing key) and keeps your layout,
   wallpaper, icons, widgets and every setting.
2. Press Home and choose **Fluid One** → **Always**, or set it as the default Home app in the system settings.
3. Being the default home app also turns on app shortcuts in the long-press menu.

## What's in it

**New in 1.2**
- **Welcome to Fluid One**: a fully animated tour on first install. After an update it shows **What's new in 1.2** instead,
  and everything you customized is kept.
- **Brand modes**, switched on automatically for your phone: Samsung, Xiaomi, Nothing, Pixel, OnePlus, OPPO, realme, Motorola,
  vivo, HONOR, HUAWEI, Xperia and ASUS. Depending on the phone they offer:
  - the highest refresh rate on home;
  - edge-safe dragging;
  - battery-aware and performance-tuned effects;
  - split swipe-down (notifications on the left, control centre on the right);
  - Material You colours and themed icons that follow dark mode;
  - Nothing's dot-matrix clock and monochrome look;
  - a shortcut to the system's auto-start and battery exemption, so the launcher isn't closed in the background.
- **Themed icons fixed on every phone.** Apps without a monochrome icon used to show plain squares or circles, or a symbol
  spilling past the plate. Fluid One now extracts the real symbol, sizes it to fit and clips it to the icon shape. If there is
  no usable symbol it falls back to a duotone or the app's initial.
- **More icon options**:
  - 9 shapes (new: hexagon, flower, leaf);
  - 9 styles: Original, Fluid Glass, Themed dark, Themed light, Tinted, Mono, Pastel, Neon, Gradient;
  - symbol size;
  - a plate for legacy icons;
  - icon shadows.

  The transparent style is now **Fluid Glass**, and it is called **Blur** when Fluid Glass is off.
- **9 Fluid One widgets**: Clock & date, Analog clock, Date, Calendar, Battery, Search, Note, Photo and Quick toggles. Each
  one can have a Fluid Glass/blur background, a colour background (any colour) or no background.
- **Custom accent colour** with a full colour picker.
- **Fluid Glass advanced settings**: edge curve, depth, zoom, softness, rim light, edge shadow, colour split, effects quality and press animations, with a reset button.
- **Liquid toggles**: hold a switch and drag its glass knob left or right; it follows your finger with spring physics.
- **App open & close animations** use the transitions Android lets a launcher drive, so they now play on One UI and other
  systems too: Zoom (default), Reveal, Fade, Morph or System, with a toggle.
- **Unlock animations**: Fluid One (default), ColorOS, One UI, HyperOS, Pixel, Ripple, Zoom or Off.
- **Smarter search**:
  - your phone's own settings pages, read from the system Settings app (where the phone exposes them);
  - percentages and tips (`20% of 80`, `20% off 50`);
  - world clocks (`time in tokyo`) and countdowns (`days until christmas`);
  - more units;
  - learning which results you pick.
- Wallpapers are reordered: Fluid Glass wallpapers first, then the newer ones, then the originals.
- Fixes:
  - **Notifications no longer open by themselves after unlocking.** A swipe that was still in progress during the unlock
    animation could pull down the shade.
  - **Widgets that wouldn't add now add.** Widgets that need a setup screen or bind permission finish adding when you return.
  - **Rounded corners on every widget**, including One UI's weather widget.
  - **The search gradient stays above the keyboard** on every keyboard.

**Home screen**
- Fixed pages with no scrolling inside them; finger-following page swipes with ColorOS deceleration, edge rubber-banding and wallpaper parallax.
- Default layout modelled on ColorOS 17: big date and gradient time, a large 2×2 folder, a calendar card, a search capsule and a four-app dock.
- The dock sizes itself to the apps it holds and lines up with the grid columns. Styles: Clear (default), Glass, Hidden.
- Page transitions: Slide, Depth, Cube, Fade, Carousel.

**Blur that works on the S25 Ultra**
- Glass (dock, search capsule, folders, menus, sheets) samples a pre-blurred copy of the wallpaper aligned to its exact screen position, so it keeps working when One UI's own window blur is off (power saving, "Reduce transparency and blur").
- Behind menus and folders the home screen also gets a live GPU blur (RenderEffect) plus a dimming scrim; strength and tint are adjustable.

**Motion**
- App open: the app grows out of its icon (Zoom, Reveal, Fade, Morph or the system default) while the home screen zooms past and the wallpaper blurs.
- App close: the home screen settles back and the icon pops while neighbouring icons ripple.
- Unlock: Fluid One (icons gather in from the edges), ColorOS, One UI, HyperOS, Pixel, Ripple, Zoom or Off.
- Spring physics throughout, plus a global speed setting.

**Editing and customization**
- Long-press an app: the background blurs, the icon lifts and a frosted menu shows app shortcuts plus Edit / Remove / Uninstall / App info. Move your finger to drag instead.
- Drag anything anywhere: free placement, push-reorder of neighbours, hover on an app to make a folder, hover at the screen edge to change page (or create one), drop in the dock, Remove/Uninstall targets at the top.
- Move many apps at once: while holding an app, tap other apps (home or dock) with another finger. Each one lifts and flies into a stack behind your finger; the stacked apps trail a few milliseconds behind as you move and hide behind the top app when you hold still, with a count badge. While holding, swipe sideways with another finger to change pages. Release to drop: the apps land in the following cells (spilling onto the next page), or all go into a folder, the dock, or Remove.
- Long-press empty space (or pinch in): the home zooms out into page cards over a blurred wallpaper. Swipe between pages, add or delete pages, set the main page, and open the Wallpapers, Widgets, Icons, Layout and Settings sheets.
- Icons: 9 shapes; 9 styles (Original, Fluid Glass, Themed dark/light, Tinted, Mono, Pastel, Neon, Gradient); symbol size, legacy plate and shadows; ADW/Nova icon packs; per-app icon from a pack (searchable), a gallery image or a generated style; rename apps.
- Folders: small or large (2×2, tap the tiles to launch directly), rename in place, reorder, drag out.
- Widgets: 9 built-in Fluid One widgets with glass, colour or no background, plus every Android app widget, with previews, resizing and rounded corners.
- Built-in abstract wallpapers (Fluid Glass ones first) rendered on the phone at native resolution (no download), your own photo,
  optional lock-screen sync.
- ColorOS-style settings with large titles, grouped cards, spring toggles, sliders and segmented controls, in light and dark.

**Samsung mode** (on automatically on Galaxy devices; other brands get their own mode)
- For every Galaxy: highest refresh rate on home, edge-safe dragging (One UI's back gesture can't grab a dragged icon), battery-aware blur, and a diagnostics card.
- Galaxy S25 Ultra optimizations (only on SM-S938*): S Pen hover lift, S Pen button opens an icon's menu, and a recommended 4×6 layout.

## Privacy

Fluid One has no `INTERNET` permission, so nothing it reads can leave the phone. Contacts and calendar access are optional, are
requested only after a privacy notice, and are used only to show results on the phone. Web searches start only when you tap one,
and they open in your own browser or app.

## Limits

- Android 13+ only honours a few launch transitions from third-party launchers (scale-up and clip-reveal). Fluid One uses those for opening apps and draws the rest of the motion itself. On some systems you may still see the system's own close animation.
- If One UI's "Remove animations" is on (animator scale 0), Android skips all animations; Settings › Animations warns about this.
- Swipe-down-for-notifications uses a widely used but unofficial Android call; if a future system update blocks it, the gesture does nothing.
- Searching the phone's own settings depends on which pages the system Settings app makes public; on phones that hide them, Fluid One still finds the common Android settings pages.
- Recents is provided by the system, not by the launcher.

## Build

Requirements: Android Studio (or JDK 17 + Android SDK Platform 35 / Build Tools 35).

```bash
./gradlew assembleDebug
```

The APK is written to `app/build/outputs/apk/debug/app-debug.apk`. The GitHub Actions workflow in
`.github/workflows/build-apk.yml` builds it, runs the tests and uploads both the APK and test screenshots.

## Tests

`app/src/test` holds Robolectric UI tests that boot the launcher with 32 fake apps and drive it with real
touch events: page swipes, the drawer, long-press menus, drag & drop (free placement, push-reorder, folder
creation, dock ⇄ home, drawer → home, out of a folder across pages, remove), edit mode and every sheet,
every settings page and toggle, theme changes, icon styles, grid changes, widget resizing, page deletion,
page effects, app launch/return, unlock and activity recreation, multi-app stacks, every search source and the
privacy-first permission flow, upgrading from 1.1, brand modes (with a simulated Nothing Phone), every widget background, the welcome and What's new screens, and Fluid Glass rendered through the GPU path. Screenshots go to `app/build/screenshots`.

```bash
./gradlew testDebugUnitTest
```
