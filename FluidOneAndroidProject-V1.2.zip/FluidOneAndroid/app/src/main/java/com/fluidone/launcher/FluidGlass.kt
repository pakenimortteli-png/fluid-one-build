package com.fluidone.launcher

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapShader
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.RuntimeShader
import android.graphics.Shader
import android.os.Build
import android.view.MotionEvent
import android.view.View
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * Fluid Glass: every glass surface is drawn as a thick, clear lens on the GPU (AGSL, Android 13+).
 *
 * - The rim curves away like the edge of a lens. It pulls in and bends what lies around the glass, and the
 *   middle magnifies a little.
 * - Red and blue split slightly on the curve.
 * - The glass is never perfectly clear: there is always a touch of blur.
 * - The edge is a crisp line of light, brightest at the top-left and bottom-right corners, with a thin
 *   shadow just inside it that gives the glass its thickness.
 * - [intensity] goes from plain frosted blur (0) to clear liquid glass (1).
 */
object FluidGlass {
    val supported: Boolean get() = Build.VERSION.SDK_INT >= 33

    // Advanced settings (Settings › Blur & Fluid Glass › Advanced). 1 = default look.
    @Volatile var edgeCurve = 1f
    @Volatile var depth = 1f
    @Volatile var zoom = 1f
    @Volatile var softness = 1f
    @Volatile var rimLight = 1f
    @Volatile var edgeShadow = 1f
    @Volatile var dispersion = 1f
    /** 2 = high, 1 = balanced, 0 = lite (fewer samples for mid-range and budget GPUs). */
    @Volatile var quality = 2

    fun load(p: LauncherPrefs, tier: Tier) {
        edgeCurve = 0.5f + p.fgEdge / 100f
        depth = p.fgDepth / 50f
        zoom = p.fgZoom / 47f
        softness = p.fgSoftness / 50f
        rimLight = p.fgRim / 50f
        edgeShadow = p.fgShadow / 50f
        dispersion = p.fgDispersion / 50f
        quality = when (tier) { Tier.HIGH -> 2; Tier.BALANCED -> 1; Tier.LITE -> 0 }
    }

    const val AGSL = """
uniform shader sharp;
uniform shader blurred;
uniform float2 size;
uniform float radius;
uniform float intensity;
uniform float bevel;
uniform float refraction;
uniform float blurPx;
uniform float dp;
uniform float4 tint;
uniform float2 light;
uniform float press;
uniform float magnify;
uniform float rimAmt;
uniform float shadeAmt;
uniform float dispersion;
uniform float quality;

float sdRR(float2 p, float2 b, float r) {
    float2 q = abs(p) - b + float2(r, r);
    return min(max(q.x, q.y), 0.0) + length(max(q, float2(0.0, 0.0))) - r;
}

float3 tap(float2 at) { return float3(sharp.eval(at).rgb); }

float3 soft(float2 at, float r) {
    float d = r * 0.7071;
    float3 s = tap(at) * 0.2;
    s += (tap(at + float2(r, 0.0)) + tap(at - float2(r, 0.0)) + tap(at + float2(0.0, r)) + tap(at - float2(0.0, r))) * 0.1;
    s += (tap(at + float2(d, d)) + tap(at - float2(d, d)) + tap(at + float2(d, -d)) + tap(at + float2(-d, d))) * 0.1;
    return s;
}

float3 soft5(float2 at, float r) {
    float d = r * 0.7071;
    return tap(at) * 0.2 + (tap(at + float2(d, d)) + tap(at - float2(d, d)) + tap(at + float2(d, -d)) + tap(at + float2(-d, d))) * 0.2;
}

half4 main(float2 coord) {
    float2 c = size * 0.5;
    float2 p = coord - c;
    float r = min(radius, min(c.x, c.y));
    float d = sdRR(p, c, r);
    float cover = clamp(0.5 - d, 0.0, 1.0);
    if (cover <= 0.0) { return half4(0.0); }

    // The surface normal comes from a rounder twin of the shape, so the curved surface has no creases.
    float rn = min(max(r, bevel), min(c.x, c.y));
    float dn = sdRR(p, c, rn);
    float2 g = float2(sdRR(p + float2(1.0, 0.0), c, rn) - sdRR(p - float2(1.0, 0.0), c, rn),
                      sdRR(p + float2(0.0, 1.0), c, rn) - sdRR(p - float2(0.0, 1.0), c, rn));
    float2 n = g / max(length(g), 0.0001);

    // 1 at the rim, 0 where the glass is flat; steeper towards the rim, like the edge of a lens.
    float k = clamp(1.0 + dn / bevel, 0.0, 1.0);
    float f = k * k * (0.55 + 0.45 * k);
    float i = intensity;
    float bulge = 1.0 + 0.4 * press;

    // Refraction: the middle magnifies, the curved rim gathers in what lies around the glass.
    float2 base = c + p * (1.0 - magnify * i * bulge);
    float shift = refraction * i * bulge * f;
    float2 bent = base + n * shift;
    float br = blurPx * (1.0 + 1.6 * f);
    float3 clear;
    if (quality > 1.5) { clear = soft(bent, br); }
    else if (quality > 0.5) { clear = soft5(bent, br); }
    else { clear = tap(bent); }
    if (quality > 0.5 && dispersion > 0.01) {
        float spread = min(shift * 0.028 * dispersion, 0.9 * dp * dispersion);
        float edge = min(1.0, f * 1.2) * 0.8;
        clear.r = mix(clear.r, tap(bent + n * spread).r, edge);
        clear.b = mix(clear.b, tap(bent - n * spread).b, edge);
    }

    float3 frost = float3(blurred.eval(coord + n * shift * 0.5).rgb);
    float3 col = mix(clear, frost, pow(1.0 - i, 1.6));

    // Glass makes colours a touch richer, then the tint keeps text on top readable.
    float l = dot(col, float3(0.2126, 0.7152, 0.0722));
    col = clamp(mix(float3(l, l, l), col, 1.0 + 0.2 * i), 0.0, 1.0);
    float3 tintRgb = tint.a > 0.001 ? tint.rgb / tint.a : float3(0.0, 0.0, 0.0);
    col = mix(col, tintRgb, tint.a * (1.0 - 0.5 * i));
    // Glass is a material, not a hole: a faint even haze lifts it off what is behind.
    col = col * (1.0 - 0.05 * i) + 0.035 * i;

    // The edge: a crisp rim of light, brightest where it faces the light and at the opposite corner,
    // and a thin shadow line just inside it.
    float facing = dot(n, float2(-0.6222, -0.7828));
    float glint = facing * facing;
    float rimW = 1.25 * dp;
    float rim = clamp((d + rimW + 0.5) / rimW, 0.0, 1.0);
    // On bright backgrounds a white rim would vanish: there the edge reads as a soft grey line instead.
    float bright = smoothstep(0.62, 0.95, dot(col, float3(0.2126, 0.7152, 0.0722)));
    col = mix(col, float3(1.0, 1.0, 1.0), clamp(rim * (0.22 + 0.68 * glint) * (0.35 + 0.65 * i) * (1.0 - 0.7 * bright) * rimAmt, 0.0, 1.0));
    col *= 1.0 - clamp(rim * bright * (0.16 + 0.14 * (1.0 - glint)) * (0.4 + 0.6 * i) * rimAmt, 0.0, 0.8);
    float inner = (d + 2.6 * dp) / (1.2 * dp);
    col *= 1.0 - clamp(exp(-inner * inner) * (1.0 - 0.7 * glint) * 0.12 * i * shadeAmt, 0.0, 0.6);

    // Pressing lights the glass from under the finger.
    if (press > 0.001 && light.x >= 0.0) {
        float2 dl = coord - light;
        float s = min(size.x, size.y) * 0.65;
        col += float3(0.08, 0.08, 0.08) * press * exp(-dot(dl, dl) / (s * s));
    }
    col = clamp(col, 0.0, 1.0);
    return half4(half3(col * cover), half(cover));
}
"""
}

/**
 * An interruptible spring (stiffness + damping ratio) driven by vsync. Unlike a fixed-duration animation it
 * keeps its velocity when retargeted, which is what makes glass feel like liquid.
 */
class SpringValue(initial: Float = 0f, private val onUpdate: (Float) -> Unit) : android.view.Choreographer.FrameCallback {
    var value = initial
        private set
    var velocity = 0f
        private set
    var target = initial
        private set
    private var stiffness = 400f
    private var damping = 30f
    private var running = false
    private var last = 0L

    val isRunning: Boolean get() = running

    fun animateTo(to: Float, stiffness: Float = 400f, dampingRatio: Float = 0.75f) {
        target = to
        this.stiffness = stiffness
        damping = 2f * dampingRatio * kotlin.math.sqrt(stiffness)
        if (!ValueAnimator.areAnimatorsEnabled()) { snapTo(to); return }
        if (!running) {
            running = true
            last = 0L
            android.view.Choreographer.getInstance().postFrameCallback(this)
        }
    }

    fun snapTo(v: Float) {
        stop()
        value = v; target = v; velocity = 0f
        onUpdate(v)
    }

    fun stop() {
        if (running) { android.view.Choreographer.getInstance().removeFrameCallback(this); running = false }
    }

    override fun doFrame(frameTimeNanos: Long) {
        if (!running) return
        val dt = if (last == 0L) 1f / 60f else ((frameTimeNanos - last) / 1e9f).coerceIn(0.001f, 0.05f)
        last = frameTimeNanos
        var left = dt
        while (left > 0f) {
            val h = min(left, 1f / 240f)
            val a = -stiffness * (value - target) - damping * velocity
            velocity += a * h
            value += velocity * h
            left -= h
        }
        if (kotlin.math.abs(value - target) < 0.0008f * (1f + kotlin.math.abs(target)) && kotlin.math.abs(velocity) < 0.01f * (1f + kotlin.math.abs(target))) {
            value = target; velocity = 0f; running = false
            onUpdate(value)
            return
        }
        onUpdate(value)
        android.view.Choreographer.getInstance().postFrameCallback(this)
    }
}

/** Draws one glass surface. Holds the compiled shader and its inputs; falls back when unavailable. */
class GlassPainter(private val context: Context) {
    private var runtime: Any? = null
    private var failed = false
    private var sharpBmp: Bitmap? = null
    private var sharpShader: BitmapShader? = null
    private var blurBmp: Bitmap? = null
    private var blurShader: BitmapShader? = null
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val m1 = Matrix()
    private val m2 = Matrix()

    /**
     * True when the shader path drew the glass. [press] (0..1, may overshoot) swells the lens and lights it at
     * ([lightX], [lightY]) in [rect]'s coordinates.
     */
    fun draw(
        canvas: Canvas, rect: RectF, radius: Float, intensity: Float, tint: Int,
        sharp: Bitmap, sharpMatrix: Matrix, blur: Bitmap, blurMatrix: Matrix,
        press: Float = 0f, lightX: Float = -1f, lightY: Float = -1f
    ): Boolean {
        // Software canvases (e.g. drag snapshots) cannot run shaders: use frosted glass for that draw only.
        if (!FluidGlass.supported || failed || !canvas.isHardwareAccelerated || rect.width() < 2f || rect.height() < 2f) return false
        return try { drawApi33(canvas, rect, radius, intensity, tint, sharp, sharpMatrix, blur, blurMatrix, press, lightX, lightY) }
        catch (t: Throwable) { failed = true; android.util.Log.w("FluidGlass", "Fluid Glass unavailable, using frosted glass", t); false }
    }

    @android.annotation.TargetApi(33)
    private fun drawApi33(
        canvas: Canvas, rect: RectF, radius: Float, intensity: Float, tint: Int,
        sharp: Bitmap, sharpMatrix: Matrix, blur: Bitmap, blurMatrix: Matrix,
        press: Float, lightX: Float, lightY: Float
    ): Boolean {
        val rs = (runtime as? RuntimeShader) ?: RuntimeShader(FluidGlass.AGSL).also { runtime = it }
        if (sharp !== sharpBmp) { sharpBmp = sharp; sharpShader = BitmapShader(sharp, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP).also { it.setFilterMode(BitmapShader.FILTER_MODE_LINEAR) } }
        if (blur !== blurBmp) { blurBmp = blur; blurShader = BitmapShader(blur, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP).also { it.setFilterMode(BitmapShader.FILTER_MODE_LINEAR) } }
        m1.set(sharpMatrix); m1.postTranslate(-rect.left, -rect.top)
        m2.set(blurMatrix); m2.postTranslate(-rect.left, -rect.top)
        sharpShader!!.setLocalMatrix(m1)
        blurShader!!.setLocalMatrix(m2)
        rs.setInputShader("sharp", sharpShader!!)
        rs.setInputShader("blurred", blurShader!!)
        val w = rect.width(); val h = rect.height()
        val density = context.resources.displayMetrics.density
        val i = intensity.coerceIn(0f, 1f)
        val e = FluidGlass.edgeCurve
        val bevel = min(min(w, h) * (0.46f * e).coerceAtMost(0.5f), 36f * density * e).coerceAtLeast(3f)
        rs.setFloatUniform("size", w, h)
        rs.setFloatUniform("radius", radius)
        rs.setFloatUniform("intensity", i)
        rs.setFloatUniform("bevel", bevel)
        rs.setFloatUniform("refraction", bevel * 0.62f * FluidGlass.depth)
        rs.setFloatUniform("blurPx", density * (1.5f * FluidGlass.softness + 2.5f * (1f - i)))
        rs.setFloatUniform("magnify", (0.07f * FluidGlass.zoom).coerceIn(0f, 0.2f))
        rs.setFloatUniform("rimAmt", FluidGlass.rimLight)
        rs.setFloatUniform("shadeAmt", FluidGlass.edgeShadow)
        rs.setFloatUniform("dispersion", FluidGlass.dispersion)
        rs.setFloatUniform("quality", FluidGlass.quality.toFloat())
        rs.setFloatUniform("dp", density)
        val a = Color.alpha(tint) / 255f
        rs.setFloatUniform("tint", Color.red(tint) / 255f * a, Color.green(tint) / 255f * a, Color.blue(tint) / 255f * a, a)
        rs.setFloatUniform("light", lightX, lightY)
        rs.setFloatUniform("press", press.coerceIn(-0.3f, 1.4f))
        paint.shader = rs
        val save = canvas.save()
        canvas.translate(rect.left, rect.top)
        canvas.drawRect(0f, 0f, w, h, paint)
        canvas.restoreToCount(save)
        return true
    }
}

/**
 * The settings playground: a lens and a glass tab bar over your own wallpaper, with text and a grid behind
 * them so the refraction is easy to see.
 * - Drag the lens anywhere: it follows on a spring, stretches with its speed and settles with a wobble.
 * - Tap the bar: its highlight glides across.
 * - The intensity slider changes everything live.
 */
class FluidGlassPreview(private val launcher: MainActivity) : View(launcher) {
    private val lensPainter = GlassPainter(launcher)
    private val barPainter = GlassPainter(launcher)
    private var backdrop: Bitmap? = null
    private var blurred: Bitmap? = null
    private val identity = Matrix()
    private val blurMatrix = Matrix()
    private var darkText = false

    private var lensX = 0f
    private var lensY = 0f
    private val springX = SpringValue(0f) { lensX = it; invalidate() }
    private val springY = SpringValue(0f) { lensY = it; invalidate() }
    private var press = 0f
    private val pressSpring = SpringValue(0f) { press = it; invalidate() }
    private var dragging = false
    private var grabDX = 0f
    private var grabDY = 0f
    private var downX = 0f
    private var downY = 0f
    private var placed = false

    private var selected = 0
    private var tabPos = 0f
    private val tabSpring = SpringValue(0f) { tabPos = it; invalidate() }
    private val icons = listOf(R.drawable.ic_home, R.drawable.ic_search, R.drawable.ic_apps, R.drawable.ic_settings)

    private val plus = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; strokeCap = Paint.Cap.ROUND; style = Paint.Style.STROKE }
    private val shadow = Paint(Paint.ANTI_ALIAS_FLAG)
    private val fallbackPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val selPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val clip = android.graphics.Path()
    private val rect = RectF()

    init {
        isClickable = true
        contentDescription = "Fluid Glass preview. Drag the lens or tap the bar."
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) =
        setMeasuredDimension(MeasureSpec.getSize(widthMeasureSpec), dpi(236))

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        if (w <= 0 || h <= 0) return
        buildBackdrop(w, h)
        if (!placed) {
            placed = true
            springX.snapTo(w * 0.30f); springY.snapTo(h * 0.36f)
        }
        tabSpring.snapTo(selected.toFloat())
        clip.reset()
        clip.addRoundRect(RectF(0f, 0f, w.toFloat(), h.toFloat()), dp(24f), dp(24f), android.graphics.Path.Direction.CW)
    }

    private fun buildBackdrop(w: Int, h: Int) {
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val wall = launcher.wallpaperView.thumbnailSource()
        if (wall != null) {
            // Centre-crop the wallpaper's middle band.
            val s = kotlin.math.max(w / wall.width.toFloat(), h * 2.2f / wall.height.toFloat())
            val sw = w / s; val sh = h / s
            val src = android.graphics.Rect(((wall.width - sw) / 2f).roundToInt(), ((wall.height - sh) / 2f).roundToInt(),
                ((wall.width + sw) / 2f).roundToInt(), ((wall.height + sh) / 2f).roundToInt())
            c.drawBitmap(wall, src, RectF(0f, 0f, w.toFloat(), h.toFloat()), Paint(Paint.FILTER_BITMAP_FLAG))
        } else {
            val p = Paint()
            p.shader = LinearGradient(0f, 0f, w.toFloat(), h.toFloat(), Color.rgb(90, 70, 200), Color.rgb(230, 90, 140), Shader.TileMode.CLAMP)
            c.drawRect(0f, 0f, w.toFloat(), h.toFloat(), p)
        }
        // Average brightness decides dark or light text.
        val probe = Bitmap.createScaledBitmap(bmp, 8, 8, true)
        var lum = 0f
        for (x in 0 until 8) for (y in 0 until 8) lum += luminance(probe.getPixel(x, y))
        darkText = lum / 64f > 0.6f
        val ink = if (darkText) Color.rgb(22, 22, 28) else Color.WHITE
        // A faint grid and big type: details the glass visibly bends.
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.color = withAlpha(ink, 0.16f); p.strokeWidth = dp(1f)
        val step = dp(36f)
        var x = step * 0.5f; while (x < w) { c.drawLine(x, 0f, x, h.toFloat(), p); x += step }
        var y = step * 0.5f; while (y < h) { c.drawLine(0f, y, w.toFloat(), y, p); y += step }
        p.color = ink; p.typeface = Fonts.bold; p.textSize = dp(54f)
        c.drawText("Fluid", w * 0.30f, h * 0.36f + dp(18f), p)
        p.color = withAlpha(ink, 0.72f); p.typeface = Fonts.medium; p.textSize = dp(30f)
        c.drawText("Glass", w * 0.47f, h * 0.36f + dp(56f), p)
        backdrop = bmp
        blurred = BlurEngine.blur(bmp, 0.25f, 7)
        blurMatrix.setScale(w / blurred!!.width.toFloat(), h / blurred!!.height.toFloat())
    }

    private fun intensity() = if (launcher.prefs.fluidGlass) launcher.prefs.fluidIntensity / 100f else 0f

    private fun barRect(): RectF {
        val bh = dp(60f)
        return RectF(dp(16f), height - dp(16f) - bh, width - dp(16f), height - dp(16f))
    }

    private fun slotX(i: Float): Float { val b = barRect(); return b.left + b.width() * (i + 0.5f) / icons.size }

    private fun glass(canvas: Canvas, painter: GlassPainter, r: RectF, radius: Float, tint: Int, light: Boolean, lx: Float = -1f, ly: Float = -1f, pr: Float = 0f) {
        val b = backdrop ?: return
        val bl = blurred ?: return
        if (painter.draw(canvas, r, radius, intensity(), tint, b, identity, bl, blurMatrix, pr, lx, ly)) return
        // Frosted fallback for software canvases.
        val save = canvas.save()
        val path = android.graphics.Path().apply { addRoundRect(r, radius, radius, android.graphics.Path.Direction.CW) }
        canvas.clipPath(path)
        canvas.drawBitmap(bl, null, RectF(0f, 0f, width.toFloat(), height.toFloat()), fallbackPaint)
        canvas.drawColor(tint)
        canvas.restoreToCount(save)
        if (light) {
            shadow.style = Paint.Style.STROKE; shadow.strokeWidth = dp(1f); shadow.color = Color.argb(90, 255, 255, 255)
            canvas.drawRoundRect(r, radius, radius, shadow)
            shadow.style = Paint.Style.FILL
        }
    }

    override fun onDraw(canvas: Canvas) {
        val b = backdrop ?: return
        val save = canvas.save()
        canvas.clipPath(clip)
        canvas.drawBitmap(b, 0f, 0f, null)
        val tint = if (darkText) Color.argb(26, 255, 255, 255) else Color.argb(34, 16, 16, 22)

        // Tab bar: glass capsule with a soft highlight that glides between items.
        val bar = barRect()
        drawShadow(canvas, bar, bar.height() / 2f, 0.16f)
        glass(canvas, barPainter, bar, bar.height() / 2f, tint, true)
        val seg = bar.width() / icons.size
        val stretch = kotlin.math.min(1f, kotlin.math.abs(tabSpring.velocity) / 9f)
        val sw = seg - dp(10f) + stretch * dp(26f)
        val sx = slotX(tabPos)
        rect.set(sx - sw / 2f, bar.top + dp(6f), sx + sw / 2f, bar.bottom - dp(6f))
        selPaint.color = if (darkText) Color.argb(40, 0, 0, 0) else Color.argb(46, 255, 255, 255)
        canvas.drawRoundRect(rect, rect.height() / 2f, rect.height() / 2f, selPaint)
        icons.forEachIndexed { i, res ->
            val d = launcher.getDrawable(res)?.mutate() ?: return@forEachIndexed
            val on = kotlin.math.max(0f, 1f - kotlin.math.abs(tabPos - i))
            d.setTint(if (darkText) blendColors(Color.argb(150, 0, 0, 0), Color.BLACK, on) else blendColors(Color.argb(170, 255, 255, 255), Color.WHITE, on))
            val s = dp(23f) * (1f + 0.08f * on)
            val cx = slotX(i.toFloat()); val cy = bar.centerY()
            d.setBounds((cx - s / 2f).roundToInt(), (cy - s / 2f).roundToInt(), (cx + s / 2f).roundToInt(), (cy + s / 2f).roundToInt())
            d.draw(canvas)
        }

        // The lens: swells while held and stretches along its motion, like a drop of liquid.
        val base = dp(84f)
        val vx = springX.velocity; val vy = springY.velocity
        val speed = dp(1200f)
        val sxk = (kotlin.math.abs(vx) / speed).coerceAtMost(0.22f)
        val syk = (kotlin.math.abs(vy) / speed).coerceAtMost(0.22f)
        val grow = 1f + 0.12f * press
        val lw = base * grow * (1f + sxk - 0.5f * syk)
        val lh = base * grow * (1f + syk - 0.5f * sxk)
        rect.set(lensX - lw / 2f, lensY - lh / 2f, lensX + lw / 2f, lensY + lh / 2f)
        drawShadow(canvas, rect, kotlin.math.min(lw, lh) / 2f, 0.22f)
        val lr = RectF(rect)
        glass(canvas, lensPainter, lr, kotlin.math.min(lw, lh) / 2f, Color.argb(10, 255, 255, 255), true,
            lr.width() * 0.4f, lr.height() * 0.35f, press)
        plus.strokeWidth = dp(4.5f) * grow
        plus.color = if (darkText) Color.argb(230, 30, 30, 36) else Color.WHITE
        val arm = dp(13f) * grow
        canvas.drawLine(lensX - arm, lensY, lensX + arm, lensY, plus)
        canvas.drawLine(lensX, lensY - arm, lensX, lensY + arm, plus)
        canvas.restoreToCount(save)
    }

    private fun drawShadow(canvas: Canvas, r: RectF, radius: Float, strength: Float) {
        shadow.style = Paint.Style.FILL
        shadow.color = Color.argb((strength * 255).toInt(), 0, 0, 0)
        shadow.maskFilter = android.graphics.BlurMaskFilter(dp(10f), android.graphics.BlurMaskFilter.Blur.NORMAL)
        canvas.drawRoundRect(r.left + dp(2f), r.top + dp(6f), r.right - dp(2f), r.bottom + dp(6f), radius, radius, shadow)
        shadow.maskFilter = null
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downX = event.x; downY = event.y
                val hit = dp(58f)
                dragging = kotlin.math.hypot(event.x - lensX, event.y - lensY) < hit
                if (dragging) {
                    grabDX = lensX - event.x; grabDY = lensY - event.y
                    pressSpring.animateTo(1f, 600f, 0.6f)
                    parent?.requestDisallowInterceptTouchEvent(true)
                    launcher.haptic(this, android.view.HapticFeedbackConstants.CLOCK_TICK)
                }
            }
            MotionEvent.ACTION_MOVE -> if (dragging) {
                val m = dp(30f)
                springX.animateTo((event.x + grabDX).coerceIn(m, width - m), 900f, 0.72f)
                springY.animateTo((event.y + grabDY).coerceIn(m, height - m), 900f, 0.72f)
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                if (dragging) {
                    dragging = false
                    pressSpring.animateTo(0f, 240f, 0.3f)
                    parent?.requestDisallowInterceptTouchEvent(false)
                } else if (event.actionMasked == MotionEvent.ACTION_UP && barRect().contains(event.x, event.y)) {
                    val i = ((event.x - barRect().left) / (barRect().width() / icons.size)).toInt().coerceIn(0, icons.size - 1)
                    select(i)
                    performClick()
                }
            }
        }
        return true
    }

    fun select(i: Int) {
        if (i == selected) return
        selected = i
        tabSpring.animateTo(i.toFloat(), 260f, 0.62f)
        launcher.haptic(this, android.view.HapticFeedbackConstants.CLOCK_TICK)
    }

    /** Moves the lens (used by tests and accessibility). */
    fun moveLensTo(x: Float, y: Float) { springX.animateTo(x, 900f, 0.72f); springY.animateTo(y, 900f, 0.72f) }

    override fun onDetachedFromWindow() {
        springX.stop(); springY.stop(); pressSpring.stop(); tabSpring.stop()
        super.onDetachedFromWindow()
    }
}
