package com.fluidone.launcher

import android.Manifest
import android.appwidget.AppWidgetHost
import android.appwidget.AppWidgetHostView
import android.appwidget.AppWidgetProviderInfo
import android.content.BroadcastReceiver
import android.content.ContentUris
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Shader
import android.os.BatteryManager
import android.os.Bundle
import android.provider.AlarmClock
import android.provider.CalendarContract
import android.text.format.DateFormat
import android.util.SizeF
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import java.util.Calendar
import java.util.Locale
import java.util.concurrent.Executors
import kotlin.math.abs
import kotlin.math.min
import kotlin.math.roundToInt

/** Long-press detection that works even when the child (a widget) consumes touches. */
class LongPressDetector(private val view: View, private val onLong: () -> Unit) {
    private val slop = ViewConfiguration.get(view.context).scaledTouchSlop
    private var downX = 0f
    private var downY = 0f
    var fired = false
        private set
    private var pending = false
    private val runnable = Runnable { if (pending) { pending = false; fired = true; onLong() } }

    /** Returns true once a long press fired, so the caller intercepts the rest of the gesture. */
    fun handle(ev: MotionEvent): Boolean {
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downX = ev.rawX; downY = ev.rawY; fired = false; pending = true
                view.postDelayed(runnable, min(ViewConfiguration.getLongPressTimeout(), 420).toLong())
            }
            MotionEvent.ACTION_MOVE -> if (pending && (abs(ev.rawX - downX) > slop || abs(ev.rawY - downY) > slop)) cancel()
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> cancel()
            MotionEvent.ACTION_POINTER_DOWN -> cancel()
        }
        return fired
    }

    fun cancel() { pending = false; view.removeCallbacks(runnable) }
}

/** Frame for built-in widgets: routes long presses to the launcher (menu / drag). */
open class WidgetFrame(context: Context) : FrameLayout(context) {
    var item: HomeItem? = null
    var onLongPress: ((View) -> Unit)? = null
    private val detector = LongPressDetector(this) { onLongPress?.invoke(this) }

    init { clipChildren = false; clipToPadding = false }

    override fun onInterceptTouchEvent(ev: MotionEvent): Boolean = detector.handle(ev)
    override fun onTouchEvent(ev: MotionEvent): Boolean { detector.handle(ev); return true }
    override fun onDetachedFromWindow() { detector.cancel(); super.onDetachedFromWindow() }

    /** The built-in widget's content view, if this frame holds one. */
    val content: View? get() = (getChildAt(0) as? WidgetSurface)?.content

    /** Re-applies the widget's background, colours and style. */
    fun refreshContent() { (getChildAt(0) as? WidgetSurface)?.applyLook() }
}

/** Host view for real Android widgets with long-press and size reporting (Android 12+ responsive widgets). */
class FluidWidgetHostView(context: Context) : AppWidgetHostView(context) {
    var item: HomeItem? = null
    var onLongPress: ((View) -> Unit)? = null
    private val detector = LongPressDetector(this) { onLongPress?.invoke(this) }
    private var lastW = -1
    private var lastH = -1
    private val radius: Float = run {
        val d = context.resources.displayMetrics.density
        val system = try { context.resources.getDimension(android.R.dimen.system_app_widget_background_radius) } catch (_: Exception) { 0f }
        (if (system > 0f) system else 22f * d).coerceIn(12f * d, 28f * d)
    }
    private val rounded = object : android.view.ViewOutlineProvider() {
        override fun getOutline(view: View, outline: android.graphics.Outline) {
            outline.setRoundRect(0, 0, view.width, view.height, radius)
        }
    }

    /**
     * Rounds widgets that come with square corners (like One UI's weather widget). The widget's own
     * background view is clipped when it declares one; otherwise the whole widget is, when it fills its cell.
     */
    private fun enforceRoundedCorners() {
        val content = getChildAt(0) ?: return
        val bg = content.findViewById<View>(android.R.id.background)
        if (bg != null && bg.width > 0) {
            if (bg.outlineProvider !== rounded) { bg.outlineProvider = rounded; bg.clipToOutline = true; bg.invalidateOutline() }
            if (clipToOutline) clipToOutline = false
            return
        }
        val slack = 4f * resources.displayMetrics.density
        val fills = content.left <= slack && content.top <= slack && width - content.right <= slack && height - content.bottom <= slack
        if (fills) {
            if (outlineProvider !== rounded) outlineProvider = rounded
            if (!clipToOutline) clipToOutline = true
            invalidateOutline()
        } else if (clipToOutline) clipToOutline = false
    }

    override fun onLayout(changed: Boolean, left: Int, top: Int, right: Int, bottom: Int) {
        super.onLayout(changed, left, top, right, bottom)
        try { enforceRoundedCorners() } catch (_: Exception) { }
    }

    override fun onInterceptTouchEvent(ev: MotionEvent): Boolean = detector.handle(ev) || super.onInterceptTouchEvent(ev)
    override fun onTouchEvent(ev: MotionEvent): Boolean { detector.handle(ev); return super.onTouchEvent(ev) || true }
    override fun onDetachedFromWindow() { detector.cancel(); super.onDetachedFromWindow() }

    fun reportSize() {
        if (width == lastW && height == lastH || width == 0 || height == 0) return
        lastW = width; lastH = height
        val d = resources.displayMetrics.density
        try { updateAppWidgetSize(Bundle(), listOf(SizeF(width / d, height / d))) } catch (_: Exception) { }
    }
}

class LauncherWidgetHost(context: Context, id: Int) : AppWidgetHost(context, id) {
    override fun onCreateView(context: Context, appWidgetId: Int, appWidget: AppWidgetProviderInfo?): AppWidgetHostView =
        FluidWidgetHostView(context)
}

