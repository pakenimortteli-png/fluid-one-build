package com.fluidone.launcher

import android.Manifest
import android.content.BroadcastReceiver
import android.content.ContentUris
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Shader
import android.os.BatteryManager
import android.provider.AlarmClock
import android.provider.CalendarContract
import android.provider.MediaStore
import android.text.format.DateFormat
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import org.json.JSONObject
import java.io.File
import java.util.Calendar
import java.util.Locale
import java.util.concurrent.Executors
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sin

/**
 * How one built-in widget looks, saved per widget under "widget|<item id>".
 * - [bg]: "glass" (Fluid Glass, or Blur when Fluid Glass is off), "color" (a solid colour) or "off".
 * - [tone]: glass tone, "auto", "light" or "dark".
 * - [clock]: clock face, "auto", "classic" or "dot".
 */
class WidgetLook(var bg: String, var color: Int, var tone: String, var clock: String) {
    fun toJson(): String = JSONObject().put("bg", bg).put("color", color).put("tone", tone).put("clock", clock).toString()

    companion object {
        fun defaults(builtin: String): WidgetLook = when (builtin) {
            Builtins.CLOCK, Builtins.DATE, Builtins.PHOTO -> WidgetLook("off", Color.WHITE, "auto", "auto")
            Builtins.CALENDAR -> WidgetLook("glass", Color.WHITE, "light", "auto")
            Builtins.NOTE -> WidgetLook("color", Color.rgb(255, 233, 150), "auto", "auto")
            Builtins.SEARCH, Builtins.BATTERY -> WidgetLook("glass", Color.WHITE, "auto", "auto")
            else -> WidgetLook("glass", Color.WHITE, "dark", "auto")
        }

        fun parse(raw: String?, builtin: String): WidgetLook {
            val d = defaults(builtin)
            if (raw.isNullOrEmpty()) return d
            return try {
                val o = JSONObject(raw)
                WidgetLook(o.optString("bg", d.bg), o.optInt("color", d.color), o.optString("tone", d.tone), o.optString("clock", d.clock))
            } catch (_: Exception) { d }
        }
    }
}

/** Content of a built-in widget: recolours itself for the background it sits on. */
interface BuiltinContent {
    /** [dark] = dark text and symbols (light background). */
    fun applyColors(dark: Boolean, look: WidgetLook)
}

object Builtins {
    const val CLOCK = "clock"
    const val ANALOG = "analog"
    const val DATE = "date"
    const val CALENDAR = "calendar"
    const val BATTERY = "battery"
    const val SEARCH = "search"
    const val NOTE = "note"
    const val PHOTO = "photo"
    const val TOGGLES = "toggles"
    val all = listOf(CLOCK, ANALOG, DATE, CALENDAR, BATTERY, SEARCH, NOTE, PHOTO, TOGGLES)

    fun name(id: String) = when (id) {
        CLOCK -> "Clock & date"; ANALOG -> "Analog clock"; DATE -> "Date"; CALENDAR -> "Calendar"; BATTERY -> "Battery"
        SEARCH -> "Search bar"; NOTE -> "Note"; PHOTO -> "Photo"; TOGGLES -> "Quick toggles"; else -> id
    }

    fun icon(id: String) = when (id) {
        CLOCK, ANALOG -> R.drawable.ic_clock; DATE, CALENDAR -> R.drawable.ic_calendar; BATTERY -> R.drawable.ic_battery
        SEARCH -> R.drawable.ic_search; NOTE -> R.drawable.ic_note; PHOTO -> R.drawable.ic_image; else -> R.drawable.ic_toggles
    }

    fun defaultSpan(id: String, cols: Int): Pair<Int, Int> = when (id) {
        CLOCK -> cols to 2
        SEARCH, TOGGLES -> cols to 1
        else -> 2 to 2
    }

    fun sizes(id: String, cols: Int, rows: Int): List<Pair<Int, Int>> = when (id) {
        CLOCK -> listOf(cols to 2, cols to 3, 2 to 2)
        CALENDAR -> listOf(2 to 2, cols to 2, 2 to 3)
        SEARCH -> listOf(cols to 1, 3 to 1)
        TOGGLES -> listOf(cols to 1, 2 to 2)
        NOTE -> listOf(2 to 2, cols to 2, 2 to 1, cols to 3)
        PHOTO -> listOf(2 to 2, cols to 2, cols to 3, 1 to 1)
        DATE, ANALOG -> listOf(2 to 2, 1 to 1, cols to 2)
        else -> listOf(2 to 2, 1 to 1, cols to 2)
    }.map { (x, y) -> x.coerceAtMost(cols) to y.coerceAtMost(rows) }.distinct()

    fun create(launcher: MainActivity, item: HomeItem): View {
        val content: View = when (item.builtin) {
            CLOCK -> ClockWidget(launcher)
            ANALOG -> AnalogClockWidget(launcher)
            DATE -> DateWidget(launcher)
            CALENDAR -> CalendarWidget(launcher)
            SEARCH -> SearchWidget(launcher)
            NOTE -> NoteWidget(launcher, item)
            PHOTO -> PhotoWidget(launcher, item)
            TOGGLES -> TogglesWidget(launcher)
            else -> BatteryWidget(launcher)
        }
        return WidgetSurface(launcher, item, content)
    }
}

/**
 * The background of a built-in widget: Fluid Glass (or Blur), a solid colour, or nothing at all. It also
 * picks text colours that stay readable on whatever is behind.
 */
class WidgetSurface(private val launcher: MainActivity, val item: HomeItem, val content: View) : GlassView(launcher, launcher.dp(26f), Style.HOME) {
    init {
        addView(content, flp(MATCH, MATCH))
        applyLook()
    }

    fun applyLook() {
        val look = launcher.prefs.widgetLook(item.id, item.builtin)
        val wallLight = launcher.wallpaperIsLight
        val dark: Boolean = when (look.bg) {
            "off" -> { surfaceMode = SURFACE_OFF; wallLight }
            "color" -> { surfaceMode = SURFACE_SOLID; surfaceColor = look.color; luminance(look.color) > 0.6f }
            else -> {
                surfaceMode = SURFACE_GLASS
                when (look.tone) {
                    "light" -> { style = Style.CARD_LIGHT; tintOverride = null; true }
                    "dark" -> { style = Style.HOME; tintOverride = Color.argb(96, 14, 14, 20); false }
                    else -> { style = Style.HOME; tintOverride = null; wallLight }
                }
            }
        }
        val pad = when {
            item.builtin == Builtins.PHOTO -> 0
            item.builtin == Builtins.SEARCH -> dpi(4)
            look.bg == "off" -> dpi(2)
            item.builtin == Builtins.TOGGLES -> dpi(8)
            else -> dpi(14)
        }
        setPadding(pad, pad, pad, pad)
        // Without a background nothing should be clipped by the rounded corners (text near the edge).
        clipToOutline = look.bg != "off"
        if (item.builtin == Builtins.SEARCH && height > 0) cornerRadius = height / 2f
        (content as? BuiltinContent)?.applyColors(dark, look)
        invalidate()
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        if (item.builtin == Builtins.SEARCH) cornerRadius = h / 2f
    }
}

private fun inkFor(dark: Boolean, alpha: Float = 1f) = if (dark) withAlpha(Color.rgb(22, 22, 28), alpha) else withAlpha(Color.WHITE, alpha)

/** Tap detection that leaves long presses to the widget frame. */
private class TapHelper(private val view: View, private val onTap: (Float, Float) -> Unit) {
    private var downX = 0f
    private var downY = 0f
    private var downTime = 0L
    private val slop = ViewConfiguration.get(view.context).scaledTouchSlop

    fun handle(event: MotionEvent): Boolean {
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> { downX = event.x; downY = event.y; downTime = event.eventTime }
            MotionEvent.ACTION_UP -> if (abs(event.x - downX) < slop && abs(event.y - downY) < slop &&
                event.eventTime - downTime < ViewConfiguration.getLongPressTimeout()) {
                view.performClick(); onTap(event.x, event.y)
            }
        }
        return true
    }
}

// ---- Clock & date ---------------------------------------------------------------------------------------

/**
 * Big home clock: date line plus large time. Classic uses a soft lavender-to-white gradient, like the ColorOS 17
 * home screen; Dot matrix draws the digits from dots, like Nothing OS. Refreshed by the system minute tick.
 */
class ClockWidget(private val launcher: MainActivity) : View(launcher), BuiltinContent {
    private val datePaint = android.text.TextPaint(Paint.ANTI_ALIAS_FLAG).apply { typeface = Fonts.medium; textAlign = Paint.Align.CENTER }
    private val timePaint = android.text.TextPaint(Paint.ANTI_ALIAS_FLAG).apply { typeface = Fonts.semibold; textAlign = Paint.Align.CENTER; letterSpacing = -0.02f }
    private val dotPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private var dateText = ""
    private var timeText = ""
    private var dark = false
    private var dot = false
    private var dateBottom = 0f
    private val tap = TapHelper(this) { _, y ->
        if (y < dateBottom + dp(4f)) {
            val uri = CalendarContract.CONTENT_URI.buildUpon().appendPath("time")
            ContentUris.appendId(uri, System.currentTimeMillis())
            launcher.startSafely(Intent(Intent.ACTION_VIEW).setData(uri.build()).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK), this)
        } else launcher.startSafely(Intent(AlarmClock.ACTION_SHOW_ALARMS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK), this)
    }
    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, intent: Intent) = tick()
    }

    init {
        isClickable = true
        tick()
    }

    fun tick() {
        val now = java.util.Date()
        val locale = Locale.getDefault()
        dateText = java.text.SimpleDateFormat(DateFormat.getBestDateTimePattern(locale, "EEEMMMMd"), locale).format(now)
        timeText = java.text.SimpleDateFormat(if (DateFormat.is24HourFormat(context)) "H:mm" else "h:mm", locale).format(now)
        contentDescription = "$timeText, $dateText"
        invalidate()
    }

    override fun applyColors(dark: Boolean, look: WidgetLook) {
        this.dark = dark
        dot = look.clock == "dot" || (look.clock == "auto" && launcher.prefs.dotClock && launcher.brandModeOn() && launcher.brand == Brand.NOTHING)
        datePaint.color = if (dark) Color.argb(205, 30, 26, 46) else Color.argb(230, 255, 255, 255)
        if (dark) { datePaint.clearShadowLayer(); timePaint.clearShadowLayer() }
        else {
            datePaint.setShadowLayer(dp(4f), 0f, dp(1f), Color.argb(70, 0, 0, 0))
            timePaint.setShadowLayer(dp(14f), 0f, dp(2f), Color.argb(46, 20, 0, 60))
        }
        dotPaint.color = if (dark) Color.rgb(24, 24, 30) else Color.WHITE
        if (dark) dotPaint.clearShadowLayer() else dotPaint.setShadowLayer(dp(3f), 0f, dp(1f), Color.argb(60, 0, 0, 0))
        datePaint.letterSpacing = if (dot) 0.14f else 0f
        timePaint.shader = null
        invalidate()
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        val filter = IntentFilter().apply {
            addAction(Intent.ACTION_TIME_TICK); addAction(Intent.ACTION_TIME_CHANGED); addAction(Intent.ACTION_TIMEZONE_CHANGED)
        }
        try { context.registerReceiver(receiver, filter, Context.RECEIVER_EXPORTED) } catch (_: Exception) { }
        tick()
    }

    override fun onDetachedFromWindow() {
        try { context.unregisterReceiver(receiver) } catch (_: Exception) { }
        super.onDetachedFromWindow()
    }

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        if (w <= 0f || h <= 0f) return
        if (dot) { drawDots(canvas, w, h); return }
        timePaint.textSize = minOf(h * 0.56f, w * 0.3f)
        datePaint.textSize = (timePaint.textSize * 0.2f).coerceIn(dp(13f), dp(19f))
        val dateH = datePaint.descent() - datePaint.ascent()
        val capTop = -timePaint.fontMetrics.ascent * 0.72f   // digits are roughly cap height
        val gap = dp(6f)
        val total = dateH + gap + capTop
        val top = (h - total) / 2f
        dateBottom = top + dateH
        canvas.drawText(dateText, w / 2f, top - datePaint.ascent(), datePaint)
        val timeBaseline = top + dateH + gap + capTop
        if (timePaint.shader == null) {
            val colors = if (dark) intArrayOf(Color.rgb(46, 38, 82), Color.rgb(96, 78, 160))
                         else intArrayOf(Color.rgb(222, 210, 255), Color.WHITE, Color.rgb(198, 184, 255))
            timePaint.shader = LinearGradient(0f, timeBaseline - capTop, 0f, timeBaseline, colors, null, Shader.TileMode.CLAMP)
        }
        canvas.drawText(timeText, w / 2f, timeBaseline, timePaint)
    }

    private fun drawDots(canvas: Canvas, w: Float, h: Float) {
        val glyphs = timeText.map { DotFont.glyph(it) }
        val cols = glyphs.sumOf { it.cols } + (glyphs.size - 1)
        datePaint.textSize = dp(14f).coerceAtMost(h * 0.12f)
        val dateText = this.dateText.uppercase(Locale.getDefault())
        val dateH = datePaint.descent() - datePaint.ascent()
        val gap = dp(10f)
        val cell = min(w * 0.9f / cols, (h - dateH - gap) * 0.86f / 7f)
        val gridH = cell * 7f
        val top = (h - dateH - gap - gridH) / 2f
        dateBottom = top + dateH
        canvas.drawText(dateText, w / 2f, top - datePaint.ascent(), datePaint)
        var x = (w - cols * cell) / 2f
        val y0 = top + dateH + gap
        val r = cell * 0.36f
        for (g in glyphs) {
            for (row in 0 until 7) for (col in 0 until g.cols) if (g.on(col, row)) {
                canvas.drawCircle(x + (col + 0.5f) * cell, y0 + (row + 0.5f) * cell, r, dotPaint)
            }
            x += (g.cols + 1) * cell
        }
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        timePaint.shader = null
    }

    override fun onTouchEvent(event: MotionEvent): Boolean = tap.handle(event)
}

/** A 5 x 7 dot font for the dot-matrix clock. */
object DotFont {
    class Glyph(val cols: Int, private val rows: List<String>) {
        fun on(col: Int, row: Int) = rows.getOrNull(row)?.getOrNull(col) == '1'
    }
    private val digits = mapOf(
        '0' to listOf("01110", "10001", "10011", "10101", "11001", "10001", "01110"),
        '1' to listOf("00100", "01100", "00100", "00100", "00100", "00100", "01110"),
        '2' to listOf("01110", "10001", "00001", "00010", "00100", "01000", "11111"),
        '3' to listOf("11111", "00010", "00100", "00010", "00001", "10001", "01110"),
        '4' to listOf("00010", "00110", "01010", "10010", "11111", "00010", "00010"),
        '5' to listOf("11111", "10000", "11110", "00001", "00001", "10001", "01110"),
        '6' to listOf("00110", "01000", "10000", "11110", "10001", "10001", "01110"),
        '7' to listOf("11111", "00001", "00010", "00100", "01000", "01000", "01000"),
        '8' to listOf("01110", "10001", "10001", "01110", "10001", "10001", "01110"),
        '9' to listOf("01110", "10001", "10001", "01111", "00001", "00010", "01100")
    )

    fun glyph(c: Char): Glyph = digits[c]?.let { Glyph(5, it) }
        ?: if (c == ':') Glyph(1, listOf("0", "0", "1", "0", "1", "0", "0")) else Glyph(2, List(7) { "00" })
}

// ---- Analog clock --------------------------------------------------------------------------------------

class AnalogClockWidget(private val launcher: MainActivity) : View(launcher), BuiltinContent {
    private val tick = Paint(Paint.ANTI_ALIAS_FLAG).apply { strokeCap = Paint.Cap.ROUND; style = Paint.Style.STROKE }
    private val hand = Paint(Paint.ANTI_ALIAS_FLAG).apply { strokeCap = Paint.Cap.ROUND; style = Paint.Style.STROKE }
    private val center = Paint(Paint.ANTI_ALIAS_FLAG)
    private var dark = false
    private val tap = TapHelper(this) { _, _ -> launcher.startSafely(Intent(AlarmClock.ACTION_SHOW_ALARMS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK), this) }
    private val receiver = object : BroadcastReceiver() { override fun onReceive(c: Context, intent: Intent) = invalidate() }

    init { isClickable = true; contentDescription = "Analog clock" }

    override fun applyColors(dark: Boolean, look: WidgetLook) { this.dark = dark; invalidate() }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        val filter = IntentFilter().apply { addAction(Intent.ACTION_TIME_TICK); addAction(Intent.ACTION_TIME_CHANGED); addAction(Intent.ACTION_TIMEZONE_CHANGED) }
        try { context.registerReceiver(receiver, filter, Context.RECEIVER_EXPORTED) } catch (_: Exception) { }
    }

    override fun onDetachedFromWindow() {
        try { context.unregisterReceiver(receiver) } catch (_: Exception) { }
        super.onDetachedFromWindow()
    }

    override fun onDraw(canvas: Canvas) {
        val s = min(width, height).toFloat()
        if (s <= 0f) return
        val cx = width / 2f; val cy = height / 2f; val r = s * 0.46f
        val ink = inkFor(dark)
        for (i in 0 until 12) {
            val a = Math.toRadians(i * 30.0)
            val major = i % 3 == 0
            tick.color = withAlpha(ink, if (major) 0.9f else 0.4f)
            tick.strokeWidth = s * if (major) 0.028f else 0.016f
            val r0 = r * if (major) 0.8f else 0.86f
            canvas.drawLine(cx + (r0 * sin(a)).toFloat(), cy - (r0 * cos(a)).toFloat(), cx + (r * 0.95f * sin(a)).toFloat(), cy - (r * 0.95f * cos(a)).toFloat(), tick)
        }
        val now = Calendar.getInstance()
        val minutes = now.get(Calendar.MINUTE) + now.get(Calendar.SECOND) / 60f
        val hours = (now.get(Calendar.HOUR) + minutes / 60f)
        fun drawHand(angleDeg: Float, length: Float, width: Float, color: Int) {
            val a = Math.toRadians(angleDeg.toDouble())
            hand.strokeWidth = width; hand.color = color
            canvas.drawLine(cx - (length * 0.12f * sin(a)).toFloat(), cy + (length * 0.12f * cos(a)).toFloat(),
                cx + (length * sin(a)).toFloat(), cy - (length * cos(a)).toFloat(), hand)
        }
        drawHand(hours * 30f, r * 0.5f, s * 0.055f, ink)
        drawHand(minutes * 6f, r * 0.74f, s * 0.035f, withAlpha(ink, 0.92f))
        center.color = launcher.prefs.accent
        canvas.drawCircle(cx, cy, s * 0.04f, center)
    }

    override fun onTouchEvent(event: MotionEvent): Boolean = tap.handle(event)
}

// ---- Date ------------------------------------------------------------------------------------------------

class DateWidget(private val launcher: MainActivity) : LinearLayout(launcher), BuiltinContent {
    private val weekday = context.textView("", 15f, Color.WHITE, Fonts.semibold, Gravity.CENTER)
    private val day = context.textView("", 54f, Color.WHITE, Fonts.bold, Gravity.CENTER)
    private val month = context.textView("", 13f, Color.WHITE, Fonts.medium, Gravity.CENTER)
    private val tap = TapHelper(this) { _, _ ->
        val uri = CalendarContract.CONTENT_URI.buildUpon().appendPath("time")
        ContentUris.appendId(uri, System.currentTimeMillis())
        launcher.startSafely(Intent(Intent.ACTION_VIEW).setData(uri.build()).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK), this)
    }
    private val receiver = object : BroadcastReceiver() { override fun onReceive(c: Context, intent: Intent) = update() }

    init {
        orientation = VERTICAL; gravity = Gravity.CENTER
        isClickable = true
        addView(weekday, llp(MATCH, WRAP))
        addView(day, llp(MATCH, WRAP))
        addView(month, llp(MATCH, WRAP))
        update()
    }

    private fun update() {
        val now = Calendar.getInstance()
        val locale = Locale.getDefault()
        weekday.text = now.getDisplayName(Calendar.DAY_OF_WEEK, Calendar.LONG, locale)?.uppercase(locale) ?: ""
        day.text = now.get(Calendar.DAY_OF_MONTH).toString()
        month.text = java.text.SimpleDateFormat(DateFormat.getBestDateTimePattern(locale, "MMMMy"), locale).format(now.time)
        contentDescription = "${weekday.text} ${day.text} ${month.text}"
    }

    override fun applyColors(dark: Boolean, look: WidgetLook) {
        weekday.setTextColor(readableOn(launcher.prefs.accent, !dark).let { if (dark) blendColors(it, Color.BLACK, 0.15f) else blendColors(it, Color.WHITE, 0.35f) })
        day.setTextColor(inkFor(dark)); month.setTextColor(inkFor(dark, 0.7f))
        val shadow = !dark && look.bg == "off"
        listOf(weekday, day, month).forEach { if (shadow) it.setShadowLayer(dp(4f), 0f, dp(1f), Color.argb(80, 0, 0, 0)) else it.setShadowLayer(0f, 0f, 0f, 0) }
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        day.textSize = (h / resources.displayMetrics.scaledDensity * 0.4f).coerceIn(24f, 72f)
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        val filter = IntentFilter().apply { addAction(Intent.ACTION_DATE_CHANGED); addAction(Intent.ACTION_TIME_CHANGED); addAction(Intent.ACTION_TIMEZONE_CHANGED) }
        try { context.registerReceiver(receiver, filter, Context.RECEIVER_EXPORTED) } catch (_: Exception) { }
        update()
    }

    override fun onDetachedFromWindow() {
        try { context.unregisterReceiver(receiver) } catch (_: Exception) { }
        super.onDetachedFromWindow()
    }

    override fun onInterceptTouchEvent(ev: MotionEvent): Boolean = true
    override fun onTouchEvent(event: MotionEvent): Boolean = tap.handle(event)
}

// ---- Calendar --------------------------------------------------------------------------------------------

/** Today's date and the next events (Calendar permission optional, asked with a privacy notice). */
class CalendarWidget(private val launcher: MainActivity) : LinearLayout(launcher), BuiltinContent {
    private val day = context.textView("", 30f, Color.rgb(20, 20, 26), Fonts.bold)
    private val weekday = context.textView("", 13f, launcher.prefs.accent, Fonts.semibold)
    private val list = LinearLayout(context).apply { orientation = VERTICAL }
    private var dark = true
    private var lastEvents: List<Triple<String, Long, Boolean>>? = null

    init {
        orientation = VERTICAL
        val head = LinearLayout(context).apply { orientation = HORIZONTAL; gravity = Gravity.BOTTOM }
        head.addView(day)
        head.addView(weekday, llp(WRAP, WRAP).apply { marginStart = dpi(8); bottomMargin = dpi(4) })
        addView(head)
        addView(list, llp(MATCH, WRAP).apply { topMargin = dpi(8) })
        isClickable = true
        setOnClickListener {
            if (!hasPermission()) launcher.requestCalendarPermission()
            else {
                val uri = CalendarContract.CONTENT_URI.buildUpon().appendPath("time")
                ContentUris.appendId(uri, System.currentTimeMillis())
                launcher.startSafely(Intent(Intent.ACTION_VIEW).setData(uri.build()).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK), this)
            }
        }
        refresh()
    }

    private fun hasPermission() = context.checkSelfPermission(Manifest.permission.READ_CALENDAR) == PackageManager.PERMISSION_GRANTED

    override fun onAttachedToWindow() { super.onAttachedToWindow(); refresh() }

    override fun applyColors(dark: Boolean, look: WidgetLook) {
        this.dark = dark
        day.setTextColor(inkFor(dark))
        weekday.setTextColor(readableOn(launcher.prefs.accent, !dark).let { if (dark) it else blendColors(it, Color.WHITE, 0.35f) })
        lastEvents?.let { showEvents(it) } ?: refresh()
    }

    fun refresh() {
        val now = Calendar.getInstance()
        day.text = now.get(Calendar.DAY_OF_MONTH).toString()
        weekday.text = now.getDisplayName(Calendar.DAY_OF_WEEK, Calendar.LONG, Locale.getDefault()) ?: ""
        if (!hasPermission()) { showMessage("Tap to show your events"); return }
        val start = System.currentTimeMillis()
        val end = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, 23); set(Calendar.MINUTE, 59); set(Calendar.SECOND, 59)
        }.timeInMillis + 24L * 3600_000L
        executor.execute {
            val events = mutableListOf<Triple<String, Long, Boolean>>()
            try {
                val uri = CalendarContract.Instances.CONTENT_URI.buildUpon()
                ContentUris.appendId(uri, start); ContentUris.appendId(uri, end)
                context.contentResolver.query(uri.build(),
                    arrayOf(CalendarContract.Instances.TITLE, CalendarContract.Instances.BEGIN, CalendarContract.Instances.ALL_DAY),
                    null, null, CalendarContract.Instances.BEGIN + " ASC")?.use { c ->
                    while (c.moveToNext() && events.size < 3) events.add(Triple(c.getString(0) ?: "(No title)", c.getLong(1), c.getInt(2) == 1))
                }
            } catch (_: Exception) { }
            post { lastEvents = events; showEvents(events) }
        }
    }

    private fun showMessage(text: String) {
        list.removeAllViews()
        list.addView(context.textView(text, 12f, inkFor(dark, 0.6f), Fonts.regular, maxLines = 3))
    }

    private fun showEvents(events: List<Triple<String, Long, Boolean>>) {
        if (!hasPermission()) { showMessage("Tap to show your events"); return }
        if (events.isEmpty()) { showMessage("No upcoming events"); return }
        list.removeAllViews()
        val fmt = DateFormat.getTimeFormat(context)
        events.take(2).forEach { (title, begin, allDay) ->
            val row = LinearLayout(context).apply { orientation = HORIZONTAL; setPadding(0, dpi(3), 0, dpi(3)) }
            row.addView(View(context).apply { background = roundRect(readableOn(launcher.prefs.accent, !dark), dp(2f)) }, llp(dpi(3), MATCH).apply { marginEnd = dpi(7) })
            val col = LinearLayout(context).apply { orientation = VERTICAL }
            col.addView(context.textView(title, 12f, inkFor(dark, 0.92f), Fonts.medium, maxLines = 1))
            col.addView(context.textView(if (allDay) "All day" else fmt.format(java.util.Date(begin)), 10.5f, inkFor(dark, 0.55f), maxLines = 1).apply { setPadding(0, dpi(2), 0, 0) })
            row.addView(col)
            list.addView(row, llp(MATCH, WRAP))
        }
        if (events.size > 2) list.addView(context.textView("${events.size - 2} more", 10.5f, inkFor(dark, 0.5f)).apply { setPadding(dpi(10), dpi(2), 0, 0) })
    }

    companion object { private val executor = Executors.newSingleThreadExecutor() }
}

// ---- Battery ---------------------------------------------------------------------------------------------

class BatteryWidget(private val launcher: MainActivity) : FrameLayout(launcher), BuiltinContent {
    private var level = -1
    private var charging = false
    private var dark = false
    private val ring = object : View(context) {
        private val track = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND }
        private val arc = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND }
        private val r = RectF()
        override fun onDraw(canvas: Canvas) {
            val s = min(width, height).toFloat()
            val sw = s * 0.09f
            r.set((width - s) / 2f + sw, (height - s) / 2f + sw, (width + s) / 2f - sw, (height + s) / 2f - sw)
            track.strokeWidth = sw; arc.strokeWidth = sw
            track.color = inkFor(dark, 0.22f)
            arc.color = if (charging) Color.rgb(52, 199, 110) else if (level in 0..15) Color.rgb(255, 90, 80) else inkFor(dark)
            canvas.drawArc(r, 0f, 360f, false, track)
            if (level >= 0) canvas.drawArc(r, -90f, 360f * level / 100f, false, arc)
        }
    }
    private val percent = context.textView("--", 20f, Color.WHITE, Fonts.semibold, Gravity.CENTER)
    private val caption = context.textView("Battery", 11f, Color.argb(200, 255, 255, 255), Fonts.medium, Gravity.CENTER)
    private val receiver = object : BroadcastReceiver() { override fun onReceive(c: Context, intent: Intent) = update(intent) }

    init {
        val col = LinearLayout(context).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER }
        val ringFrame = FrameLayout(context)
        ringFrame.addView(ring, flp(MATCH, MATCH))
        ringFrame.addView(percent, flp(MATCH, MATCH))
        col.addView(ringFrame, llp(MATCH, 0, 1f))
        col.addView(caption, llp(MATCH, WRAP).apply { topMargin = dpi(6) })
        addView(col, flp(MATCH, MATCH))
        isClickable = true
        setOnClickListener { launcher.startSafely(Intent(Intent.ACTION_POWER_USAGE_SUMMARY).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK), this) }
    }

    override fun applyColors(dark: Boolean, look: WidgetLook) {
        this.dark = dark
        percent.setTextColor(inkFor(dark)); caption.setTextColor(inkFor(dark, 0.75f))
        ring.invalidate()
    }

    private fun update(intent: Intent?) {
        intent ?: return
        val l = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
        val s = intent.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
        level = if (l >= 0 && s > 0) (l * 100f / s).roundToInt() else -1
        val status = intent.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
        charging = status == BatteryManager.BATTERY_STATUS_CHARGING || status == BatteryManager.BATTERY_STATUS_FULL
        percent.text = if (level >= 0) "$level%" else "--"
        caption.text = if (charging) "Charging" else "Battery"
        contentDescription = "Battery ${percent.text}${if (charging) ", charging" else ""}"
        ring.invalidate()
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        val sticky = try { context.registerReceiver(receiver, IntentFilter(Intent.ACTION_BATTERY_CHANGED), Context.RECEIVER_NOT_EXPORTED) } catch (_: Exception) { null }
        update(sticky)
    }

    override fun onDetachedFromWindow() {
        try { context.unregisterReceiver(receiver) } catch (_: Exception) { }
        super.onDetachedFromWindow()
    }
}

// ---- Search bar ------------------------------------------------------------------------------------------

class SearchWidget(private val launcher: MainActivity) : LinearLayout(launcher), BuiltinContent {
    private val icon = context.iconImage(R.drawable.ic_search, Color.WHITE, 0)
    private val hint = context.textView("Search apps, contacts…", 15f, Color.WHITE, Fonts.medium, maxLines = 1)
    private val voice = Intent(android.speech.RecognizerIntent.ACTION_WEB_SEARCH).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    private val mic = context.iconImage(R.drawable.ic_mic, Color.WHITE, 8).apply {
        isClickable = true
        contentDescription = "Voice search"
        background = pressable(null, Color.argb(50, 255, 255, 255), dp(20f))
        setOnClickListener { launcher.haptic(it, HapticFeedbackConstants.CONTEXT_CLICK); launcher.startSafely(voice, it) }
    }

    init {
        orientation = HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
        setPadding(dpi(18), 0, dpi(8), 0)
        isClickable = true
        contentDescription = "Search"
        addView(icon, llp(dpi(20), dpi(20)).apply { marginEnd = dpi(12) })
        addView(hint, llp(0, WRAP, 1f))
        if (voice.resolveActivity(launcher.packageManager) != null) addView(mic, llp(dpi(40), dpi(40)))
        setOnClickListener { launcher.haptic(it, HapticFeedbackConstants.CONTEXT_CLICK); launcher.openDrawer(focusSearch = true) }
    }

    override fun applyColors(dark: Boolean, look: WidgetLook) {
        val ink = inkFor(dark, 0.9f)
        hint.setTextColor(ink)
        icon.imageTintList = android.content.res.ColorStateList.valueOf(ink)
        mic.imageTintList = android.content.res.ColorStateList.valueOf(ink)
    }
}

// ---- Note ------------------------------------------------------------------------------------------------

class NoteWidget(private val launcher: MainActivity, private val item: HomeItem) : LinearLayout(launcher), BuiltinContent {
    private val title = context.textView("NOTE", 11f, Color.WHITE, Fonts.semibold).apply { letterSpacing = 0.08f }
    private val text = context.textView("", 15f, Color.WHITE, Fonts.medium).apply { setLineSpacing(dp(2f), 1f) }
    private var dark = true

    init {
        orientation = VERTICAL
        isClickable = true
        addView(title, llp(MATCH, WRAP))
        addView(text, llp(MATCH, 0, 1f).apply { topMargin = dpi(6) })
        setOnClickListener { edit() }
        load()
    }

    private fun load() {
        val note = launcher.prefs.widgetNote(item.id)
        text.text = note.ifEmpty { "Tap to write a note" }
        text.alpha = if (note.isEmpty()) 0.6f else 1f
        contentDescription = if (note.isEmpty()) "Empty note. Tap to write." else "Note: $note"
    }

    fun edit() {
        FluidDialog(launcher, "Note", null, "Save", inputInitial = launcher.prefs.widgetNote(item.id), multiline = true) { value ->
            launcher.prefs.setWidgetNote(item.id, value.trim())
            load()
        }.show()
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        val lineH = text.lineHeight.coerceAtLeast(1)
        text.maxLines = ((h - dp(28f)) / lineH).toInt().coerceAtLeast(1)
        text.ellipsize = android.text.TextUtils.TruncateAt.END
    }

    override fun applyColors(dark: Boolean, look: WidgetLook) {
        this.dark = dark
        title.setTextColor(inkFor(dark, 0.55f)); text.setTextColor(inkFor(dark, 0.92f))
    }
}

// ---- Photo -----------------------------------------------------------------------------------------------

class PhotoWidget(private val launcher: MainActivity, private val item: HomeItem) : FrameLayout(launcher), BuiltinContent {
    private val image = ImageView(launcher).apply { scaleType = ImageView.ScaleType.CENTER_CROP }
    private val empty = LinearLayout(launcher).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER }
    private val emptyIcon = context.iconImage(R.drawable.ic_image, Color.WHITE, 0)
    private val emptyText = context.textView("Tap to add a photo", 12f, Color.WHITE, Fonts.medium, Gravity.CENTER)

    init {
        addView(image, flp(MATCH, MATCH))
        empty.addView(emptyIcon, llp(dpi(28), dpi(28)))
        empty.addView(emptyText, llp(WRAP, WRAP).apply { topMargin = dpi(8) })
        addView(empty, flp(MATCH, MATCH))
        isClickable = true
        contentDescription = "Photo"
        setOnClickListener { launcher.pickWidgetPhoto(item) }
        reload()
    }

    fun reload() {
        val file = launcher.widgetPhotoFile(item.id)
        if (!file.exists()) { image.setImageDrawable(null); empty.visibility = VISIBLE; return }
        empty.visibility = GONE
        io.execute {
            val bmp = try { BitmapFactory.decodeFile(file.absolutePath) } catch (_: Throwable) { null }
            post { if (bmp != null) image.setImageBitmap(bmp) else empty.visibility = VISIBLE }
        }
    }

    override fun applyColors(dark: Boolean, look: WidgetLook) {
        val surfaced = look.bg != "off"
        emptyIcon.imageTintList = android.content.res.ColorStateList.valueOf(inkFor(dark, 0.8f))
        emptyText.setTextColor(inkFor(dark, 0.8f))
        empty.background = if (surfaced) null else roundRect(Color.argb(60, 0, 0, 0), dp(22f))
        // Without a background the photo still gets rounded corners.
        outlineProvider = object : android.view.ViewOutlineProvider() {
            override fun getOutline(view: View, outline: android.graphics.Outline) = outline.setRoundRect(0, 0, view.width, view.height, dp(24f))
        }
        clipToOutline = true
        reload()
    }

    companion object { private val io = Executors.newSingleThreadExecutor() }
}

// ---- Quick toggles ---------------------------------------------------------------------------------------

class TogglesWidget(private val launcher: MainActivity) : LinearLayout(launcher), BuiltinContent {
    private class Toggle(val icon: Int, val label: String, val run: (View) -> Unit)
    private val buttons = ArrayList<Pair<FrameLayout, ImageView>>()
    private var dark = false
    private val torchButton: Int

    init {
        orientation = HORIZONTAL; gravity = Gravity.CENTER
        val toggles = mutableListOf<Toggle>()
        val torchAvailable = launcher.torch.available
        if (torchAvailable) toggles += Toggle(R.drawable.ic_flash, "Flashlight") { v ->
            if (launcher.torch.toggle()) { launcher.haptic(v, HapticFeedbackConstants.CONFIRM); refreshStates() } else launcher.toast("The flashlight is busy")
        }
        toggles += Toggle(R.drawable.ic_wifi, "Wi-Fi") { v -> openFirst(v, "android.settings.panel.action.WIFI", "android.settings.WIFI_SETTINGS") }
        toggles += Toggle(R.drawable.ic_bluetooth, "Bluetooth") { v -> openFirst(v, "android.settings.BLUETOOTH_SETTINGS") }
        toggles += Toggle(R.drawable.ic_moon, "Do not disturb") { v -> openFirst(v, "android.settings.ZEN_MODE_PRIORITY_SETTINGS", "android.settings.SOUND_SETTINGS") }
        toggles += Toggle(R.drawable.ic_camera, "Camera") { v -> launcher.startSafely(Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK), v) }
        torchButton = if (torchAvailable) 0 else -1
        toggles.forEach { t ->
            val cell = FrameLayout(launcher)
            val circle = FrameLayout(launcher).apply {
                isClickable = true
                contentDescription = t.label
                setOnClickListener { launcher.haptic(it, HapticFeedbackConstants.CONTEXT_CLICK); t.run(it) }
            }
            val img = launcher.iconImage(t.icon, Color.WHITE, 0)
            circle.addView(img, flp(MATCH, MATCH))
            cell.addView(circle, flp(dpi(48), dpi(48), Gravity.CENTER))
            buttons += circle to img
            addView(cell, llp(0, MATCH, 1f))
        }
    }

    private fun openFirst(v: View, vararg actions: String) {
        val pm = launcher.packageManager
        for (a in actions) {
            val i = Intent(a).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            if (i.resolveActivity(pm) != null) { launcher.startSafely(i, v); return }
        }
        launcher.startSafely(Intent(android.provider.Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK), v)
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        if (buttons.isEmpty() || w <= 0 || h <= 0) return
        // Buttons stay round: as big as the narrower of a column and the widget height allows.
        val size = min(w / buttons.size - dpi(6), h - dpi(8)).coerceIn(dpi(28), dpi(56))
        post {
            buttons.forEach { (circle, img) ->
                circle.layoutParams = flp(size, size, Gravity.CENTER)
                val p = (size * 0.27f).roundToInt()
                img.setPadding(p, p, p, p)
            }
            refreshStates()
        }
    }

    private fun refreshStates() {
        buttons.forEachIndexed { i, (circle, img) ->
            val active = i == torchButton && launcher.torch.on
            circle.background = pressable(oval(if (active) launcher.prefs.accent else inkFor(dark, 0.14f)), inkFor(dark, 0.2f), dp(28f))
            img.imageTintList = android.content.res.ColorStateList.valueOf(if (active) inkOn(launcher.prefs.accent) else inkFor(dark, 0.9f))
        }
    }

    override fun applyColors(dark: Boolean, look: WidgetLook) { this.dark = dark; refreshStates() }

    // Follow the flashlight when it is switched from the system's quick settings too.
    private val torchListener: () -> Unit = { refreshStates() }
    override fun onAttachedToWindow() { super.onAttachedToWindow(); if (torchButton >= 0) { launcher.torch.listeners.add(torchListener); refreshStates() } }
    override fun onDetachedFromWindow() { launcher.torch.listeners.remove(torchListener); super.onDetachedFromWindow() }
}
