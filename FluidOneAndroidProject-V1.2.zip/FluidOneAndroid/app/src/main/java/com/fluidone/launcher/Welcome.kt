package com.fluidone.launcher

import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PathMeasure
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.os.SystemClock
import android.provider.Settings
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.VelocityTracker
import android.view.View
import android.view.ViewConfiguration
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sin

/**
 * First run: "Welcome to Fluid One", a few swipeable pages that show what the launcher does, with live,
 * animated illustrations. After an update it says "What's new in 1.2" instead. Shown once per version.
 */
class WelcomeOverlay(launcher: MainActivity, private val isUpdate: Boolean, private val version: String) : Overlay(launcher) {
    private val aurora = AuroraView(launcher)
    private val pages = ArrayList<WelcomePage>()
    private val pager = WelcomePager(launcher)
    private val indicator = LiquidDots(launcher)
    private val primary = WelcomeButton(launcher, "Continue")
    private val secondary = launcher.textView("", 15f, Color.argb(220, 255, 255, 255), Fonts.medium, Gravity.CENTER)
    private val skip = launcher.textView("Skip", 15f, Color.argb(200, 255, 255, 255), Fonts.medium, Gravity.CENTER)
    private var shownPage = -1

    init {
        root.isClickable = true
        root.setBackgroundColor(Color.rgb(8, 8, 14))
        root.addView(aurora, flp(MATCH, MATCH))
        if (isUpdate) buildWhatsNew() else buildWelcome()
    }

    // ---- Fresh install: welcome pages ---------------------------------------------------------------------

    private fun buildWelcome() {
        val brand = launcher.brand
        pages += WelcomePage(launcher, LogoHero(launcher), "Welcome to\nFluid One",
            "A home screen made of light and glass, with smooth motion everywhere.")
        pages += WelcomePage(launcher, FluidGlassPreview(launcher), "Fluid Glass",
            "Real liquid glass that bends what's behind it. Drag the lens above. Tune every detail in Settings.")
        pages += WelcomePage(launcher, SearchHero(launcher), "Search everything",
            "Apps, contacts, settings, sums, conversions and quick actions, all from one bar.")
        pages += WelcomePage(launcher, StylesHero(launcher), "Make it yours",
            "Icon styles and shapes, glass or colour widgets, any accent colour and over 20 wallpapers.")
        pages += WelcomePage(launcher, BrandHero(launcher), if (brand == Brand.OTHER) "Tuned for your phone" else "${brand.modeName} is on",
            if (brand == Brand.OTHER) "Fluid One adjusts its effects to your phone so everything stays smooth."
            else "Fluid One recognised your ${brand.label} phone and tuned itself for ${brand.system}. Change it any time in Settings.")
        pages += WelcomePage(launcher, PrivacyHero(launcher), "Private by design",
            "Fluid One has no internet access. Your apps, contacts and searches stay on this phone and are never shared with third parties.")
        pages.forEach { pager.addPage(it) }
        root.addView(pager, flp(MATCH, MATCH))

        skip.apply {
            setPadding(launcher.dpi(16), launcher.dpi(10), launcher.dpi(16), launcher.dpi(10))
            background = pressable(null, Color.argb(40, 255, 255, 255), launcher.dp(18f))
            isClickable = true
            contentDescription = "Skip introduction"
            setOnClickListener { launcher.haptic(it, HapticFeedbackConstants.CONTEXT_CLICK); finishWelcome() }
        }
        root.addView(skip, flp(WRAP, WRAP, Gravity.TOP or Gravity.END).apply { topMargin = launcher.insetTop + launcher.dpi(8); rightMargin = launcher.dpi(12) })

        val bottom = LinearLayout(launcher).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL }
        indicator.count = pages.size
        bottom.addView(indicator, llp(MATCH, launcher.dpi(24)))
        primary.setOnClickListener {
            launcher.haptic(it, HapticFeedbackConstants.CONTEXT_CLICK)
            if (pager.current < pages.size - 1) pager.goTo(pager.current + 1) else finishWelcome()
        }
        bottom.addView(primary, llp(MATCH, launcher.dpi(56)).apply { topMargin = launcher.dpi(14); marginStart = launcher.dpi(28); marginEnd = launcher.dpi(28) })
        secondary.apply {
            setPadding(launcher.dpi(16), launcher.dpi(12), launcher.dpi(16), launcher.dpi(12))
            background = pressable(null, Color.argb(40, 255, 255, 255), launcher.dp(18f))
            isClickable = true
            setOnClickListener {
                launcher.haptic(it, HapticFeedbackConstants.CONTEXT_CLICK)
                launcher.startSafely(Intent(Settings.ACTION_HOME_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK), it)
            }
        }
        bottom.addView(secondary, llp(WRAP, WRAP).apply { topMargin = launcher.dpi(6) })
        root.addView(bottom, flp(MATCH, WRAP, Gravity.BOTTOM).apply { bottomMargin = launcher.insetBottom + launcher.dpi(18) })

        pager.onScroll = { pos -> indicator.position = pos; updateButtons(pos) }
        pager.onPage = { i -> showPage(i) }
    }

    private fun updateButtons(pos: Float) {
        val last = pages.size - 1
        val t = clamp01(pos - (last - 1))
        primary.label = if (t > 0.5f) "Get started" else "Continue"
        primary.labelAlpha = 1f - 2f * abs(t - 0.5f).let { 0.5f - it }.coerceAtLeast(0f)
        val showHome = !launcher.isDefaultLauncher()
        secondary.text = "Set Fluid One as your home app"
        secondary.alpha = if (showHome) t else 0f
        secondary.visibility = if (showHome && t > 0.02f) View.VISIBLE else View.INVISIBLE
        skip.alpha = 1f - t
        skip.visibility = if (t > 0.98f) View.INVISIBLE else View.VISIBLE
    }

    private fun showPage(i: Int) {
        if (i == shownPage) return
        shownPage = i
        pages.getOrNull(i)?.reveal()
        launcher.haptic(root, HapticFeedbackConstants.CLOCK_TICK)
    }

    // ---- Update: what's new --------------------------------------------------------------------------------

    private fun buildWhatsNew() {
        val scroll = ScrollView(launcher).apply { isVerticalScrollBarEnabled = false; overScrollMode = View.OVER_SCROLL_IF_CONTENT_SCROLLS; clipToPadding = false }
        val col = LinearLayout(launcher).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(launcher.dpi(24), launcher.insetTop + launcher.dpi(48), launcher.dpi(24), launcher.insetBottom + launcher.dpi(120))
        }
        val badge = launcher.textView("FLUID ONE $version", 12f, Color.argb(200, 255, 255, 255), Fonts.semibold).apply { letterSpacing = 0.14f }
        val title = launcher.textView("What's new\nin $version", 40f, Color.WHITE, Fonts.bold).apply { setLineSpacing(0f, 0.95f) }
        val sub = launcher.textView("Your layout, wallpaper and settings are all still here.", 15f, Color.argb(190, 255, 255, 255)).apply { setPadding(0, launcher.dpi(10), 0, launcher.dpi(18)) }
        col.addView(badge); col.addView(title, llp(MATCH, WRAP).apply { topMargin = launcher.dpi(10) }); col.addView(sub)
        val brand = launcher.brand
        val items = listOf(
            Triple(R.drawable.ic_blur, "Fluid Glass, refined", "Advanced controls for edge curve, depth, zoom, softness and rim light, plus smoother effects on every phone."),
            Triple(R.drawable.ic_device, if (brand == Brand.OTHER) "Device optimizations" else "${brand.modeName} is on", "New modes for Samsung, Xiaomi, Nothing, Pixel, OnePlus, OPPO, realme, Motorola, vivo, HONOR, HUAWEI, Xperia and ASUS, each switched on by itself."),
            Triple(R.drawable.ic_search, "Smarter search", "Your phone's own settings, time anywhere, countdowns, \"15% of 80\", and it remembers what you pick."),
            Triple(R.drawable.ic_widgets, "New widgets", "Analog clock, date, search bar, notes, photo and quick toggles, with a glass, colour or no background."),
            Triple(R.drawable.ic_palette, "Any accent colour", "Pick any colour, or one from your wallpaper, for the accent and for widgets."),
            Triple(R.drawable.ic_drop, "Fluid Glass icons", "Icons on real glass plates, plus Monochrome, Pastel, Neon and Gradient styles and new shapes."),
            Triple(R.drawable.ic_toggles, "Glass switches", "Hold any switch and slide the knob. It turns into a glass lens."),
            Triple(R.drawable.ic_animation, "App animations that work", "Apps zoom out of their icon and back again, on Android 13 and newer too."),
            Triple(R.drawable.ic_sparkle, "Unlock styles", "Fluid One, ColorOS, One UI, HyperOS, Pixel and Ripple."),
            Triple(R.drawable.ic_check, "Fixes", "Themed icons on every phone, search over the keyboard, widgets that wouldn't add, square widget corners and the notification shade after unlock.")
        )
        val colors = listOf(Color.rgb(32, 160, 230), Color.rgb(20, 40, 160), Color.rgb(20, 150, 120), Color.rgb(255, 140, 40), Color.rgb(242, 80, 128),
            Color.rgb(132, 94, 247), Color.rgb(52, 186, 110), Color.rgb(255, 98, 72), Color.rgb(230, 170, 40), Color.rgb(90, 98, 120))
        val rows = ArrayList<View>()
        items.forEachIndexed { i, (icon, head, body) ->
            val row = LinearLayout(launcher).apply {
                orientation = LinearLayout.HORIZONTAL
                setPadding(launcher.dpi(14), launcher.dpi(14), launcher.dpi(14), launcher.dpi(14))
                background = roundRect(Color.argb(30, 255, 255, 255), launcher.dp(22f), launcher.dpi(1), Color.argb(36, 255, 255, 255))
            }
            val chip = FrameLayout(launcher).apply { background = roundRect(colors[i % colors.size], launcher.dp(12f)) }
            chip.addView(launcher.iconImage(icon, Color.WHITE, 8), flp(MATCH, MATCH))
            row.addView(chip, llp(launcher.dpi(40), launcher.dpi(40)).apply { marginEnd = launcher.dpi(14) })
            val texts = LinearLayout(launcher).apply { orientation = LinearLayout.VERTICAL }
            texts.addView(launcher.textView(head, 16f, Color.WHITE, Fonts.semibold))
            texts.addView(launcher.textView(body, 13.5f, Color.argb(185, 255, 255, 255)).apply { setPadding(0, launcher.dpi(4), 0, 0); setLineSpacing(launcher.dp(2f), 1f) })
            row.addView(texts, llp(0, WRAP, 1f))
            col.addView(row, llp(MATCH, WRAP).apply { topMargin = launcher.dpi(10) })
            rows += row
        }
        scroll.addView(col, flp(MATCH, WRAP))
        root.addView(scroll, flp(MATCH, MATCH))
        val fade = View(launcher).apply {
            background = android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation.BOTTOM_TOP,
                intArrayOf(Color.argb(235, 8, 8, 14), Color.argb(0, 8, 8, 14)))
        }
        root.addView(fade, flp(MATCH, launcher.insetBottom + launcher.dpi(130), Gravity.BOTTOM))
        primary.label = "Continue"
        primary.setOnClickListener { launcher.haptic(it, HapticFeedbackConstants.CONFIRM); finishWelcome() }
        root.addView(primary, flp(MATCH, launcher.dpi(56), Gravity.BOTTOM).apply {
            bottomMargin = launcher.insetBottom + launcher.dpi(22); leftMargin = launcher.dpi(28); rightMargin = launcher.dpi(28)
        })
        // Everything arrives in sequence.
        val views = listOf<View>(badge, title, sub) + rows
        views.forEachIndexed { i, v ->
            v.alpha = 0f; v.translationY = launcher.dp(if (i < 3) 22f else 34f); v.scaleX = if (i < 3) 1f else 0.96f; v.scaleY = v.scaleX
            val spring = Spring(0.82f, 0.5f)
            v.animate().alpha(1f).translationY(0f).scaleX(1f).scaleY(1f).setStartDelay(Motion.d(120L + i * 55L))
                .setDuration(spring.ms).setInterpolator(spring).start()
        }
        primary.alpha = 0f; primary.translationY = launcher.dp(40f)
        val spring = Spring(0.75f, 0.5f)
        primary.animate().alpha(1f).translationY(0f).setStartDelay(Motion.d(420)).setDuration(spring.ms).setInterpolator(spring).start()
    }

    // ---- Lifecycle -----------------------------------------------------------------------------------------

    fun show() {
        launcher.showOverlay(this)
        root.alpha = 0f
        root.animate().alpha(1f).setDuration(Motion.d(320)).setInterpolator(Motion.decel).start()
        if (!isUpdate) {
            indicator.alpha = 0f; primary.alpha = 0f; primary.translationY = launcher.dp(40f); skip.alpha = 0f
            val spring = Spring(0.75f, 0.5f)
            indicator.animate().alpha(1f).setStartDelay(Motion.d(520)).setDuration(Motion.d(400)).start()
            primary.animate().alpha(1f).translationY(0f).setStartDelay(Motion.d(460)).setDuration(spring.ms).setInterpolator(spring).start()
            skip.animate().alpha(1f).setStartDelay(Motion.d(700)).setDuration(Motion.d(400)).start()
            root.post { showPage(0); updateButtons(0f) }
        }
    }

    private fun finishWelcome() {
        launcher.markWelcomeSeen()
        close(true)
    }

    override val sticky: Boolean get() = true

    override fun onBack(): Boolean {
        if (!isUpdate && pager.current > 0) { pager.goTo(pager.current - 1); return true }
        finishWelcome()
        return true
    }

    override fun close(animate: Boolean) {
        if (closing) return
        closing = true
        launcher.markWelcomeSeen()
        if (!animate) { finish(); launcher.onWelcomeClosed(); return }
        root.animate().alpha(0f).scaleX(1.05f).scaleY(1.05f).setDuration(Motion.d(340)).setInterpolator(Motion.accel)
            .withEndAction { finish(); }.start()
        // The home screen gathers in underneath as the welcome lifts away.
        launcher.rootView.postDelayed({ launcher.onWelcomeClosed() }, Motion.d(120))
    }

    /** Test hook: the current welcome page. */
    val currentPage: Int get() = pager.current
    fun next() = pager.goTo(pager.current + 1)
}

/** A welcome page: illustration, title and text, with parallax while swiping and a staggered entrance. */
class WelcomePage(launcher: MainActivity, val hero: View, title: String, body: String) : LinearLayout(launcher) {
    private val titleView: TextView = launcher.textView(title, 34f, Color.WHITE, Fonts.bold, Gravity.CENTER).apply { setLineSpacing(0f, 0.95f) }
    private val bodyView: TextView = launcher.textView(body, 16f, Color.argb(200, 255, 255, 255), Fonts.regular, Gravity.CENTER).apply { setLineSpacing(launcher.dp(3f), 1f) }
    private var revealed = false

    init {
        orientation = VERTICAL
        gravity = Gravity.CENTER_HORIZONTAL
        setPadding(launcher.dpi(28), launcher.insetTop + launcher.dpi(72), launcher.dpi(28), 0)
        val heroH = if (hero is FluidGlassPreview) WRAP else launcher.dpi(236)
        addView(hero, llp(MATCH, heroH))
        addView(titleView, llp(MATCH, WRAP).apply { topMargin = launcher.dpi(34) })
        addView(bodyView, llp(MATCH, WRAP).apply { topMargin = launcher.dpi(14) })
        listOf(hero, titleView, bodyView).forEach { it.alpha = 0f }
    }

    /** Plays the entrance once: illustration springs in, then title and text rise into place. */
    fun reveal() {
        if (revealed) return
        revealed = true
        val parts = listOf(hero, titleView, bodyView)
        parts.forEachIndexed { i, v ->
            v.alpha = 0f
            v.translationY = dp(if (i == 0) 10f else 26f)
            val s = if (i == 0) 0.86f else 1f
            v.scaleX = s; v.scaleY = s
            val spring = if (i == 0) Spring(0.7f, 0.55f) else Spring(0.85f, 0.5f)
            v.animate().alpha(1f).translationY(0f).scaleX(1f).scaleY(1f).setStartDelay(Motion.d(40L + i * 90L))
                .setDuration(spring.ms).setInterpolator(spring).start()
        }
        (hero as? Hero)?.start()
    }

    /** -1..1: how far this page is from the centre while swiping. */
    fun parallax(offset: Float, width: Int) {
        hero.translationX = offset * width * 0.28f
        bodyView.translationX = -offset * width * 0.12f
        val fade = 1f - min(1f, abs(offset)) * 0.6f
        if (revealed) { titleView.alpha = fade; bodyView.alpha = fade; hero.alpha = fade }
    }
}

/** Horizontal pager with spring snapping. */
class WelcomePager(context: android.content.Context) : ViewGroup(context) {
    private val pages = ArrayList<WelcomePage>()
    var position = 0f
        private set
    val current: Int get() = position.roundToInt().coerceIn(0, (pages.size - 1).coerceAtLeast(0))
    var onScroll: ((Float) -> Unit)? = null
    var onPage: ((Int) -> Unit)? = null
    private val spring = SpringValue(0f) { setPos(it) }
    private var downX = 0f
    private var downY = 0f
    private var startPos = 0f
    private var dragging = false
    private var velocity: VelocityTracker? = null
    private val slop = ViewConfiguration.get(context).scaledTouchSlop

    fun addPage(p: WelcomePage) { pages += p; addView(p) }

    fun goTo(i: Int) {
        val target = i.coerceIn(0, pages.size - 1).toFloat()
        spring.animateTo(target, 300f, 0.86f)
        onPage?.invoke(target.toInt())
    }

    private fun setPos(p: Float) {
        position = p
        layoutPages()
        onScroll?.invoke(p)
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val w = MeasureSpec.getSize(widthMeasureSpec); val h = MeasureSpec.getSize(heightMeasureSpec)
        pages.forEach { it.measure(MeasureSpec.makeMeasureSpec(w, MeasureSpec.EXACTLY), MeasureSpec.makeMeasureSpec(h, MeasureSpec.EXACTLY)) }
        setMeasuredDimension(w, h)
    }

    override fun onLayout(changed: Boolean, l: Int, t: Int, r: Int, b: Int) {
        pages.forEach { it.layout(0, 0, r - l, b - t) }
        layoutPages()
    }

    private fun layoutPages() {
        val w = width
        pages.forEachIndexed { i, p ->
            val offset = i - position
            p.translationX = offset * w
            p.visibility = if (abs(offset) < 1.2f) VISIBLE else INVISIBLE
            p.parallax(offset, w)
        }
    }

    override fun onInterceptTouchEvent(ev: MotionEvent): Boolean {
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN -> { downX = ev.x; downY = ev.y; dragging = false }
            MotionEvent.ACTION_MOVE -> if (!dragging && abs(ev.x - downX) > slop * 1.5f && abs(ev.x - downX) > abs(ev.y - downY) * 1.4f) {
                // The Fluid Glass playground keeps its own drags on its lens.
                if (!heroWantsTouch(downX, downY)) { startDrag(ev); return true }
            }
        }
        return false
    }

    private fun heroWantsTouch(x: Float, y: Float): Boolean {
        val page = pages.getOrNull(current) ?: return false
        val hero = page.hero as? FluidGlassPreview ?: return false
        val loc = IntArray(2); hero.getLocationInWindow(loc)
        val me = IntArray(2); getLocationInWindow(me)
        val hx = x + me[0] - loc[0]; val hy = y + me[1] - loc[1]
        return hx >= 0 && hy >= 0 && hx <= hero.width && hy <= hero.height
    }

    private fun startDrag(ev: MotionEvent) {
        dragging = true
        downX = ev.x
        startPos = position
        spring.stop()
        velocity?.recycle(); velocity = VelocityTracker.obtain()
        parent?.requestDisallowInterceptTouchEvent(true)
    }

    override fun onTouchEvent(ev: MotionEvent): Boolean {
        if (ev.actionMasked == MotionEvent.ACTION_DOWN) { downX = ev.x; downY = ev.y; return true }
        if (!dragging && ev.actionMasked == MotionEvent.ACTION_MOVE && abs(ev.x - downX) > slop) startDrag(ev)
        if (!dragging) return true
        velocity?.addMovement(ev)
        when (ev.actionMasked) {
            MotionEvent.ACTION_MOVE -> {
                var p = startPos - (ev.x - downX) / width.coerceAtLeast(1)
                val maxP = (pages.size - 1).toFloat()
                if (p < 0f) p *= 0.3f
                if (p > maxP) p = maxP + (p - maxP) * 0.3f
                spring.snapTo(p)
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                dragging = false
                velocity?.computeCurrentVelocity(1000)
                val vx = velocity?.xVelocity ?: 0f
                velocity?.recycle(); velocity = null
                val target = when {
                    vx < -dp(500f) -> kotlin.math.floor(position) + 1
                    vx > dp(500f) -> kotlin.math.ceil(position) - 1
                    else -> position.roundToInt().toFloat()
                }
                goTo(target.roundToInt())
            }
        }
        return true
    }
}

/** Page dots where the active one is a pill that stretches like liquid between pages. */
class LiquidDots(context: android.content.Context) : View(context) {
    var count = 1
        set(v) { field = v; invalidate() }
    var position = 0f
        set(v) { field = v; invalidate() }
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)

    override fun onDraw(canvas: Canvas) {
        val d = dp(7f); val gap = dp(10f)
        val total = count * d + (count - 1) * gap
        val x0 = (width - total) / 2f
        val cy = height / 2f
        paint.color = Color.argb(70, 255, 255, 255)
        for (i in 0 until count) canvas.drawCircle(x0 + i * (d + gap) + d / 2f, cy, d / 2f, paint)
        // Active pill: its two ends follow the position at different speeds, so it stretches and snaps.
        val p = position.coerceIn(0f, (count - 1).toFloat())
        val frac = p - kotlin.math.floor(p)
        val base = kotlin.math.floor(p)
        val lead = base + min(1f, frac * 1.8f)
        val tail = base + max(0f, frac * 1.8f - 0.8f)
        val left = x0 + tail * (d + gap)
        val right = x0 + lead * (d + gap) + d
        paint.color = Color.WHITE
        canvas.drawRoundRect(left - dp(4f), cy - d / 2f, right + dp(4f), cy + d / 2f, d / 2f, d / 2f, paint)
    }
}

/** The big white pill button of the welcome screen, with a springy press. */
class WelcomeButton(context: android.content.Context, initial: String) : View(context) {
    var label = initial
        set(v) { if (field != v) { field = v; contentDescription = v; invalidate() } }
    var labelAlpha = 1f
        set(v) { field = v; invalidate() }
    private val bg = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }
    private val text = android.text.TextPaint(Paint.ANTI_ALIAS_FLAG).apply { typeface = Fonts.semibold; color = Color.rgb(14, 14, 20); textAlign = Paint.Align.CENTER }
    private var press = 0f
    private val spring = SpringValue(0f) { press = it; scaleX = 1f - 0.04f * it; scaleY = 1f - 0.04f * it; invalidate() }

    init { isClickable = true; contentDescription = initial }

    override fun onDraw(canvas: Canvas) {
        val r = height / 2f
        bg.alpha = (255 * (0.96f - 0.08f * press)).roundToInt().coerceIn(0, 255)
        canvas.drawRoundRect(0f, 0f, width.toFloat(), height.toFloat(), r, r, bg)
        text.textSize = dp(17f)
        text.alpha = (255 * labelAlpha.coerceIn(0.25f, 1f)).roundToInt()
        canvas.drawText(label, width / 2f, height / 2f - (text.ascent() + text.descent()) / 2f, text)
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> spring.animateTo(1f, 700f, 0.7f)
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> spring.animateTo(0f, 300f, 0.4f)
        }
        return super.onTouchEvent(event)
    }
}

/** Slowly drifting colour light behind the welcome screen. */
class AuroraView(private val launcher: MainActivity) : View(launcher) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val start = SystemClock.uptimeMillis()
    private val colors: IntArray = run {
        val a = launcher.prefs.accent
        val hsv = FloatArray(3); android.graphics.Color.colorToHSV(a, hsv)
        IntArray(3) { i -> Color.HSVToColor(floatArrayOf((hsv[0] + i * 55f) % 360f, 0.75f, 0.85f)) }
    }

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        if (w <= 0f) return
        val t = (SystemClock.uptimeMillis() - start) / 1000f
        for (i in 0 until 3) {
            val ph = t * (0.12f + i * 0.04f) + i * 2.1f
            val cx = w * (0.5f + 0.38f * sin(ph * 1.3f + i))
            val cy = h * (0.32f + 0.3f * cos(ph + i * 1.7f))
            val r = w * (0.75f + 0.15f * sin(ph * 0.7f))
            paint.shader = RadialGradient(cx, cy, r, intArrayOf(withAlpha(colors[i], 0.55f), withAlpha(colors[i], 0f)), null, Shader.TileMode.CLAMP)
            canvas.drawCircle(cx, cy, r, paint)
        }
        paint.shader = null
        if (isAttachedToWindow) postInvalidateOnAnimation()
    }
}

/** Illustrations that run an animation once they are on screen. */
interface Hero { fun start() }

/** The Fluid One mark: a glossy app tile breathing gently, with glass beads circling it. */
class LogoHero(private val launcher: MainActivity) : View(launcher), Hero {
    private val icon: Bitmap? = try { FluidLogo.render(launcher, launcher.dpi(120)) } catch (_: Exception) { null }
    private val glow = Paint(Paint.ANTI_ALIAS_FLAG)
    private val bead = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rim = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val bmp = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private var t0 = 0L

    override fun start() { t0 = SystemClock.uptimeMillis(); invalidate() }

    override fun onDraw(canvas: Canvas) {
        val cx = width / 2f; val cy = height / 2f
        val t = if (t0 == 0L) 0f else (SystemClock.uptimeMillis() - t0) / 1000f
        val breathe = 1f + 0.035f * sin(t * 2.2f)
        val s = dp(120f) * breathe
        glow.shader = RadialGradient(cx, cy, s * 1.3f, intArrayOf(withAlpha(launcher.prefs.accent, 0.55f), Color.TRANSPARENT), null, Shader.TileMode.CLAMP)
        canvas.drawCircle(cx, cy, s * 1.3f, glow)
        icon?.let { canvas.drawBitmap(it, null, RectF(cx - s / 2f, cy - s / 2f, cx + s / 2f, cy + s / 2f), bmp) }
        // Glass beads in orbit: translucent, with a bright rim and a soft highlight.
        for (i in 0 until 3) {
            val a = t * (0.9f + i * 0.25f) + i * 2.1f
            val rr = dp(96f) + dp(12f) * i
            val bx = cx + rr * cos(a); val by = cy + rr * 0.42f * sin(a)
            val br = dp(13f) - dp(3f) * i
            val front = sin(a) > 0f
            bead.color = Color.argb(if (front) 70 else 36, 255, 255, 255)
            canvas.drawCircle(bx, by, br, bead)
            rim.strokeWidth = dp(1.2f); rim.color = Color.argb(if (front) 200 else 90, 255, 255, 255)
            canvas.drawCircle(bx, by, br, rim)
        }
        if (isAttachedToWindow && t0 != 0L) postInvalidateOnAnimation()
    }
}

/** A search bar that types real queries and shows what Fluid One would answer. */
class SearchHero(private val launcher: MainActivity) : View(launcher), Hero {
    private val queries = listOf("spotify" to "Opens the app", "12*7" to "= 84", "time in tokyo" to "World clock", "wifi" to "Wi-Fi settings", "timer 5 min" to "Start a 5 min timer")
    private val pill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rim = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val text = android.text.TextPaint(Paint.ANTI_ALIAS_FLAG).apply { typeface = Fonts.medium; color = Color.WHITE }
    private val result = android.text.TextPaint(Paint.ANTI_ALIAS_FLAG).apply { typeface = Fonts.semibold; color = Color.WHITE }
    private val searchIcon = launcher.getDrawable(R.drawable.ic_search)?.mutate()
    private var t0 = 0L

    override fun start() { t0 = SystemClock.uptimeMillis(); invalidate() }

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        val t = if (t0 == 0L) 0f else (SystemClock.uptimeMillis() - t0) / 1000f
        val cycle = 2.6f
        val idx = ((t / cycle).toInt()) % queries.size
        val local = t % cycle
        val (q, answer) = queries[idx]
        val typed = q.take(((local / 0.9f) * q.length).toInt().coerceIn(0, q.length))
        val ph = dp(56f)
        val top = h * 0.28f
        val r = RectF(dp(8f), top, w - dp(8f), top + ph)
        pill.color = Color.argb(46, 255, 255, 255)
        canvas.drawRoundRect(r, ph / 2f, ph / 2f, pill)
        rim.strokeWidth = dp(1.2f); rim.color = Color.argb(120, 255, 255, 255)
        canvas.drawRoundRect(r, ph / 2f, ph / 2f, rim)
        searchIcon?.let { d ->
            d.setTint(Color.WHITE)
            val s = dp(20f).roundToInt()
            d.setBounds((r.left + dp(20f)).roundToInt(), (r.centerY() - s / 2f).roundToInt(), (r.left + dp(20f)).roundToInt() + s, (r.centerY() + s / 2f).roundToInt())
            d.draw(canvas)
        }
        text.textSize = dp(18f)
        val tx = r.left + dp(54f)
        val baseline = r.centerY() - (text.ascent() + text.descent()) / 2f
        canvas.drawText(typed, tx, baseline, text)
        // Blinking caret.
        if ((t * 2f).toInt() % 2 == 0 || typed.length < q.length) {
            val cxp = tx + text.measureText(typed) + dp(2f)
            pill.color = Color.WHITE
            canvas.drawRect(cxp, r.centerY() - dp(11f), cxp + dp(2f), r.centerY() + dp(11f), pill)
        }
        // The answer card rises in once the query is typed.
        val appear = clamp01((local - 1.0f) / 0.35f).let { it * it * (3 - 2 * it) }
        val fadeOut = clamp01((cycle - local) / 0.3f)
        if (appear > 0f) {
            val a = appear * fadeOut
            val cardTop = r.bottom + dp(18f) + dp(14f) * (1f - appear)
            val card = RectF(dp(8f), cardTop, w - dp(8f), cardTop + dp(64f))
            pill.color = Color.argb((34 * a).roundToInt(), 255, 255, 255)
            canvas.drawRoundRect(card, dp(22f), dp(22f), pill)
            rim.color = Color.argb((80 * a).roundToInt(), 255, 255, 255)
            canvas.drawRoundRect(card, dp(22f), dp(22f), rim)
            result.textSize = dp(20f); result.alpha = (255 * a).roundToInt()
            canvas.drawText(answer, card.left + dp(22f), card.centerY() - (result.ascent() + result.descent()) / 2f, result)
        }
        if (isAttachedToWindow && t0 != 0L) postInvalidateOnAnimation()
    }
}

/** Real app icons cycling through icon styles with a springy pop. */
class StylesHero(private val launcher: MainActivity) : FrameLayout(launcher), Hero {
    private val styles = listOf("original", "glass", "themed_dark", "pastel", "neon", "tinted", "gradient", "mono")
    private val tiles = ArrayList<android.widget.ImageView>()
    private val frames = HashMap<String, List<Bitmap>>()
    private var step = 0
    private val tick = object : Runnable {
        override fun run() {
            if (!isAttachedToWindow) return
            step++
            apply(styles[step % styles.size])
            postDelayed(this, 1500)
        }
    }

    init {
        val row = LinearLayout(launcher).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        repeat(3) {
            val iv = android.widget.ImageView(launcher)
            tiles += iv
            row.addView(iv, llp(launcher.dpi(76), launcher.dpi(76)).apply { marginStart = launcher.dpi(10); marginEnd = launcher.dpi(10) })
        }
        addView(row, flp(MATCH, MATCH))
        // Render every style in the background so the animation never stutters.
        val apps = launcher.previewApps(3)
        val size = launcher.dpi(76)
        Thread {
            styles.forEach { st ->
                val list = apps.map { e -> try { launcher.icons.forDisplay(launcher.icons.preview(e, size, IconOverride("style", style = st))) } catch (_: Throwable) { null } }
                if (list.all { it != null }) synchronized(frames) { frames[st] = list.filterNotNull() }
            }
            post { apply(styles[step % styles.size]) }
        }.apply { isDaemon = true; priority = Thread.MIN_PRIORITY }.start()
    }

    private fun apply(style: String) {
        val bmps = synchronized(frames) { frames[style] } ?: return
        tiles.forEachIndexed { i, iv ->
            iv.animate().cancel()
            iv.animate().scaleX(0.82f).scaleY(0.82f).alpha(0.4f).setStartDelay(i * 70L).setDuration(Motion.d(120)).withEndAction {
                bmps.getOrNull(i)?.let { iv.setImageBitmap(it) }
                val spring = Spring(0.55f, 0.42f)
                iv.animate().scaleX(1f).scaleY(1f).alpha(1f).setStartDelay(0).setDuration(spring.ms).setInterpolator(spring).start()
            }.start()
        }
    }

    override fun start() { removeCallbacks(tick); postDelayed(tick, 1200) }
    override fun onDetachedFromWindow() { removeCallbacks(tick); super.onDetachedFromWindow() }
}

/** A phone outline with the brand's name and a check mark that draws itself. */
class BrandHero(private val launcher: MainActivity) : View(launcher), Hero {
    private val frame = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; color = Color.argb(200, 255, 255, 255); strokeCap = Paint.Cap.ROUND }
    private val screen = Paint(Paint.ANTI_ALIAS_FLAG)
    private val check = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; color = Color.WHITE; strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND }
    private val text = android.text.TextPaint(Paint.ANTI_ALIAS_FLAG).apply { typeface = Fonts.semibold; color = Color.WHITE; textAlign = Paint.Align.CENTER }
    private var t0 = 0L
    private val path = Path()
    private val seg = Path()

    override fun start() { t0 = SystemClock.uptimeMillis(); invalidate() }

    override fun onDraw(canvas: Canvas) {
        val cx = width / 2f; val cy = height / 2f
        val t = if (t0 == 0L) 0f else (SystemClock.uptimeMillis() - t0) / 1000f
        val pw = dp(112f); val ph = dp(220f)
        val r = RectF(cx - pw / 2f, cy - ph / 2f, cx + pw / 2f, cy + ph / 2f)
        screen.shader = LinearGradient(r.left, r.top, r.right, r.bottom, withAlpha(launcher.prefs.accent, 0.55f), Color.argb(40, 255, 255, 255), Shader.TileMode.CLAMP)
        canvas.drawRoundRect(r, dp(24f), dp(24f), screen)
        frame.strokeWidth = dp(3f)
        canvas.drawRoundRect(r, dp(24f), dp(24f), frame)
        text.textSize = dp(17f)
        val name = launcher.brand.label
        canvas.drawText(name, cx, r.top + dp(46f), text)
        // Check mark drawn progressively.
        val p = clamp01((t - 0.3f) / 0.6f).let { it * it * (3 - 2 * it) }
        path.reset()
        path.moveTo(cx - dp(24f), cy + dp(6f)); path.lineTo(cx - dp(6f), cy + dp(24f)); path.lineTo(cx + dp(28f), cy - dp(14f))
        val pm = PathMeasure(path, false)
        seg.reset()
        pm.getSegment(0f, pm.length * p, seg, true)
        check.strokeWidth = dp(7f)
        canvas.drawPath(seg, check)
        if (isAttachedToWindow && t0 != 0L && t < 1.2f) postInvalidateOnAnimation()
    }
}

/** A shield with calm pulses: privacy. */
class PrivacyHero(private val launcher: MainActivity) : View(launcher), Hero {
    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; color = Color.WHITE }
    private val disc = Paint(Paint.ANTI_ALIAS_FLAG)
    private val shield = launcher.getDrawable(R.drawable.ic_shield)?.mutate()
    private var t0 = 0L

    override fun start() { t0 = SystemClock.uptimeMillis(); invalidate() }

    override fun onDraw(canvas: Canvas) {
        val cx = width / 2f; val cy = height / 2f
        val t = if (t0 == 0L) 0f else (SystemClock.uptimeMillis() - t0) / 1000f
        val base = dp(62f)
        for (i in 0 until 2) {
            val ph = ((t * 0.55f + i * 0.5f) % 1f)
            ring.strokeWidth = dp(2f)
            ring.alpha = ((1f - ph) * 150).roundToInt()
            canvas.drawCircle(cx, cy, base + ph * dp(70f), ring)
        }
        disc.color = Color.rgb(20, 150, 120)
        canvas.drawCircle(cx, cy, base, disc)
        shield?.let { d ->
            d.setTint(Color.WHITE)
            val s = dp(64f).roundToInt()
            d.setBounds((cx - s / 2f).roundToInt(), (cy - s / 2f).roundToInt(), (cx + s / 2f).roundToInt(), (cy + s / 2f).roundToInt())
            d.draw(canvas)
        }
        if (isAttachedToWindow && t0 != 0L) postInvalidateOnAnimation()
    }
}

/** The Fluid One mark: a glossy squircle in the accent colours with a white drop. */
object FluidLogo {
    fun render(launcher: MainActivity, size: Int, accent: Int = launcher.prefs.accent): Bitmap {
        val out = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val c = Canvas(out)
        val path = IconShapes.path("squircle", size.toFloat())
        val hsv = FloatArray(3); Color.colorToHSV(accent, hsv)
        val second = Color.HSVToColor(floatArrayOf((hsv[0] + 50f) % 360f, (hsv[1] * 0.9f).coerceIn(0.4f, 1f), 0.75f))
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.shader = LinearGradient(0f, 0f, size.toFloat(), size.toFloat(), blendColors(accent, Color.WHITE, 0.15f), second, Shader.TileMode.CLAMP)
        c.drawPath(path, p)
        // Glass sheen on the top half.
        p.shader = LinearGradient(0f, 0f, 0f, size * 0.6f, Color.argb(90, 255, 255, 255), Color.argb(0, 255, 255, 255), Shader.TileMode.CLAMP)
        c.save(); c.clipPath(path); c.drawRect(0f, 0f, size.toFloat(), size * 0.6f, p); c.restore()
        p.shader = null
        p.style = Paint.Style.STROKE; p.strokeWidth = size / 40f; p.color = Color.argb(120, 255, 255, 255)
        c.drawPath(path, p)
        launcher.getDrawable(R.drawable.ic_drop)?.mutate()?.let { d ->
            d.setTint(Color.WHITE)
            val g = (size * 0.5f).roundToInt(); val o = (size - g) / 2
            d.setBounds(o, o + size / 30, o + g, o + g + size / 30)
            d.draw(c)
        }
        return out
    }
}

