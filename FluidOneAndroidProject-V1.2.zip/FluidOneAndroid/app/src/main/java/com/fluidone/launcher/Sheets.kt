package com.fluidone.launcher

import android.appwidget.AppWidgetProviderInfo
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.drawable.Drawable
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.widget.AbsListView
import android.widget.BaseAdapter
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.GridView
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import java.util.concurrent.Executors
import kotlin.math.roundToInt

private val sheetExecutor = Executors.newFixedThreadPool(2)

/** Horizontal wallpaper carousel used by the edit sheet and settings. */
class WallpaperPicker(private val launcher: MainActivity, private val ui: UiTheme) {
    val view: View
    private val cards = mutableMapOf<String, FrameLayout>()

    init {
        val scroll = HorizontalScrollView(launcher).apply { isHorizontalScrollBarEnabled = false; overScrollMode = View.OVER_SCROLL_NEVER; clipToPadding = false }
        val row = LinearLayout(launcher).apply { orientation = LinearLayout.HORIZONTAL; setPadding(launcher.dpi(16), launcher.dpi(4), launcher.dpi(16), launcher.dpi(4)) }
        val w = launcher.dpi(94); val h = launcher.dpi(196)
        row.addView(card("Your photo", w, h, null), llp(w, WRAP).apply { marginEnd = launcher.dpi(12) })
        Wallpapers.presets.forEach { preset ->
            row.addView(card(preset.name, w, h, preset.id), llp(w, WRAP).apply { marginEnd = launcher.dpi(12) })
        }
        scroll.addView(row)
        view = scroll
        refreshSelection()
    }

    private fun card(name: String, w: Int, h: Int, id: String?): View {
        val col = LinearLayout(launcher).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL }
        val frame = FrameLayout(launcher).apply {
            background = roundRect(ui.chip, launcher.dp(18f))
            clipToOutline = true
            isClickable = true
            contentDescription = name
        }
        val img = ImageView(launcher).apply { scaleType = ImageView.ScaleType.CENTER_CROP }
        frame.addView(img, flp(MATCH, MATCH))
        if (id == null) {
            val plus = FrameLayout(launcher).apply { background = oval(withAlpha(ui.text, 0.12f)) }
            plus.addView(launcher.iconImage(R.drawable.ic_image, ui.text, 12), flp(MATCH, MATCH))
            frame.addView(plus, flp(launcher.dpi(48), launcher.dpi(48), Gravity.CENTER))
            frame.setOnClickListener { launcher.pickWallpaperImage() }
        } else {
            launcher.wallpaperThumbnail(id, w, h) { img.setImageBitmap(it) }
            if (Wallpapers.preset(id).hasGlass) {
                val badge = launcher.textView("GLASS", 9f, Color.WHITE, Fonts.semibold, Gravity.CENTER, maxLines = 1).apply {
                    letterSpacing = 0.08f
                    background = roundRect(Color.argb(96, 0, 0, 0), launcher.dp(8f), 1, Color.argb(90, 255, 255, 255))
                    setPadding(launcher.dpi(6), launcher.dpi(2), launcher.dpi(6), launcher.dpi(2))
                }
                frame.addView(badge, flp(WRAP, WRAP, Gravity.TOP or Gravity.START).apply { leftMargin = launcher.dpi(8); topMargin = launcher.dpi(8) })
            }
            frame.setOnClickListener {
                launcher.haptic(it, HapticFeedbackConstants.CONTEXT_CLICK)
                launcher.setWallpaper(id)
                refreshSelection()
            }
            cards[id] = frame
        }
        col.addView(frame, llp(w, h))
        col.addView(launcher.textView(name, 12f, ui.textSecondary, Fonts.medium, Gravity.CENTER, maxLines = 1).apply { setPadding(0, launcher.dpi(7), 0, 0) }, llp(w, WRAP))
        return col
    }

    fun refreshSelection() {
        val current = launcher.prefs.wallpaper
        cards.forEach { (id, frame) ->
            frame.foreground = if (id == current) roundRect(Color.TRANSPARENT, launcher.dp(18f), launcher.dpi(3), ui.accent) else null
        }
    }
}

class WallpaperSheet(launcher: MainActivity) : BottomSheet(launcher, "Wallpapers", dimBackground = false) {
    init {
        body.addView(WallpaperPicker(launcher, ui).view)
        val b = SettingsBuilder(launcher, ui, body, ui.chip)
        b.group {
            toggle("Also use on lock screen", get = { launcher.prefs.lockWallpaper }) {
                launcher.prefs.lockWallpaper = it
                if (it) launcher.applyLockWallpaper()
            }
        }
        body.addView(View(launcher), llp(MATCH, launcher.dpi(12)))
    }
}

/** Built-in widgets plus every app widget on the device, grouped by app with previews. */
class WidgetsSheet(launcher: MainActivity) : BottomSheet(launcher, "Widgets", dimBackground = false) {
    init {
        // Fluid One widgets in a grid of three per row.
        val builtins = LinearLayout(launcher).apply { orientation = LinearLayout.VERTICAL; setPadding(launcher.dpi(16), 0, launcher.dpi(16), 0) }
        Builtins.all.chunked(3).forEach { chunk ->
            val row = LinearLayout(launcher).apply { orientation = LinearLayout.HORIZONTAL }
            chunk.forEachIndexed { i, id ->
                val (sx, sy) = Builtins.defaultSpan(id, launcher.prefs.columns)
                row.addView(tile(Builtins.icon(id), Builtins.name(id), "$sx × $sy", null) { close(); launcher.addBuiltin(id) },
                    llp(0, WRAP, 1f).apply { if (i < 2) marginEnd = launcher.dpi(8) })
            }
            repeat(3 - chunk.size) { row.addView(View(launcher), llp(0, 1, 1f)) }
            builtins.addView(row, llp(MATCH, WRAP).apply { bottomMargin = launcher.dpi(8) })
        }
        body.addView(launcher.textView("FLUID ONE", 11.5f, ui.textSecondary, Fonts.semibold).apply { letterSpacing = 0.06f; setPadding(launcher.dpi(24), 0, 0, launcher.dpi(8)) })
        body.addView(builtins, llp(MATCH, WRAP))
        val providers = launcher.widgetProviders()
        if (providers.isEmpty()) {
            body.addView(launcher.textView("No app widgets are installed.", 14f, ui.textSecondary, gravity = Gravity.CENTER).apply { setPadding(0, launcher.dpi(24), 0, launcher.dpi(24)) }, llp(MATCH, WRAP))
        }
        providers.groupBy { it.provider.packageName }.toList()
            .sortedBy { (pkg, _) -> appLabel(pkg).lowercase() }
            .forEach { (pkg, list) ->
                val head = LinearLayout(launcher).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(launcher.dpi(24), launcher.dpi(18), launcher.dpi(16), launcher.dpi(8)) }
                launcher.apps.forPackage(pkg).firstOrNull()?.let { entry ->
                    head.addView(ImageView(launcher).apply { setImageBitmap(launcher.icons.appIconForDisplay(entry, launcher.dpi(22))) }, llp(launcher.dpi(22), launcher.dpi(22)).apply { marginEnd = launcher.dpi(10) })
                }
                head.addView(launcher.textView(appLabel(pkg), 15f, ui.text, Fonts.medium, maxLines = 1))
                body.addView(head)
                val scroll = HorizontalScrollView(launcher).apply { isHorizontalScrollBarEnabled = false; overScrollMode = View.OVER_SCROLL_NEVER }
                val row = LinearLayout(launcher).apply { orientation = LinearLayout.HORIZONTAL; setPadding(launcher.dpi(16), 0, launcher.dpi(16), 0) }
                list.forEach { info ->
                    val (sx, sy) = launcher.widgetSpan(info)
                    val label = try { info.loadLabel(launcher.packageManager) } catch (_: Exception) { null } ?: "Widget"
                    row.addView(tile(null, label, "$sx × $sy", info) { close(); launcher.addAppWidget(info) }, llp(launcher.dpi(150), WRAP).apply { marginEnd = launcher.dpi(10) })
                }
                scroll.addView(row)
                body.addView(scroll)
            }
        body.addView(View(launcher), llp(MATCH, launcher.dpi(16)))
    }

    private fun appLabel(pkg: String): String = launcher.apps.forPackage(pkg).firstOrNull()?.let { launcher.apps.label(it) }
        ?: try { launcher.packageManager.getApplicationLabel(launcher.packageManager.getApplicationInfo(pkg, 0)).toString() } catch (_: Exception) { pkg }

    private fun tile(iconRes: Int?, title: String, size: String, info: AppWidgetProviderInfo?, click: () -> Unit): View {
        val col = LinearLayout(launcher).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(launcher.dpi(10), launcher.dpi(10), launcher.dpi(10), launcher.dpi(10))
            background = pressable(roundRect(ui.chip, launcher.dp(18f)), ui.cardPressed, launcher.dp(18f))
            isClickable = true
            setOnClickListener { launcher.haptic(it, HapticFeedbackConstants.CONTEXT_CLICK); click() }
            contentDescription = "$title, $size"
        }
        val preview = ImageView(launcher).apply { scaleType = ImageView.ScaleType.FIT_CENTER }
        if (iconRes != null) {
            preview.setImageResource(iconRes)
            preview.imageTintList = android.content.res.ColorStateList.valueOf(ui.accent)
            preview.setPadding(launcher.dpi(16), launcher.dpi(16), launcher.dpi(16), launcher.dpi(16))
        } else if (info != null) {
            val density = launcher.resources.displayMetrics.densityDpi
            sheetExecutor.execute {
                val d: Drawable? = try { info.loadPreviewImage(launcher, density) ?: info.loadIcon(launcher, density) } catch (_: Exception) { null }
                if (d != null) preview.post { preview.setImageDrawable(d) }
            }
        }
        col.addView(preview, llp(MATCH, launcher.dpi(if (iconRes != null) 72 else 96)))
        col.addView(launcher.textView(title, 13f, ui.text, Fonts.medium, maxLines = 2).apply { setPadding(0, launcher.dpi(8), 0, 0) })
        col.addView(launcher.textView(size, 11.5f, ui.textSecondary).apply { setPadding(0, launcher.dpi(2), 0, 0) })
        return col
    }
}

/** Icon shape, style, icon pack and size. Used by the Icons sheet and the settings page. */
object IconSettings {
    fun build(launcher: MainActivity, b: SettingsBuilder) {
        val ui = b.ui
        val p = launcher.prefs
        val previewRow = LinearLayout(launcher).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER; setPadding(0, launcher.dpi(16), 0, launcher.dpi(16)) }
        fun refreshPreview() {
            previewRow.removeAllViews()
            val size = launcher.dpi(52)
            launcher.previewApps(4).forEach { e ->
                previewRow.addView(ImageView(launcher).apply { setImageBitmap(launcher.icons.appIconForDisplay(e, size)) }, llp(size, size).apply { marginStart = launcher.dpi(10); marginEnd = launcher.dpi(10) })
            }
        }
        refreshPreview()
        b.group { custom(previewRow) }

        val stylePicker = StylePicker(launcher, ui)
        b.group("Shape") {
            val scroll = android.widget.HorizontalScrollView(launcher).apply { isHorizontalScrollBarEnabled = false; overScrollMode = View.OVER_SCROLL_NEVER }
            val shapes = LinearLayout(launcher).apply { orientation = LinearLayout.HORIZONTAL; setPadding(launcher.dpi(8), launcher.dpi(12), launcher.dpi(8), launcher.dpi(12)) }
            val views = mutableMapOf<String, ShapeChip>()
            IconShapes.ids.forEach { id ->
                val chip = ShapeChip(launcher, ui, id, p.iconShape == id)
                chip.setOnClickListener {
                    p.iconShape = id
                    views.forEach { (k, v) -> v.selectedShape = k == id }
                    launcher.haptic(chip, HapticFeedbackConstants.CONTEXT_CLICK)
                    launcher.applyIconChange(); refreshPreview(); stylePicker.refresh()
                }
                views[id] = chip
                shapes.addView(chip, llp(launcher.dpi(54), launcher.dpi(54)).apply { marginEnd = launcher.dpi(2) })
            }
            scroll.addView(shapes)
            custom(scroll)
        }
        b.group("Style", "Themed styles use the app's monochrome icon when it has one, and otherwise find its symbol. ${IconStyles.name("glass", p.fluidGlass)} puts each symbol on a real glass plate.") {
            stylePicker.onPick = { id -> p.iconStyle = id; launcher.applyIconChange(); refreshPreview() }
            custom(stylePicker)
            segmented("Symbol size", listOf("Small", "Medium", "Large"), listOf("small", "medium", "large").indexOf(p.glyphSize).coerceAtLeast(1),
                summary = "For themed, ${IconStyles.name("glass", p.fluidGlass)} and accent styles") {
                p.glyphSize = listOf("small", "medium", "large")[it]; launcher.applyIconChange(); refreshPreview(); stylePicker.refresh()
            }
        }
        b.group("Details") {
            toggle("Icon shadows", "A soft shadow under each icon on the home screen", get = { p.iconShadow }) {
                p.iconShadow = it; launcher.applyIconChange()
            }
            toggle("Wrap older icons", "Places non-adaptive icons on a matching shape", get = { p.normalizeLegacy }) {
                p.normalizeLegacy = it; launcher.applyIconChange(); refreshPreview(); stylePicker.refresh()
            }
            segmented("Plate for older icons", listOf("White", "App colour"), if (p.legacyPlate == "colour") 1 else 0) {
                p.legacyPlate = if (it == 1) "colour" else "white"; launcher.applyIconChange(); refreshPreview(); stylePicker.refresh()
            }
        }
        b.group("Icon pack") {
            val packs = launcher.icons.packs.installedPacks()
            val options = listOf("" to "System icons") + packs.map { it.packageName to it.label }
            choice("Icon pack", options, { p.iconPack }) { pkg ->
                launcher.toast(if (pkg.isEmpty()) "Using system icons" else "Loading icon pack…")
                launcher.setIconPack(pkg) { refreshPreview() }
            }
            if (packs.isEmpty()) info("No icon packs installed. Any ADW / Nova compatible icon pack from the Play Store works.")
        }
        b.group("Size") {
            slider("Icon size", 70, 130, { p.iconScale }, { "$it%" }) { p.iconScale = it; launcher.applyLayoutChange(); refreshPreview() }
            toggle("Show app names", get = { p.showLabels }) { p.showLabels = it; launcher.applyLayoutChange() }
        }
    }
}

/**
 * Horizontal row of icon-style tiles, each showing a real app icon rendered in that style (built in the
 * background so opening the page never stutters).
 */
class StylePicker(private val launcher: MainActivity, private val ui: UiTheme) : android.widget.HorizontalScrollView(launcher) {
    var onPick: ((String) -> Unit)? = null
    private val row = LinearLayout(launcher).apply { orientation = LinearLayout.HORIZONTAL; setPadding(launcher.dpi(10), launcher.dpi(14), launcher.dpi(10), launcher.dpi(10)) }
    private val tiles = HashMap<String, Pair<ImageView, TextView>>()
    private var generation = 0

    init {
        isHorizontalScrollBarEnabled = false
        overScrollMode = OVER_SCROLL_NEVER
        IconStyles.ids.forEach { id ->
            val col = LinearLayout(launcher).apply {
                orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL
                setPadding(launcher.dpi(6), launcher.dpi(6), launcher.dpi(6), launcher.dpi(6))
                isClickable = true
                contentDescription = IconStyles.name(id, launcher.prefs.fluidGlass)
                setOnClickListener {
                    launcher.haptic(it, HapticFeedbackConstants.CONTEXT_CLICK)
                    onPick?.invoke(id); select(id)
                }
            }
            val img = ImageView(launcher)
            col.addView(img, llp(launcher.dpi(54), launcher.dpi(54)))
            val label = launcher.textView(IconStyles.name(id, launcher.prefs.fluidGlass), 12f, ui.textSecondary, Fonts.medium, Gravity.CENTER, maxLines = 1)
            col.addView(label, llp(launcher.dpi(78), WRAP).apply { topMargin = launcher.dpi(6) })
            tiles[id] = img to label
            row.addView(col)
        }
        addView(row)
        refresh()
    }

    fun select(id: String) {
        tiles.forEach { (k, v) ->
            val on = k == id
            v.second.setTextColor(if (on) ui.accent else ui.textSecondary)
            v.second.typeface = if (on) Fonts.semibold else Fonts.medium
            (v.first.parent as View).background = if (on) roundRect(withAlpha(ui.accent, 0.12f), launcher.dp(16f)) else null
        }
    }

    /** Re-renders every tile with the current shape and options. */
    fun refresh() {
        select(launcher.prefs.iconStyle)
        val sample = launcher.previewApps(1).firstOrNull() ?: return
        val gen = ++generation
        val size = launcher.dpi(54)
        IconStyles.ids.forEach { id ->
            sheetExecutor.execute {
                val bmp = try { launcher.icons.forDisplay(launcher.icons.preview(sample, size, IconOverride("style", style = id))) } catch (_: Throwable) { null }
                post { if (gen == generation && bmp != null) tiles[id]?.first?.setImageBitmap(bmp) }
            }
        }
    }
}

/** A selectable icon-shape sample. */
class ShapeChip(context: MainActivity, private val ui: UiTheme, private val shape: String, selected: Boolean) : View(context) {
    var selectedShape = selected
        set(v) { field = v; invalidate() }
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()

    init { isClickable = true; contentDescription = IconShapes.names[shape] }

    override fun onDraw(canvas: Canvas) {
        val s = minOf(width, height) * 0.72f
        IconShapes.path(shape, s, path, (width - s) / 2f, (height - s) / 2f)
        paint.style = Paint.Style.FILL
        paint.color = if (selectedShape) ui.accent else withAlpha(ui.text, 0.18f)
        canvas.drawPath(path, paint)
    }
}

class IconsSheet(launcher: MainActivity) : BottomSheet(launcher, "Icons", dimBackground = false) {
    init {
        IconSettings.build(launcher, SettingsBuilder(launcher, ui, body, ui.chip))
        body.addView(View(launcher), llp(MATCH, launcher.dpi(12)))
    }
}

class LayoutSheet(launcher: MainActivity) : BottomSheet(launcher, "Layout", dimBackground = false) {
    init {
        val p = launcher.prefs
        val b = SettingsBuilder(launcher, ui, body, ui.chip)
        b.group {
            segmented("Columns", listOf("4", "5"), if (p.columns >= 5) 1 else 0) { p.columns = if (it == 1) 5 else 4; launcher.applyLayoutChange() }
            segmented("Rows", listOf("5", "6", "7"), (p.rows - 5).coerceIn(0, 2)) { p.rows = 5 + it; launcher.applyLayoutChange() }
        }
        b.group {
            segmented("Dock", listOf("Clear", "Glass", "Hidden"), listOf("clear", "glass", "off").indexOf(p.dockStyle).coerceAtLeast(0)) {
                p.dockStyle = listOf("clear", "glass", "off")[it]; launcher.applyLayoutChange()
            }
            toggle("Search capsule", get = { p.searchBar }) { p.searchBar = it; launcher.applyLayoutChange() }
        }
        b.group {
            choice("Page transition", listOf("slide" to "Slide", "depth" to "Depth", "cube" to "Cube", "fade" to "Fade", "carousel" to "Carousel"), { p.pageEffect }) {
                p.pageEffect = it; launcher.applyLayoutChange()
            }
            toggle("Lock layout", get = { p.lockLayout }) { p.lockLayout = it }
        }
        body.addView(View(launcher), llp(MATCH, launcher.dpi(12)))
    }
}

/**
 * Per-app icon editor: rename, pick one of several generated styles, choose from any installed icon pack,
 * or use your own image.
 */
class IconEditorSheet(launcher: MainActivity, private val entry: AppEntry) : BottomSheet(launcher, "Edit icon") {
    private val preview = ImageView(launcher)
    private val name = EditText(launcher)

    init {
        val head = LinearLayout(launcher).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL; setPadding(0, launcher.dpi(4), 0, launcher.dpi(12)) }
        head.addView(preview, llp(launcher.dpi(84), launcher.dpi(84)))
        name.apply {
            setText(launcher.apps.label(entry))
            setSelection(text.length)
            textSize = 17f
            typeface = Fonts.medium
            gravity = Gravity.CENTER
            setTextColor(ui.text)
            setSingleLine(true)
            background = roundRect(ui.chip, launcher.dp(14f))
            setPadding(launcher.dpi(14), launcher.dpi(10), launcher.dpi(14), launcher.dpi(10))
            imeOptions = EditorInfo.IME_ACTION_DONE
            hint = entry.systemLabel
            setHintTextColor(ui.textTertiary)
        }
        head.addView(name, llp(launcher.dpi(240), WRAP).apply { topMargin = launcher.dpi(14) })
        body.addView(head, llp(MATCH, WRAP))
        refreshPreview()

        body.addView(launcher.textView("STYLES", 11.5f, ui.textSecondary, Fonts.semibold).apply { letterSpacing = 0.06f; setPadding(launcher.dpi(24), launcher.dpi(4), 0, launcher.dpi(8)) })
        val scroll = HorizontalScrollView(launcher).apply { isHorizontalScrollBarEnabled = false; overScrollMode = View.OVER_SCROLL_NEVER }
        val row = LinearLayout(launcher).apply { orientation = LinearLayout.HORIZONTAL; setPadding(launcher.dpi(16), 0, launcher.dpi(16), 0) }
        val options = listOf<Pair<String, IconOverride?>>("Default" to null) + IconStyles.ids.map { IconStyles.name(it, launcher.prefs.fluidGlass) to IconOverride("style", style = it) }
        options.forEach { (label, override) ->
            val size = launcher.dpi(58)
            val bmp = launcher.icons.forDisplay(launcher.icons.preview(entry, size, override))
            row.addView(option(label, bmp) { launcher.prefs.setIconOverride(entry.key, override); applied() }, llp(launcher.dpi(78), WRAP))
        }
        scroll.addView(row)
        body.addView(scroll)

        val b = SettingsBuilder(launcher, ui, body, ui.chip)
        b.group {
            nav("Choose from icon pack", icon = R.drawable.ic_palette, iconBg = Color.rgb(242, 80, 128)) {
                val packs = launcher.icons.packs.installedPacks()
                when {
                    packs.isEmpty() -> launcher.toast("Install an icon pack from the Play Store first")
                    packs.size == 1 -> { close(); IconPackBrowser(launcher, entry, packs[0]).show() }
                    else -> ChoiceSheet(launcher, "Icon pack", packs.map { it.packageName to it.label }, "") { pkg ->
                        close(); IconPackBrowser(launcher, entry, packs.first { it.packageName == pkg }).show()
                    }.show()
                }
            }
            nav("Choose image", icon = R.drawable.ic_image, iconBg = Color.rgb(146, 92, 255)) {
                close()
                launcher.pickIconImage(entry)
            }
            button("Reset to default", ui.danger) {
                launcher.prefs.setIconOverride(entry.key, null)
                launcher.prefs.setCustomLabel(entry.key, null)
                name.setText(entry.systemLabel)
                applied()
            }
        }
        body.addView(View(launcher), llp(MATCH, launcher.dpi(12)))
    }

    private fun option(label: String, bmp: Bitmap, click: () -> Unit): View {
        val col = LinearLayout(launcher).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(launcher.dpi(4), launcher.dpi(8), launcher.dpi(4), launcher.dpi(8))
            background = pressable(null, ui.cardPressed, launcher.dp(16f))
            isClickable = true
            setOnClickListener { launcher.haptic(it, HapticFeedbackConstants.CONTEXT_CLICK); click() }
            contentDescription = label
        }
        col.addView(ImageView(launcher).apply { setImageBitmap(bmp) }, llp(launcher.dpi(58), launcher.dpi(58)))
        col.addView(launcher.textView(label, 11.5f, ui.textSecondary, Fonts.medium, Gravity.CENTER, maxLines = 1).apply { setPadding(0, launcher.dpi(6), 0, 0) }, llp(MATCH, WRAP))
        return col
    }

    private fun applied() {
        launcher.applyIconChange()
        refreshPreview()
    }

    private fun refreshPreview() = preview.setImageBitmap(launcher.icons.appIconForDisplay(entry, launcher.dpi(84)))

    override fun onClosing() {
        val label = name.text.toString().trim()
        val newLabel = if (label.isEmpty() || label == entry.systemLabel) null else label
        if (newLabel != launcher.prefs.customLabel(entry.key)) {
            launcher.prefs.setCustomLabel(entry.key, newLabel)
            launcher.apps.refresh()
            launcher.drawer.reload()
            launcher.applyIconChange()
        }
        launcher.hideKeyboard(name)
    }
}

/** Searchable grid of every icon in an icon pack. */
class IconPackBrowser(launcher: MainActivity, private val entry: AppEntry, private val packInfo: IconPackManager.PackInfo) :
    BottomSheet(launcher, packInfo.label) {
    private var names: List<String> = emptyList()
    private var shown: List<String> = emptyList()
    private val grid = GridView(launcher)
    private val adapter = object : BaseAdapter() {
        override fun getCount() = shown.size
        override fun getItem(position: Int) = shown[position]
        override fun getItemId(position: Int) = position.toLong()
        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
            val iv = (convertView as? ImageView) ?: ImageView(launcher).apply {
                layoutParams = AbsListView.LayoutParams(MATCH, launcher.dpi(64))
                setPadding(launcher.dpi(6), launcher.dpi(6), launcher.dpi(6), launcher.dpi(6))
                scaleType = ImageView.ScaleType.FIT_CENTER
            }
            val name = shown[position]
            iv.tag = name
            iv.setImageDrawable(null)
            sheetExecutor.execute {
                val d = launcher.icons.packs.pack(packInfo.packageName)?.drawable(name)
                iv.post { if (iv.tag == name) iv.setImageDrawable(d) }
            }
            return iv
        }
    }

    init {
        val search = EditText(launcher).apply {
            hint = "Search icons"
            setHintTextColor(ui.textTertiary)
            setTextColor(ui.text)
            textSize = 15f
            setSingleLine(true)
            background = roundRect(ui.chip, launcher.dp(14f))
            setPadding(launcher.dpi(14), launcher.dpi(10), launcher.dpi(14), launcher.dpi(10))
            addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
                override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { filter(s?.toString().orEmpty()) }
                override fun afterTextChanged(s: Editable?) {}
            })
        }
        body.addView(search, llp(MATCH, WRAP).apply { marginStart = launcher.dpi(16); marginEnd = launcher.dpi(16); bottomMargin = launcher.dpi(8) })
        grid.numColumns = 5
        grid.isNestedScrollingEnabled = true
        grid.adapter = adapter
        grid.isVerticalScrollBarEnabled = false
        grid.selector = transparentDrawable
        grid.setOnItemClickListener { _, _, position, _ ->
            launcher.prefs.setIconOverride(entry.key, IconOverride("pack", pack = packInfo.packageName, drawable = shown[position]))
            launcher.applyIconChange()
            launcher.toast("Icon updated")
            close()
        }
        body.addView(grid, llp(MATCH, (launcher.rootView.height * 0.5f).roundToInt()))
        sheetExecutor.execute {
            val pack = launcher.icons.packs.pack(packInfo.packageName)
            val list = pack?.names().orEmpty()
            grid.post {
                names = list
                // Suggest icons that look related to this app first.
                val hint = launcher.apps.label(entry).lowercase().filter { it.isLetterOrDigit() }
                filter("")
                if (hint.length >= 3) shown = names.sortedByDescending { it.lowercase().contains(hint.take(5)) }
                adapter.notifyDataSetChanged()
            }
        }
    }

    private fun filter(q: String) {
        val lower = q.trim().lowercase()
        shown = if (lower.isEmpty()) names else names.filter { it.lowercase().contains(lower.replace(' ', '_')) }
        adapter.notifyDataSetChanged()
    }
}
