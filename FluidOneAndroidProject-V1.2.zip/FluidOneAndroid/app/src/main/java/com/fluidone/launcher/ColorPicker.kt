package com.fluidone.launcher

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Shader
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import java.util.Locale
import kotlin.math.abs
import kotlin.math.roundToInt

/** A slider over a colour gradient (hue, saturation or brightness) with a round knob showing the colour. */
class ColorTrack(context: android.content.Context, private val colors: () -> IntArray, private val knobColor: () -> Int) : View(context) {
    var value = 0f
        set(v) { field = v.coerceIn(0f, 1f); invalidate() }
    var onChange: ((Float) -> Unit)? = null
    private val track = Paint(Paint.ANTI_ALIAS_FLAG)
    private val knob = Paint(Paint.ANTI_ALIAS_FLAG)
    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; color = Color.WHITE }
    private val shadow = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(50, 0, 0, 0) }
    private val r = RectF()
    private var press = 0f
    private val pressSpring = SpringValue(0f) { press = it; invalidate() }

    init { isClickable = true }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) =
        setMeasuredDimension(MeasureSpec.getSize(widthMeasureSpec), dpi(40))

    override fun onDraw(canvas: Canvas) {
        val h = dp(14f)
        val left = dp(14f); val right = width - dp(14f)
        val cy = height / 2f
        r.set(left, cy - h / 2f, right, cy + h / 2f)
        track.shader = LinearGradient(left, 0f, right, 0f, colors(), null, Shader.TileMode.CLAMP)
        canvas.drawRoundRect(r, h / 2f, h / 2f, track)
        val x = left + (right - left) * value
        val kr = dp(12f) * (1f + 0.22f * press)
        canvas.drawCircle(x, cy + dp(1f), kr, shadow)
        knob.color = knobColor()
        canvas.drawCircle(x, cy, kr, knob)
        ring.strokeWidth = dp(3f)
        canvas.drawCircle(x, cy, kr - dp(1.5f), ring)
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        val left = dp(14f); val right = width - dp(14f)
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> { parent?.requestDisallowInterceptTouchEvent(true); pressSpring.animateTo(1f, 600f, 0.6f) }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> { parent?.requestDisallowInterceptTouchEvent(false); pressSpring.animateTo(0f, 260f, 0.42f) }
        }
        if (event.actionMasked != MotionEvent.ACTION_CANCEL) {
            value = (event.x - left) / (right - left).coerceAtLeast(1f)
            onChange?.invoke(value)
        }
        return true
    }
}

/**
 * Pick any colour: hue, saturation and brightness sliders, a hex field, colours taken from your wallpaper,
 * the system's Material You accent and a few presets. Used for the accent colour and widget backgrounds.
 */
class ColorPickerSheet(
    launcher: MainActivity,
    title: String,
    initial: Int,
    private val onPick: (Int) -> Unit
) : BottomSheet(launcher, title, dimBackground = true) {
    private val hsv = FloatArray(3).also { Color.colorToHSV(initial or 0xFF000000.toInt(), it) }
    private val swatch = View(launcher)
    private val hex = EditText(launcher)
    private lateinit var hue: ColorTrack
    private lateinit var sat: ColorTrack
    private lateinit var value: ColorTrack
    private var updatingHex = false

    private fun current(): Int = Color.HSVToColor(hsv)

    init {
        val col = LinearLayout(launcher).apply { orientation = LinearLayout.VERTICAL; setPadding(launcher.dpi(16), 0, launcher.dpi(16), launcher.dpi(8)) }
        val head = LinearLayout(launcher).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        head.addView(swatch, llp(launcher.dpi(64), launcher.dpi(64)).apply { marginEnd = launcher.dpi(16) })
        hex.apply {
            textSize = 18f; typeface = Fonts.medium; setTextColor(ui.text)
            background = roundRect(ui.chip, launcher.dp(14f))
            setPadding(launcher.dpi(14), launcher.dpi(10), launcher.dpi(14), launcher.dpi(10))
            setSingleLine(true)
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
            imeOptions = EditorInfo.IME_ACTION_DONE
            contentDescription = "Hex colour"
            addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
                override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
                override fun afterTextChanged(s: Editable?) {
                    if (updatingHex) return
                    parseHex(s?.toString().orEmpty())?.let { c -> Color.colorToHSV(c, hsv); refresh(updateHex = false) }
                }
            })
        }
        head.addView(hex, llp(0, launcher.dpi(48), 1f))
        col.addView(head, llp(MATCH, WRAP).apply { bottomMargin = launcher.dpi(12) })

        hue = ColorTrack(launcher, { IntArray(13) { Color.HSVToColor(floatArrayOf(it * 30f, 1f, 1f)) } }, { Color.HSVToColor(floatArrayOf(hsv[0], 1f, 1f)) })
        sat = ColorTrack(launcher, { intArrayOf(Color.HSVToColor(floatArrayOf(hsv[0], 0f, hsv[2])), Color.HSVToColor(floatArrayOf(hsv[0], 1f, hsv[2]))) }, { current() })
        value = ColorTrack(launcher, { intArrayOf(Color.BLACK, Color.HSVToColor(floatArrayOf(hsv[0], hsv[1], 1f))) }, { current() })
        hue.contentDescription = "Hue"; sat.contentDescription = "Saturation"; value.contentDescription = "Brightness"
        hue.onChange = { hsv[0] = it * 360f; refresh() }
        sat.onChange = { hsv[1] = it; refresh() }
        value.onChange = { hsv[2] = it; refresh() }
        listOf("Hue" to hue, "Saturation" to sat, "Brightness" to value).forEach { (label, track) ->
            col.addView(launcher.textView(label, 13f, ui.textSecondary, Fonts.medium).apply { setPadding(launcher.dpi(14), launcher.dpi(6), 0, 0) })
            col.addView(track, llp(MATCH, WRAP))
        }
        body.addView(col)

        val suggestions = suggestedColors()
        body.addView(launcher.textView("SUGGESTED", 11.5f, ui.textSecondary, Fonts.semibold).apply { letterSpacing = 0.06f; setPadding(launcher.dpi(28), launcher.dpi(10), 0, launcher.dpi(8)) })
        val scroll = HorizontalScrollView(launcher).apply { isHorizontalScrollBarEnabled = false; overScrollMode = View.OVER_SCROLL_NEVER }
        val row = LinearLayout(launcher).apply { orientation = LinearLayout.HORIZONTAL; setPadding(launcher.dpi(20), 0, launcher.dpi(20), 0) }
        suggestions.forEach { c ->
            row.addView(View(launcher).apply {
                background = oval(c)
                isClickable = true
                contentDescription = "Colour " + hexOf(c)
                setOnClickListener { Color.colorToHSV(c, hsv); refresh(); launcher.haptic(it, HapticFeedbackConstants.CLOCK_TICK) }
            }, llp(launcher.dpi(38), launcher.dpi(38)).apply { marginEnd = launcher.dpi(10) })
        }
        scroll.addView(row)
        body.addView(scroll)

        val buttons = LinearLayout(launcher).apply { orientation = LinearLayout.HORIZONTAL; setPadding(launcher.dpi(16), launcher.dpi(18), launcher.dpi(16), launcher.dpi(12)) }
        buttons.addView(launcher.textView("Cancel", 16f, ui.text, Fonts.medium, Gravity.CENTER).apply {
            background = pressable(roundRect(ui.chip, launcher.dp(24f)), ui.cardPressed, launcher.dp(24f)); isClickable = true
            setOnClickListener { close() }
        }, llp(0, launcher.dpi(48), 1f).apply { marginEnd = launcher.dpi(10) })
        buttons.addView(launcher.textView("Apply", 16f, ui.onAccent, Fonts.semibold, Gravity.CENTER).apply {
            background = pressable(roundRect(ui.accent, launcher.dp(24f)), ui.cardPressed, launcher.dp(24f)); isClickable = true
            contentDescription = "Apply colour"
            setOnClickListener { launcher.haptic(it, HapticFeedbackConstants.CONFIRM); close(); onPick(current()) }
        }, llp(0, launcher.dpi(48), 1f))
        body.addView(buttons, llp(MATCH, WRAP))
        refresh()
    }

    /** Applies [c] as if picked (tests and accessibility). */
    fun choose(c: Int) { Color.colorToHSV(c, hsv); refresh() }

    fun apply() { close(); onPick(current()) }

    private fun refresh(updateHex: Boolean = true) {
        val c = current()
        swatch.background = roundRect(c, launcher.dp(20f), launcher.dpi(1), withAlpha(ui.text, 0.12f))
        hue.value = hsv[0] / 360f; sat.value = hsv[1]; value.value = hsv[2]
        hue.invalidate(); sat.invalidate(); value.invalidate()
        if (updateHex) { updatingHex = true; hex.setText(hexOf(c)); updatingHex = false }
    }

    private fun suggestedColors(): List<Int> {
        val out = ArrayList<Int>()
        if (android.os.Build.VERSION.SDK_INT >= 31) {
            try { out += launcher.getColor(android.R.color.system_accent1_500); out += launcher.getColor(android.R.color.system_accent3_400) } catch (_: Exception) { }
        }
        launcher.wallpaperView.thumbnailSource()?.let { out += wallpaperColors(it) }
        out += LauncherPrefs.ACCENTS.map { it.second }
        out += listOf(Color.WHITE, Color.rgb(28, 28, 32), Color.rgb(255, 233, 150), Color.rgb(255, 196, 214), Color.rgb(190, 240, 210), Color.rgb(196, 220, 255))
        return out.distinctBy { it or 0xFF000000.toInt() }
    }

    companion object {
        fun hexOf(c: Int) = String.format(Locale.ROOT, "#%06X", c and 0xFFFFFF)

        fun parseHex(s: String): Int? {
            val t = s.trim().removePrefix("#")
            if (t.length != 6 && t.length != 3) return null
            val full = if (t.length == 3) t.map { "$it$it" }.joinToString("") else t
            return full.toLongOrNull(16)?.let { (0xFF000000 or it).toInt() }
        }

        /** A few distinct, lively colours from a wallpaper. */
        fun wallpaperColors(src: Bitmap): List<Int> {
            val small = Bitmap.createScaledBitmap(src, 24, 48, true)
            val buckets = HashMap<Int, IntArray>()   // key -> [count, r, g, b]
            val hsv = FloatArray(3)
            for (y in 0 until small.height) for (x in 0 until small.width) {
                val c = small.getPixel(x, y)
                Color.colorToHSV(c, hsv)
                if (hsv[1] < 0.22f || hsv[2] < 0.25f) continue
                val key = ((hsv[0] / 24f).toInt() shl 4) or (hsv[2] * 3f).toInt()
                val b = buckets.getOrPut(key) { IntArray(4) }
                b[0]++; b[1] += Color.red(c); b[2] += Color.green(c); b[3] += Color.blue(c)
            }
            if (small != src) small.recycle()
            val picked = ArrayList<Int>()
            for (b in buckets.values.sortedWith(Comparator { a, c -> c[0] - a[0] })) {
                val col = Color.rgb(b[1] / b[0], b[2] / b[0], b[3] / b[0])
                Color.colorToHSV(col, hsv)
                val h = hsv[0]
                if (picked.none { p -> val q = FloatArray(3); Color.colorToHSV(p, q); abs(q[0] - h).let { d -> minOf(d, 360f - d) } < 28f }) picked += col
                if (picked.size >= 5) break
            }
            return picked
        }
    }
}

/** Long-press a Fluid One widget › Edit: background (Fluid Glass / Blur, colour or off), tone and options. */
class WidgetStyleSheet(launcher: MainActivity, private val item: HomeItem) : BottomSheet(launcher, Builtins.name(item.builtin), dimBackground = false) {
    private val look = launcher.prefs.widgetLook(item.id, item.builtin)
    private val options = LinearLayout(launcher).apply { orientation = LinearLayout.VERTICAL }

    init {
        val b = SettingsBuilder(launcher, ui, body, ui.chip)
        val glassName = if (launcher.prefs.fluidGlass && FluidGlass.supported) "Fluid Glass" else "Blur"
        val modes = listOf("glass", "color", "off")
        b.group("Background") {
            segmented(null, listOf(glassName, "Colour", "Off"), modes.indexOf(look.bg).coerceAtLeast(0)) {
                look.bg = modes[it]; save(); rebuildOptions()
            }
        }
        body.addView(options, llp(MATCH, WRAP))
        rebuildOptions()
        if (item.builtin == Builtins.CLOCK) b.group("Clock face") {
            val faces = listOf("auto", "classic", "dot")
            segmented(null, listOf("Auto", "Classic", "Dot matrix"), faces.indexOf(look.clock).coerceAtLeast(0),
                summary = "Auto uses the dot matrix face on Nothing phones") { look.clock = faces[it]; save() }
        }
        if (item.builtin == Builtins.NOTE) b.group { nav("Edit note") { close(); (findContent() as? NoteWidget)?.edit() } }
        if (item.builtin == Builtins.PHOTO) b.group { nav("Choose photo") { close(); launcher.pickWidgetPhoto(item) } }
        body.addView(View(launcher), llp(MATCH, launcher.dpi(12)))
    }

    private fun findContent(): View? {
        var found: View? = null
        launcher.workspace.pages.forEach { cl -> cl.childList().forEach { v -> if (v is WidgetFrame && v.item?.id == item.id) found = v.content } }
        return found
    }

    private fun save() {
        launcher.prefs.setWidgetLook(item.id, look)
        launcher.refreshBuiltinWidgets()
    }

    private fun rebuildOptions() {
        options.removeAllViews()
        val b = SettingsBuilder(launcher, ui, options, ui.chip)
        when (look.bg) {
            "glass" -> b.group("Tone") {
                val tones = listOf("auto", "light", "dark")
                segmented(null, listOf("Auto", "Light", "Dark"), tones.indexOf(look.tone).coerceAtLeast(0),
                    summary = "Auto follows your wallpaper") { look.tone = tones[it]; save() }
            }
            "color" -> b.group("Colour") {
                val row = LinearLayout(launcher).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(launcher.dpi(12), launcher.dpi(14), launcher.dpi(12), launcher.dpi(14)) }
                val presets = listOf(Color.WHITE, Color.rgb(28, 28, 32), Color.rgb(255, 233, 150), Color.rgb(255, 196, 214), Color.rgb(190, 240, 210), launcher.prefs.accent)
                presets.forEach { c ->
                    val selected = (look.color or 0xFF000000.toInt()) == (c or 0xFF000000.toInt())
                    val dot = FrameLayout(launcher).apply {
                        background = roundRect(c, launcher.dp(19f), launcher.dpi(if (selected) 3 else 1), if (selected) ui.accent else withAlpha(ui.text, 0.14f))
                        isClickable = true
                        contentDescription = "Colour " + ColorPickerSheet.hexOf(c)
                        setOnClickListener { look.color = c; save(); rebuildOptions() }
                    }
                    row.addView(dotCell(launcher, dot, 4), llp(0, launcher.dpi(38), 1f))
                }
                // A colour picked by hand shows in the custom dot, selected.
                val isCustom = presets.none { (it or 0xFF000000.toInt()) == (look.color or 0xFF000000.toInt()) }
                val custom = FrameLayout(launcher).apply {
                    background = if (isCustom) roundRect(look.color or 0xFF000000.toInt(), launcher.dp(19f), launcher.dpi(3), ui.accent) else rainbow(launcher)
                    isClickable = true
                    contentDescription = "Custom colour"
                    setOnClickListener { ColorPickerSheet(launcher, "Widget colour", look.color) { c -> look.color = c; save(); rebuildOptions() }.show() }
                }
                custom.addView(launcher.iconImage(if (isCustom) R.drawable.ic_check else R.drawable.ic_plus, if (isCustom) inkOn(look.color or 0xFF000000.toInt()) else Color.WHITE, 9), flp(MATCH, MATCH))
                row.addView(dotCell(launcher, custom, 4), llp(0, launcher.dpi(38), 1f))
                custom(row)
            }
        }
    }

    companion object {
        /** A round rainbow swatch for "custom colour" buttons. */
        fun rainbow(launcher: MainActivity): android.graphics.drawable.Drawable {
            val colors = IntArray(7) { Color.HSVToColor(floatArrayOf(it * 60f, 0.85f, 1f)) }
            return android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation.TL_BR, colors).apply {
                shape = android.graphics.drawable.GradientDrawable.OVAL
                gradientType = android.graphics.drawable.GradientDrawable.SWEEP_GRADIENT
            }
        }
    }
}
