package com.fluidone.launcher

import android.app.ActivityManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.PowerManager
import android.provider.Settings
import java.util.Locale

/**
 * Phone makers Fluid One has a dedicated mode for. Each mode switches itself on for its own phones (like
 * Samsung mode) and only that brand's page appears in Settings.
 */
enum class Brand(val key: String, val label: String, val system: String) {
    SAMSUNG("samsung", "Samsung", "One UI"),
    XIAOMI("xiaomi", "Xiaomi", "HyperOS"),
    NOTHING("nothing", "Nothing", "Nothing OS"),
    GOOGLE("google", "Pixel", "Android"),
    ONEPLUS("oneplus", "OnePlus", "OxygenOS"),
    OPPO("oppo", "OPPO", "ColorOS"),
    REALME("realme", "realme", "realme UI"),
    MOTOROLA("motorola", "Motorola", "Hello UI"),
    VIVO("vivo", "vivo", "OriginOS"),
    HONOR("honor", "HONOR", "MagicOS"),
    HUAWEI("huawei", "HUAWEI", "EMUI"),
    SONY("sony", "Xperia", "Xperia UI"),
    ASUS("asus", "ASUS", "ZenUI"),
    OTHER("other", "Android", "Android");

    val modeName: String get() = if (this == OTHER) "Device optimizations" else "$label mode"
    val isOplus: Boolean get() = this == ONEPLUS || this == OPPO || this == REALME

    /** Systems with a separate control centre pulled down from the right side of the status bar. */
    val splitShade: Boolean get() = this == XIAOMI || isOplus || this == VIVO || this == HONOR || this == HUAWEI

    /** Systems known for closing or restricting background apps, where an auto-start/battery exemption helps. */
    val strictBackground: Boolean get() = this == XIAOMI || isOplus || this == VIVO || this == HONOR || this == HUAWEI || this == SAMSUNG

    /** Near-stock Android with Material You colours. */
    val materialYou: Boolean get() = this == GOOGLE || this == MOTOROLA || this == NOTHING || this == SONY || this == ASUS || this == OTHER

    companion object {
        fun detect(manufacturer: String = Build.MANUFACTURER.orEmpty(), brand: String = Build.BRAND.orEmpty()): Brand {
            val m = manufacturer.lowercase(Locale.ROOT).trim()
            val b = brand.lowercase(Locale.ROOT).trim()
            fun any(vararg k: String) = k.any { m.contains(it) || b.contains(it) }
            return when {
                any("samsung") -> SAMSUNG
                any("xiaomi", "redmi", "poco") -> XIAOMI
                m == "nothing" || b == "nothing" || b == "cmf" -> NOTHING
                m == "google" || b == "google" -> GOOGLE
                any("oneplus") -> ONEPLUS
                any("oppo") -> OPPO
                any("realme") -> REALME
                any("motorola") || b == "moto" -> MOTOROLA
                any("vivo", "iqoo") -> VIVO
                any("honor") -> HONOR
                any("huawei") -> HUAWEI
                any("sony") -> SONY
                any("asus") -> ASUS
                else -> OTHER
            }
        }

        /** The brand of this phone (not cached, so tests can change it). */
        val current: Brand get() = detect()
    }
}

/** How much GPU work effects may use. Chosen automatically from the chip and memory unless set by hand. */
enum class Tier { HIGH, BALANCED, LITE }

object Performance {
    private val flagship = listOf(
        "SM8450", "SM8475", "SM8550", "SM8635", "SM8650", "SM8735", "SM8750", "SM8850",   // Snapdragon 8 Gen 1 and newer
        "GS201", "GS301", "ZUMA", "ZUMAPRO", "LAGUNA", "TENSOR",                          // Google Tensor G2 and newer
        "MT6983", "MT6985", "MT6989", "MT6991", "MT6993",                                 // Dimensity 9000 and newer
        "S5E9925", "S5E9945", "S5E9955", "EXYNOS 2200", "EXYNOS 2400", "EXYNOS 2500"      // Exynos 2200 and newer
    )

    fun detect(context: Context): Tier {
        val am = context.getSystemService(ActivityManager::class.java)
        if (am?.isLowRamDevice == true) return Tier.LITE
        val gb = try { ActivityManager.MemoryInfo().also { am?.getMemoryInfo(it) }.totalMem / 1e9 } catch (_: Exception) { 0.0 }
        val soc = if (Build.VERSION.SDK_INT >= 31) try { Build.SOC_MODEL.orEmpty().uppercase(Locale.ROOT) } catch (_: Throwable) { "" } else ""
        val hardware = Build.HARDWARE.orEmpty().uppercase(Locale.ROOT)
        if (flagship.any { soc.startsWith(it) || hardware.startsWith(it) }) return Tier.HIGH
        if (gb in 0.1..4.6) return Tier.LITE
        // A known chip that is not on the flagship list is mid-range, whatever the memory.
        if (soc.isNotBlank() && soc != "UNKNOWN") return Tier.BALANCED
        return if (gb >= 11.5) Tier.HIGH else Tier.BALANCED
    }

    fun label(t: Tier) = when (t) { Tier.HIGH -> "High"; Tier.BALANCED -> "Balanced"; Tier.LITE -> "Lite" }
}

/** Brand-specific system screens. */
object BrandIntents {
    private fun component(pkg: String, cls: String) = Intent().setComponent(ComponentName(pkg, cls))

    /**
     * Where the system lets you exempt an app from battery restrictions / allow auto-start. Tried in order;
     * the generic Android screens come last so there is always somewhere to go.
     */
    fun backgroundSettings(brand: Brand, pkg: String): List<Intent> {
        val list = ArrayList<Intent>()
        when {
            brand == Brand.XIAOMI -> {
                list += component("com.miui.securitycenter", "com.miui.permcenter.autostart.AutoStartManagementActivity")
                list += component("com.miui.powerkeeper", "com.miui.powerkeeper.ui.HiddenAppsConfigActivity")
                    .putExtra("package_name", pkg).putExtra("package_label", "Fluid One")
            }
            brand.isOplus -> {
                list += component("com.coloros.safecenter", "com.coloros.safecenter.permission.startup.StartupAppListActivity")
                list += component("com.coloros.safecenter", "com.coloros.safecenter.startupapp.StartupAppListActivity")
                list += component("com.oplus.safecenter", "com.oplus.safecenter.permission.startup.StartupAppListActivity")
                list += component("com.oneplus.security", "com.oneplus.security.chainlaunch.view.ChainLaunchAppListActivity")
            }
            brand == Brand.VIVO -> {
                list += component("com.vivo.permissionmanager", "com.vivo.permissionmanager.activity.BgStartUpManagerActivity")
                list += component("com.iqoo.secure", "com.iqoo.secure.ui.phoneoptimize.BgStartUpManager")
                list += component("com.iqoo.secure", "com.iqoo.secure.ui.phoneoptimize.AddWhiteListActivity")
            }
            brand == Brand.HUAWEI || brand == Brand.HONOR -> {
                list += component("com.hihonor.systemmanager", "com.hihonor.systemmanager.startupmgr.ui.StartupNormalAppListActivity")
                list += component("com.huawei.systemmanager", "com.huawei.systemmanager.startupmgr.ui.StartupNormalAppListActivity")
                list += component("com.huawei.systemmanager", "com.huawei.systemmanager.optimize.process.ProtectActivity")
            }
            brand == Brand.SAMSUNG -> {
                list += component("com.samsung.android.lool", "com.samsung.android.sm.battery.ui.BatteryActivity")
                list += component("com.samsung.android.sm", "com.samsung.android.sm.ui.battery.BatteryActivity")
            }
        }
        list += Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.fromParts("package", pkg, null))
        list += Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)
        return list.map { it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK) }
    }

    /** Starts the first intent that exists and is allowed. Returns false if none could open. */
    fun launchFirst(context: Context, intents: List<Intent>): Boolean {
        for (i in intents) {
            if (i.resolveActivity(context.packageManager) == null) continue
            try { context.startActivity(i); return true } catch (_: Exception) { }
        }
        return false
    }

    fun ignoresBatteryLimits(context: Context): Boolean =
        try { context.getSystemService(PowerManager::class.java)?.isIgnoringBatteryOptimizations(context.packageName) == true } catch (_: Exception) { false }

    /** The app store to search when Google Play is missing (Huawei, Honor and Xiaomi phones sold in China). */
    fun storeSearch(context: Context, query: String): Intent? {
        val pm = context.packageManager
        val q = Uri.encode(query)
        val candidates = listOf("market://search?q=$q", "appmarket://search?q=$q", "mimarket://search?q=$q", "oppomarket://search?keyword=$q", "vivomarket://search?q=$q")
        for (c in candidates) {
            val i = Intent(Intent.ACTION_VIEW, Uri.parse(c)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            if (i.resolveActivity(pm) != null) return i
        }
        return null
    }
}
