package com.fluidone.launcher

import android.content.Context
import android.content.res.ColorStateList
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.roundToInt

fun Context.dp(v: Float): Float = v * resources.displayMetrics.density
fun Context.dpi(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()
fun Context.dpi(v: Float): Int = (v * resources.displayMetrics.density + 0.5f).toInt()
fun View.dp(v: Float): Float = context.dp(v)
fun View.dpi(v: Int): Int = context.dpi(v)

fun lerp(a: Float, b: Float, t: Float): Float = a + (b - a) * t
fun clamp01(v: Float): Float = v.coerceIn(0f, 1f)

fun withAlpha(color: Int, alpha: Float): Int =
    (color and 0x00FFFFFF) or ((Color.alpha(color) * alpha.coerceIn(0f, 1f)).roundToInt() shl 24)

fun blendColors(a: Int, b: Int, t: Float): Int {
    val f = clamp01(t)
    return Color.argb(
        lerp(Color.alpha(a).toFloat(), Color.alpha(b).toFloat(), f).roundToInt(),
        lerp(Color.red(a).toFloat(), Color.red(b).toFloat(), f).roundToInt(),
        lerp(Color.green(a).toFloat(), Color.green(b).toFloat(), f).roundToInt(),
        lerp(Color.blue(a).toFloat(), Color.blue(b).toFloat(), f).roundToInt()
    )
}

fun luminance(color: Int): Float =
    (0.2126f * Color.red(color) + 0.7152f * Color.green(color) + 0.0722f * Color.blue(color)) / 255f

object Fonts {
    val regular: Typeface = Typeface.create(Typeface.SANS_SERIF, 400, false)
    val medium: Typeface = Typeface.create(Typeface.SANS_SERIF, 500, false)
    val semibold: Typeface = Typeface.create(Typeface.SANS_SERIF, 600, false)
    val bold: Typeface = Typeface.create(Typeface.SANS_SERIF, 700, false)
    val light: Typeface = Typeface.create(Typeface.SANS_SERIF, 300, false)
}

/**
 * [color] nudged just enough to stay visible on a light (or dark) background, so a white or yellow custom accent
 * still reads on white cards and a near-black one on black. Mid colours (every preset) are returned unchanged.
 */
fun readableOn(color: Int, darkBackground: Boolean): Int {
    val base = color or 0xFF000000.toInt()
    var out = base
    var f = 0f
    if (darkBackground) {
        while (luminance(out) < 0.25f && f < 0.95f) { f += 0.05f; out = blendColors(base, Color.WHITE, f) }
        // Pure white would hide white switch knobs.
        while (luminance(out) > 0.86f && f < 0.95f) { f += 0.05f; out = blendColors(base, Color.BLACK, f) }
    } else while (luminance(out) > 0.68f && f < 0.95f) { f += 0.05f; out = blendColors(base, Color.BLACK, f) }
    return out
}

/** Black or white, whichever reads better on [color]. */
fun inkOn(color: Int): Int = if (luminance(color) > 0.62f) Color.BLACK else Color.WHITE

/** Colors for launcher chrome (menus, sheets, settings). Mirrors ColorOS light/dark surfaces. */
class UiTheme(val dark: Boolean, chosenAccent: Int) {
    /** The accent for chrome: the chosen colour, kept readable on this theme's cards. */
    val accent: Int = readableOn(chosenAccent, dark)
    val background = if (dark) Color.rgb(0, 0, 0) else Color.rgb(243, 243, 246)
    val card = if (dark) Color.rgb(28, 28, 30) else Color.WHITE
    val cardPressed = if (dark) Color.rgb(44, 44, 47) else Color.rgb(232, 232, 236)
    val text = if (dark) Color.argb(235, 255, 255, 255) else Color.argb(230, 0, 0, 0)
    val textSecondary = if (dark) Color.argb(140, 255, 255, 255) else Color.argb(138, 0, 0, 0)
    val textTertiary = if (dark) Color.argb(90, 255, 255, 255) else Color.argb(90, 0, 0, 0)
    val divider = if (dark) Color.argb(36, 255, 255, 255) else Color.argb(26, 0, 0, 0)
    val glassTint = if (dark) Color.argb(150, 30, 30, 34) else Color.argb(178, 248, 248, 251)
    val glassStroke = if (dark) Color.argb(40, 255, 255, 255) else Color.argb(90, 255, 255, 255)
    val chip = if (dark) Color.argb(28, 255, 255, 255) else Color.argb(14, 0, 0, 0)
    val switchOff = if (dark) Color.rgb(64, 64, 68) else Color.rgb(219, 219, 224)
    val onAccent = inkOn(accent)
    val danger = Color.rgb(243, 74, 72)
}

fun Context.isSystemDark(): Boolean =
    (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES

fun roundRect(color: Int, radius: Float, strokeWidth: Int = 0, strokeColor: Int = 0): GradientDrawable =
    GradientDrawable().apply {
        setColor(color)
        cornerRadius = radius
        if (strokeWidth > 0) setStroke(strokeWidth, strokeColor)
    }

fun oval(color: Int): GradientDrawable = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(color) }

fun pressable(content: Drawable?, pressedColor: Int, radius: Float): Drawable =
    RippleDrawable(ColorStateList.valueOf(pressedColor), content, roundRect(Color.WHITE, radius))

fun Context.textView(
    value: CharSequence,
    sizeSp: Float,
    color: Int,
    face: Typeface = Fonts.regular,
    gravity: Int = Gravity.START or Gravity.CENTER_VERTICAL,
    maxLines: Int = 0
): TextView = TextView(this).apply {
    text = value
    textSize = sizeSp
    setTextColor(color)
    typeface = face
    includeFontPadding = false
    this.gravity = gravity
    if (maxLines > 0) {
        this.maxLines = maxLines
        ellipsize = TextUtils.TruncateAt.END
    }
}

fun Context.iconImage(res: Int, tint: Int, paddingDp: Int = 0): ImageView = ImageView(this).apply {
    setImageResource(res)
    imageTintList = ColorStateList.valueOf(tint)
    scaleType = ImageView.ScaleType.FIT_CENTER
    val p = dpi(paddingDp)
    setPadding(p, p, p, p)
}

fun lp(w: Int, h: Int): ViewGroup.LayoutParams = ViewGroup.LayoutParams(w, h)
fun flp(w: Int, h: Int, gravity: Int = Gravity.NO_GRAVITY): FrameLayout.LayoutParams = FrameLayout.LayoutParams(w, h, gravity)
fun llp(w: Int, h: Int, weight: Float = 0f): LinearLayout.LayoutParams = LinearLayout.LayoutParams(w, h, weight)

const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

fun View.removeFromParent() {
    (parent as? ViewGroup)?.removeView(this)
}

val transparentDrawable: Drawable get() = ColorDrawable(Color.TRANSPARENT)
