package com.fluidone.launcher

import android.content.Intent
import android.graphics.Color
import android.provider.Settings
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.View
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import kotlin.math.roundToInt

/** Builds ColorOS-style grouped settings rows into a container. Shared by the settings screen and sheets. */
class SettingsBuilder(
    val launcher: MainActivity,
    val ui: UiTheme,
    val container: LinearLayout,
    private val cardColor: Int = ui.card,
    private val sidePadding: Int = launcher.dpi(16)
) {
    fun label(text: String) {
        container.addView(launcher.textView(text, 13f, ui.textSecondary, Fonts.medium).apply {
            setPadding(sidePadding + launcher.dpi(12), launcher.dpi(18), sidePadding, launcher.dpi(8))
        })
    }

    fun group(title: String? = null, footer: String? = null, block: Group.() -> Unit) {
        if (title != null) label(title)
        else container.addView(View(launcher), llp(MATCH, launcher.dpi(12)))
        val box = LinearLayout(launcher).apply {
            orientation = LinearLayout.VERTICAL
            background = roundRect(cardColor, launcher.dp(18f))
            clipToOutline = true
        }
        container.addView(box, llp(MATCH, WRAP).apply { marginStart = sidePadding; marginEnd = sidePadding })
        Group(box).block()
        if (footer != null) container.addView(launcher.textView(footer, 12f, ui.textSecondary).apply {
            setLineSpacing(launcher.dp(2f), 1f)
            setPadding(sidePadding + launcher.dpi(12), launcher.dpi(8), sidePadding + launcher.dpi(12), 0)
        })
    }

    fun view(v: View, marginTop: Int = 12) {
        container.addView(v, llp(MATCH, WRAP).apply { marginStart = sidePadding; marginEnd = sidePadding; topMargin = launcher.dpi(marginTop) })
    }

    inner class Group(val box: LinearLayout) {
        private var rows = 0

        private fun addRow(v: View, hasIcon: Boolean) {
            if (rows > 0) box.addView(View(launcher).apply { setBackgroundColor(ui.divider) }, llp(MATCH, 1).apply {
                marginStart = launcher.dpi(if (hasIcon) 60 else 16); marginEnd = launcher.dpi(16)
            })
            box.addView(v, llp(MATCH, WRAP))
            rows++
        }

        private fun row(icon: Int?, iconBg: Int?, title: String, summary: String?, clickable: Boolean): Pair<LinearLayout, LinearLayout> {
            val row = LinearLayout(launcher).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                minimumHeight = launcher.dpi(if (summary != null) 66 else 54)
                setPadding(launcher.dpi(16), launcher.dpi(10), launcher.dpi(14), launcher.dpi(10))
                if (clickable) { background = pressable(null, ui.cardPressed, 0f); isClickable = true }
            }
            if (icon != null) {
                val chip = FrameLayout(launcher).apply { background = roundRect(iconBg ?: ui.accent, launcher.dp(9f)) }
                chip.addView(launcher.iconImage(icon, Color.WHITE, 6), flp(MATCH, MATCH))
                row.addView(chip, llp(launcher.dpi(30), launcher.dpi(30)).apply { marginEnd = launcher.dpi(14) })
            }
            val texts = LinearLayout(launcher).apply { orientation = LinearLayout.VERTICAL }
            texts.addView(launcher.textView(title, 16f, ui.text, Fonts.regular))
            if (summary != null) texts.addView(launcher.textView(summary, 12.5f, ui.textSecondary).apply {
                setPadding(0, launcher.dpi(3), 0, 0); setLineSpacing(launcher.dp(1.5f), 1f)
            })
            row.addView(texts, llp(0, WRAP, 1f))
            return row to texts
        }

        fun nav(title: String, summary: String? = null, value: String? = null, icon: Int? = null, iconBg: Int? = null, onClick: () -> Unit): TextView? {
            val (row, _) = row(icon, iconBg, title, summary, true)
            var valueView: TextView? = null
            if (value != null) {
                valueView = launcher.textView(value, 14f, ui.textSecondary, maxLines = 1)
                row.addView(valueView, llp(WRAP, WRAP).apply { marginStart = launcher.dpi(8) })
            }
            row.addView(launcher.iconImage(R.drawable.ic_chevron, ui.textTertiary, 0), llp(launcher.dpi(18), launcher.dpi(18)).apply { marginStart = launcher.dpi(4) })
            row.setOnClickListener { launcher.haptic(it, HapticFeedbackConstants.CONTEXT_CLICK); onClick() }
            addRow(row, icon != null)
            return valueView
        }

        fun toggle(title: String, summary: String? = null, icon: Int? = null, iconBg: Int? = null, get: () -> Boolean, set: (Boolean) -> Unit): ColorSwitch {
            val (row, _) = row(icon, iconBg, title, summary, true)
            val sw = ColorSwitch(launcher, ui)
            sw.backdropColor = cardColor
            sw.setChecked(get())
            sw.contentDescription = title
            sw.onChange = { set(it) }
            row.addView(sw, llp(WRAP, WRAP).apply { marginStart = launcher.dpi(10) })
            row.setOnClickListener { sw.setChecked(!sw.isChecked, animate = true, fromUser = true) }
            addRow(row, icon != null)
            return sw
        }

        fun slider(title: String, min: Int, max: Int, get: () -> Int, format: (Int) -> String, summary: String? = null, onChange: ((Int) -> Unit)? = null, onCommit: (Int) -> Unit): FluidSlider {
            val col = LinearLayout(launcher).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(launcher.dpi(16), launcher.dpi(12), launcher.dpi(16), launcher.dpi(6))
            }
            val head = LinearLayout(launcher).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
            head.addView(launcher.textView(title, 16f, ui.text), llp(0, WRAP, 1f))
            val value = launcher.textView(format(get()), 14f, ui.accent, Fonts.medium)
            head.addView(value)
            col.addView(head)
            if (summary != null) col.addView(launcher.textView(summary, 12.5f, ui.textSecondary).apply { setPadding(0, launcher.dpi(3), 0, 0) })
            val slider = FluidSlider(launcher, ui, min, max, get())
            slider.backdropColor = cardColor
            slider.contentDescription = title
            slider.onChange = { value.text = format(it); onChange?.invoke(it) }
            slider.onCommit = { onCommit(it) }
            col.addView(slider, llp(MATCH, WRAP).apply { topMargin = launcher.dpi(4) })
            addRow(col, false)
            return slider
        }

        fun segmented(title: String?, labels: List<String>, selected: Int, summary: String? = null, onSelect: (Int) -> Unit): SegmentedControl {
            val col = LinearLayout(launcher).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(launcher.dpi(16), launcher.dpi(12), launcher.dpi(16), launcher.dpi(14))
            }
            if (title != null) col.addView(launcher.textView(title, 16f, ui.text))
            if (summary != null) col.addView(launcher.textView(summary, 12.5f, ui.textSecondary).apply { setPadding(0, launcher.dpi(3), 0, 0) })
            val seg = SegmentedControl(launcher, ui, labels, selected)
            seg.contentDescription = title
            seg.onSelect = onSelect
            col.addView(seg, llp(MATCH, WRAP).apply { topMargin = launcher.dpi(if (title != null) 10 else 0) })
            addRow(col, false)
            return seg
        }

        fun choice(title: String, options: List<Pair<String, String>>, current: () -> String, icon: Int? = null, iconBg: Int? = null, onPick: (String) -> Unit) {
            var valueView: TextView? = null
            valueView = nav(title, null, options.firstOrNull { it.first == current() }?.second ?: "", icon, iconBg) {
                ChoiceSheet(launcher, title, options, current()) { picked ->
                    onPick(picked)
                    valueView?.text = options.firstOrNull { it.first == picked }?.second ?: ""
                }.show()
            }
        }

        fun info(text: String) {
            val t = launcher.textView(text, 13f, ui.textSecondary).apply {
                setLineSpacing(launcher.dp(3f), 1f)
                setPadding(launcher.dpi(16), launcher.dpi(14), launcher.dpi(16), launcher.dpi(14))
            }
            addRow(t, false)
        }

        fun button(title: String, color: Int = ui.accent, onClick: () -> Unit) {
            val t = launcher.textView(title, 16f, color, Fonts.medium, Gravity.CENTER).apply {
                minHeight = launcher.dpi(54)
                background = pressable(null, ui.cardPressed, 0f)
                isClickable = true
                setOnClickListener { launcher.haptic(it, HapticFeedbackConstants.CONTEXT_CLICK); onClick() }
            }
            addRow(t, false)
        }

        fun custom(v: View) = addRow(v, false)
    }
}

/** Radio list in a bottom sheet. */
class ChoiceSheet(launcher: MainActivity, title: String, options: List<Pair<String, String>>, current: String, onPick: (String) -> Unit) :
    BottomSheet(launcher, title) {
    init {
        val box = LinearLayout(launcher).apply { orientation = LinearLayout.VERTICAL; setPadding(launcher.dpi(12), 0, launcher.dpi(12), launcher.dpi(12)) }
        options.forEach { (value, label) ->
            val row = LinearLayout(launcher).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(launcher.dpi(14), 0, launcher.dpi(14), 0)
                background = pressable(null, ui.cardPressed, launcher.dp(14f))
                isClickable = true
                setOnClickListener {
                    launcher.haptic(it, HapticFeedbackConstants.CONTEXT_CLICK)
                    close()
                    onPick(value)
                }
            }
            row.addView(launcher.textView(label, 16f, if (value == current) ui.accent else ui.text, if (value == current) Fonts.medium else Fonts.regular), llp(0, WRAP, 1f))
            if (value == current) row.addView(launcher.iconImage(R.drawable.ic_check, ui.accent, 0), llp(launcher.dpi(20), launcher.dpi(20)))
            box.addView(row, llp(MATCH, launcher.dpi(54)))
        }
        body.addView(box)
    }
}

/**
 * Full-screen launcher settings in the ColorOS style: large titles that collapse into the toolbar, grouped
 * rounded cards, and pages that slide in from the right.
 */
class SettingsPanel(launcher: MainActivity, private val initialPage: String? = null) : Overlay(launcher) {
    private val ui = launcher.ui
    private val stack = mutableListOf<View>()
    private val pagesHost = FrameLayout(launcher)

    init {
        root.setBackgroundColor(ui.background)
        root.isClickable = true
        root.addView(pagesHost, flp(MATCH, MATCH))
    }

    fun show() {
        launcher.showOverlay(this)
        push(page("Settings", ::mainPage), animate = false)
        initialPage?.let { id -> pageFor(id)?.let { (title, build) -> push(page(title, build), animate = false) } }
        root.alpha = 0f
        root.scaleX = 0.94f; root.scaleY = 0.94f
        val spring = Spring(0.9f, 0.4f)
        root.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(spring.ms).setInterpolator(spring).start()
    }

    private val titles = ArrayList<String>()

    /** The id of the page on top (see [pageFor]), so a theme change can reopen settings right there. */
    fun currentPageId(): String? {
        val title = titles.lastOrNull() ?: return null
        return listOf("layout", "dock", "wallpapers", "icons", "theme", "blur", "glass_advanced", "animations", "gestures", "drawer", "hidden", "search", "device", "about")
            .firstOrNull { pageFor(it)?.first == title }
    }

    private fun page(title: String, build: SettingsBuilder.() -> Unit): View {
        val frame = FrameLayout(launcher).apply { setBackgroundColor(ui.background); isClickable = true }
        frame.tag = title
        val scroll = ScrollView(launcher).apply { isVerticalScrollBarEnabled = false; overScrollMode = View.OVER_SCROLL_IF_CONTENT_SCROLLS }
        val content = LinearLayout(launcher).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, launcher.insetTop + launcher.dpi(56), 0, launcher.insetBottom + launcher.dpi(32))
        }
        val big = launcher.textView(title, 32f, ui.text, Fonts.bold).apply { setPadding(launcher.dpi(28), launcher.dpi(8), launcher.dpi(24), launcher.dpi(4)) }
        content.addView(big)
        SettingsBuilder(launcher, ui, content).build()
        scroll.addView(content, flp(MATCH, WRAP))
        frame.addView(scroll, flp(MATCH, MATCH))
        // Toolbar with a small title that fades in once the large title scrolls away.
        val bar = LinearLayout(launcher).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(launcher.dpi(8), launcher.insetTop, launcher.dpi(16), 0)
            setBackgroundColor(Color.TRANSPARENT)
        }
        val back = launcher.iconImage(R.drawable.ic_back, ui.text, 12).apply {
            background = pressable(null, ui.cardPressed, launcher.dp(24f))
            isClickable = true
            contentDescription = "Back"
            setOnClickListener { onBack() }
        }
        bar.addView(back, llp(launcher.dpi(48), launcher.dpi(48)))
        val small = launcher.textView(title, 18f, ui.text, Fonts.semibold).apply { alpha = 0f }
        bar.addView(small, llp(0, WRAP, 1f).apply { marginStart = launcher.dpi(4) })
        frame.addView(bar, flp(MATCH, launcher.insetTop + launcher.dpi(56)))
        scroll.setOnScrollChangeListener { _, _, y, _, _ ->
            val t = clamp01((y - launcher.dp(20f)) / launcher.dp(40f))
            small.alpha = t
            bar.setBackgroundColor(withAlpha(ui.background, t))
            big.alpha = 1f - t
        }
        return frame
    }

    private fun push(v: View, animate: Boolean = true) {
        val prev = stack.lastOrNull()
        stack.add(v)
        titles.add(v.tag as? String ?: "")
        pagesHost.addView(v, flp(MATCH, MATCH))
        if (!animate) return
        val w = root.width.toFloat().takeIf { it > 0f } ?: launcher.rootView.width.toFloat()
        v.translationX = w
        v.elevation = launcher.dp(6f)
        v.animate().translationX(0f).setDuration(Motion.d(380)).setInterpolator(Motion.move).start()
        prev?.animate()?.translationX(-w * 0.28f)?.alpha(0.6f)?.setDuration(Motion.d(380))?.setInterpolator(Motion.move)?.start()
    }

    private fun pop() {
        val top = stack.removeAt(stack.lastIndex)
        if (titles.isNotEmpty()) titles.removeAt(titles.lastIndex)
        val prev = stack.lastOrNull()
        val w = root.width.toFloat()
        top.animate().translationX(w).setDuration(Motion.d(320)).setInterpolator(Motion.move).withEndAction { top.removeFromParent() }.start()
        prev?.animate()?.translationX(0f)?.alpha(1f)?.setDuration(Motion.d(320))?.setInterpolator(Motion.move)?.start()
    }

    override fun onBack(): Boolean {
        if (stack.size > 1) pop() else close()
        return true
    }

    override fun close(animate: Boolean) {
        if (closing) return
        closing = true
        if (!animate) { finish(); return }
        root.animate().alpha(0f).scaleX(0.96f).scaleY(0.96f).setDuration(Motion.d(200)).setInterpolator(Motion.accel).withEndAction { finish() }.start()
    }

    private fun open(title: String, build: SettingsBuilder.() -> Unit) = push(page(title, build))

    /** Pages that can be opened directly, e.g. from search. */
    private fun pageFor(id: String): Pair<String, SettingsBuilder.() -> Unit>? = when (id) {
        "layout" -> "Layout" to ::layoutPage
        "dock" -> "Dock & search bar" to ::dockPage
        "wallpapers" -> "Wallpapers" to ::wallpaperPage
        "icons" -> "Icons" to ::iconsPage
        "theme" -> "Theme & accent colour" to ::themePage
        "blur" -> "Blur & Fluid Glass" to ::blurPage
        "glass_advanced" -> "Fluid Glass advanced" to ::fluidAdvancedPage
        "animations" -> "Animations" to ::motionPage
        "gestures" -> "Gestures" to ::gesturePage
        "drawer" -> "App drawer" to ::drawerPage
        "hidden" -> "Hidden apps" to ::hiddenPage
        "search" -> "Search" to ::searchPage
        "samsung", "device" -> launcher.brand.modeName to ::brandPage
        "about" -> "About" to ::aboutPage
        else -> null
    }

    // ---- Pages ---------------------------------------------------------------------------------------------

    private fun mainPage(b: SettingsBuilder) = with(b) {
        if (!launcher.isDefaultLauncher()) {
            group {
                nav("Set Fluid One as default home", "Required for app shortcuts and the full experience", icon = R.drawable.ic_home, iconBg = ui.accent) {
                    launcher.startSafely(Intent(Settings.ACTION_HOME_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK), root)
                }
            }
        }
        group("Home screen") {
            nav("Layout", "${launcher.prefs.columns} × ${launcher.prefs.rows} grid · icon size · page effect", icon = R.drawable.ic_grid, iconBg = Color.rgb(64, 132, 255)) { open("Layout", ::layoutPage) }
            nav("Dock & search bar", icon = R.drawable.ic_dock, iconBg = Color.rgb(0, 168, 160)) { open("Dock & search bar", ::dockPage) }
            nav("Edit home screen", "Pages, widgets and wallpapers", icon = R.drawable.ic_widgets, iconBg = Color.rgb(255, 140, 40)) { close(); launcher.enterEditMode() }
        }
        group("Personalization") {
            nav("Wallpapers", icon = R.drawable.ic_wallpaper, iconBg = Color.rgb(146, 92, 255)) { open("Wallpapers", ::wallpaperPage) }
            nav("Icons", "Shape, style, icon packs", icon = R.drawable.ic_palette, iconBg = Color.rgb(242, 80, 128)) { open("Icons", ::iconsPage) }
            nav("Theme & accent colour", icon = R.drawable.ic_tune, iconBg = Color.rgb(90, 98, 120)) { open("Theme & accent colour", ::themePage) }
        }
        group("Effects") {
            nav("Blur & Fluid Glass", if (launcher.prefs.fluidGlass && FluidGlass.supported) "Fluid Glass on · ${launcher.prefs.fluidIntensity}%" else "Real wallpaper blur for dock, folders and menus",
                icon = R.drawable.ic_blur, iconBg = Color.rgb(32, 160, 230)) { open("Blur & Fluid Glass", ::blurPage) }
            nav("Animations", "App open & close, unlock, speed", icon = R.drawable.ic_animation, iconBg = Color.rgb(255, 98, 72)) { open("Animations", ::motionPage) }
        }
        group("Navigation") {
            nav("Gestures", icon = R.drawable.ic_gesture, iconBg = Color.rgb(52, 186, 110)) { open("Gestures", ::gesturePage) }
            nav("App drawer", icon = R.drawable.ic_apps, iconBg = Color.rgb(70, 110, 240)) { open("App drawer", ::drawerPage) }
            nav("Search", "Apps, contacts, settings, calculator and more", icon = R.drawable.ic_search, iconBg = Color.rgb(20, 150, 120)) { open("Search", ::searchPage) }
        }
        group("Device") {
            nav(launcher.brand.modeName, when {
                !launcher.brandModeOn() -> "Off"
                launcher.s25On() -> "On · S25 Ultra optimizations on"
                else -> "On"
            }, icon = R.drawable.ic_device, iconBg = Color.rgb(20, 40, 160)) { open(launcher.brand.modeName, ::brandPage) }
            nav("About Fluid One", icon = R.drawable.ic_info, iconBg = Color.rgb(120, 126, 140)) { open("About", ::aboutPage) }
        }
    }

    private fun layoutPage(b: SettingsBuilder) = with(b) {
        val p = launcher.prefs
        group("Grid") {
            segmented("Columns", listOf("4", "5"), if (p.columns >= 5) 1 else 0) { p.columns = if (it == 1) 5 else 4; launcher.applyLayoutChange() }
            segmented("Rows", listOf("5", "6", "7"), (p.rows - 5).coerceIn(0, 2)) { p.rows = 5 + it; launcher.applyLayoutChange() }
        }
        group("Icons") {
            slider("Icon size", 70, 130, { p.iconScale }, { "$it%" }) { p.iconScale = it; launcher.applyLayoutChange() }
            toggle("Show app names", get = { p.showLabels }) { p.showLabels = it; launcher.applyLayoutChange() }
            slider("Name size", 10, 15, { p.labelSize }, { "${it}sp" }) { p.labelSize = it; launcher.applyLayoutChange() }
        }
        group("Pages") {
            choice("Page transition", listOf("slide" to "Slide", "depth" to "Depth", "cube" to "Cube", "fade" to "Fade", "carousel" to "Carousel"), { p.pageEffect }) {
                p.pageEffect = it; launcher.applyLayoutChange()
            }
            toggle("Lock home screen layout", "Prevents icons and widgets from being moved or removed", get = { p.lockLayout }) { p.lockLayout = it }
            toggle("Add new apps to home screen", get = { p.addNewApps }) { p.addNewApps = it }
        }
    }

    private fun dockPage(b: SettingsBuilder) = with(b) {
        val p = launcher.prefs
        group("Dock", "The dock always sizes itself to the apps you put in it.") {
            segmented("Style", listOf("Clear", "Glass", "Hidden"), listOf("clear", "glass", "off").indexOf(p.dockStyle).coerceAtLeast(0)) {
                p.dockStyle = listOf("clear", "glass", "off")[it]; launcher.applyLayoutChange()
            }
            toggle("Show app names in dock", get = { p.dockLabels }) { p.dockLabels = it; launcher.applyLayoutChange() }
        }
        group("Search bar") {
            toggle("Search capsule above dock", "Shows page dots while you swipe between pages", get = { p.searchBar }) { p.searchBar = it; launcher.applyLayoutChange() }
        }
    }

    private fun wallpaperPage(b: SettingsBuilder) = with(b) {
        view(WallpaperPicker(launcher, ui).view, 8)
        group {
            toggle("Also use on lock screen", "Matching wallpapers make the unlock zoom seamless", get = { launcher.prefs.lockWallpaper }) {
                launcher.prefs.lockWallpaper = it
                if (it) launcher.applyLockWallpaper()
            }
            toggle("Wallpaper parallax", "Wallpaper drifts gently as you change pages", get = { launcher.prefs.parallax }) {
                launcher.prefs.parallax = it; launcher.applyLayoutChange()
            }
        }
    }

    private fun iconsPage(b: SettingsBuilder) = with(b) { IconSettings.build(launcher, this) }

    private fun themePage(b: SettingsBuilder) = with(b) {
        val p = launcher.prefs
        group("Appearance", "Menus, folders and settings follow this theme.") {
            segmented(null, listOf("System", "Light", "Dark"), listOf("system", "light", "dark").indexOf(p.theme).coerceAtLeast(0)) {
                p.theme = listOf("system", "light", "dark")[it]
                launcher.applyThemeChange()
            }
        }
        group("Accent colour") {
            val row = LinearLayout(launcher).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(launcher.dpi(12), launcher.dpi(16), launcher.dpi(12), launcher.dpi(16))
            }
            LauncherPrefs.ACCENTS.forEach { (name, color) ->
                val selected = p.accent == color
                val dot = FrameLayout(launcher).apply {
                    background = oval(color)
                    contentDescription = name
                    isClickable = true
                    setOnClickListener {
                        p.accent = color
                        p.systemAccent = false
                        launcher.haptic(it, HapticFeedbackConstants.CONTEXT_CLICK)
                        launcher.applyThemeChange()
                    }
                }
                if (selected) dot.addView(launcher.iconImage(R.drawable.ic_check, Color.WHITE, 6), flp(MATCH, MATCH))
                row.addView(dotCell(launcher, dot), llp(0, launcher.dpi(36), 1f))
            }
            // Any colour at all: a rainbow dot opens the colour picker. A custom accent shows in it.
            val isCustom = LauncherPrefs.ACCENTS.none { it.second == p.accent }
            val customDot = FrameLayout(launcher).apply {
                background = if (!isCustom) WidgetStyleSheet.rainbow(launcher) else oval(p.accent).apply {
                    // A white (or black) accent would vanish into the card without a hairline.
                    if (kotlin.math.abs(luminance(p.accent) - luminance(ui.card)) < 0.2f) setStroke(launcher.dpi(1), withAlpha(ui.text, 0.22f))
                }
                contentDescription = "Custom accent colour"
                isClickable = true
                setOnClickListener {
                    launcher.haptic(it, HapticFeedbackConstants.CONTEXT_CLICK)
                    ColorPickerSheet(launcher, "Accent colour", p.accent) { c ->
                        p.accent = c; p.systemAccent = false
                        launcher.applyThemeChange()
                    }.show()
                }
            }
            customDot.addView(launcher.iconImage(if (isCustom) R.drawable.ic_check else R.drawable.ic_plus, if (isCustom) inkOn(p.accent) else Color.WHITE, 7), flp(MATCH, MATCH))
            row.addView(dotCell(launcher, customDot), llp(0, launcher.dpi(36), 1f))
            custom(row)
        }
    }

    private fun blurPage(b: SettingsBuilder) = with(b) {
        val p = launcher.prefs
        val preview = FluidGlassPreview(launcher)
        view(preview, 8)
        var intensity: View? = null
        fun refreshFluid(animate: Boolean) {
            val on = p.fluidGlass && FluidGlass.supported
            val v = intensity ?: return
            setEnabledDeep(v, on)
            if (animate) v.animate().alpha(if (on) 1f else 0.4f).setDuration(180).start() else v.alpha = if (on) 1f else 0.4f
        }
        group("Fluid Glass", if (FluidGlass.supported)
            "Drag the lens and tap the bar to try it. Buttons, the search bar, folders, menus, sheets, switches and sliders all use this glass."
            else "Fluid Glass needs Android 13 or newer. Frosted glass is used instead.") {
            toggle("Fluid Glass", "Liquid glass with curved, light-catching edges", get = { p.fluidGlass && FluidGlass.supported }) {
                p.fluidGlass = it; launcher.invalidateGlass(); preview.invalidate(); refreshFluid(true)
            }.also { if (!FluidGlass.supported) setEnabledDeep(it, false) }
            val s = slider("Fluid Glass intensity", 0, 100, { p.fluidIntensity }, { "$it%" }, summary = "Left: frosted blur · Right: clear liquid glass",
                onChange = { p.fluidIntensity = it; launcher.invalidateGlass(); preview.invalidate() }) {
                p.fluidIntensity = it; launcher.invalidateGlass(); preview.invalidate()
            }
            intensity = s.parent as? View
            nav("Advanced", "Edge curve, depth, zoom, softness, rim light and more") { open("Fluid Glass advanced", ::fluidAdvancedPage) }
        }
        refreshFluid(false)
        view(BlurPreview(launcher), 18)
        group("Glass", "Fluid One blurs the wallpaper itself, so glass works even when One UI's system blur is off (power saving, Reduce transparency).") {
            slider("Blur strength", 0, 100, { p.blurStrength }, { "$it" }, onChange = { p.blurStrength = it; launcher.scheduleBlurRebuild() }) {
                p.blurStrength = it; launcher.scheduleBlurRebuild()
            }
            slider("Glass tint", 0, 100, { p.glassTint }, { "$it%" }, onChange = { p.glassTint = it; launcher.invalidateGlass() }) {
                p.glassTint = it; launcher.invalidateGlass()
            }
        }
        group("Live blur") {
            toggle("Blur home behind menus", "GPU blur of icons and widgets behind folders, menus and the drawer", get = { p.liveBlur }) { p.liveBlur = it }
        }
        if (Device.samsungReduceTransparency(launcher)) group {
            info("One UI's \"Reduce transparency and blur\" is on. Fluid One's own blur still works; live blur of icons is reduced to keep things smooth.")
        }
    }

    /** Fine control over the Fluid Glass optics, with a live preview and a reset. */
    private fun fluidAdvancedPage(b: SettingsBuilder) = with(b) {
        val p = launcher.prefs
        val preview = FluidGlassPreview(launcher)
        view(preview, 8)
        fun changed() { launcher.invalidateGlass(); preview.invalidate() }
        val sliders = ArrayList<Pair<FluidSlider, () -> Int>>()
        fun SettingsBuilder.Group.knob(title: String, summary: String, get: () -> Int, set: (Int) -> Unit) {
            sliders += slider(title, 0, 100, get, { "$it" }, summary = summary, onChange = { set(it); changed() }) { set(it); changed() } to get
        }
        group("Shape", "Drag the lens in the preview to see each change.") {
            knob("Edge curve", "How far the rounded edge reaches in. More curve, more liquid", { p.fgEdge }) { p.fgEdge = it }
            knob("Depth", "How strongly the curved edge bends what is behind it", { p.fgDepth }) { p.fgDepth = it }
            knob("Zoom", "How much the middle of the glass magnifies", { p.fgZoom }) { p.fgZoom = it }
        }
        group("Light") {
            knob("Softness", "A touch of blur even at full intensity", { p.fgSoftness }) { p.fgSoftness = it }
            knob("Rim light", "The bright outline that catches light", { p.fgRim }) { p.fgRim = it }
            knob("Edge shadow", "The thin line inside the rim that gives the glass thickness", { p.fgShadow }) { p.fgShadow = it }
            knob("Colour split", "Rainbow fringes where the edge bends light", { p.fgDispersion }) { p.fgDispersion = it }
        }
        group("Motion & performance", "Auto uses ${Performance.label(launcher.detectedTier)} on this phone.") {
            toggle("Liquid press animations", "Glass swells toward your finger and wobbles when let go", get = { p.fgPress }) { p.fgPress = it }
            val q = listOf("auto", "high", "balanced", "lite")
            segmented("Effects quality", listOf("Auto", "High", "Balanced", "Lite"), q.indexOf(p.effectsQuality).coerceAtLeast(0),
                summary = "Lower quality uses fewer samples per pixel and a lighter live blur") {
                p.effectsQuality = q[it]; changed()
            }
        }
        group {
            button("Reset Fluid Glass settings", ui.danger) {
                FluidDialog(launcher, "Reset Fluid Glass?", "Edge curve, depth, zoom, softness, rim light, edge shadow, colour split, quality and press animations go back to their defaults.", "Reset", destructive = true) {
                    p.resetFluidAdvanced()
                    sliders.forEach { (sl, get) -> sl.setValue(get()); sl.onChange?.invoke(get()) }
                    changed()
                    launcher.toast("Fluid Glass reset")
                }.show()
            }
        }
    }

    private fun motionPage(b: SettingsBuilder) = with(b) {
        val p = launcher.prefs
        group("Opening & closing apps", "Zoom and Reveal are played by Android itself, so apps never open later because of them. Fade and Fluid morph are custom animations that some Android 13+ phones replace with their own.") {
            toggle("App open & close animations", "Turn off to use your phone's default animations", get = { p.launchAnimations }) { p.launchAnimations = it }
            choice("App open animation", listOf("zoom" to "Zoom from icon", "reveal" to "Reveal from icon", "fade" to "Fade", "morph" to "Fluid morph (classic)", "system" to "System default"), { p.launchAnim }) { p.launchAnim = it }
            toggle("Shrink back into icon", "When you return home the screen zooms back to the app's icon", get = { p.returnAnim }) { p.returnAnim = it }
        }
        group("Unlock", "How the apps arrive when you unlock the phone.") {
            choice("Unlock animation", listOf("gather" to "Fluid One", "coloros" to "ColorOS", "oneui" to "One UI", "hyperos" to "HyperOS",
                "rise" to "Pixel", "ripple" to "Ripple", "zoom" to "Zoom", "off" to "Off"), { p.unlockAnim }) { p.unlockAnim = it }
            button("Preview unlock animation") { close(); launcher.rootView.postDelayed({ launcher.previewUnlock() }, 260) }
        }
        group("Speed") {
            slider("Animation speed", 60, 160, { (10000 / p.animSpeed.coerceAtLeast(1)).coerceIn(60, 160) }, { "${it}%" }, summary = "100% matches ColorOS timing. Higher is faster.") {
                p.animSpeed = (10000 / it).coerceIn(62, 167); launcher.applyMotionSpeed()
            }
        }
        val scale = Device.animatorScale(launcher)
        if (scale != 1f) group {
            info(if (scale == 0f) "System animations are turned off (Remove animations / animator scale 0×). Fluid One's animations can't play until they're turned back on."
                 else "System animator scale is ${scale}×, which changes every animation's speed.")
            button("Open accessibility settings") { launcher.startSafely(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK), root) }
        }
    }

    private fun gesturePage(b: SettingsBuilder) = with(b) {
        val p = launcher.prefs
        group {
            choice("Swipe up", listOf("drawer" to "App drawer", "search" to "Search", "none" to "Nothing"), { p.swipeUp }) { p.swipeUp = it }
            choice("Swipe down", listOf("notifications" to "Notifications", "search" to "Search", "none" to "Nothing"), { p.swipeDown }) { p.swipeDown = it }
            choice("Pinch in", listOf("edit" to "Edit home screen", "none" to "Nothing"), { p.pinchIn }) { p.pinchIn = it }
        }
        group {
            toggle("Haptic feedback", get = { p.haptics }) { p.haptics = it }
        }
    }

    private fun drawerPage(b: SettingsBuilder) = with(b) {
        val p = launcher.prefs
        group {
            segmented("Columns", listOf("4", "5"), if (p.drawerColumns >= 5) 1 else 0) { p.drawerColumns = if (it == 1) 5 else 4; launcher.drawer.reload() }
            toggle("Open keyboard automatically", get = { p.drawerKeyboard }) { p.drawerKeyboard = it }
        }
        group {
            nav("Hidden apps", "${p.hiddenApps.size} hidden") { open("Hidden apps", ::hiddenPage) }
        }
    }

    private fun searchPage(b: SettingsBuilder) = with(b) {
        val p = launcher.prefs
        group {
            val row = LinearLayout(launcher).apply {
                orientation = LinearLayout.HORIZONTAL
                setPadding(launcher.dpi(16), launcher.dpi(16), launcher.dpi(16), launcher.dpi(16))
            }
            val chip = FrameLayout(launcher).apply { background = roundRect(Color.rgb(20, 150, 120), launcher.dp(10f)) }
            chip.addView(launcher.iconImage(R.drawable.ic_shield, Color.WHITE, 7), flp(MATCH, MATCH))
            row.addView(chip, llp(launcher.dpi(34), launcher.dpi(34)).apply { marginEnd = launcher.dpi(14) })
            val texts = LinearLayout(launcher).apply { orientation = LinearLayout.VERTICAL }
            texts.addView(launcher.textView("Private by design", 16f, ui.text, Fonts.medium))
            texts.addView(launcher.textView("Search runs entirely on your phone. Fluid One has no internet access and never uploads, sells or shares your contacts, calendar, searches or any other data with third parties. Web searches only start when you tap one, in your own browser.",
                13f, ui.textSecondary).apply { setPadding(0, launcher.dpi(4), 0, 0); setLineSpacing(launcher.dp(2.5f), 1f) })
            row.addView(texts, llp(0, WRAP, 1f))
            custom(row)
        }
        var contactsSwitch: ColorSwitch? = null
        var calendarSwitch: ColorSwitch? = null
        fun permissionSummary(perm: String, what: String) =
            if (launcher.hasPermission(perm)) "On this phone only · access allowed" else "Needs access to your $what (asked with a privacy notice)"
        group("Search in", "Apps are always searched. Turning a source on asks for access only if it's needed.") {
            contactsSwitch = toggle("Contacts", permissionSummary(android.Manifest.permission.READ_CONTACTS, "contacts"), get = { p.searchContacts }) { on ->
                p.searchContacts = on
                if (on) launcher.requestWithPrivacy(listOf(android.Manifest.permission.READ_CONTACTS to "contacts"), "Find people and call or message them right from search.") { granted ->
                    if (!granted) { p.searchContacts = false; contactsSwitch?.setChecked(false, animate = true) }
                }
            }
            calendarSwitch = toggle("Calendar events", permissionSummary(android.Manifest.permission.READ_CALENDAR, "calendar"), get = { p.searchCalendar }) { on ->
                p.searchCalendar = on
                if (on) launcher.requestWithPrivacy(listOf(android.Manifest.permission.READ_CALENDAR to "calendar"), "Find your upcoming events right from search.") { granted ->
                    if (!granted) { p.searchCalendar = false; calendarSwitch?.setChecked(false, animate = true) }
                }
            }
            toggle("App shortcuts", if (launcher.isDefaultLauncher()) "Actions inside apps, like \"New message\"" else "Works when Fluid One is your default home app", get = { p.searchShortcuts }) { p.searchShortcuts = it }
            toggle("Settings", "Android settings and Fluid One's own settings and wallpapers", get = { p.searchSettings }) { p.searchSettings = it }
            toggle("Calculator & conversions", "Type 12*7, 15% of 80 or 10 km to mi", get = { p.searchCalc }) { p.searchCalc = it }
            toggle("Quick actions", "Call numbers, open links, start timers, set alarms, flashlight", get = { p.searchActions }) { p.searchActions = it }
            toggle("Web, Play Store, YouTube & Maps", "Shortcut buttons that open your search in those apps", get = { p.searchWeb }) { p.searchWeb = it }
        }
        group("Suggestions") {
            toggle("Suggested apps", "Your most used apps when the search is empty", get = { p.searchSuggest }) { p.searchSuggest = it }
            toggle("Remember recent searches", "Stored only on this phone", get = { p.searchKeepHistory }) {
                p.searchKeepHistory = it
                if (!it) p.searchHistory = emptyList()
            }
            button("Clear search history") { p.searchHistory = emptyList(); launcher.toast("Search history cleared") }
        }
        group {
            nav("App permissions", "See or change what Fluid One can access") {
                launcher.startSafely(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, android.net.Uri.fromParts("package", launcher.packageName, null)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK), root)
            }
        }
    }

    private fun hiddenPage(b: SettingsBuilder) = with(b) {
        group(footer = "Hidden apps disappear from the app drawer and search. They stay installed.") {
            launcher.apps.apps.forEach { entry ->
                val (row, _) = run {
                    val r = LinearLayout(launcher).apply {
                        orientation = LinearLayout.HORIZONTAL
                        gravity = Gravity.CENTER_VERTICAL
                        setPadding(launcher.dpi(16), launcher.dpi(8), launcher.dpi(14), launcher.dpi(8))
                    }
                    val icon = ImageView(launcher).apply { setImageBitmap(launcher.icons.appIconForDisplay(entry, launcher.dpi(36))) }
                    r.addView(icon, llp(launcher.dpi(36), launcher.dpi(36)).apply { marginEnd = launcher.dpi(14) })
                    r.addView(launcher.textView(launcher.apps.label(entry), 16f, ui.text, maxLines = 1), llp(0, WRAP, 1f))
                    r to icon
                }
                val sw = ColorSwitch(launcher, ui)
                sw.setChecked(entry.key in launcher.prefs.hiddenApps)
                sw.onChange = { hide ->
                    val set = launcher.prefs.hiddenApps.toMutableSet()
                    if (hide) set.add(entry.key) else set.remove(entry.key)
                    launcher.prefs.hiddenApps = set
                    launcher.drawer.reload()
                }
                row.addView(sw)
                row.isClickable = true
                row.setOnClickListener { sw.setChecked(!sw.isChecked, animate = true, fromUser = true) }
                custom(row)
            }
        }
    }

    /**
     * The brand mode page: only the mode for this phone's maker is shown. Every mode switches itself on for
     * its own phones and holds optimizations that make sense for that system.
     */
    private fun brandPage(b: SettingsBuilder) = with(b) {
        val p = launcher.prefs
        val brand = launcher.brand
        val isS25 = Device.isS25Ultra()
        var optGroup: View? = null
        var s25Master: View? = null
        var s25Group: View? = null
        fun modeOn() = launcher.brandModeOn()

        fun refresh(animate: Boolean) {
            val on = modeOn()
            val s25Available = on && brand == Brand.SAMSUNG && isS25
            val s25On = s25Available && p.s25Optimizations
            listOf(optGroup to on, s25Master to s25Available, s25Group to s25On).forEach { (v, enabled) ->
                v ?: return@forEach
                setEnabledDeep(v, enabled)
                if (animate) v.animate().alpha(if (enabled) 1f else 0.4f).setDuration(180).start() else v.alpha = if (enabled) 1f else 0.4f
            }
        }

        val model = "${android.os.Build.MANUFACTURER.replaceFirstChar { it.uppercase() }} ${android.os.Build.MODEL}".trim()
        group(footer = when (brand) {
            Brand.SAMSUNG -> if (isS25) "Galaxy S25 Ultra detected: Samsung and S25 Ultra optimizations are both available." else "Samsung Galaxy detected ($model)."
            Brand.OTHER -> "$model detected. These optimizations work on any Android phone."
            else -> "$model detected. ${brand.modeName} tunes Fluid One for ${brand.system}. It turned on by itself."
        }) {
            toggle(brand.modeName, when (brand) {
                Brand.SAMSUNG -> "Optimizations for One UI on every Galaxy device"
                Brand.OTHER -> "Device-specific tuning for smoother effects and gestures"
                else -> "Optimizations for ${brand.system} on ${brand.label} phones"
            }, get = { modeOn() }) {
                if (brand == Brand.SAMSUNG) p.samsungMode = it else p.brandMode = it
                launcher.applyDeviceTuning()
                launcher.applyIconChange()
                launcher.invalidateGlass()
                refresh(true)
            }
        }
        group("Optimizations") {
            optGroup = box
            toggle("High refresh rate on home", "Asks for the screen's top refresh rate (up to ${Device.maxRefreshRate(launcher).roundToInt()} Hz) while the home screen is open",
                get = { p.highRefresh }) { p.highRefresh = it; launcher.applyDeviceTuning() }
            toggle("Edge-safe dragging", "Stops the system back gesture from grabbing icons dragged near the screen edges",
                get = { p.gestureGuard }) { p.gestureGuard = it }
            toggle("Battery-aware effects", "Lighter effects while ${if (brand == Brand.OTHER) "battery saver" else brand.system + " power saving"} is on; wallpaper glass stays",
                get = { p.batteryBlur }) { p.batteryBlur = it; launcher.invalidateGlass() }
            if (brand.splitShade || brand == Brand.OTHER) toggle("Split swipe down",
                "Swipe down on the left for notifications, on the right for ${if (brand == Brand.XIAOMI) "Control Center" else "quick settings"}, like ${brand.system}",
                get = { p.splitShade }) { p.splitShade = it }
            if (brand.materialYou && android.os.Build.VERSION.SDK_INT >= 31) {
                toggle("Material You colours", "The accent colour follows your system colours", get = { p.systemAccent }) {
                    p.systemAccent = it; launcher.applyDeviceTuning()
                }
            }
            if (brand.materialYou) toggle("Themed icons follow dark mode", "Dark and Light icon styles switch with the system theme",
                get = { p.autoThemedIcons }) { p.autoThemedIcons = it; launcher.applyIconChange() }
            if (brand == Brand.NOTHING) {
                toggle("Dot-matrix clock", "The Clock & date widget in Nothing's dot style", get = { p.dotClock }) {
                    p.dotClock = it; launcher.refreshBuiltinWidgets()
                }
                button("Apply Nothing look") {
                    p.iconStyle = "mono"; p.accent = Color.rgb(215, 25, 32); p.dotClock = true; p.systemAccent = false
                    launcher.applyThemeChange(); launcher.refreshBuiltinWidgets()
                    launcher.toast("Monochrome icons, red accent and dot clock applied")
                }
            }
            if (brand.strictBackground) nav("Keep Fluid One running",
                if (BrandIntents.ignoresBatteryLimits(launcher)) "No battery restrictions" else "Allow auto-start and remove battery limits so ${brand.system} never closes your home screen") {
                if (!BrandIntents.launchFirst(launcher, BrandIntents.backgroundSettings(brand, launcher.packageName))) launcher.toast("This phone has no such setting")
            }
        }
        if (brand == Brand.SAMSUNG) {
            group("Galaxy S25 Ultra") {
                s25Master = box
                toggle("S25 Ultra optimizations", if (isS25) "Extra tuning for the S25 Ultra's S Pen and display" else "Only available on a Galaxy S25 Ultra",
                    get = { p.s25Optimizations && isS25 }) { p.s25Optimizations = it; refresh(true) }
            }
            group {
                s25Group = box
                toggle("S Pen hover", "Icons lift when the S Pen hovers over them", get = { p.spenHover }) { p.spenHover = it }
                toggle("S Pen button menus", "Press the S Pen button while hovering an icon to open its menu", get = { p.spenButton }) { p.spenButton = it }
                button("Apply S25 Ultra layout (4 × 6, 100% icons)") {
                    p.columns = 4; p.rows = 6; p.iconScale = 100; p.labelSize = 12
                    launcher.applyLayoutChange()
                    launcher.toast("Layout applied")
                }
            }
        }
        refresh(false)
        group("Diagnostics") {
            info(Device.description(launcher) + "\nEffects: ${Performance.label(launcher.effectsTier())} (chip rated ${Performance.label(launcher.detectedTier)})")
        }
    }

    private fun aboutPage(b: SettingsBuilder) = with(b) {
        group {
            info("Fluid One ${launcher.versionName()}\nA ColorOS-inspired home screen for Android 12 and newer, tuned for Samsung Galaxy phones and the Galaxy S25 Ultra.")
        }
        group("Privacy") {
            info("Fluid One has no internet access. Everything it reads to search or show widgets (apps, contacts, calendar) stays on this phone and is never shared with third parties.")
        }
        group {
            nav("Default home app", if (launcher.isDefaultLauncher()) "Fluid One" else "Not set") {
                launcher.startSafely(Intent(Settings.ACTION_HOME_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK), root)
            }
        }
        group {
            button("Reset home screen layout", ui.danger) {
                FluidDialog(launcher, "Reset layout?", "Your pages, folders, dock and widgets go back to the default layout. Apps stay installed.", "Reset", destructive = true) {
                    close(); launcher.resetLayout()
                }.show()
            }
            button("Reset appearance settings", ui.danger) {
                FluidDialog(launcher, "Reset appearance?", "Blur, icons, animations and layout settings return to their defaults.", "Reset", destructive = true) {
                    launcher.prefs.resetAppearance(); close(); launcher.applyEverything()
                }.show()
            }
        }
    }
}

private fun setEnabledDeep(v: View, enabled: Boolean) {
    v.isEnabled = enabled
    if (v is android.view.ViewGroup) for (i in 0 until v.childCount) setEnabledDeep(v.getChildAt(i), enabled)
}

/** A live sample of the glass effect on the blur settings page. */
class BlurPreview(launcher: MainActivity) : FrameLayout(launcher) {
    init {
        val glass = GlassView(launcher, launcher.dp(22f), GlassView.Style.HOME)
        val row = LinearLayout(launcher).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        launcher.apps.apps.take(4).forEach { e ->
            row.addView(ImageView(launcher).apply { setImageBitmap(launcher.icons.appIconForDisplay(e, launcher.dpi(48))) }, llp(launcher.dpi(48), launcher.dpi(48)).apply {
                marginStart = launcher.dpi(10); marginEnd = launcher.dpi(10)
            })
        }
        glass.addView(row, flp(MATCH, MATCH))
        addView(glass, flp(MATCH, launcher.dpi(96)))
    }
}

/** A frame that stays square (the smaller of its width and height), so round things never turn into ovals. */
class SquareFrame(context: android.content.Context) : FrameLayout(context) {
    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val w = MeasureSpec.getSize(widthMeasureSpec); val h = MeasureSpec.getSize(heightMeasureSpec)
        val side = when {
            MeasureSpec.getMode(widthMeasureSpec) == MeasureSpec.UNSPECIFIED -> h
            MeasureSpec.getMode(heightMeasureSpec) == MeasureSpec.UNSPECIFIED -> w
            else -> minOf(w, h)
        }
        val spec = MeasureSpec.makeMeasureSpec(side, MeasureSpec.EXACTLY)
        super.onMeasure(spec, spec)
    }
}

/** Centres a colour dot in its share of a row and keeps it round however many colours there are. */
fun dotCell(launcher: MainActivity, dot: View, gap: Int = 3): FrameLayout = FrameLayout(launcher).apply {
    addView(SquareFrame(launcher).apply { addView(dot, flp(MATCH, MATCH)) }, flp(MATCH, MATCH, Gravity.CENTER).apply {
        marginStart = launcher.dpi(gap); marginEnd = launcher.dpi(gap)
    })
}
