package com.fluidone.launcher

import android.graphics.Point
import org.json.JSONArray
import org.json.JSONObject
import kotlin.math.abs

/** One thing placed on a home page grid. */
class HomeItem(
    var id: Long,
    var type: Int,
    var x: Int = 0,
    var y: Int = 0,
    var spanX: Int = 1,
    var spanY: Int = 1,
    var appKey: String = "",
    var title: String = "",
    val apps: MutableList<String> = mutableListOf(),
    var widgetId: Int = -1,
    var builtin: String = ""
) {
    val isLargeFolder get() = type == FOLDER && (spanX > 1 || spanY > 1)
    val isWidgetLike get() = type == WIDGET || type == BUILTIN

    fun toJson(): JSONObject = JSONObject().apply {
        put("id", id); put("t", type); put("x", x); put("y", y); put("sx", spanX); put("sy", spanY)
        if (appKey.isNotEmpty()) put("a", appKey)
        if (title.isNotEmpty()) put("ti", title)
        if (apps.isNotEmpty()) put("ap", JSONArray(apps))
        if (widgetId != -1) put("w", widgetId)
        if (builtin.isNotEmpty()) put("b", builtin)
    }

    companion object {
        const val APP = 0
        const val FOLDER = 1
        const val WIDGET = 2
        const val BUILTIN = 3

        fun fromJson(o: JSONObject): HomeItem {
            val apps = mutableListOf<String>()
            o.optJSONArray("ap")?.let { arr -> for (i in 0 until arr.length()) apps.add(arr.getString(i)) }
            return HomeItem(
                o.getLong("id"), o.getInt("t"), o.optInt("x"), o.optInt("y"),
                o.optInt("sx", 1).coerceAtLeast(1), o.optInt("sy", 1).coerceAtLeast(1),
                o.optString("a"), o.optString("ti"), apps, o.optInt("w", -1), o.optString("b")
            )
        }
    }
}

/**
 * Home screen state: pages of grid items plus the dock. Everything is persisted as one JSON document so a
 * layout can never be half saved.
 */
class LauncherModel(private val prefs: LauncherPrefs) {
    val pages = mutableListOf<MutableList<HomeItem>>()
    val dock = mutableListOf<String>()
    private var nextId = 1L

    fun newId(): Long = nextId++

    fun load(): Boolean {
        val raw = prefs.sp.getString(KEY, null) ?: return false
        return try {
            val o = JSONObject(raw)
            pages.clear(); dock.clear()
            val ps = o.getJSONArray("pages")
            for (i in 0 until ps.length()) {
                val arr = ps.getJSONArray(i)
                pages.add(MutableList(arr.length()) { HomeItem.fromJson(arr.getJSONObject(it)) })
            }
            val d = o.optJSONArray("dock") ?: JSONArray()
            for (i in 0 until d.length()) dock.add(d.getString(i))
            nextId = (pages.flatten().maxOfOrNull { it.id } ?: 0L) + 1
            if (pages.isEmpty()) pages.add(mutableListOf())
            true
        } catch (_: Exception) { false }
    }

    fun save() {
        val o = JSONObject()
        o.put("v", 2)
        o.put("pages", JSONArray().apply { pages.forEach { page -> put(JSONArray().apply { page.forEach { put(it.toJson()) } }) } })
        o.put("dock", JSONArray(dock))
        prefs.sp.edit().putString(KEY, o.toString()).apply()
    }

    fun clear() {
        pages.clear(); dock.clear(); nextId = 1L
        prefs.sp.edit().remove(KEY).apply()
    }

    fun pageOf(item: HomeItem): Int = pages.indexOfFirst { p -> p.any { it === item } }

    fun itemById(id: Long): HomeItem? = pages.firstNotNullOfOrNull { p -> p.firstOrNull { it.id == id } }

    fun occupancy(page: Int, cols: Int, rows: Int, ignore: HomeItem? = null): Array<BooleanArray> {
        val grid = Array(cols) { BooleanArray(rows) }
        pages.getOrNull(page)?.forEach { item ->
            if (item === ignore) return@forEach
            for (x in item.x until item.x + item.spanX) for (y in item.y until item.y + item.spanY) {
                if (x in 0 until cols && y in 0 until rows) grid[x][y] = true
            }
        }
        return grid
    }

    fun isRegionFree(page: Int, x: Int, y: Int, sx: Int, sy: Int, cols: Int, rows: Int, ignore: HomeItem? = null): Boolean {
        if (x < 0 || y < 0 || x + sx > cols || y + sy > rows) return false
        val occ = occupancy(page, cols, rows, ignore)
        for (i in x until x + sx) for (j in y until y + sy) if (occ[i][j]) return false
        return true
    }

    fun findVacant(page: Int, sx: Int, sy: Int, cols: Int, rows: Int, ignore: HomeItem? = null): Point? {
        if (page !in pages.indices) return null
        val occ = occupancy(page, cols, rows, ignore)
        for (y in 0..rows - sy) for (x in 0..cols - sx) {
            var free = true
            loop@ for (i in x until x + sx) for (j in y until y + sy) if (occ[i][j]) { free = false; break@loop }
            if (free) return Point(x, y)
        }
        return null
    }

    fun findNearestVacant(page: Int, x: Int, y: Int, sx: Int, sy: Int, cols: Int, rows: Int, ignore: HomeItem? = null): Point? {
        if (page !in pages.indices) return null
        val occ = occupancy(page, cols, rows, ignore)
        var best: Point? = null
        var bestDist = Int.MAX_VALUE
        for (cy in 0..rows - sy) for (cx in 0..cols - sx) {
            var free = true
            loop@ for (i in cx until cx + sx) for (j in cy until cy + sy) if (occ[i][j]) { free = false; break@loop }
            if (!free) continue
            val d = abs(cx - x) * abs(cx - x) + abs(cy - y) * abs(cy - y)
            if (d < bestDist) { bestDist = d; best = Point(cx, cy) }
        }
        return best
    }

    fun itemAt(page: Int, x: Int, y: Int, ignore: HomeItem? = null): HomeItem? =
        pages.getOrNull(page)?.firstOrNull { it !== ignore && x >= it.x && x < it.x + it.spanX && y >= it.y && y < it.y + it.spanY }

    fun findAppItem(key: String): HomeItem? = pages.firstNotNullOfOrNull { p -> p.firstOrNull { it.type == HomeItem.APP && it.appKey == key } }

    fun isOnHome(key: String): Boolean =
        key in dock || pages.any { p -> p.any { (it.type == HomeItem.APP && it.appKey == key) || (it.type == HomeItem.FOLDER && key in it.apps) } }

    fun removeItem(item: HomeItem) {
        pages.forEach { p -> p.removeAll { it === item } }
    }

    fun folderContaining(key: String): HomeItem? =
        pages.firstNotNullOfOrNull { p -> p.firstOrNull { it.type == HomeItem.FOLDER && key in it.apps } }

    /** Removes every reference to an uninstalled app. */
    fun removeAppEverywhere(key: String): Boolean {
        var changed = dock.remove(key)
        pages.forEach { p ->
            if (p.removeAll { it.type == HomeItem.APP && it.appKey == key }) changed = true
            p.filter { it.type == HomeItem.FOLDER }.forEach { if (it.apps.remove(key)) changed = true }
        }
        if (changed) normalizeFolders()
        return changed
    }

    /** Folders with one app become that app; empty folders disappear. Large folders keep their size. */
    fun normalizeFolders() {
        pages.forEach { p ->
            val iterator = p.listIterator()
            while (iterator.hasNext()) {
                val item = iterator.next()
                if (item.type != HomeItem.FOLDER) continue
                when (item.apps.size) {
                    0 -> iterator.remove()
                    1 -> if (!item.isLargeFolder) {
                        item.type = HomeItem.APP
                        item.appKey = item.apps[0]
                        item.apps.clear()
                        item.title = ""
                    }
                }
            }
        }
    }

    /** Re-packs items that no longer fit after the grid size changes. */
    fun fitToGrid(cols: Int, rows: Int) {
        val overflow = mutableListOf<HomeItem>()
        pages.forEachIndexed { index, page ->
            page.sortWith(Comparator { a, b -> if (a.y != b.y) a.y - b.y else a.x - b.x })
            val keep = mutableListOf<HomeItem>()
            for (item in page) {
                item.spanX = item.spanX.coerceAtMost(cols)
                item.spanY = item.spanY.coerceAtMost(rows)
                val fits = item.x + item.spanX <= cols && item.y + item.spanY <= rows
                if (fits && keep.none { overlaps(it, item) }) keep.add(item) else overflow.add(item)
            }
            page.clear(); page.addAll(keep)
            pages[index] = page
        }
        for (item in overflow) place(item, cols, rows, startPage = 0)
    }

    /** Puts an item in the first page with room from [startPage], adding a page when needed. */
    fun place(item: HomeItem, cols: Int, rows: Int, startPage: Int): Int {
        item.spanX = item.spanX.coerceIn(1, cols); item.spanY = item.spanY.coerceIn(1, rows)
        // The current page first, then the following pages, then earlier ones, then a new page.
        val order = (startPage until pages.size) + (0 until startPage.coerceAtMost(pages.size))
        for (p in order) {
            val spot = findVacant(p, item.spanX, item.spanY, cols, rows)
            if (spot != null) { item.x = spot.x; item.y = spot.y; pages[p].add(item); return p }
        }
        if (pages.size >= MAX_PAGES) return -1
        pages.add(mutableListOf())
        item.x = 0; item.y = 0
        pages.last().add(item)
        return pages.lastIndex
    }

    private fun overlaps(a: HomeItem, b: HomeItem): Boolean =
        a.x < b.x + b.spanX && b.x < a.x + a.spanX && a.y < b.y + b.spanY && b.y < a.y + a.spanY

    /**
     * Push reorder used while dragging over an occupied cell: the 1x1 items from the target cell onward shift
     * along reading order into the next free cell (or backward if nothing is free ahead). Gaps elsewhere and
     * multi-cell items stay where the user put them. Returns new positions, or null if the page is full.
     */
    fun computePush(page: Int, cols: Int, rows: Int, tx: Int, ty: Int, dragged: HomeItem?): Map<HomeItem, Point>? {
        val items = pages.getOrNull(page) ?: return null
        val blocked = Array(cols) { BooleanArray(rows) }
        val singles = HashMap<Int, HomeItem>()
        for (item in items) {
            if (item === dragged) continue
            if (item.spanX > 1 || item.spanY > 1) {
                for (x in item.x until item.x + item.spanX) for (y in item.y until item.y + item.spanY)
                    if (x in 0 until cols && y in 0 until rows) blocked[x][y] = true
            } else if (item.x in 0 until cols && item.y in 0 until rows) singles[item.y * cols + item.x] = item
        }
        if (tx !in 0 until cols || ty !in 0 until rows || blocked[tx][ty]) return null
        val slots = ArrayList<Int>()
        for (y in 0 until rows) for (x in 0 until cols) if (!blocked[x][y]) slots.add(y * cols + x)
        val target = slots.indexOf(ty * cols + tx)
        if (target < 0) return null
        if (singles[slots[target]] == null) return emptyMap()
        val result = HashMap<HomeItem, Point>()
        var free = -1
        for (i in target + 1 until slots.size) if (singles[slots[i]] == null) { free = i; break }
        if (free >= 0) {
            for (i in free - 1 downTo target) {
                val item = singles[slots[i]] ?: continue
                val dst = slots[i + 1]
                result[item] = Point(dst % cols, dst / cols)
            }
            return result
        }
        for (i in target - 1 downTo 0) if (singles[slots[i]] == null) { free = i; break }
        if (free < 0) return null
        for (i in free + 1..target) {
            val item = singles[slots[i]] ?: continue
            val dst = slots[i - 1]
            result[item] = Point(dst % cols, dst / cols)
        }
        return result
    }

    companion object {
        private const val KEY = "home_model"
        const val MAX_PAGES = 12
    }
}
