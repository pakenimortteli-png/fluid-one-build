package com.fluidone.launcher

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.Resources
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.BitmapShader
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PorterDuff
import android.graphics.PorterDuffColorFilter
import android.graphics.PorterDuffXfermode
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.drawable.AdaptiveIconDrawable
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.Drawable
import android.os.Build
import android.util.LruCache
import org.xmlpull.v1.XmlPullParser
import org.xmlpull.v1.XmlPullParserFactory
import java.io.File
import java.util.concurrent.ConcurrentHashMap
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.roundToInt
import kotlin.math.sign
import kotlin.math.sin

object IconShapes {
    val ids = listOf("squircle", "circle", "rounded", "teardrop", "pebble", "square", "hexagon", "flower", "leaf")
    val names = mapOf(
        "squircle" to "Squircle", "circle" to "Circle", "rounded" to "Rounded",
        "teardrop" to "Teardrop", "pebble" to "Pebble", "square" to "Square",
        "hexagon" to "Hexagon", "flower" to "Flower", "leaf" to "Leaf"
    )

    fun path(id: String, size: Float, out: Path = Path(), offsetX: Float = 0f, offsetY: Float = 0f): Path {
        out.reset()
        val r = RectF(offsetX, offsetY, offsetX + size, offsetY + size)
        when (id) {
            "circle" -> out.addOval(r, Path.Direction.CW)
            "rounded" -> out.addRoundRect(r, size * 0.24f, size * 0.24f, Path.Direction.CW)
            "square" -> out.addRoundRect(r, size * 0.1f, size * 0.1f, Path.Direction.CW)
            "teardrop" -> {
                val rr = size * 0.5f
                out.addRoundRect(r, floatArrayOf(rr, rr, rr, rr, size * 0.14f, size * 0.14f, rr, rr), Path.Direction.CW)
            }
            "pebble" -> superellipse(out, r, 3.2f, squash = 0.04f)
            "hexagon" -> roundedPolygon(out, r, 6, size * 0.1f, PI.toFloat() / 6f)
            "flower" -> flower(out, r)
            "leaf" -> {
                val big = size * 0.5f; val small = size * 0.16f
                out.addRoundRect(r, floatArrayOf(big, big, small, small, big, big, small, small), Path.Direction.CW)
            }
            else -> superellipse(out, r, 5f)
        }
        return out
    }

    /** A regular polygon with softly rounded corners, filling [r]. */
    private fun roundedPolygon(out: Path, r: RectF, sides: Int, corner: Float, rotation: Float) {
        val cx = r.centerX(); val cy = r.centerY(); val rad = r.width() / 2f
        val pts = Array(sides) { i ->
            val a = rotation + 2f * PI.toFloat() * i / sides
            floatArrayOf(cx + rad * cos(a), cy + rad * sin(a))
        }
        for (i in 0 until sides) {
            val p0 = pts[(i + sides - 1) % sides]; val p1 = pts[i]; val p2 = pts[(i + 1) % sides]
            val d1x = p0[0] - p1[0]; val d1y = p0[1] - p1[1]; val l1 = kotlin.math.hypot(d1x, d1y)
            val d2x = p2[0] - p1[0]; val d2y = p2[1] - p1[1]; val l2 = kotlin.math.hypot(d2x, d2y)
            val ax = p1[0] + d1x / l1 * corner; val ay = p1[1] + d1y / l1 * corner
            val bx = p1[0] + d2x / l2 * corner; val by = p1[1] + d2y / l2 * corner
            if (i == 0) out.moveTo(ax, ay) else out.lineTo(ax, ay)
            out.quadTo(p1[0], p1[1], bx, by)
        }
        out.close()
    }

    /** A soft eight-petal scallop. */
    private fun flower(out: Path, r: RectF) {
        val cx = r.centerX(); val cy = r.centerY(); val rad = r.width() / 2f
        val steps = 160
        for (i in 0..steps) {
            val t = 2.0 * PI * i / steps
            val rr = rad * (0.9f + 0.1f * cos(8.0 * t).toFloat())
            val x = cx + rr * cos(t).toFloat(); val y = cy + rr * sin(t).toFloat()
            if (i == 0) out.moveTo(x, y) else out.lineTo(x, y)
        }
        out.close()
    }

    /** Corner radius (fraction of the size) of the rounded rectangle closest to each shape, for glass plates. */
    fun cornerFraction(id: String): Float = when (id) {
        "circle", "flower" -> 0.5f
        "rounded" -> 0.24f
        "square" -> 0.1f
        "pebble", "teardrop" -> 0.42f
        "hexagon" -> 0.36f
        "leaf" -> 0.3f
        else -> 0.31f
    }

    /** Shapes the glass shader can draw exactly; others are clipped to their outline. */
    fun isRoundRect(id: String) = id == "circle" || id == "rounded" || id == "square"

    private fun superellipse(out: Path, r: RectF, n: Float, squash: Float = 0f) {
        val cx = r.centerX(); val cy = r.centerY()
        val a = r.width() / 2f; val b = r.height() / 2f
        val steps = 96
        for (i in 0..steps) {
            val t = 2 * PI * i / steps
            val ct = cos(t); val st = sin(t)
            val x = cx + a * (1 - squash * st.toFloat()) * sign(ct).toFloat() * abs(ct).pow(2.0 / n).toFloat()
            val y = cy + b * sign(st).toFloat() * abs(st).pow(2.0 / n).toFloat()
            if (i == 0) out.moveTo(x, y) else out.lineTo(x, y)
        }
        out.close()
    }
}

object IconStyles {
    val ids = listOf("original", "glass", "themed_dark", "themed_light", "tinted", "mono", "pastel", "neon", "gradient")

    /** "glass" is called Fluid Glass while Fluid Glass is on, and Blur when it is off. */
    fun name(id: String, fluidOn: Boolean): String = when (id) {
        "original" -> "Original"
        // Android 12 has no Fluid Glass shader, so the plate is plain blur there whatever the setting says.
        "glass" -> if (fluidOn && FluidGlass.supported) "Fluid Glass" else "Blur"
        "themed_dark" -> "Dark"
        "themed_light" -> "Light"
        "tinted" -> "Accent"
        "mono" -> "Monochrome"
        "pastel" -> "Pastel"
        "neon" -> "Neon"
        "gradient" -> "Gradient"
        else -> id
    }

    /** Styles that draw a live glass plate behind a glyph. */
    fun isGlass(id: String) = id == "glass"
}

/**
 * Builds every app icon the launcher shows: shapes adaptive icons, wraps legacy icons, applies global or
 * per-app styles, icon packs and custom images. Results are cached by app and settings signature.
 */
class IconFactory(private val launcher: MainActivity) {
    private val cache = object : LruCache<String, Bitmap>((Runtime.getRuntime().maxMemory() / 1024 / 10).toInt()) {
        override fun sizeOf(key: String, value: Bitmap): Int = max(1, value.byteCount / 1024)
    }
    private val colorCache = ConcurrentHashMap<String, Int>()
    val packs = IconPackManager(launcher)

    fun clear() {
        generation++
        cache.evictAll()
        colorCache.clear()
    }

    // ---- Background generation -------------------------------------------------------------------------
    // Themed styles (and One UI glyph extraction) are expensive; lists must never build icons while scrolling.

    @Volatile private var generation = 0
    private val main = android.os.Handler(android.os.Looper.getMainLooper())
    private val pending = ConcurrentHashMap<String, MutableList<(Bitmap) -> Unit>>()
    private fun lowPriority(name: String) = java.util.concurrent.ThreadFactory { r ->
        Thread({ android.os.Process.setThreadPriority(android.os.Process.THREAD_PRIORITY_BACKGROUND); r.run() }, name).apply { isDaemon = true }
    }
    private val workers = java.util.concurrent.Executors.newFixedThreadPool(2, lowPriority("fluid-icons"))
    private val warmer = java.util.concurrent.Executors.newSingleThreadExecutor(lowPriority("fluid-icon-warm"))

    private fun cacheKey(entry: AppEntry, size: Int) =
        "${entry.key}|$size|${signature()}|${launcher.prefs.sp.getString("icon|${entry.key}", "")}"

    /** The icon if it is already built, otherwise null (never builds on the calling thread). */
    fun cachedIcon(entry: AppEntry, size: Int): Bitmap? = cache.get(cacheKey(entry, size))

    /** Builds the icon on a worker thread and delivers it on the main thread. */
    fun loadIcon(entry: AppEntry, size: Int, done: (Bitmap) -> Unit) {
        val key = cacheKey(entry, size)
        cache.get(key)?.let { done(it); return }
        val gen = generation
        // Pending jobs belong to one cache generation, so a request made after clear() never joins a job whose
        // result is about to be thrown away.
        val job = "$gen#$key"
        val waiting = pending[job]
        if (waiting != null) { synchronized(waiting) { waiting.add(done) }; return }
        val list = mutableListOf(done)
        pending[job] = list
        workers.execute {
            val bmp = cache.get(key) ?: try { build(entry, size, launcher.prefs.iconOverride(entry.key)) } catch (_: Throwable) { fallback(size) }
            if (gen == generation) cache.put(key, bmp)
            main.post {
                val callbacks = pending.remove(job) ?: return@post
                val all = synchronized(callbacks) { callbacks.toList() }
                // Settings changed while this was building: serve everyone the icon in the new style instead.
                if (gen == generation) all.forEach { it(bmp) } else all.forEach { loadIcon(entry, size, it) }
            }
        }
    }

    /** Pre-builds icons in the background so lists open with every icon ready. */
    fun prewarm(entries: List<AppEntry>, size: Int) {
        val gen = generation
        warmer.execute {
            for (e in entries) {
                if (gen != generation) return@execute
                val key = cacheKey(e, size)
                if (cache.get(key) != null || pending.containsKey("$gen#$key")) continue
                val bmp = try { build(e, size, launcher.prefs.iconOverride(e.key)) } catch (_: Throwable) { continue }
                if (gen == generation) cache.put(key, bmp)
            }
        }
    }

    private fun signature(): String {
        val p = launcher.prefs
        return "${p.iconShape}|${launcher.effectiveIconStyle()}|${p.iconPack}|${p.normalizeLegacy}|${p.accent}|${p.glyphSize}|${p.legacyPlate}|g2"
    }

    fun appIcon(entry: AppEntry, size: Int): Bitmap {
        val key = cacheKey(entry, size)
        cache.get(key)?.let { return it }
        val bmp = try { build(entry, size, launcher.prefs.iconOverride(entry.key)) } catch (_: Throwable) { fallback(size) }
        cache.put(key, bmp)
        return bmp
    }

    /** Renders an icon with an explicit override (used by the icon editor previews). */
    fun preview(entry: AppEntry, size: Int, override: IconOverride?): Bitmap =
        try { build(entry, size, override) } catch (_: Throwable) { fallback(size) }

    fun dominantColor(entry: AppEntry, size: Int): Int {
        colorCache[entry.key]?.let { return it }
        val c = averageColor(appIcon(entry, size))
        colorCache[entry.key] = c
        return c
    }

    private fun build(entry: AppEntry, size: Int, override: IconOverride?): Bitmap {
        val p = launcher.prefs
        val shape = p.iconShape
        val result: Bitmap = when (override?.mode) {
            "image" -> {
                val file = File(override.file)
                val src = if (file.exists()) BitmapFactory.decodeFile(file.absolutePath) else null
                if (src != null) maskBitmap(src, size, shape) else styled(systemIcon(entry), size, shape, launcher.effectiveIconStyle(), entry.systemLabel)
            }
            "pack" -> {
                val d = packs.loadedOrRequest(override.pack) { launcher.applyIconChange() }?.drawable(override.drawable)
                if (d != null) drawPlain(d, size) else styled(systemIcon(entry), size, shape, launcher.effectiveIconStyle(), entry.systemLabel)
            }
            "style" -> styled(systemIcon(entry), size, shape, override.style.ifEmpty { "original" }, entry.systemLabel)
            else -> {
                val pack = packs.loadedOrRequest(p.iconPack) { launcher.applyIconChange() }
                val packIcon = pack?.iconFor(entry.component.flattenToString())
                when {
                    packIcon != null -> drawPlain(packIcon, size)
                    pack != null && pack.hasMasking -> pack.applyMask(systemIcon(entry), size)
                    else -> styled(systemIcon(entry), size, shape, launcher.effectiveIconStyle(), entry.systemLabel)
                }
            }
        }
        return if (entry.isWorkProfile) badge(result, entry) else result
    }

    fun systemIcon(entry: AppEntry): Drawable {
        val density = launcher.resources.displayMetrics.densityDpi
        return try { entry.info.getIcon(density) } catch (_: Exception) { null }
            ?: launcher.packageManager.defaultActivityIcon
    }

    private fun badge(bmp: Bitmap, entry: AppEntry): Bitmap = try {
        val d = launcher.packageManager.getUserBadgedIcon(BitmapDrawable(launcher.resources, bmp), entry.user)
        drawPlain(d, bmp.width)
    } catch (_: Exception) { bmp }

    /** Bitmaps made for the Fluid Glass / Blur style: a glyph that the icon view puts on a live glass plate. */
    private val glassBitmaps = java.util.Collections.newSetFromMap(java.util.WeakHashMap<Bitmap, Boolean>())

    fun isGlassIcon(b: Bitmap?): Boolean = b != null && synchronized(glassBitmaps) { b in glassBitmaps }

    /** Applies shape + style to a system icon. [label] is used when an icon has no usable symbol. */
    fun styled(d: Drawable, size: Int, shape: String, style: String, label: String = ""): Bitmap {
        val accent = launcher.prefs.accent
        return when (style) {
            "themed_dark" -> themed(d, size, shape, Color.rgb(30, 31, 38), Color.rgb(30, 31, 38), blendColors(accent, Color.WHITE, 0.55f), label)
            "themed_light" -> themed(d, size, shape, Color.rgb(246, 247, 250), Color.rgb(226, 229, 238), blendColors(accent, Color.BLACK, 0.45f), label)
            "tinted" -> themed(d, size, shape, blendColors(accent, Color.WHITE, 0.22f), blendColors(accent, Color.BLACK, 0.18f), Color.WHITE, label)
            "mono" -> themed(d, size, shape, Color.rgb(44, 44, 48), Color.rgb(22, 22, 25), Color.rgb(238, 238, 242), label)
            "neon" -> themed(d, size, shape, Color.rgb(16, 16, 22), Color.rgb(6, 6, 10), blendColors(accent, Color.WHITE, 0.25f), label)
            "gradient" -> themed(d, size, shape, blendColors(accent, Color.WHITE, 0.1f), hueShift(accent, 38f), Color.WHITE, label)
            "pastel" -> {
                val c = vividColor(d)
                themed(d, size, shape, blendColors(c, Color.WHITE, 0.74f), blendColors(c, Color.WHITE, 0.62f), blendColors(c, Color.BLACK, 0.38f), label)
            }
            "glass" -> {
                val out = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
                val c = Canvas(out)
                c.clipPath(IconShapes.path(shape, size.toFloat()))
                val mask = ThemedGlyph.mask(d, size, glyphScale(), label) { shaped(d, size, "square") }
                c.drawBitmap(mask, 0f, 0f, Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG).apply {
                    colorFilter = PorterDuffColorFilter(Color.WHITE, PorterDuff.Mode.SRC_IN)
                })
                mask.recycle()
                synchronized(glassBitmaps) { glassBitmaps.add(out) }
                out
            }
            else -> shaped(d, size, shape)
        }
    }

    /** Glyph size for themed styles (Settings › Icons › Symbol size). */
    private fun glyphScale(): Float = when (launcher.prefs.glyphSize) { "small" -> 0.44f; "large" -> 0.58f; else -> 0.51f }

    private fun shaped(d: Drawable, size: Int, shape: String): Bitmap {
        if (d is AdaptiveIconDrawable) {
            val layer = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
            val c = Canvas(layer)
            // Layers are 108dp with a 72dp visible centre, so they extend 25% past each edge.
            val inset = size * 0.25f
            val l = (-inset).roundToInt(); val r = (size + inset).roundToInt()
            d.background?.let { it.setBounds(l, l, r, r); it.draw(c) }
            d.foreground?.let { it.setBounds(l, l, r, r); it.draw(c) }
            return maskBitmap(layer, size, shape, recycleSource = true)
        }
        if (!launcher.prefs.normalizeLegacy) return drawPlain(d, size)
        // Full-bleed square legacy icons are masked; transparent ones are placed on a soft plate.
        val probe = drawPlain(d, 32)
        var opaque = 0
        for (y in 0 until 32) for (x in 0 until 32) if (Color.alpha(probe.getPixel(x, y)) > 200) opaque++
        probe.recycle()
        if (opaque > 32 * 32 * 0.86f) return maskBitmap(drawPlain(d, size), size, shape, recycleSource = true)
        val out = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val c = Canvas(out)
        val plateColor = if (launcher.prefs.legacyPlate == "colour") blendColors(vividColor(d), Color.WHITE, 0.82f) else Color.WHITE
        val plate = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            shader = LinearGradient(0f, 0f, 0f, size.toFloat(), plateColor, blendColors(plateColor, Color.rgb(220, 224, 234), 0.45f), Shader.TileMode.CLAMP)
        }
        c.drawPath(IconShapes.path(shape, size.toFloat()), plate)
        val inner = (size * 0.7f).roundToInt()
        val off = (size - inner) / 2
        d.setBounds(off, off, off + inner, off + inner)
        d.draw(c)
        return out
    }

    /**
     * A themed icon: a plate in the theme's colours with the app's symbol on it. The symbol always comes out
     * the same size, centred and clipped to the shape, whatever the app ships (see [ThemedGlyph]).
     */
    private fun themed(d: Drawable, size: Int, shape: String, top: Int, bottom: Int, glyphColor: Int, label: String): Bitmap {
        val out = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val c = Canvas(out)
        val path = IconShapes.path(shape, size.toFloat())
        val plate = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            shader = LinearGradient(0f, 0f, 0f, size.toFloat(), top, bottom, Shader.TileMode.CLAMP)
        }
        c.drawPath(path, plate)
        val mask = ThemedGlyph.mask(d, size, glyphScale(), label) { shaped(d, size, "square") }
        val save = c.save()
        c.clipPath(path)
        val gp = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG).apply { colorFilter = PorterDuffColorFilter(glyphColor, PorterDuff.Mode.SRC_IN) }
        c.drawBitmap(mask, 0f, 0f, gp)
        c.restoreToCount(save)
        mask.recycle()
        return out
    }

    /** The icon's most characteristic colour: saturated pixels count more than greys. */
    fun vividColor(d: Drawable): Int {
        val small = try { if (d is AdaptiveIconDrawable) shaped(d, 24, "square") else drawPlain(d, 24) } catch (_: Throwable) { return Color.rgb(120, 130, 150) }
        var r = 0f; var g = 0f; var b = 0f; var wsum = 0f
        val hsv = FloatArray(3)
        for (y in 0 until 24) for (x in 0 until 24) {
            val c = small.getPixel(x, y)
            if (Color.alpha(c) < 160) continue
            Color.colorToHSV(c, hsv)
            val w = 0.15f + hsv[1] * hsv[2]
            r += Color.red(c) * w; g += Color.green(c) * w; b += Color.blue(c) * w; wsum += w
        }
        small.recycle()
        if (wsum <= 0f) return Color.rgb(120, 130, 150)
        return Color.rgb((r / wsum).roundToInt(), (g / wsum).roundToInt(), (b / wsum).roundToInt())
    }

    private fun hueShift(color: Int, degrees: Float): Int {
        val hsv = FloatArray(3); Color.colorToHSV(color, hsv)
        hsv[0] = (hsv[0] + degrees + 360f) % 360f
        hsv[2] = (hsv[2] * 0.82f).coerceIn(0f, 1f)
        return Color.HSVToColor(hsv)
    }

    private val shadows = java.util.WeakHashMap<Bitmap, Pair<Bitmap, Int>>()

    /** A soft shadow for an icon (Settings › Icons › Icon shadows): (alpha bitmap, offset in icon pixels). */
    fun shadowFor(icon: Bitmap): Pair<Bitmap, Int>? = synchronized(shadows) {
        shadows[icon] ?: try {
            val radius = max(2f, icon.width * 0.06f)
            val off = IntArray(2)
            val sh = icon.extractAlpha(Paint().apply { maskFilter = android.graphics.BlurMaskFilter(radius, android.graphics.BlurMaskFilter.Blur.NORMAL) }, off)
            (sh to off[0]).also { shadows[icon] = it }
        } catch (_: Throwable) { null }
    }

    /**
     * An icon for plain image views (settings lists, previews). Glass icons are only a glyph, so they get a
     * dark frosted plate here to stay visible on light backgrounds.
     */
    fun forDisplay(icon: Bitmap): Bitmap {
        if (!isGlassIcon(icon)) return icon
        val size = icon.width
        val out = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val c = Canvas(out)
        val path = IconShapes.path(launcher.prefs.iconShape, size.toFloat())
        c.drawPath(path, Paint(Paint.ANTI_ALIAS_FLAG).apply {
            shader = LinearGradient(0f, 0f, size.toFloat(), size.toFloat(), Color.rgb(96, 104, 128), Color.rgb(52, 56, 72), Shader.TileMode.CLAMP)
        })
        c.drawPath(path, Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = max(1f, size / 40f); color = Color.argb(120, 255, 255, 255) })
        c.drawBitmap(icon, 0f, 0f, Paint(Paint.FILTER_BITMAP_FLAG))
        return out
    }

    fun appIconForDisplay(entry: AppEntry, size: Int): Bitmap = forDisplay(appIcon(entry, size))

    fun maskBitmap(src: Bitmap, size: Int, shape: String, recycleSource: Boolean = false): Bitmap {
        val out = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val c = Canvas(out)
        val shader = BitmapShader(src, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP)
        val m = Matrix()
        val s = max(size / src.width.toFloat(), size / src.height.toFloat())
        m.setScale(s, s)
        m.postTranslate((size - src.width * s) / 2f, (size - src.height * s) / 2f)
        shader.setLocalMatrix(m)
        val p = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG).apply { this.shader = shader }
        c.drawPath(IconShapes.path(shape, size.toFloat()), p)
        if (recycleSource && src != out) src.recycle()
        return out
    }

    fun drawPlain(d: Drawable, size: Int): Bitmap {
        val out = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val c = Canvas(out)
        val w = if (d.intrinsicWidth > 0) d.intrinsicWidth else size
        val h = if (d.intrinsicHeight > 0) d.intrinsicHeight else size
        val s = min(size / w.toFloat(), size / h.toFloat())
        val dw = (w * s).roundToInt(); val dh = (h * s).roundToInt()
        d.setBounds((size - dw) / 2, (size - dh) / 2, (size - dw) / 2 + dw, (size - dh) / 2 + dh)
        d.draw(c)
        return out
    }

    private fun fallback(size: Int): Bitmap {
        val out = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val c = Canvas(out)
        c.drawPath(IconShapes.path(launcher.prefs.iconShape, size.toFloat()), Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.GRAY })
        return out
    }

    fun shapeIcon(d: Drawable, size: Int): Bitmap = styled(d, size, launcher.prefs.iconShape, "original")

    companion object {
        fun averageColor(bmp: Bitmap): Int {
            val small = Bitmap.createScaledBitmap(bmp, 10, 10, true)
            var r = 0f; var g = 0f; var b = 0f; var wsum = 0f
            for (y in 0 until 10) for (x in 0 until 10) {
                val c = small.getPixel(x, y)
                val a = Color.alpha(c) / 255f
                if (a < 0.3f) continue
                r += Color.red(c) * a; g += Color.green(c) * a; b += Color.blue(c) * a; wsum += a
            }
            if (small != bmp) small.recycle()
            if (wsum <= 0f) return Color.rgb(60, 60, 70)
            return Color.rgb((r / wsum).roundToInt(), (g / wsum).roundToInt(), (b / wsum).roundToInt())
        }
    }
}

/** Icon packs in the ADW / Nova / Lawnchair format (appfilter.xml + drawable.xml). */
class IconPackManager(private val context: Context) {
    private val loaded = ConcurrentHashMap<String, IconPack>()

    data class PackInfo(val packageName: String, val label: String)

    fun installedPacks(): List<PackInfo> {
        val pm = context.packageManager
        val actions = listOf(
            "org.adw.launcher.THEMES", "com.novalauncher.THEME", "com.teslacoilsw.launcher.THEME",
            "com.gau.go.launcherex.theme", "org.adw.ActivityStarter.THEMES", "com.dlto.atom.launcher.THEME"
        )
        val found = LinkedHashMap<String, PackInfo>()
        for (action in actions) {
            val list = try { pm.queryIntentActivities(Intent(action), PackageManager.MATCH_ALL) } catch (_: Exception) { emptyList() }
            for (ri in list) {
                val pkg = ri.activityInfo?.packageName ?: continue
                if (pkg !in found) found[pkg] = PackInfo(pkg, ri.loadLabel(pm)?.toString() ?: pkg)
            }
        }
        return found.values.sortedBy { it.label.lowercase() }
    }

    /** Loads a pack. The first call parses XML; call from a worker thread when possible. */
    fun pack(pkg: String): IconPack? {
        if (pkg.isEmpty()) return null
        loaded[pkg]?.let { return it }
        val pack = try { IconPack(context, pkg).also { it.load() } } catch (_: Exception) { null } ?: return null
        loaded[pkg] = pack
        return pack
    }

    fun evict(pkg: String) { loaded.remove(pkg); requested.remove(pkg) }

    private val requested = java.util.Collections.newSetFromMap(ConcurrentHashMap<String, Boolean>())
    private val loader = java.util.concurrent.Executors.newSingleThreadExecutor()

    /**
     * Returns the pack if it is already parsed; otherwise starts parsing it in the background and calls
     * [onLoaded] on the main thread when ready. Keeps XML parsing off the UI thread.
     */
    fun loadedOrRequest(pkg: String, onLoaded: () -> Unit): IconPack? {
        if (pkg.isEmpty()) return null
        loaded[pkg]?.let { return it }
        if (requested.add(pkg)) loader.execute {
            pack(pkg)
            android.os.Handler(android.os.Looper.getMainLooper()).post(onLoaded)
        }
        return null
    }
}

class IconPack(private val context: Context, val packageName: String) {
    private lateinit var res: Resources
    private val components = HashMap<String, String>()
    private val allNames = LinkedHashSet<String>()
    private val backs = ArrayList<String>()
    private var mask: String? = null
    private var upon: String? = null
    private var scale = 1f
    val hasMasking get() = backs.isNotEmpty()

    fun load() {
        res = context.packageManager.getResourcesForApplication(packageName)
        parse("appfilter") { parser ->
            when (parser.name) {
                "item" -> {
                    val comp = parser.getAttributeValue(null, "component")
                    val draw = parser.getAttributeValue(null, "drawable")
                    if (comp != null && draw != null) {
                        val normalized = comp.removePrefix("ComponentInfo{").removeSuffix("}")
                        components[normalized] = draw
                        allNames.add(draw)
                    }
                }
                "iconback" -> for (i in 0 until parser.attributeCount) parser.getAttributeValue(i)?.let { backs.add(it) }
                "iconmask" -> mask = parser.getAttributeValue(null, "img1")
                "iconupon" -> upon = parser.getAttributeValue(null, "img1")
                "scale" -> scale = parser.getAttributeValue(null, "factor")?.toFloatOrNull() ?: 1f
            }
        }
        parse("drawable") { parser ->
            if (parser.name == "item") parser.getAttributeValue(null, "drawable")?.let { allNames.add(it) }
        }
    }

    private fun parse(name: String, handle: (XmlPullParser) -> Unit) {
        val parser: XmlPullParser = run {
            val id = res.getIdentifier(name, "xml", packageName)
            if (id != 0) res.getXml(id) else try {
                val stream = res.assets.open("$name.xml")
                XmlPullParserFactory.newInstance().newPullParser().apply { setInput(stream, "UTF-8") }
            } catch (_: Exception) { return }
        }
        try {
            var event = parser.eventType
            while (event != XmlPullParser.END_DOCUMENT) {
                if (event == XmlPullParser.START_TAG) handle(parser)
                event = parser.next()
            }
        } catch (_: Exception) { }
    }

    fun names(): List<String> = allNames.toList()

    fun drawable(name: String): Drawable? = try {
        val id = res.getIdentifier(name, "drawable", packageName)
        if (id == 0) null else res.getDrawable(id, null)
    } catch (_: Exception) { null }

    fun iconFor(flatComponent: String): Drawable? {
        val name = components[flatComponent] ?: return null
        return drawable(name)
    }

    fun applyMask(original: Drawable, size: Int): Bitmap {
        val out = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val c = Canvas(out)
        val back = backs.firstOrNull()?.let { drawable(it) }
        back?.let { it.setBounds(0, 0, size, size); it.draw(c) }
        val inner = (size * scale).roundToInt()
        val off = (size - inner) / 2
        val layer = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val lc = Canvas(layer)
        original.setBounds(off, off, off + inner, off + inner)
        original.draw(lc)
        mask?.let { drawable(it) }?.let { m ->
            val maskBmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
            val mc = Canvas(maskBmp)
            m.setBounds(0, 0, size, size); m.draw(mc)
            lc.drawBitmap(maskBmp, 0f, 0f, Paint().apply { xfermode = PorterDuffXfermode(PorterDuff.Mode.DST_OUT) })
            maskBmp.recycle()
        }
        c.drawBitmap(layer, 0f, 0f, null)
        layer.recycle()
        upon?.let { drawable(it) }?.let { it.setBounds(0, 0, size, size); it.draw(c) }
        return out
    }
}

/**
 * Finds an app's symbol for themed icon styles, on any phone.
 *
 * Apps ship very different icons:
 * - Android 13 monochrome layers.
 * - Plain foreground logos.
 * - Foregrounds that are a whole icon with its own plate (One UI and many games).
 * - Old full-bleed pictures.
 *
 * Every candidate is checked: a real symbol is neither empty nor a filled plate or circle. In order:
 * 1. The monochrome layer.
 * 2. The foreground logo.
 * 3. The symbol separated from its plate by colour.
 * 4. For photo-like icons, a duotone "detail" map of the whole icon, which stays recognisable.
 * 5. If nothing works, the app's initial.
 *
 * Symbols are resized to a consistent size and centred, so nothing overflows the plate.
 */
object ThemedGlyph {
    /** A white alpha mask (size x size) to draw in the glyph colour over the plate, clipped to the shape. */
    fun mask(d: Drawable, size: Int, scale: Float, label: String, renderFull: () -> Bitmap): Bitmap {
        glyph(d, size, renderFull)?.let { return normalize(it, size, scale) }
        val full = renderFull()
        val detail = detailMap(full)
        full.recycle()
        if (detail != null) return detail
        return letter(label, size, scale)
    }

    private fun glyph(d: Drawable, size: Int, renderFull: () -> Bitmap): Bitmap? {
        if (d is AdaptiveIconDrawable) {
            if (Build.VERSION.SDK_INT >= 33) d.monochrome?.let { mono ->
                val b = renderLayer(mono, size)
                if (isGlyph(b)) return whiten(b)
                b.recycle()
            }
            d.foreground?.let { fg ->
                val b = renderLayer(fg, size)
                if (isGlyph(b) && isFlatColour(b)) return whiten(b)
                separate(b)?.let { b.recycle(); return it }
                if (isGlyph(b)) return whiten(b)
                b.recycle()
            }
        }
        val full = renderFull()
        separate(full)?.let { full.recycle(); return it }
        if (isGlyph(full) && isFlatColour(full)) return whiten(full)
        full.recycle()
        return null
    }

    private fun renderLayer(layer: Drawable, size: Int): Bitmap {
        val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val ext = size * 0.25f
        val l = (-ext).roundToInt(); val r = (size + ext).roundToInt()
        layer.setBounds(l, l, r, r)
        layer.draw(Canvas(bmp))
        return bmp
    }

    /**
     * Coverage between 1.5% and 60% of the tile and not a plate: a solid square or disc filling most of the
     * tile is the icon's background, not its symbol. Solid but smaller shapes (a folder, a bubble) are fine.
     */
    fun isGlyph(b: Bitmap): Boolean {
        val w = b.width; val h = b.height
        val px = IntArray(w * h); b.getPixels(px, 0, w, 0, 0, w, h)
        var count = 0; var minX = w; var minY = h; var maxX = -1; var maxY = -1
        for (y in 0 until h) for (x in 0 until w) if ((px[y * w + x] ushr 24) > 128) {
            count++
            if (x < minX) minX = x; if (x > maxX) maxX = x; if (y < minY) minY = y; if (y > maxY) maxY = y
        }
        val coverage = count / (w * h).toFloat()
        if (coverage < 0.015f || coverage > 0.6f) return false
        val boxW = maxX - minX + 1; val boxH = maxY - minY + 1
        val solidity = count / (boxW * boxH).toFloat()
        val discFill = count / (PI.toFloat() / 4f * boxW * boxH)
        val plateSized = boxW > w * 0.7f && boxH > h * 0.7f
        return !(plateSized && (solidity > 0.78f || discFill > 0.9f))
    }

    /** True when the opaque pixels are essentially one colour (a logo, not artwork). */
    private fun isFlatColour(b: Bitmap): Boolean {
        val small = Bitmap.createScaledBitmap(b, 32, 32, true)
        var n = 0; var sum = 0f; var sumSq = 0f
        for (y in 0 until 32) for (x in 0 until 32) {
            val c = small.getPixel(x, y)
            if ((c ushr 24) < 200) continue
            val l = luminance(c); n++; sum += l; sumSq += l * l
        }
        if (small != b) small.recycle()
        if (n < 8) return true
        val mean = sum / n
        return sumSq / n - mean * mean < 0.012f
    }

    private fun whiten(b: Bitmap): Bitmap {
        val w = b.width; val h = b.height
        val px = IntArray(w * h); b.getPixels(px, 0, w, 0, 0, w, h)
        for (i in px.indices) px[i] = (px[i] and 0xFF000000.toInt()) or 0x00FFFFFF
        val out = Bitmap.createBitmap(px, w, h, Bitmap.Config.ARGB_8888).copy(Bitmap.Config.ARGB_8888, true)
        b.recycle()
        return out
    }

    /**
     * Finds the plate's background colour from samples just inside its edge, then keeps the pixels that
     * clearly differ from it. Returns null when the result does not look like a symbol.
     */
    fun separate(src: Bitmap): Bitmap? {
        val w = src.width; val h = src.height
        val px = IntArray(w * h); src.getPixels(px, 0, w, 0, 0, w, h)
        val opaqueMask = BooleanArray(w * h) { (px[it] ushr 24) > 200 }
        fun opaque(x: Int, y: Int) = x in 0 until w && y in 0 until h && opaqueMask[y * w + x]
        var minX = w; var minY = h; var maxX = -1; var maxY = -1
        for (y in 0 until h) {
            val row = y * w
            for (x in 0 until w) if (opaqueMask[row + x]) {
                if (x < minX) minX = x; if (x > maxX) maxX = x; if (y < minY) minY = y; if (y > maxY) maxY = y
            }
        }
        if (maxX < 0) return null
        val bw = maxX - minX + 1; val bh = maxY - minY + 1
        if (bw < w * 0.5f || bh < h * 0.5f) return null   // no plate to separate from
        val samples = ArrayList<Int>(160)
        val steps = 32
        val ix = (bw * 0.09f).roundToInt(); val iy = (bh * 0.09f).roundToInt()
        for (i in 0..steps) {
            val fx = minX + (bw - 1) * i / steps; val fy = minY + (bh - 1) * i / steps
            if (opaque(fx, minY + iy)) samples.add(px[(minY + iy) * w + fx])
            if (opaque(fx, maxY - iy)) samples.add(px[(maxY - iy) * w + fx])
            if (opaque(minX + ix, fy)) samples.add(px[fy * w + minX + ix])
            if (opaque(maxX - ix, fy)) samples.add(px[fy * w + maxX - ix])
        }
        if (samples.size < 12) return null
        val buckets = HashMap<Int, MutableList<Int>>()
        for (c in samples) buckets.getOrPut(((Color.red(c) shr 4) shl 8) or ((Color.green(c) shr 4) shl 4) or (Color.blue(c) shr 4)) { mutableListOf() }.add(c)
        val top = buckets.values.maxByOrNull { it.size } ?: return null
        if (top.size < samples.size * 0.35f) return null   // no dominant background (e.g. a photo icon)
        var sr = 0; var sg = 0; var sb = 0
        for (c in top) { sr += Color.red(c); sg += Color.green(c); sb += Color.blue(c) }
        val br = sr / top.size.toFloat(); val bgc = sg / top.size.toFloat(); val bb = sb / top.size.toFloat()
        val inset = max(2, (min(bw, bh) * 0.05f).roundToInt())
        val out = IntArray(w * h)
        var sum = 0f; var inner = 0
        for (y in minY..maxY) {
            val row = y * w
            for (x in minX..maxX) {
                if (!opaqueMask[row + x] || !opaque(x - inset, y) || !opaque(x + inset, y) || !opaque(x, y - inset) || !opaque(x, y + inset)) continue
                inner++
                val c = px[row + x]
                val dr = ((c shr 16) and 255) - br; val dg = ((c shr 8) and 255) - bgc; val db = (c and 255) - bb
                val dist = kotlin.math.sqrt(dr * dr + dg * dg + db * db) / 441.7f
                val a = ((dist - 0.1f) / 0.18f).coerceIn(0f, 1f)
                val alpha = a * a * (3 - 2 * a)
                sum += alpha
                if (alpha > 0f) out[row + x] = ((alpha * 255).roundToInt() shl 24) or 0x00FFFFFF
            }
        }
        if (inner == 0) return null
        val result = Bitmap.createBitmap(out, w, h, Bitmap.Config.ARGB_8888).copy(Bitmap.Config.ARGB_8888, true)
        val coverage = sum / inner
        return if (coverage in 0.02f..0.62f && isGlyph(result)) result else { result.recycle(); null }
    }

    /**
     * Scales a symbol so its longest side is about [scale] of the icon (never tiny, never touching the edge)
     * and centres it on its own bounding box.
     */
    fun normalize(src: Bitmap, size: Int, scale: Float): Bitmap {
        val w = src.width; val h = src.height
        val px = IntArray(w * h); src.getPixels(px, 0, w, 0, 0, w, h)
        var minX = w; var minY = h; var maxX = -1; var maxY = -1
        for (y in 0 until h) for (x in 0 until w) if ((px[y * w + x] ushr 24) > 24) {
            if (x < minX) minX = x; if (x > maxX) maxX = x; if (y < minY) minY = y; if (y > maxY) maxY = y
        }
        if (maxX < 0) return src
        val bw = (maxX - minX + 1).toFloat(); val bh = (maxY - minY + 1).toFloat()
        val longest = max(bw, bh)
        val lo = size * (scale - 0.1f); val hi = size * (scale + 0.06f)
        val k = when {
            longest > hi -> hi / longest
            longest < lo -> (lo / longest).coerceAtMost(2.4f)
            else -> 1f
        }
        val out = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val m = Matrix()
        m.postTranslate(-(minX + bw / 2f), -(minY + bh / 2f))
        m.postScale(k, k)
        m.postTranslate(size / 2f, size / 2f)
        Canvas(out).drawBitmap(src, m, Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG))
        src.recycle()
        return out
    }

    /**
     * For artwork icons (games, photos): a full-size map of the icon's details, so the themed icon is a
     * recognisable duotone picture instead of a blob. The dominant tone maps to the plate.
     */
    fun detailMap(full: Bitmap): Bitmap? {
        val w = full.width; val h = full.height
        val px = IntArray(w * h); full.getPixels(px, 0, w, 0, 0, w, h)
        val hist = IntArray(256); var n = 0
        for (c in px) if ((c ushr 24) > 200) { hist[(luminance(c) * 255f).roundToInt().coerceIn(0, 255)]++; n++ }
        if (n < w * h * 0.2f) return null
        fun pct(p: Float): Int { var acc = 0; val target = n * p; for (i in 0..255) { acc += hist[i]; if (acc >= target) return i }; return 255 }
        val lo = pct(0.05f); val hi = pct(0.95f); val med = pct(0.5f)
        val span = (hi - lo).toFloat()
        if (span < 18f) return null   // an almost uniform picture: use the initial instead
        val invert = med > (lo + hi) / 2f
        for (i in px.indices) {
            val c = px[i]
            val a = (c ushr 24) / 255f
            var t = (((luminance(c) * 255f) - lo) / span).coerceIn(0f, 1f)
            if (invert) t = 1f - t
            t = t * t * (3 - 2 * t)
            px[i] = Color.argb((t * a * 255f).roundToInt().coerceIn(0, 255), 255, 255, 255)
        }
        return Bitmap.createBitmap(px, w, h, Bitmap.Config.ARGB_8888).copy(Bitmap.Config.ARGB_8888, true)
    }

    /** Last resort: the app's initial, so a themed icon is never an empty or solid tile. */
    fun letter(label: String, size: Int, scale: Float): Bitmap {
        val out = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val ch = label.trim().firstOrNull { it.isLetterOrDigit() }?.uppercaseChar()?.toString() ?: "•"
        val p = android.text.TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE; typeface = Fonts.bold; textAlign = Paint.Align.CENTER; textSize = size * scale * 1.05f
        }
        Canvas(out).drawText(ch, size / 2f, size / 2f - (p.ascent() + p.descent()) / 2f, p)
        return out
    }
}
