package com.fluidone.launcher

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.os.SystemClock
import android.view.View
import android.view.ViewGroup
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.roundToInt

/** The expanding card used for app launch / return morphs. */
class MorphView(context: Context) : View(context) {
    val rect = RectF()
    var radius = 0f
    var color = Color.WHITE
    var bgAlpha = 0f
    var icon: Bitmap? = null
    var iconSize = 0f
    var iconAlpha = 1f
    private val bg = Paint(Paint.ANTI_ALIAS_FLAG)
    private val ip = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val dst = RectF()

    override fun onDraw(canvas: Canvas) {
        if (rect.isEmpty) return
        if (bgAlpha > 0f) {
            bg.color = color
            bg.alpha = (bgAlpha * 255).roundToInt().coerceIn(0, 255)
            canvas.drawRoundRect(rect, radius, radius, bg)
        }
        val b = icon ?: return
        if (iconAlpha <= 0f) return
        ip.alpha = (iconAlpha * 255).roundToInt().coerceIn(0, 255)
        val cx = rect.centerX(); val cy = rect.centerY()
        dst.set(cx - iconSize / 2f, cy - iconSize / 2f, cx + iconSize / 2f, cy + iconSize / 2f)
        canvas.drawBitmap(b, null, dst, ip)
    }
}

/**
 * App open/close and unlock choreography modelled on ColorOS:
 *  • open: the icon grows into a full-screen card with the screen's corner radius while the home screen zooms
 *    past the camera and the wallpaper blurs; the app window then fades in on top of the card;
 *  • return: the card is waiting under the closing app and shrinks back into the icon while the home screen
 *    settles and neighbouring icons ripple;
 *  • unlock: the wallpaper zooms out and icons gather in from the edges.
 */
class LaunchAnimator(private val launcher: MainActivity) {
    private enum class State { IDLE, OPENING, COVERING, RETURNING }

    private class Record(val key: String, val source: Int, val icon: Bitmap?, val color: Int, val time: Long, val folderId: Long)

    private val morph get() = launcher.morphView
    private var state = State.IDLE
    private var record: Record? = null
    private var anim: ValueAnimator? = null
    private var homeAnim: ValueAnimator? = null
    private var hiddenSource: View? = null
    private var stoppedSinceLaunch = false
    private var unlockPrimed = false
    private val coverCheck = Runnable { if (state == State.COVERING || state == State.OPENING) { if (!stoppedSinceLaunch) settleWithoutApp() } }

    val isBusy get() = state == State.OPENING || state == State.RETURNING

    // ---- App launch ----------------------------------------------------------------------------------------

    /** Starts the launch choreography. Returns the style that the activity options should use. */
    fun beginLaunch(entry: AppEntry?, iconRect: RectF?, source: Int, sourceView: View?, folderId: Long = -1L) {
        cancelAll()
        val style = launcher.prefs.launchAnim
        val pivotX = iconRect?.centerX() ?: launcher.rootView.width / 2f
        val pivotY = iconRect?.centerY() ?: launcher.rootView.height / 2f
        // Render the morph icon at splash size so it stays crisp while it grows.
        val icon = entry?.let { launcher.icons.appIconForDisplay(it, maxOf(launcher.iconSizePx, launcher.dpi(96))) }
        val color = icon?.let { edgeColor(it) } ?: Color.rgb(30, 30, 36)
        record = entry?.let { Record(it.key, source, icon, color, SystemClock.uptimeMillis(), folderId) }
        stoppedSinceLaunch = false
        state = State.OPENING
        val home = launcher.contentLayer
        home.pivotX = pivotX
        home.pivotY = pivotY
        if (!launcher.prefs.launchAnimations) {
            morph.visibility = View.GONE
            anim = null
            state = State.COVERING
            launcher.rootView.removeCallbacks(coverCheck)
            return
        }
        if (style == "morph" && iconRect != null && icon != null) {
            hiddenSource = sourceView
            sourceView?.alpha = 0f
            val end = RectF(0f, 0f, launcher.rootView.width.toFloat(), launcher.rootView.height.toFloat())
            val startRadius = iconRect.width() * 0.26f
            val endRadius = Device.screenCornerRadius(launcher.rootView)
            val splash = launcher.dp(96f)
            morph.icon = icon
            morph.color = color
            morph.visibility = View.VISIBLE
            val spring = Spring(0.93f, 0.44f)
            anim = ValueAnimator.ofFloat(0f, 1f).apply {
                duration = spring.ms
                interpolator = spring
                addUpdateListener {
                    val p = it.animatedValue as Float
                    lerpRect(morph.rect, iconRect, end, p)
                    morph.radius = lerp(startRadius, endRadius, clamp01(p))
                    morph.bgAlpha = clamp01(p * 2.4f)
                    morph.iconSize = lerp(iconRect.width(), splash, clamp01(p))
                    morph.iconAlpha = 1f
                    morph.invalidate()
                    applyHome(1f + 0.14f * p, 1f - clamp01(p * 1.4f), p)
                }
                addListener(endListener { if (state == State.OPENING) state = State.COVERING })
                start()
            }
        } else {
            // The system grows the app window out of the icon; the home screen eases back behind it, centred
            // on the icon, so both move as one.
            morph.visibility = View.GONE
            animateHome(Motion.d(280).toInt().toLong(), Motion.decel) { p -> applyHome(1f + 0.08f * p, 1f - 0.35f * p, 0.5f * p) }
            anim = null
            state = State.COVERING
        }
        launcher.rootView.removeCallbacks(coverCheck)
    }

    /** The app could not be started: run the opening backwards right away. */
    fun launchFailed() {
        stoppedSinceLaunch = true
        playReturn(force = true)
    }

    fun onPaused() {
        if (state == State.OPENING || state == State.COVERING) {
            launcher.rootView.removeCallbacks(coverCheck)
            launcher.rootView.postDelayed(coverCheck, 4000)
        }
    }

    fun onStopped() {
        if (state == State.OPENING || state == State.COVERING) {
            stoppedSinceLaunch = true
            launcher.rootView.removeCallbacks(coverCheck)
            anim?.end()
            state = State.COVERING
        }
    }

    /** The launcher is visible again. */
    fun onResumed() {
        launcher.rootView.removeCallbacks(coverCheck)
        if (unlockPrimed && !launcher.isKeyguardLocked()) { playUnlock(); return }
        if (state == State.COVERING || state == State.OPENING) playReturn()
    }

    /** Translucent app or failed launch: no stop happened, so quietly restore the home screen. */
    private fun settleWithoutApp() {
        anim?.cancel()
        val from = morph.bgAlpha
        anim = Motion.animate(240, Motion.decel, update = { p ->
            morph.bgAlpha = from * (1 - p); morph.iconAlpha = 1 - p; morph.invalidate()
            applyHome(lerp(1.08f, 1f, p), p, 1 - p)
        }, end = { finishReturn() })
        state = State.RETURNING
    }

    private fun playReturn(force: Boolean = false) {
        val rec = record
        anim?.cancel()
        state = State.RETURNING
        val stale = rec == null || SystemClock.uptimeMillis() - rec.time > 30 * 60_000L
        val target = if (stale) null else launcher.findLaunchTarget(rec!!.key, rec.source, rec.folderId)
        val targetRect = target?.second
        val morphing = launcher.prefs.launchAnim == "morph" && launcher.prefs.returnAnim && morph.visibility == View.VISIBLE && targetRect != null
        if (target?.first !== hiddenSource) { hiddenSource?.alpha = 1f; hiddenSource = target?.first }
        hiddenSource?.alpha = if (morphing) 0f else 1f
        if (morphing && targetRect != null) {
            val start = RectF(morph.rect.takeIf { !it.isEmpty } ?: RectF(0f, 0f, launcher.rootView.width.toFloat(), launcher.rootView.height.toFloat()))
            val startRadius = morph.radius.takeIf { it > 0f } ?: Device.screenCornerRadius(launcher.rootView)
            val endRadius = targetRect.width() * 0.26f
            val startIcon = morph.iconSize.takeIf { it > 0f } ?: launcher.dp(96f)
            launcher.contentLayer.pivotX = targetRect.centerX()
            launcher.contentLayer.pivotY = targetRect.centerY()
            ripple(target?.first)
            val spring = Spring(0.86f, 0.42f)
            anim = ValueAnimator.ofFloat(0f, 1f).apply {
                duration = spring.ms
                interpolator = spring
                addUpdateListener {
                    val p = it.animatedValue as Float
                    lerpRect(morph.rect, start, targetRect, p)
                    morph.radius = lerp(startRadius, endRadius, clamp01(p))
                    morph.bgAlpha = 1f - clamp01(p * 1.6f)
                    morph.iconSize = lerp(startIcon, targetRect.width(), p)
                    morph.iconAlpha = 1f
                    morph.invalidate()
                    applyHome(lerp(1.14f, 1f, p), clamp01(p * 1.7f), 1f - clamp01(p * 1.3f))
                }
                addListener(endListener { finishReturn() })
                start()
            }
        } else {
            morph.visibility = View.GONE
            if (!launcher.prefs.launchAnimations && !force) { finishReturn(); return }
            // Closing: while the system shrinks the app away, the home screen zooms back in toward the icon
            // the app came from, which springs into place.
            targetRect?.let { launcher.contentLayer.pivotX = it.centerX(); launcher.contentLayer.pivotY = it.centerY() }
            val fromAlpha = if (force) launcher.contentLayer.alpha else 0.55f
            val fromScale = if (force) launcher.contentLayer.scaleX else 1.08f
            val spring = Spring(0.9f, 0.4f)
            animateHome(spring.ms, spring) { p ->
                applyHome(lerp(fromScale, 1f, p), lerp(fromAlpha, 1f, clamp01(p * 1.5f)), (1f - p) * 0.5f)
            }
            if (launcher.prefs.returnAnim) target?.first?.let { v ->
                if (v !is IconView) return@let
                v.scaleX = 0.86f; v.scaleY = 0.86f
                val pop = Spring(0.6f, 0.4f)
                v.animate().scaleX(1f).scaleY(1f).setStartDelay(Motion.d(60)).setDuration(pop.ms).setInterpolator(pop).start()
            }
            if (launcher.prefs.returnAnim) target?.first?.let { ripple(it) }
            launcher.rootView.postDelayed({ if (state == State.RETURNING) finishReturn() }, spring.ms + 20)
        }
    }

    private fun finishReturn() {
        morph.visibility = View.GONE
        morph.rect.setEmpty()
        morph.icon = null
        hiddenSource?.alpha = 1f
        hiddenSource = null
        applyHome(1f, 1f, 0f)
        state = State.IDLE
        record = null
    }

    private fun ripple(center: View?) {
        if (center == null || launcher.prefs.animSpeed <= 0) return
        val parent = center.parent as? ViewGroup ?: return
        val cx = center.left + center.width / 2f
        val cy = center.top + center.height / 2f
        val maxD = hypot(parent.width.toFloat(), parent.height.toFloat()).coerceAtLeast(1f)
        for (i in 0 until parent.childCount) {
            val v = parent.getChildAt(i)
            if (v === center || v.visibility != View.VISIBLE) continue
            val d = hypot(v.left + v.width / 2f - cx, v.top + v.height / 2f - cy)
            v.scaleX = 0.9f; v.scaleY = 0.9f
            val spring = Spring(0.66f, 0.42f)
            v.animate().scaleX(1f).scaleY(1f).setStartDelay(Motion.d((d / maxD * 140).toLong()))
                .setDuration(spring.ms).setInterpolator(spring).start()
        }
    }

    private fun applyHome(scale: Float, alpha: Float, blur: Float) {
        val home = launcher.contentLayer
        home.scaleX = scale; home.scaleY = scale
        home.alpha = alpha.coerceIn(0f, 1f)
        launcher.wallpaperView.zoom = 1f + (scale - 1f) * 0.45f
        if (blur > 0.002f) launcher.backdrop.set(this, blur * 0.7f, blur * 0.12f) else launcher.backdrop.clear(this)
    }

    private fun animateHome(ms: Long, interp: android.animation.TimeInterpolator, update: (Float) -> Unit) {
        homeAnim?.cancel()
        homeAnim = Motion.animate(ms, interp, update = update)
    }

    fun cancelAll() {
        anim?.cancel(); homeAnim?.cancel()
        launcher.rootView.removeCallbacks(coverCheck)
        if (state != State.IDLE) finishReturn()
    }

    /** Called when another app covered the launcher by other means (e.g. Home pressed while opening). */
    fun reset() = cancelAll()

    // ---- Unlock --------------------------------------------------------------------------------------------

    /** The screen turned off while home was showing: hide the content so the unlock can reveal it. */
    fun primeUnlock() {
        if (launcher.prefs.unlockAnim == "off" || state != State.IDLE || launcher.isDrawerOpen || launcher.isEditing) return
        unlockPrimed = true
        launcher.contentLayer.alpha = 0f
        launcher.wallpaperView.zoom = 1.12f
    }

    val isUnlockPrimed get() = unlockPrimed

    fun playUnlock() {
        if (!unlockPrimed || !launcher.wallpaperView.hasWallpaper) return
        unlockPrimed = false
        playEntrance(launcher.prefs.unlockAnim)
    }

    /** Entrance used for unlock and first start. */
    fun playEntrance(style: String) {
        val home = launcher.contentLayer
        homeAnim?.cancel()
        home.scaleX = 1f; home.scaleY = 1f
        if (style == "off") { home.alpha = 1f; launcher.wallpaperView.zoom = 1f; launcher.backdrop.clear(this); return }
        val wall = launcher.wallpaperView
        val startZoom = max(wall.zoom, 1.1f)
        Motion.animate(680, Motion.emphasized, update = { p -> wall.zoom = lerp(startZoom, 1f, p) })
        val blurSpring = Spring(1f, 0.34f)
        Motion.animate(blurSpring.durationMs, blurSpring, update = { p ->
            if (p >= 0.999f) launcher.backdrop.clear(this) else launcher.backdrop.set(this, (1 - p) * 0.8f, 0f)
        })
        val views = launcher.entranceViews()
        val w = launcher.rootView.width.toFloat()
        val h = launcher.rootView.height.toFloat()
        val cx = w / 2f
        val cy = h * 0.45f
        val maxD = hypot(w, h) / 2f
        when (style) {
            "oneui" -> {
                // One UI: the whole home screen settles in from slightly larger, quickly and together.
                home.alpha = 0f
                home.pivotX = cx; home.pivotY = h * 0.5f
                val spring = Spring(0.95f, 0.36f)
                Motion.animate(spring.durationMs, spring, update = { p ->
                    val s = lerp(1.08f, 1f, p)
                    home.scaleX = s; home.scaleY = s
                    home.alpha = clamp01(p * 2.2f)
                })
            }
            "coloros" -> {
                // ColorOS: icons float up from a little below while growing from 82%, nearest to the middle first.
                home.alpha = 1f
                views.forEach { (v, r) ->
                    val d = hypot(r.centerX() - cx, r.centerY() - cy) / maxD
                    v.alpha = 0f; v.translationY = launcher.dp(28f); v.scaleX = 0.82f; v.scaleY = 0.82f
                    val spring = Spring(0.82f, 0.46f)
                    v.animate().alpha(1f).translationY(0f).scaleX(1f).scaleY(1f).setStartDelay(Motion.d((d * 120).toLong()))
                        .setDuration(spring.ms).setInterpolator(spring)
                        .withEndAction { v.alpha = 1f; v.translationY = 0f; v.scaleX = 1f; v.scaleY = 1f }.start()
                }
            }
            "hyperos" -> {
                // HyperOS: icons drop in from above, row by row, with a soft bounce.
                home.alpha = 1f
                views.forEach { (v, r) ->
                    val row = r.centerY() / h
                    v.alpha = 0f; v.translationY = -launcher.dp(56f)
                    val spring = Spring(0.62f, 0.5f)
                    v.animate().alpha(1f).translationY(0f).setStartDelay(Motion.d((row * 160).toLong()))
                        .setDuration(spring.ms).setInterpolator(spring)
                        .withEndAction { v.alpha = 1f; v.translationY = 0f }.start()
                }
            }
            "ripple" -> {
                // Ripple: icons pop up in a wave that spreads from the middle of the screen.
                home.alpha = 1f
                views.forEach { (v, r) ->
                    val d = hypot(r.centerX() - cx, r.centerY() - cy) / maxD
                    v.alpha = 0f; v.scaleX = 0.4f; v.scaleY = 0.4f
                    val spring = Spring(0.58f, 0.42f)
                    v.animate().alpha(1f).scaleX(1f).scaleY(1f).setStartDelay(Motion.d((d * 240).toLong()))
                        .setDuration(spring.ms).setInterpolator(spring)
                        .withEndAction { v.alpha = 1f; v.scaleX = 1f; v.scaleY = 1f }.start()
                }
            }
            "zoom" -> {
                home.alpha = 0f
                home.pivotX = cx; home.pivotY = cy
                val spring = Spring(0.85f, 0.5f)
                Motion.animate(spring.durationMs, spring, update = { p ->
                    val s = lerp(1.18f, 1f, p)
                    home.scaleX = s; home.scaleY = s
                    home.alpha = clamp01(p * 2f)
                })
            }
            "rise" -> {
                home.alpha = 1f
                views.forEach { (v, r) ->
                    v.alpha = 0f
                    v.translationY = launcher.dp(70f)
                    val row = (r.centerY() / h)
                    val spring = Spring(0.8f, 0.5f)
                    v.animate().alpha(1f).translationY(0f).setStartDelay(Motion.d((row * 140).toLong()))
                        .setDuration(spring.ms).setInterpolator(spring).start()
                }
            }
            else -> { // gather
                home.alpha = 1f
                views.forEach { (v, r) ->
                    val dx = r.centerX() - cx
                    val dy = r.centerY() - cy
                    val d = hypot(dx, dy) / maxD
                    v.alpha = 0f
                    v.translationX = dx * 0.42f
                    v.translationY = dy * 0.42f
                    v.scaleX = 1.36f; v.scaleY = 1.36f
                    val spring = Spring(0.8f, 0.52f)
                    v.animate().alpha(1f).translationX(0f).translationY(0f).scaleX(1f).scaleY(1f)
                        .setStartDelay(Motion.d((d * 90).toLong()))
                        .setDuration(spring.ms).setInterpolator(spring)
                        .withEndAction { v.alpha = 1f; v.translationX = 0f; v.translationY = 0f; v.scaleX = 1f; v.scaleY = 1f }
                        .start()
                }
            }
        }
    }

    fun cancelUnlockPrime() {
        if (!unlockPrimed) return
        unlockPrimed = false
        launcher.contentLayer.alpha = 1f
        launcher.wallpaperView.zoom = 1f
    }

    companion object {
        fun lerpRect(out: RectF, a: RectF, b: RectF, t: Float) {
            out.set(lerp(a.left, b.left, t), lerp(a.top, b.top, t), lerp(a.right, b.right, t), lerp(a.bottom, b.bottom, t))
        }

        /** Colour of an icon's background layer, sampled just inside its left edge. */
        fun edgeColor(icon: Bitmap): Int {
            val x = (icon.width * 0.16f).roundToInt().coerceIn(0, icon.width - 1)
            val y = (icon.height * 0.5f).roundToInt().coerceIn(0, icon.height - 1)
            val c = icon.getPixel(x, y)
            return if (Color.alpha(c) < 200) IconFactory.averageColor(icon) else c or 0xFF000000.toInt()
        }

        private fun endListener(block: () -> Unit) = object : android.animation.AnimatorListenerAdapter() {
            private var cancelled = false
            override fun onAnimationCancel(animation: android.animation.Animator) { cancelled = true }
            override fun onAnimationEnd(animation: android.animation.Animator) { if (!cancelled) block() }
        }
    }
}
