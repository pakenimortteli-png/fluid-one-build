package com.fluidone.launcher

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.RectF
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.accessibility.AccessibilityNodeInfo
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.roundToInt

/**
 * Draws a control's own track into a bitmap so a Fluid Glass knob can refract it. Shared by the switch and
 * the slider; the bitmap is reused and only redrawn while the glass knob is showing.
 */
internal class KnobGlass(private val view: View) {
    val painter: GlassPainter? = if (FluidGlass.supported) GlassPainter(view.context) else null
    private var bmp: Bitmap? = null
    val identity = Matrix()
    private val shadow = Paint(Paint.ANTI_ALIAS_FLAG)

    /** The soft shadow a glass knob casts on the track. */
    fun shadow(canvas: Canvas, r: RectF, radius: Float, amount: Float) {
        val dp = view.resources.displayMetrics.density
        shadow.color = Color.argb((46 * amount.coerceIn(0f, 1f)).toInt(), 0, 0, 0)
        shadow.maskFilter = android.graphics.BlurMaskFilter(3f * dp, android.graphics.BlurMaskFilter.Blur.NORMAL)
        canvas.drawRoundRect(r.left + dp, r.top + 2f * dp, r.right - dp, r.bottom + 2f * dp, radius, radius, shadow)
    }

    fun enabled(): Boolean = painter != null && (view.context as? MainActivity)?.prefs?.fluidGlass != false

    /** A fresh bitmap of what is under the knob, painted by [draw]. */
    fun backdrop(color: Int, draw: (Canvas) -> Unit): Bitmap? {
        val w = view.width; val h = view.height
        if (w <= 0 || h <= 0) return null
        var b = bmp
        if (b == null || b.width != w || b.height != h) { b = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888); bmp = b }
        b!!.eraseColor(color)
        draw(Canvas(b))
        return b
    }
}

/**
 * ColorOS-style toggle: a pill track that fills with the accent colour and a white thumb that glides on a
 * spring. While touched, the thumb turns into a Fluid Glass lens that magnifies the track beneath it.
 */
class ColorSwitch(context: Context, private val theme: UiTheme) : View(context) {
    /** The colour behind the switch (its settings card), so the glass knob shows the right thing around the track. */
    var backdropColor: Int = theme.card
    var isChecked = false
        private set
    var onChange: ((Boolean) -> Unit)? = null

    private var progress = 0f
    private var pressAmount = 0f
    private val progressSpring = SpringValue(0f) { progress = it.coerceIn(-0.15f, 1.15f); invalidate() }
    private var pressAnim: ValueAnimator? = null
    // Holding the thumb and sliding it, like a real switch.
    private var dragging = false
    private var downX = 0f
    private var downProgress = 0f
    // A switch only travels ~20 dp, so the knob starts following the finger after half the usual slop.
    private val slop = ViewConfiguration.get(context).scaledTouchSlop / 2
    private val track = Paint(Paint.ANTI_ALIAS_FLAG)
    private val thumb = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }
    private val shadow = Paint(Paint.ANTI_ALIAS_FLAG)
    private val r = RectF()
    private val knob = KnobGlass(this)
    private var lens = 0f
    private val lensSpring = SpringValue(0f) { lens = it; invalidate() }
    private var touching = false
    private val settle = Runnable { if (!touching) lensSpring.animateTo(0f, 170f, 0.6f) }

    init {
        isClickable = true
        isFocusable = true
        setOnClickListener { setChecked(!isChecked, animate = true, fromUser = true) }
        importantForAccessibility = IMPORTANT_FOR_ACCESSIBILITY_YES
    }

    fun setChecked(value: Boolean, animate: Boolean = false, fromUser: Boolean = false) {
        if (value == isChecked && !animate) { progressSpring.snapTo(if (value) 1f else 0f); return }
        isChecked = value
        // A spring keeps the thumb's speed when it is let go mid-drag, so it glides instead of jumping.
        if (!animate) progressSpring.snapTo(if (value) 1f else 0f)
        else progressSpring.animateTo(if (value) 1f else 0f, 420f, 0.62f)
        if (fromUser) {
            performHapticFeedback(if (value) HapticFeedbackConstants.CONFIRM else HapticFeedbackConstants.CLOCK_TICK)
            // The thumb turns to glass while it travels, then solidifies on the other side.
            if (animate && knob.enabled()) {
                lensSpring.animateTo(1f, 520f, 0.7f)
                removeCallbacks(settle); postDelayed(settle, 190)
            }
            onChange?.invoke(value)
        }
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) =
        setMeasuredDimension(dpi(52), dpi(32))

    private fun travelPx(): Float {
        val h = dp(28f); val w = dp(48f)
        val inset = dp(3f)
        return w - 2 * inset - (h - 2 * inset)
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        if (!isEnabled) return super.onTouchEvent(event)
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                touching = true
                dragging = false
                downX = event.x
                downProgress = progress
                animatePress(1f)
                if (knob.enabled()) lensSpring.animateTo(1f, 560f, 0.65f)
            }
            MotionEvent.ACTION_MOVE -> {
                if (!dragging && abs(event.x - downX) > slop) {
                    dragging = true
                    parent?.requestDisallowInterceptTouchEvent(true)
                    // Stop the normal tap handling: this gesture is a drag.
                    super.onTouchEvent(MotionEvent.obtain(event).apply { action = MotionEvent.ACTION_CANCEL })
                }
                if (dragging) {
                    val p = downProgress + (event.x - downX) / travelPx()
                    // Rubber-band slightly past the ends.
                    val clamped = when { p < 0f -> p * 0.25f; p > 1f -> 1f + (p - 1f) * 0.25f; else -> p }
                    progressSpring.snapTo(clamped)
                    return true
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                touching = false
                animatePress(0f)
                removeCallbacks(settle); postDelayed(settle, 190)
                if (dragging) {
                    dragging = false
                    parent?.requestDisallowInterceptTouchEvent(false)
                    val on = progress > 0.5f
                    if (event.actionMasked == MotionEvent.ACTION_UP && on != isChecked) setChecked(on, animate = true, fromUser = true)
                    else progressSpring.animateTo(if (isChecked) 1f else 0f, 420f, 0.62f)
                    return true
                }
            }
        }
        return super.onTouchEvent(event)
    }

    private fun animatePress(to: Float) {
        pressAnim?.cancel()
        pressAnim = ValueAnimator.ofFloat(pressAmount, to).apply {
            duration = if (to > 0f) 120 else 260
            interpolator = Motion.decel
            addUpdateListener { pressAmount = it.animatedValue as Float; invalidate() }
            start()
        }
    }

    override fun onDraw(canvas: Canvas) {
        val h = dp(28f)
        val w = dp(48f)
        val left = (width - w) / 2f
        val top = (height - h) / 2f
        r.set(left, top, left + w, top + h)
        track.color = blendColors(theme.switchOff, theme.accent, progress.coerceIn(0f, 1f))
        canvas.drawRoundRect(r, h / 2f, h / 2f, track)
        val inset = dp(3f)
        val d = h - 2 * inset
        val stretch = dp(7f) * pressAmount
        val travel = w - 2 * inset - d
        val pr = progress.coerceIn(0f, 1f)
        val x0 = left + inset + travel * progress
        // Stretch toward the side the thumb will travel to.
        val tl = x0 - stretch * pr
        val tr = x0 + d + stretch * (1f - pr)
        r.set(tl, top + inset, tr, top + inset + d)
        val l = lens.coerceIn(-0.2f, 1.2f)
        if (l > 0.01f && knob.enabled() && canvas.isHardwareAccelerated) {
            // Liquid knob: a wider glass lens over the track; the white thumb melts into it.
            r.inset(-dp(4.5f) * l, -dp(4f) * l)
            val trackColor = track.color
            val bg = knob.backdrop(backdropColor) { c ->
                track.color = trackColor
                c.drawRoundRect(left, top, left + w, top + h, h / 2f, h / 2f, track)
            }
            if (bg != null) knob.shadow(canvas, r, r.height() / 2f, l)
            if (bg != null && knob.painter!!.draw(canvas, r, r.height() / 2f, 1f, Color.argb(16, 255, 255, 255), bg, knob.identity, bg, knob.identity, l * 0.6f)) {
                val a = ((1f - l) * 255).toInt().coerceIn(0, 255)
                if (a > 0) {
                    shadow.color = Color.argb(40 * a / 255, 0, 0, 0)
                    canvas.drawRoundRect(r.left, r.top + dp(1f), r.right, r.bottom + dp(1f), r.height() / 2f, r.height() / 2f, shadow)
                    thumb.alpha = a
                    canvas.drawRoundRect(r, r.height() / 2f, r.height() / 2f, thumb)
                    thumb.alpha = 255
                }
                return
            }
        }
        shadow.color = Color.argb(40, 0, 0, 0)
        canvas.drawRoundRect(r.left, r.top + dp(1f), r.right, r.bottom + dp(1f), d / 2f, d / 2f, shadow)
        canvas.drawRoundRect(r, d / 2f, d / 2f, thumb)
    }

    override fun onDetachedFromWindow() {
        removeCallbacks(settle)
        lensSpring.snapTo(0f)
        progressSpring.snapTo(if (isChecked) 1f else 0f)
        super.onDetachedFromWindow()
    }

    override fun onInitializeAccessibilityNodeInfo(info: AccessibilityNodeInfo) {
        super.onInitializeAccessibilityNodeInfo(info)
        info.className = "android.widget.Switch"
        info.isCheckable = true
        info.isChecked = isChecked
    }
}

/**
 * Rounded slider with a white thumb. While dragged, the thumb becomes a wide Fluid Glass lens that magnifies
 * the track and fill beneath it, and springs back with a little wobble when released.
 */
class FluidSlider(context: Context, private val theme: UiTheme, val min: Int, val max: Int, initial: Int) : View(context) {
    /** The colour behind the slider, so the glass thumb shows the right thing around the track. */
    var backdropColor: Int = theme.card
    var value = initial.coerceIn(min, max)
        private set
    var onChange: ((Int) -> Unit)? = null
    var onCommit: ((Int) -> Unit)? = null

    private var active = 0f
    private val activeSpring = SpringValue(0f) { active = it; invalidate() }
    private val knob = KnobGlass(this)
    private val trackPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val thumbPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }
    private val shadow = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(46, 0, 0, 0) }
    private val r = RectF()
    private var lastTick = 0L
    private var downX = 0f
    private var dragging = false
    private val slop = ViewConfiguration.get(context).scaledTouchSlop

    init { isClickable = true; isFocusable = true }

    fun setValue(v: Int) { value = v.coerceIn(min, max); invalidate() }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) =
        setMeasuredDimension(MeasureSpec.getSize(widthMeasureSpec), dpi(40))

    private fun fraction() = if (max == min) 0f else (value - min) / (max - min).toFloat()

    private fun drawTrack(c: Canvas, left: Float, right: Float, cy: Float, trackH: Float, x: Float) {
        r.set(left, cy - trackH / 2f, right, cy + trackH / 2f)
        trackPaint.color = theme.switchOff
        c.drawRoundRect(r, trackH / 2f, trackH / 2f, trackPaint)
        r.set(left, cy - trackH / 2f, x, cy + trackH / 2f)
        fillPaint.color = theme.accent
        c.drawRoundRect(r, trackH / 2f, trackH / 2f, fillPaint)
    }

    override fun onDraw(canvas: Canvas) {
        val a = active.coerceIn(-0.2f, 1.25f)
        val trackH = dp(6f) + dp(2f) * a.coerceAtLeast(0f)
        val left = dp(12f)
        val right = width - dp(12f)
        val cy = height / 2f
        val x = left + (right - left) * fraction()
        drawTrack(canvas, left, right, cy, trackH, x)
        if (a > 0.01f && knob.enabled() && canvas.isHardwareAccelerated) {
            // Liquid thumb: a glass capsule that magnifies the track under it.
            val hw = dp(11f) * (1f + 0.8f * a)
            val hh = dp(11f) * (1f + 0.25f * a)
            val rr = RectF(x - hw, cy - hh, x + hw, cy + hh)
            val bg = knob.backdrop(backdropColor) { c -> drawTrack(c, left, right, cy, trackH, x) }
            if (bg != null) knob.shadow(canvas, rr, hh, a)
            if (bg != null && knob.painter!!.draw(canvas, rr, hh, 1f, Color.argb(16, 255, 255, 255), bg, knob.identity, bg, knob.identity, a * 0.6f)) {
                val alpha = ((1f - a) * 255).toInt().coerceIn(0, 255)
                if (alpha > 0) {
                    shadow.alpha = 46 * alpha / 255; thumbPaint.alpha = alpha
                    canvas.drawRoundRect(rr.left, rr.top + dp(1f), rr.right, rr.bottom + dp(1f), hh, hh, shadow)
                    canvas.drawRoundRect(rr, hh, hh, thumbPaint)
                    shadow.alpha = 46; thumbPaint.alpha = 255
                }
                return
            }
        }
        val thumbR = dp(11f) * (1f + 0.18f * a)
        canvas.drawCircle(x, cy + dp(1f), thumbR, shadow)
        canvas.drawCircle(x, cy, thumbR, thumbPaint)
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downX = event.x
                dragging = false
                animateActive(1f)
            }
            MotionEvent.ACTION_MOVE -> {
                if (!dragging && abs(event.x - downX) > slop) {
                    dragging = true
                    parent?.requestDisallowInterceptTouchEvent(true)
                }
                if (dragging) update(event.x)
            }
            MotionEvent.ACTION_UP -> {
                if (!dragging) update(event.x)
                animateActive(0f)
                onCommit?.invoke(value)
                parent?.requestDisallowInterceptTouchEvent(false)
            }
            MotionEvent.ACTION_CANCEL -> {
                animateActive(0f)
                if (dragging) onCommit?.invoke(value)
            }
        }
        return true
    }

    private fun update(x: Float) {
        val left = dp(12f)
        val right = width - dp(12f)
        val f = ((x - left) / max(1f, right - left)).coerceIn(0f, 1f)
        val v = (min + f * (max - min)).roundToInt()
        if (v != value) {
            value = v
            val now = System.currentTimeMillis()
            if (now - lastTick > 45) { performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK); lastTick = now }
            onChange?.invoke(v)
            invalidate()
        }
    }

    private fun animateActive(to: Float) {
        // Quick and firm when grabbed; a soft wobble when let go.
        if (to > 0f) activeSpring.animateTo(to, 620f, 0.68f) else activeSpring.animateTo(to, 260f, 0.42f)
    }

    override fun onDetachedFromWindow() {
        activeSpring.snapTo(0f)
        super.onDetachedFromWindow()
    }
}

/** Pill segmented control with a sliding highlight. */
class SegmentedControl(
    context: Context,
    private val theme: UiTheme,
    private val labels: List<String>,
    selected: Int
) : View(context) {
    var selected = selected.coerceIn(0, labels.size - 1)
        private set
    var onSelect: ((Int) -> Unit)? = null
    private var highlight = this.selected.toFloat()
    private var anim: ValueAnimator? = null
    private val bg = Paint(Paint.ANTI_ALIAS_FLAG)
    private val hl = Paint(Paint.ANTI_ALIAS_FLAG)
    private val text = android.text.TextPaint(Paint.ANTI_ALIAS_FLAG).apply { typeface = Fonts.medium; textSize = dp(13f) }
    private val r = RectF()

    init { isClickable = true }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) =
        setMeasuredDimension(MeasureSpec.getSize(widthMeasureSpec), dpi(38))

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        r.set(0f, 0f, w, h)
        bg.color = theme.chip
        canvas.drawRoundRect(r, h / 2f, h / 2f, bg)
        val seg = w / labels.size
        val inset = dp(3f)
        r.set(highlight * seg + inset, inset, (highlight + 1) * seg - inset, h - inset)
        hl.color = if (theme.dark) Color.argb(255, 70, 70, 76) else Color.WHITE
        canvas.drawRoundRect(r, (h - 2 * inset) / 2f, (h - 2 * inset) / 2f, hl)
        labels.forEachIndexed { i, label ->
            val t = (1f - abs(highlight - i)).coerceIn(0f, 1f)
            text.color = blendColors(theme.textSecondary, theme.text, t)
            val ellipsized = android.text.TextUtils.ellipsize(label, text, seg - dp(8f), android.text.TextUtils.TruncateAt.END)
            val tw = text.measureText(ellipsized, 0, ellipsized.length)
            canvas.drawText(ellipsized, 0, ellipsized.length, i * seg + (seg - tw) / 2f, h / 2f - (text.ascent() + text.descent()) / 2f, text)
        }
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        if (event.actionMasked == MotionEvent.ACTION_UP) {
            val i = (event.x / (width / labels.size.toFloat())).toInt().coerceIn(0, labels.size - 1)
            select(i, fromUser = true)
        }
        return true
    }

    fun select(i: Int, fromUser: Boolean) {
        if (i == selected) return
        selected = i
        anim?.cancel()
        val spring = Spring(0.82f, 0.32f)
        anim = ValueAnimator.ofFloat(highlight, i.toFloat()).apply {
            duration = spring.durationMs; interpolator = spring
            addUpdateListener { highlight = it.animatedValue as Float; invalidate() }
            start()
        }
        if (fromUser) {
            performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)
            onSelect?.invoke(i)
        }
    }
}
