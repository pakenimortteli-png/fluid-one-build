package com.fluidone.launcher

import android.content.Context
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.annotation.Config
import org.robolectric.annotation.GraphicsMode
import org.robolectric.annotation.LooperMode

/** A fresh install shows "Welcome to Fluid One"; walking through it ends on the home screen. */
@RunWith(RobolectricTestRunner::class)
@Config(sdk = [35], qualifiers = "w384dp-h832dp-xxhdpi")
@GraphicsMode(GraphicsMode.Mode.NATIVE)
@LooperMode(LooperMode.Mode.PAUSED)
class WelcomeTest : LauncherTestBase() {
    override val skipWelcome = false

    @Test
    fun welcomeOnFreshInstall() {
        idle(600)
        val w = a.overlays.filterIsInstance<WelcomeOverlay>().firstOrNull()
        assertTrue("welcome shown on first start", w != null)
        assertTrue(texts().contains("Welcome to\nFluid One"))
        assertTrue(texts().contains("Skip"))
        hwShot("w01_welcome")
        // Pressing Home, coming back from another app or a theme change keeps the welcome open.
        controller.newIntent(android.content.Intent(android.content.Intent.ACTION_MAIN).addCategory(android.content.Intent.CATEGORY_HOME)); idle(600)
        controller.pause().stop(); idle(100); controller.restart().resume(); idle(100)
        controller.newIntent(android.content.Intent(android.content.Intent.ACTION_MAIN).addCategory(android.content.Intent.CATEGORY_HOME)); idle(600)
        a.applyThemeChange(); idle(300)
        assertTrue("welcome survives Home and theme changes", a.overlays.any { it === w } && w!!.root.parent != null)
        assertEquals(0L, a.prefs.sp.getLong("welcome_seen_code", 0L))
        for (i in 1..5) {
            w!!.next(); idle(900)
            assertEquals(i, w.currentPage)
            hwShot("w0${i + 1}_page_$i")
        }
        assertTrue("last page talks about privacy", texts().contains("Private by design"))
        assertTrue(texts().any { it.contains("never shared with third parties") })
        val button = all(a.rootView).filterIsInstance<WelcomeButton>().first { it.isShown }
        assertEquals("Get started", button.label)
        button.performClick(); idle(1200)
        assertTrue("welcome closed", a.overlays.none { it is WelcomeOverlay })
        assertEquals(1f, a.contentLayer.alpha, 0.01f)
        assertTrue(a.prefs.sp.getLong("welcome_seen_code", 0L) > 0L)
        hwShot("w08_home_after_welcome")
        // Shown only once.
        controller.pause().stop().destroy(); idle(100)
        controller = org.robolectric.Robolectric.buildActivity(MainActivity::class.java).setup()
        a = controller.get(); idle(1200)
        assertTrue(a.overlays.none { it is WelcomeOverlay })
    }
}

/** Updating from an earlier version shows "What's new in 1.2" and keeps every customization. */
@RunWith(RobolectricTestRunner::class)
@Config(sdk = [35], qualifiers = "w384dp-h832dp-xxhdpi")
@GraphicsMode(GraphicsMode.Mode.NATIVE)
@LooperMode(LooperMode.Mode.PAUSED)
class WhatsNewTest : LauncherTestBase() {
    override val skipWelcome = false

    override fun beforeLaunch() {
        // Settings exactly as Fluid One 2.3 stored them.
        RuntimeEnvironment.getApplication().getSharedPreferences("fluid_one", Context.MODE_PRIVATE).edit()
            .putString("wallpaper_id", "glass_orbs").putInt("fluid_glass_intensity", 64).putString("icon_style", "themed_dark")
            .putString("search_history", "[\"weather\"]").putString("launch_counts", "{\"x\":3}").putInt("grid_columns", 5)
            .putBoolean("fluid_glass", true).commit()
    }

    @Test
    fun whatsNewAfterUpdate() {
        idle(600)
        assertTrue(a.overlays.any { it is WelcomeOverlay })
        val t = texts()
        assertTrue(t.toString(), t.any { it.startsWith("What's new") })
        assertTrue(t.contains("Your layout, wallpaper and settings are all still here."))
        hwShot("w10_whats_new")
        all(a.rootView).filterIsInstance<WelcomeButton>().first { it.isShown }.performClick(); idle(1200)
        assertTrue(a.overlays.none { it is WelcomeOverlay })
        // Customizations survived the update.
        assertEquals("glass_orbs", a.prefs.wallpaper)
        assertEquals(64, a.prefs.fluidIntensity)
        assertEquals("themed_dark", a.prefs.iconStyle)
        assertEquals(5, a.prefs.columns)
        assertEquals(listOf("weather"), a.prefs.searchHistory)
        assertTrue(a.prefs.fluidGlass)
        assertEquals("zoom", a.prefs.launchAnim)
    }
}
