package com.fluidone.launcher

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.drawable.AdaptiveIconDrawable
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.ColorDrawable
import android.os.SystemClock
import android.view.MotionEvent
import android.view.View
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import org.robolectric.annotation.GraphicsMode
import org.robolectric.annotation.LooperMode
import org.robolectric.shadows.ShadowBuild
import java.io.File
import java.io.FileOutputStream
import kotlin.math.abs

/** Fluid One 1.2: themed icons on every phone, widgets, switches, smart search, unlock styles. */
@RunWith(RobolectricTestRunner::class)
@Config(sdk = [35], qualifiers = "w384dp-h832dp-xxhdpi")
@GraphicsMode(GraphicsMode.Mode.NATIVE)
@LooperMode(LooperMode.Mode.PAUSED)
class V12Test : LauncherTestBase() {
    override fun beforeLaunch() {
        // The tester's phone: a Nothing Phone (1).
        ShadowBuild.setManufacturer("Nothing"); ShadowBuild.setBrand("Nothing"); ShadowBuild.setModel("A063"); ShadowBuild.setDevice("Spacewar")
    }

    private fun save(b: Bitmap, name: String) = FileOutputStream(File(shots, "$name.png")).use { b.compress(Bitmap.CompressFormat.PNG, 100, it) }

    private fun bmp(size: Int, draw: (Canvas, Paint) -> Unit): Bitmap {
        val b = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        draw(Canvas(b), Paint(Paint.ANTI_ALIAS_FLAG))
        return b
    }

    /** Icons like the ones that broke on the tester's Nothing Phone. */
    private fun testIcons(): List<Pair<String, android.graphics.drawable.Drawable>> {
        val res = a.resources
        val s = 216
        // A foreground that is a whole opaque square (ACECRAFT-like).
        val square = bmp(s) { c, p -> p.color = Color.rgb(230, 230, 236); c.drawRect(54f, 54f, 162f, 162f, p); p.color = Color.rgb(30, 30, 40); c.drawRect(84f, 84f, 132f, 132f, p) }
        // A big colourful disc with a face (Brawl Stars-like).
        val disc = bmp(s) { c, p ->
            p.color = Color.rgb(250, 200, 30); c.drawCircle(108f, 108f, 56f, p)
            p.color = Color.rgb(20, 20, 20); c.drawCircle(88f, 98f, 9f, p); c.drawCircle(128f, 98f, 9f, p)
            p.style = Paint.Style.STROKE; p.strokeWidth = 7f; c.drawArc(RectF(84f, 100f, 132f, 136f), 20f, 140f, false, p)
        }
        // A legacy, transparent "V" bigger than the safe zone (Carte Vitale-like).
        val vee = bmp(192) { c, p ->
            p.color = Color.rgb(200, 200, 206)
            val path = Path().apply { moveTo(0f, 0f); lineTo(70f, 0f); lineTo(96f, 120f); lineTo(122f, 0f); lineTo(192f, 0f); lineTo(120f, 192f); lineTo(72f, 192f); close() }
            c.drawPath(path, p)
        }
        // Photo-like artwork with no plate (Cookie Run-like).
        val art = bmp(s) { c, p ->
            for (i in 0 until 40) { p.color = Color.HSVToColor(floatArrayOf(i * 9f, 0.7f, 0.4f + (i % 5) * 0.12f)); c.drawCircle(40f + (i * 37) % 140, 40f + (i * 53) % 140, 22f, p) }
        }
        // A proper monochrome layer (Android 13 themed icon).
        val mono = bmp(s) { c, p -> p.color = Color.WHITE; p.style = Paint.Style.STROKE; p.strokeWidth = 14f; c.drawCircle(108f, 108f, 30f, p) }
        val list = ArrayList<Pair<String, android.graphics.drawable.Drawable>>()
        list += "square" to AdaptiveIconDrawable(ColorDrawable(Color.rgb(60, 90, 200)), BitmapDrawable(res, square))
        list += "disc" to AdaptiveIconDrawable(ColorDrawable(Color.rgb(40, 140, 220)), BitmapDrawable(res, disc))
        list += "vee" to BitmapDrawable(res, vee)
        list += "art" to AdaptiveIconDrawable(ColorDrawable(Color.rgb(90, 60, 40)), BitmapDrawable(res, art))
        list += "mono" to AdaptiveIconDrawable(ColorDrawable(Color.rgb(200, 40, 60)), BitmapDrawable(res, disc), BitmapDrawable(res, mono))
        list += "plain" to AdaptiveIconDrawable(ColorDrawable(Color.rgb(120, 120, 130)), ColorDrawable(Color.rgb(120, 120, 130)))
        return list
    }

    @Test
    fun themedIconsNeverBlobsOrOverflowOnAnyPhone() {
        assertEquals(Brand.NOTHING, a.brand)
        assertTrue("Nothing mode switches itself on", a.brandModeOn())
        val size = 192
        val styles = listOf("themed_dark", "themed_light", "tinted", "mono", "neon", "pastel", "gradient", "glass")
        val icons = testIcons()
        val sheet = Bitmap.createBitmap(size * styles.size, size * icons.size, Bitmap.Config.ARGB_8888)
        val sc = Canvas(sheet)
        sc.drawColor(Color.rgb(90, 70, 140))
        val shape = IconShapes.path("circle", size.toFloat())
        icons.forEachIndexed { row, (name, d) ->
            styles.forEachIndexed { col, style ->
                val b = a.icons.styled(d, size, "circle", style, name)
                sc.drawBitmap(a.icons.forDisplay(b), (col * size).toFloat(), (row * size).toFloat(), null)
                // Nothing is ever drawn outside the icon's shape (the Carte Vitale / Cookie Run overflow).
                for ((x, y) in listOf(2 to 2, size - 3 to 2, 2 to size - 3, size - 3 to size - 3, 6 to size / 2 - 60)) {
                    if (!shapeContains(shape, x, y)) assertEquals("$name/$style drew outside the shape at $x,$y", 0, Color.alpha(b.getPixel(x, y)))
                }
                if (style != "glass") {
                    // Not a plain tile: the symbol area differs from the plate (the ACECRAFT / Brawl Stars blob).
                    val plate = b.getPixel(size / 2, (size * 0.1f).toInt())
                    var differs = 0; var samples = 0
                    for (y in size / 4 until size * 3 / 4 step 6) for (x in size / 4 until size * 3 / 4 step 6) {
                        val c = b.getPixel(x, y); samples++
                        if (abs(Color.red(c) - Color.red(plate)) + abs(Color.green(c) - Color.green(plate)) + abs(Color.blue(c) - Color.blue(plate)) > 60) differs++
                    }
                    assertTrue("$name/$style shows a symbol ($differs/$samples)", differs > 6)
                    assertTrue("$name/$style symbol is not a solid tile ($differs/$samples)", differs < samples * 0.9f)
                }
            }
        }
        save(sheet, "v01_themed_icons")
    }

    private fun shapeContains(p: Path, x: Int, y: Int): Boolean {
        val r = android.graphics.Region(); r.setPath(p, android.graphics.Region(0, 0, 4000, 4000))
        return r.contains(x, y)
    }

    @Test
    fun nothingModePageAndDotClock() {
        a.openSettingsPage("device"); idle(900)
        val t = texts()
        assertTrue(t.contains("Nothing mode"))
        assertTrue(t.contains("Dot-matrix clock"))
        assertTrue("fresh Nothing install gets the dot clock", a.prefs.dotClock)
        assertTrue(t.contains("Themed icons follow dark mode"))
        assertTrue(t.contains("Apply Nothing look"))
        shot("v02_nothing_mode")
        clickText("Apply Nothing look"); idle(900)
        assertEquals("mono", a.prefs.iconStyle)
        assertTrue(a.prefs.dotClock)
        a.onBackPressed(); idle(400); a.onBackPressed(); idle(400)
        assertTrue(a.overlays.isEmpty())
        hwShot("v03_nothing_home")
    }

    @Test
    fun widgetsWithEveryBackground() {
        a.workspace.snapTo(1, animate = false); idle(200)
        val before = a.model.pages.flatten().size
        Builtins.all.forEach { a.addBuiltin(it); idle(300) }
        assertEquals(before + Builtins.all.size, a.model.pages.flatten().size)
        checkModel()
        val items = a.model.pages.flatten().filter { it.type == HomeItem.BUILTIN }
        for (mode in listOf("glass", "color", "off")) {
            items.forEach { it ->
                val look = a.prefs.widgetLook(it.id, it.builtin)
                look.bg = mode; look.color = Color.rgb(255, 233, 150)
                a.prefs.setWidgetLook(it.id, look)
            }
            a.refreshBuiltinWidgets(); idle(200)
            for (p in 1 until a.model.pages.size) {
                if (a.model.pages[p].none { it.type == HomeItem.BUILTIN }) continue
                a.workspace.snapTo(p, animate = false); idle(200)
                hwShot("v04_widgets_${mode}_p$p")
            }
        }
        // The edit sheet from the widget menu, then a custom colour.
        val note = items.first { it.builtin == Builtins.NOTE }
        WidgetStyleSheet(a, note).show(); idle(700)
        assertTrue(texts().toString(), texts().contains("Background"))
        shot("v05_widget_sheet")
        a.onBackPressed(); idle(600)
        val picker = ColorPickerSheet(a, "Widget colour", Color.WHITE) { c -> a.prefs.setWidgetLook(note.id, a.prefs.widgetLook(note.id, note.builtin).apply { bg = "color"; color = c }) }
        picker.show(); idle(700)
        shot("v06_color_picker")
        picker.choose(Color.rgb(20, 120, 220)); picker.apply(); idle(600)
        assertEquals(Color.rgb(20, 120, 220), a.prefs.widgetLook(note.id, note.builtin).color)
        assertTrue(a.overlays.isEmpty())
    }

    @Test
    fun customAccentColour() {
        val picker = ColorPickerSheet(a, "Accent colour", a.prefs.accent) { c -> a.prefs.accent = c; a.applyThemeChange() }
        picker.show(); idle(600)
        picker.choose(Color.rgb(250, 90, 30)); picker.apply(); idle(800)
        assertEquals(Color.rgb(250, 90, 30), a.prefs.accent)
        assertEquals("#123ABC", ColorPickerSheet.hexOf(Color.rgb(0x12, 0x3A, 0xBC)))
        assertEquals(Color.rgb(0xFF, 0x88, 0x00), ColorPickerSheet.parseHex("#f80"))
        // Presets are used exactly as picked; a white or black custom accent stays visible on cards.
        LauncherPrefs.ACCENTS.forEach { (_, c) ->
            assertEquals(c, UiTheme(false, c).accent); assertEquals(c, UiTheme(true, c).accent)
        }
        assertTrue(luminance(UiTheme(false, Color.WHITE).accent) <= 0.68f)
        assertTrue(luminance(UiTheme(true, Color.BLACK).accent) >= 0.25f)
        assertTrue(luminance(UiTheme(true, Color.WHITE).accent) <= 0.86f)
        assertEquals(Color.BLACK, UiTheme(false, Color.rgb(255, 230, 0)).onAccent)
        a.prefs.accent = Color.WHITE; a.prefs.theme = "light"; a.applyThemeChange(); idle(400)
        a.openSettingsPage("theme"); idle(900)
        shot("v06b_white_accent")
        val over = ColorPickerSheet(a, "Accent colour", a.prefs.accent) {}
        over.show(); idle(600)
        assertTrue("settings page blurred behind the sheet", over.settingsBlur > 10f)
        hwShot("v06c_sheet_over_settings")
        over.close(); idle(600)
        assertEquals(0f, over.settingsBlur, 0.01f)
        assertEquals(Color.WHITE, a.prefs.accent)
    }

    private fun send(v: View, action: Int, x: Float, y: Float, down: Long) {
        val e = MotionEvent.obtain(down, SystemClock.uptimeMillis(), action, x, y, 0)
        v.dispatchTouchEvent(e); e.recycle()
    }

    @Test
    fun holdAndSlideEverySwitch() {
        a.openSettingsPage("search"); idle(900)
        val root = a.overlays.first { it is SettingsPanel }.root
        val sw = all(root).filterIsInstance<ColorSwitch>().first { it.isShown && it.contentDescription == "Settings" }
        val changes = ArrayList<Boolean>()
        val prev = sw.onChange
        sw.onChange = { changes += it; prev?.invoke(it) }
        val start = sw.isChecked
        val t = SystemClock.uptimeMillis()
        val y = sw.height / 2f
        val fromX = if (start) sw.width * 0.7f else sw.width * 0.3f
        val dir = if (start) -1 else 1
        send(sw, MotionEvent.ACTION_DOWN, fromX, y, t); idle(120)
        for (i in 1..8) { send(sw, MotionEvent.ACTION_MOVE, fromX + dir * i * a.dp(4f), y, t); idle(16) }
        hwShot("v07_switch_drag")
        send(sw, MotionEvent.ACTION_UP, fromX + dir * a.dp(32f), y, t); idle(700)
        assertEquals("sliding across flips it", !start, sw.isChecked)
        assertEquals(listOf(!start), changes)
        // A short slide that does not cross the middle springs back.
        val t2 = SystemClock.uptimeMillis()
        val x2 = if (sw.isChecked) sw.width * 0.7f else sw.width * 0.3f
        send(sw, MotionEvent.ACTION_DOWN, x2, y, t2); idle(60)
        for (i in 1..3) { send(sw, MotionEvent.ACTION_MOVE, x2 - (if (sw.isChecked) 1 else -1) * i * a.dp(3f), y, t2); idle(16) }
        send(sw, MotionEvent.ACTION_UP, x2, y, t2); idle(700)
        assertEquals(!start, sw.isChecked)
        assertEquals(1, changes.size)
        // A plain tap still toggles.
        sw.performClick(); idle(600)
        assertEquals(start, sw.isChecked)
    }

    private fun type(q: String) { a.drawer.search.setText(q); idle(400) }

    @Test
    fun smarterSearch() {
        a.openDrawer(focusSearch = true); idle(900)
        type("15% of 80"); assertTrue(texts().toString(), texts().contains("12"))
        type("20% off 50"); assertTrue(texts().contains("40"))
        type("time in tokyo"); assertTrue(texts().contains("WORLD CLOCK"))
        shot("v08_world_clock")
        type("days until christmas"); assertTrue(texts().contains("COUNTDOWN"))
        // Impossible dates are not rolled into other months; 29 February waits for a leap year; past dates count back.
        val nov5 = java.util.Calendar.getInstance().apply { set(2026, 10, 5, 12, 0, 0) }
        assertEquals(null, DaysUntil.lookup("days until 30.2", nov5))
        assertEquals(null, DaysUntil.lookup("days until 2027-13-01", nov5))
        assertEquals(null, DaysUntil.lookup("days until 2027-02-29", nov5))
        assertEquals(50L, DaysUntil.lookup("days until christmas", nov5)!!.days)
        assertEquals(0L, DaysUntil.lookup("days until 5.11", nov5)!!.days)
        assertEquals(481L, DaysUntil.lookup("days until 29.2", nov5)!!.days)
        assertEquals(-4L, DaysUntil.lookup("days until 2026-11-01", nov5)!!.days)
        type("days until 2020-01-01"); assertTrue(texts().contains("DAYS SINCE"))
        type("voice rec"); assertEquals("Voice Recorder", a.drawer.results.appIcons.first().label)
        type("open spotify")
        assertEquals("Spotify", a.drawer.results.appIcons.first().label)
        assertTrue("app actions for the clear match", texts().containsAll(listOf("App info", "Notifications", "Uninstall")))
        shot("v09_open_spotify")
        type("turn on bluetooth"); assertTrue(texts().contains("Bluetooth"))
        // Remembers what you pick: "cal" matches Calendar first, pick Calculator, and next time it leads.
        type("cal")
        val first = a.drawer.results.appIcons.first().label
        val other = a.drawer.results.appIcons.map { it.label }.first { it != first && it.startsWith("Cal") }
        a.drawer.results.recordPick(other)
        type("ca"); type("cal")
        assertEquals(other, a.drawer.results.appIcons.first().label)
    }

    @Test
    fun everyUnlockStyleEndsClean() {
        for (style in listOf("gather", "coloros", "oneui", "hyperos", "rise", "ripple", "zoom", "off")) {
            a.prefs.unlockAnim = style
            a.animator.primeUnlock(); idle(50)
            a.animator.playUnlock(); idle(1600)
            assertEquals(1f, a.contentLayer.alpha, 0.01f)
            a.entranceViews().forEach { (v, _) ->
                assertEquals("$style alpha", 1f, v.alpha, 0.01f)
                assertEquals("$style ty", 0f, v.translationY, 0.5f)
                assertEquals("$style scale", 1f, v.scaleX, 0.01f)
            }
        }
        a.prefs.unlockAnim = "gather"
    }

    @Test
    fun appLaunchUsesSystemZoomAndHomeComesBack() {
        assertEquals("zoom", a.prefs.launchAnim)
        assertTrue(a.prefs.launchAnimations)
        val icon = a.workspace.pages[0].childList().first { it is IconView && it !is FolderIconView } as IconView
        icon.onTap?.invoke(icon, 0f, 0f); idle(300)
        controller.pause().stop(); idle(50)
        controller.restart().start().resume(); idle(1400)
        assertEquals(1f, a.contentLayer.alpha, 0.01f)
        assertEquals(1f, a.contentLayer.scaleX, 0.01f)
        assertEquals(1f, icon.scaleX, 0.01f)
        // With animations off, launching still works and nothing is left changed.
        a.prefs.launchAnimations = false
        icon.onTap?.invoke(icon, 0f, 0f); idle(100)
        controller.pause().stop(); idle(50)
        controller.restart().start().resume(); idle(800)
        assertEquals(1f, a.contentLayer.alpha, 0.01f)
        a.prefs.launchAnimations = true
    }

    @Test
    fun brandDetection() {
        val cases = mapOf(
            ("samsung" to "samsung") to Brand.SAMSUNG, ("Xiaomi" to "Redmi") to Brand.XIAOMI, ("Xiaomi" to "POCO") to Brand.XIAOMI,
            ("Nothing" to "Nothing") to Brand.NOTHING, ("Nothing" to "CMF") to Brand.NOTHING, ("Google" to "google") to Brand.GOOGLE,
            ("OnePlus" to "OnePlus") to Brand.ONEPLUS, ("OPPO" to "OPPO") to Brand.OPPO, ("realme" to "realme") to Brand.REALME,
            ("motorola" to "motorola") to Brand.MOTOROLA, ("vivo" to "iQOO") to Brand.VIVO, ("HONOR" to "HONOR") to Brand.HONOR,
            ("HUAWEI" to "HUAWEI") to Brand.HUAWEI, ("Sony" to "Sony") to Brand.SONY, ("asus" to "asus") to Brand.ASUS,
            ("Fairphone" to "Fairphone") to Brand.OTHER
        )
        cases.forEach { (mb, expected) -> assertEquals(mb.toString(), expected, Brand.detect(mb.first, mb.second)) }
        assertTrue(Brand.XIAOMI.splitShade && Brand.OPPO.splitShade && !Brand.SAMSUNG.splitShade && !Brand.GOOGLE.splitShade)
        assertTrue(BrandIntents.backgroundSettings(Brand.XIAOMI, "x").size >= 3)
    }
}
