package com.fluidone.launcher

import android.graphics.Bitmap
import android.graphics.BlurMaskFilter
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.text.TextPaint
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.annotation.Config
import org.robolectric.annotation.GraphicsMode
import java.io.File
import java.io.FileOutputStream
import kotlin.math.roundToInt

/** Renders the GitHub release image for Fluid One 1.2 with the real Fluid Glass shader (GPU path). */
@RunWith(RobolectricTestRunner::class)
@Config(sdk = [35], qualifiers = "xxhdpi")
@GraphicsMode(GraphicsMode.Mode.NATIVE)
class ReleaseArtTest {
    private val ctx get() = RuntimeEnvironment.getApplication()

    private fun gpu(w: Int, h: Int, draw: (Canvas) -> Unit): Bitmap {
        val node = android.graphics.RenderNode("art")
        node.setPosition(0, 0, w, h)
        val rc = node.beginRecording(); draw(rc); node.endRecording()
        val reader = android.media.ImageReader.newInstance(w, h, android.graphics.PixelFormat.RGBA_8888, 1,
            android.hardware.HardwareBuffer.USAGE_GPU_SAMPLED_IMAGE or android.hardware.HardwareBuffer.USAGE_GPU_COLOR_OUTPUT)
        val renderer = android.graphics.HardwareRenderer()
        renderer.setSurface(reader.surface); renderer.setContentRoot(node)
        renderer.createRenderRequest().setWaitForPresent(true).syncAndDraw()
        val image = reader.acquireNextImage()
        val plane = image.planes[0]
        val wide = Bitmap.createBitmap(plane.rowStride / plane.pixelStride, h, Bitmap.Config.ARGB_8888)
        wide.copyPixelsFromBuffer(plane.buffer)
        image.close(); renderer.destroy(); reader.close()
        return Bitmap.createBitmap(wide, 0, 0, w, h)
    }

    private class Glass(val rect: RectF, val radius: Float, val tint: Int)

    /** Draws [src], then Fluid Glass shapes sampling it, then [overlay] on top - all on the GPU. */
    private fun glassPass(src: Bitmap, shapes: List<Glass>, overlay: (Canvas) -> Unit = {}): Bitmap {
        val blurred = BlurEngine.blur(src, 0.25f, 8)
        val bm = Matrix().apply { setScale(src.width / blurred.width.toFloat(), src.height / blurred.height.toFloat()) }
        return gpu(src.width, src.height) { c ->
            c.drawBitmap(src, 0f, 0f, null)
            val shadow = Paint(Paint.ANTI_ALIAS_FLAG).apply { maskFilter = BlurMaskFilter(28f, BlurMaskFilter.Blur.NORMAL); color = Color.argb(70, 0, 0, 0) }
            for (g in shapes) {
                c.drawRoundRect(g.rect.left + 6f, g.rect.top + 18f, g.rect.right - 6f, g.rect.bottom + 18f, g.radius, g.radius, shadow)
                GlassPainter(ctx).draw(c, g.rect, g.radius, 0.92f, g.tint, src, Matrix(), blurred, bm)
            }
            overlay(c)
        }
    }

    private fun icon(c: Canvas, res: Int, r: RectF, color: Int = Color.WHITE, scale: Float = 0.5f) {
        val d = ctx.getDrawable(res)?.mutate() ?: return
        d.setTint(color)
        val s = r.width() * scale
        d.setBounds((r.centerX() - s / 2).roundToInt(), (r.centerY() - s / 2).roundToInt(), (r.centerX() + s / 2).roundToInt(), (r.centerY() + s / 2).roundToInt())
        d.draw(c)
    }

    /** A Fluid One home screen: glass icons, dock, search capsule and a date widget over a glass wallpaper. */
    private fun phoneScreen(w: Int, h: Int): Bitmap {
        val wall = Wallpapers.render(Wallpapers.preset("azure_glass"), w, h)
        val text = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; textAlign = Paint.Align.CENTER }
        val shapes = ArrayList<Glass>()
        val cols = 4
        val margin = w * 0.07f
        val cell = (w - 2 * margin) / cols
        val iconSize = cell * 0.66f
        val icons = listOf(R.drawable.ic_phone, R.drawable.ic_message, R.drawable.ic_camera, R.drawable.ic_globe,
            R.drawable.ic_place, R.drawable.ic_play, R.drawable.ic_mail, R.drawable.ic_calendar,
            R.drawable.ic_note, R.drawable.ic_calc, R.drawable.ic_store, R.drawable.ic_settings)
        val gridTop = h * 0.36f
        val rects = icons.indices.map { i ->
            val cx = margin + cell * (i % cols + 0.5f); val cy = gridTop + (i / cols) * cell * 1.18f + iconSize / 2f
            RectF(cx - iconSize / 2, cy - iconSize / 2, cx + iconSize / 2, cy + iconSize / 2)
        }
        rects.forEach { shapes += Glass(it, it.width() * 0.32f, Color.argb(30, 255, 255, 255)) }
        val widget = RectF(margin, h * 0.17f, w - margin, h * 0.31f)
        shapes += Glass(widget, w * 0.07f, Color.argb(40, 20, 30, 60))
        val search = RectF(w * 0.3f, h * 0.8f, w * 0.7f, h * 0.8f + w * 0.11f)
        shapes += Glass(search, search.height() / 2, Color.argb(36, 255, 255, 255))
        val dock = RectF(margin * 0.6f, h * 0.875f, w - margin * 0.6f, h * 0.875f + cell * 1.05f)
        shapes += Glass(dock, dock.height() * 0.42f, Color.argb(30, 255, 255, 255))
        return glassPass(wall, shapes) { c ->
            text.typeface = Fonts.semibold; text.textSize = w * 0.05f
            c.drawText("Thursday, 5 November", w / 2f, h * 0.075f, text)
            text.typeface = Fonts.bold; text.textSize = w * 0.2f
            c.drawText("12:30", w / 2f, h * 0.075f + w * 0.2f, text)
            text.textSize = w * 0.075f; text.typeface = Fonts.bold; text.textAlign = Paint.Align.LEFT
            c.drawText("5", widget.left + w * 0.06f, widget.centerY() + w * 0.025f, text)
            text.typeface = Fonts.medium; text.textSize = w * 0.04f
            c.drawText("No events today", widget.left + w * 0.19f, widget.centerY() + w * 0.015f, text)
            text.textAlign = Paint.Align.CENTER
            rects.forEachIndexed { i, r -> icon(c, icons[i], r) }
            icon(c, R.drawable.ic_search, RectF(search.left + search.height() * 0.2f, search.top, search.left + search.height() * 1.0f, search.bottom), scale = 0.4f)
            text.typeface = Fonts.medium; text.textSize = w * 0.038f
            c.drawText("Search", search.centerX() + search.height() * 0.25f, search.centerY() + w * 0.013f, text)
            val dockIcons = listOf(R.drawable.ic_phone, R.drawable.ic_message, R.drawable.ic_globe, R.drawable.ic_camera)
            dockIcons.forEachIndexed { i, res ->
                val cx = dock.left + dock.width() * (i + 0.5f) / 4f
                val s = iconSize * 0.9f
                icon(c, res, RectF(cx - s / 2, dock.centerY() - s / 2, cx + s / 2, dock.centerY() + s / 2), scale = 0.62f)
            }
        }
    }

    @Test fun renderReleaseImage() {
        val w = 2400; val h = 1260
        // Background: deep night gradient with a glowing silk ribbon and soft colour light.
        val bg = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(bg)
        val ribbon = Wallpapers.render(Wallpapers.preset("liquid_glass").let {
            WallpaperPreset(it.id + "_art", it.name, it.background, it.blobs, it.ribbons, vignette = 0.25f, grain = 6)
        }, w, h)
        c.drawBitmap(ribbon, 0f, 0f, null)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.shader = RadialGradient(w * 0.78f, h * 0.45f, h * 0.9f, intArrayOf(Color.argb(150, 70, 110, 255), Color.TRANSPARENT), null, Shader.TileMode.CLAMP)
        c.drawRect(0f, 0f, w.toFloat(), h.toFloat(), p)
        p.shader = RadialGradient(w * 0.12f, h * 0.95f, h * 0.7f, intArrayOf(Color.argb(140, 255, 80, 140), Color.TRANSPARENT), null, Shader.TileMode.CLAMP)
        c.drawRect(0f, 0f, w.toFloat(), h.toFloat(), p)
        p.shader = null

        // The phone, slightly to the right, with its own glass home screen.
        val pw = 540; val ph = 1140
        val screen = phoneScreen(pw, ph)
        val phone = RectF(w * 0.69f, (h - ph) / 2f - 12f, w * 0.69f + pw + 28f, (h - ph) / 2f + ph + 16f)
        val sp = Paint(Paint.ANTI_ALIAS_FLAG).apply { maskFilter = BlurMaskFilter(60f, BlurMaskFilter.Blur.NORMAL); color = Color.argb(160, 0, 0, 10) }
        c.drawRoundRect(phone.left + 20f, phone.top + 50f, phone.right - 20f, phone.bottom + 40f, 90f, 90f, sp)
        p.color = Color.rgb(16, 16, 20)
        c.drawRoundRect(phone, 92f, 92f, p)
        p.style = Paint.Style.STROKE; p.strokeWidth = 4f; p.color = Color.argb(120, 200, 210, 255)
        c.drawRoundRect(phone, 92f, 92f, p); p.style = Paint.Style.FILL
        val screenRect = RectF(phone.left + 14f, phone.top + 14f, phone.left + 14f + pw, phone.top + 14f + ph)
        val ss = c.save()
        c.clipPath(android.graphics.Path().apply { addRoundRect(screenRect, 78f, 78f, android.graphics.Path.Direction.CW) })
        c.drawBitmap(screen, null, screenRect, Paint(Paint.FILTER_BITMAP_FLAG))
        c.restoreToCount(ss)
        p.color = Color.rgb(10, 10, 12)
        c.drawCircle(screenRect.centerX(), screenRect.top + 30f, 13f, p)

        // Glass on the banner: a big lens over the title corner, the version badge and feature pills.
        val left = 140f
        val badge = RectF(left + 860f, 205f, left + 1160f, 345f)
        val features = listOf(
            R.drawable.ic_drop to "Fluid Glass", R.drawable.ic_search to "Smarter search", R.drawable.ic_device to "Brand modes",
            R.drawable.ic_widgets to "New widgets", R.drawable.ic_toggles to "Glass switches", R.drawable.ic_palette to "Any accent colour"
        )
        val pills = features.indices.map { i ->
            val col = i % 2; val row = i / 2
            val x = left + col * 520f; val y = 640f + row * 150f
            RectF(x, y, x + 480f, y + 116f)
        }
        val lens = RectF(left + 600f, 40f, left + 840f, 280f)
        val shapes = ArrayList<Glass>()
        shapes += Glass(lens, 120f, Color.argb(16, 255, 255, 255))
        shapes += Glass(badge, 70f, Color.argb(40, 255, 255, 255))
        pills.forEach { shapes += Glass(it, 58f, Color.argb(34, 255, 255, 255)) }
        val text = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }
        val art = glassPass(bg, shapes) { o ->
            text.typeface = Fonts.bold; text.textSize = 190f
            text.setShadowLayer(30f, 0f, 8f, Color.argb(90, 0, 0, 30))
            o.drawText("Fluid One", left - 8f, 340f, text)
            text.clearShadowLayer()
            text.textSize = 104f; text.textAlign = Paint.Align.CENTER
            o.drawText("1.2", badge.centerX(), badge.centerY() + 37f, text)
            text.textAlign = Paint.Align.LEFT
            text.typeface = Fonts.medium; text.textSize = 52f; text.color = Color.argb(225, 255, 255, 255)
            o.drawText("A liquid glass home screen for Android.", left, 460f, text)
            text.textSize = 40f; text.color = Color.argb(170, 255, 255, 255)
            o.drawText("Smooth on every phone. Private by design.", left, 530f, text)
            text.color = Color.WHITE; text.typeface = Fonts.semibold; text.textSize = 42f
            pills.forEachIndexed { i, r ->
                icon(o, features[i].first, RectF(r.left + 26f, r.top + 18f, r.left + 106f, r.bottom - 18f), scale = 0.62f)
                o.drawText(features[i].second, r.left + 118f, r.centerY() + 15f, text)
            }
        }
        val dir = File(System.getProperty("shots.dir", "build/screenshots")).apply { mkdirs() }
        FileOutputStream(File(dir, "release_fluid_one_1_2.png")).use { art.compress(Bitmap.CompressFormat.PNG, 100, it) }
    }
}
