package com.fluidone.launcher

import android.content.pm.ActivityInfo
import android.content.pm.ApplicationInfo
import android.content.pm.IncrementalStatesInfo
import android.content.pm.LauncherActivityInfo
import android.content.pm.LauncherActivityInfoInternal
import android.content.pm.LauncherApps
import android.graphics.Bitmap
import android.graphics.Canvas
import android.os.Looper
import android.os.Process
import android.os.SystemClock
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.Robolectric
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.Shadows.shadowOf
import org.robolectric.android.controller.ActivityController
import org.robolectric.annotation.Config
import org.robolectric.annotation.GraphicsMode
import org.robolectric.annotation.LooperMode
import java.io.File
import java.io.FileOutputStream
import java.time.Duration

abstract class LauncherTestBase {
    protected val shots = File(System.getProperty("shots.dir", "build/screenshots")).apply { mkdirs() }
    protected lateinit var controller: ActivityController<MainActivity>
    protected lateinit var a: MainActivity

    protected open val fakeApps = listOf(
        "com.samsung.android.dialer" to "Phone", "com.samsung.android.messaging" to "Messages",
        "com.sec.android.app.sbrowser" to "Internet", "com.sec.android.app.camera" to "Camera",
        "com.samsung.android.calendar" to "Calendar", "com.sec.android.daemonapp" to "Weather",
        "com.android.settings" to "Settings", "com.sec.android.app.clockpackage" to "Clock",
        "com.sec.android.app.myfiles" to "My Files", "com.google.android.apps.maps" to "Maps",
        "com.sec.android.gallery3d" to "Gallery", "com.android.vending" to "Play Store",
        "com.google.android.youtube" to "YouTube", "com.sec.android.app.popupcalculator" to "Calculator",
        "com.samsung.android.app.notes" to "Samsung Notes", "com.sec.android.app.voicenote" to "Voice Recorder",
        "com.google.android.gm" to "Gmail", "com.samsung.android.app.contacts" to "Contacts",
        "com.google.android.apps.translate" to "Translate", "com.spotify.music" to "Spotify",
        "com.whatsapp" to "WhatsApp", "com.instagram.android" to "Instagram", "com.netflix.mediaclient" to "Netflix",
        "com.google.android.apps.docs" to "Drive", "com.microsoft.teams" to "Teams", "com.discord" to "Discord",
        "com.reddit.frontpage" to "Reddit", "org.telegram.messenger" to "Telegram", "com.ubercab" to "Uber",
        "com.airbnb.android" to "Airbnb", "com.duolingo" to "Duolingo", "com.strava" to "Strava"
    )

    /** Runs before the launcher starts (e.g. to pretend to be a particular phone). */
    protected open fun beforeLaunch() {}

    /** Tests start on the home screen; WelcomeTest turns this off to see the welcome. */
    protected open val skipWelcome = true

    @Before
    fun setUp() {
        if (skipWelcome) RuntimeEnvironment.getApplication().getSharedPreferences("fluid_one", android.content.Context.MODE_PRIVATE)
            .edit().putLong("welcome_seen_code", Long.MAX_VALUE).commit()
        beforeLaunch()
        // Run animation frames only at real vsync times so long-press timers see honest elapsed time.
        org.robolectric.shadows.ShadowChoreographer.setPaused(true)
        org.robolectric.shadows.ShadowChoreographer.setFrameDelay(Duration.ofMillis(16))
        val ctx = RuntimeEnvironment.getApplication()
        val la = ctx.getSystemService(LauncherApps::class.java)
        val user = Process.myUserHandle()
        fakeApps.forEach { (pkg, label) ->
            val app = ApplicationInfo().apply { packageName = pkg; name = label; flags = 0; enabled = true }
            val info = ActivityInfo().apply {
                packageName = pkg; name = "$pkg.MainActivity"; applicationInfo = app; nonLocalizedLabel = label; enabled = true; exported = true
            }
            val internal = LauncherActivityInfoInternal(info, IncrementalStatesInfo(false, 1f, 0L), user)
            val lai = LauncherActivityInfo::class.java.getDeclaredConstructor(android.content.Context::class.java, LauncherActivityInfoInternal::class.java)
                .apply { isAccessible = true }.newInstance(ctx, internal)
            shadowOf(la).addActivity(user, lai)
        }
        controller = Robolectric.buildActivity(MainActivity::class.java).setup()
        a = controller.get()
        waitFor("wallpaper") { a.wallpaperView.hasWallpaper }
        idle(1500)
    }

    /** Advances time in 16 ms frames, like a real display. */
    protected fun idle(ms: Long = 16) {
        var left = ms
        while (left > 0) {
            val step = minOf(16L, left)
            shadowOf(Looper.getMainLooper()).idleFor(Duration.ofMillis(step))
            left -= step
        }
    }

    protected fun waitFor(what: String, timeoutMs: Long = 15000, cond: () -> Boolean) {
        val end = System.currentTimeMillis() + timeoutMs
        while (!cond()) {
            if (System.currentTimeMillis() > end) throw AssertionError("Timed out waiting for $what")
            Thread.sleep(30)
            idle(30)
        }
    }

    protected fun shot(name: String) {
        val v = a.window.decorView
        val b = Bitmap.createBitmap(v.width, v.height, Bitmap.Config.ARGB_8888)
        v.draw(Canvas(b))
        FileOutputStream(File(shots, "$name.png")).use { b.compress(Bitmap.CompressFormat.PNG, 90, it) }
    }

    /**
     * Screenshot through the GPU path (RenderNode + HardwareRenderer), so Fluid Glass shaders render like on a
     * phone. The plain [shot] uses a software canvas, where glass falls back to frosted blur.
     */
    protected fun hwShot(name: String): Bitmap {
        val v = a.window.decorView
        val w = v.width; val h = v.height
        val node = android.graphics.RenderNode("shot")
        node.setPosition(0, 0, w, h)
        val rc = node.beginRecording()
        v.draw(rc)
        node.endRecording()
        val reader = android.media.ImageReader.newInstance(w, h, android.graphics.PixelFormat.RGBA_8888, 1,
            android.hardware.HardwareBuffer.USAGE_GPU_SAMPLED_IMAGE or android.hardware.HardwareBuffer.USAGE_GPU_COLOR_OUTPUT)
        val renderer = android.graphics.HardwareRenderer()
        renderer.setSurface(reader.surface)
        renderer.setContentRoot(node)
        renderer.createRenderRequest().setWaitForPresent(true).syncAndDraw()
        val image = reader.acquireNextImage()
        val plane = image.planes[0]
        val wide = Bitmap.createBitmap(plane.rowStride / plane.pixelStride, h, Bitmap.Config.ARGB_8888)
        wide.copyPixelsFromBuffer(plane.buffer)
        image.close(); renderer.destroy(); reader.close()
        val out = Bitmap.createBitmap(wide, 0, 0, w, h)
        FileOutputStream(File(shots, "$name.png")).use { out.compress(Bitmap.CompressFormat.PNG, 90, it) }
        return out
    }

    protected fun texts(): List<String> = all(a.rootView).filterIsInstance<TextView>().filter { it.isShown }.map { it.text.toString() }

    protected fun all(v: View, out: MutableList<View> = mutableListOf()): List<View> {
        out.add(v)
        if (v is ViewGroup) for (i in 0 until v.childCount) all(v.getChildAt(i), out)
        return out
    }

    protected fun clickText(text: String) {
        val tv = all(a.rootView).filterIsInstance<TextView>().firstOrNull { it.text?.toString() == text && it.isShown }
        assertNotNull("No visible view with text '$text'", tv)
        var v: View? = tv
        while (v != null && !v.isClickable) v = v.parent as? View
        assertNotNull("No clickable parent for '$text'", v)
        v!!.performClick()
        idle(700)
    }

    protected fun touch(action: Int, x: Float, y: Float, down: Long) {
        val e = MotionEvent.obtain(down, SystemClock.uptimeMillis(), action, x, y, 0)
        a.rootView.dispatchTouchEvent(e)
        e.recycle()
    }

    /** A multi-touch event: pointers are (id, x, y); [index] is the pointer the action refers to. */
    protected fun multi(action: Int, down: Long, pointers: List<Triple<Int, Float, Float>>, index: Int = 0) {
        val props = pointers.map { p -> MotionEvent.PointerProperties().apply { id = p.first; toolType = MotionEvent.TOOL_TYPE_FINGER } }.toTypedArray()
        val coords = pointers.map { p -> MotionEvent.PointerCoords().apply { x = p.second; y = p.third; pressure = 1f; size = 1f } }.toTypedArray()
        val act = action or (index shl MotionEvent.ACTION_POINTER_INDEX_SHIFT)
        val e = MotionEvent.obtain(down, SystemClock.uptimeMillis(), act, pointers.size, props, coords, 0, 0, 1f, 1f, 0, 0,
            android.view.InputDevice.SOURCE_TOUCHSCREEN, 0)
        a.rootView.dispatchTouchEvent(e)
        e.recycle()
    }

    protected fun swipe(x0: Float, y0: Float, x1: Float, y1: Float, steps: Int = 12) {
        val down = SystemClock.uptimeMillis()
        touch(MotionEvent.ACTION_DOWN, x0, y0, down)
        for (i in 1..steps) {
            idle(8)
            touch(MotionEvent.ACTION_MOVE, x0 + (x1 - x0) * i / steps, y0 + (y1 - y0) * i / steps, down)
        }
        touch(MotionEvent.ACTION_UP, x1, y1, down)
        idle(900)
    }

    protected fun checkModel() {
        val cols = a.prefs.columns; val rows = a.prefs.rows
        a.model.pages.forEachIndexed { p, page ->
            val occ = Array(cols) { IntArray(rows) }
            page.forEach { item ->
                assertTrue("item out of grid on page $p", item.x >= 0 && item.y >= 0 && item.x + item.spanX <= cols && item.y + item.spanY <= rows)
                for (x in item.x until item.x + item.spanX) for (y in item.y until item.y + item.spanY) occ[x][y]++
            }
            occ.forEach { col -> col.forEach { assertTrue("overlap on page $p", it <= 1) } }
        }
        assertTrue(a.model.dock.distinct().size == a.model.dock.size)
    }

}
