package com.fluidone.launcher

import android.content.pm.ActivityInfo
import android.content.pm.ApplicationInfo
import android.content.pm.IncrementalStatesInfo
import android.content.pm.LauncherActivityInfo
import android.content.pm.LauncherActivityInfoInternal
import android.content.pm.LauncherApps
import android.graphics.Bitmap
import android.graphics.Canvas
import android.os.Looper
import android.os.Process
import android.os.SystemClock
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.Robolectric
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.Shadows.shadowOf
import org.robolectric.android.controller.ActivityController
import org.robolectric.annotation.Config
import org.robolectric.annotation.GraphicsMode
import org.robolectric.annotation.LooperMode
import java.io.File
import java.io.FileOutputStream
import java.time.Duration

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [35], qualifiers = "w384dp-h832dp-xxhdpi")
@GraphicsMode(GraphicsMode.Mode.NATIVE)
@LooperMode(LooperMode.Mode.PAUSED)
class SmokeTest : LauncherTestBase() {
    @Test
    fun fullTour() {
        // Home
        assertTrue(a.apps.apps.size >= fakeApps.size)
        assertTrue("seeded pages", a.model.pages.size >= 1)
        assertEquals(4, a.model.dock.size)
        checkModel()
        shot("01_home")

        // Swipe to page 2 and back with real touches.
        val w = a.rootView.width.toFloat(); val h = a.rootView.height.toFloat()
        swipe(w * 0.8f, h * 0.55f, w * 0.15f, h * 0.55f)
        assertEquals(1, a.workspace.currentPage)
        shot("02_page2")
        swipe(w * 0.2f, h * 0.55f, w * 0.85f, h * 0.55f)
        assertEquals(0, a.workspace.currentPage)

        // Drawer via swipe up.
        swipe(w * 0.5f, h * 0.8f, w * 0.5f, h * 0.3f)
        assertTrue("drawer open", a.isDrawerOpen)
        shot("03_drawer")
        a.setDrawerOpen(false); idle(800)
        assertFalse(a.isDrawerOpen)

        // Long press an app icon → popup.
        val page0 = a.workspace.pages[0]
        val icon = (0 until page0.childCount).map { page0.getChildAt(it) }.first { it is IconView && it !is FolderIconView } as IconView
        a.onItemLongPress(icon); idle(600)
        shot("04_popup")
        assertTrue(a.overlays.any { it is ItemPopup })
        a.overlays.last().close(true); idle(600)
        assertTrue(a.overlays.isEmpty())
        assertEquals(1f, icon.alpha)

        // Drag that icon to an empty cell on page 2 via the drag controller (as real touches would).
        val r = icon.iconRectInWindow()
        val down = SystemClock.uptimeMillis()
        touch(MotionEvent.ACTION_DOWN, r.centerX(), r.centerY(), down)
        idle(500) // long press fires
        assertTrue("popup after long press", a.overlays.any { it is ItemPopup })
        for (i in 1..10) { touch(MotionEvent.ACTION_MOVE, r.centerX() + i * 3f, r.centerY() + i * 6f, down); idle(16) }
        assertTrue("dragging", a.drag.isDragging)
        shot("05_dragging")
        val key = icon.entry!!.key
        val target = a.workspace.pages[0].cellRect(a.prefs.columns - 1, a.prefs.rows - 1)
        val m = android.graphics.Matrix(); a.workspace.pages[0].transformMatrixToGlobal(m); m.mapRect(target)
        for (i in 1..12) { touch(MotionEvent.ACTION_MOVE, lerp(r.centerX(), target.centerX(), i / 12f), lerp(r.centerY(), target.centerY(), i / 12f), down); idle(30) }
        idle(400)
        touch(MotionEvent.ACTION_UP, target.centerX(), target.centerY(), down)
        idle(900)
        assertFalse(a.drag.isDragging)
        checkModel()
        assertTrue("dragged app still on home", a.model.isOnHome(key))
        shot("06_after_drag")

        // Create a folder by dropping one app onto another (simulated through the model path).
        val apps0 = a.model.pages[0].filter { it.type == HomeItem.APP }
        if (apps0.size >= 2) {
            val src = a.workspace.pages[0].childFor(apps0[0]) as IconView
            val dst = a.workspace.pages[0].childFor(apps0[1]) as IconView
            val sr = src.iconRectInWindow(); val dr = dst.iconRectInWindow()
            val d2 = SystemClock.uptimeMillis()
            touch(MotionEvent.ACTION_DOWN, sr.centerX(), sr.centerY(), d2)
            idle(500)
            for (i in 1..14) { touch(MotionEvent.ACTION_MOVE, lerp(sr.centerX(), dr.centerX(), i / 14f), lerp(sr.centerY(), dr.centerY(), i / 14f), d2); idle(30) }
            idle(500)
            shot("07_folder_hover")
            touch(MotionEvent.ACTION_UP, dr.centerX(), dr.centerY(), d2)
            idle(900)
            checkModel()
            assertTrue("folder created", a.model.pages[0].any { it.type == HomeItem.FOLDER && it.apps.size >= 2 && it.title != "Productivity" } ||
                a.model.pages[0].count { it.type == HomeItem.FOLDER } >= 1)
        }

        // Open a folder.
        val folderItem = a.model.pages[0].firstOrNull { it.type == HomeItem.FOLDER }
        if (folderItem != null) {
            val fv = a.workspace.pages[0].childFor(folderItem) as FolderIconView
            FolderOverlay(a, folderItem, fv).show(); idle(800)
            shot("08_folder_open")
            a.onBackPressed(); idle(800)
            assertTrue(a.overlays.isEmpty())
            assertEquals(1f, fv.alpha)
        }

        // Edit mode via long press on empty space.
        a.enterEditMode(); idle(900)
        assertTrue(a.isEditing)
        shot("09_edit_mode")
        swipe(w * 0.8f, h * 0.45f, w * 0.2f, h * 0.45f)
        shot("10_edit_mode_page2")
        WidgetsSheet(a).show(); idle(800); shot("11_widgets_sheet"); a.onBackPressed(); idle(600)
        IconsSheet(a).show(); idle(800); shot("12_icons_sheet"); a.onBackPressed(); idle(600)
        LayoutSheet(a).show(); idle(800); shot("13_layout_sheet"); a.onBackPressed(); idle(600)
        WallpaperSheet(a).show(); idle(1500); shot("14_wallpaper_sheet"); a.onBackPressed(); idle(600)
        assertTrue(a.overlays.isEmpty())
        a.addPageFromEditMode(); idle(800)
        shot("15_added_page")
        a.addBuiltin(Builtins.BATTERY); idle(800)
        checkModel()
        a.exitEditMode(); idle(900)
        assertFalse(a.isEditing)
        checkModel()

        // Settings and every page.
        a.openSettings(); idle(800)
        shot("16_settings")
        for (page in listOf("Layout", "Dock & search bar", "Wallpapers", "Icons", "Theme & accent colour", "Blur & Fluid Glass", "Animations", "Gestures", "App drawer", "Search", a.brand.modeName, "About Fluid One")) {
            val panel = a.overlays.first { it is SettingsPanel }.root
            val tv = all(panel).filterIsInstance<android.widget.TextView>().first { it.text.toString() == page && it.isShown }
            var target: View? = tv
            while (target != null && !target.isClickable) target = target.parent as? View
            target!!.performClick(); idle(700)
            shot("17_settings_" + page.replace(Regex("[^A-Za-z0-9]"), "_"))
            // Flip every switch on the page twice to exercise each code path and restore the setting.
            val switches = all(panel).filterIsInstance<ColorSwitch>().filter { it.isShown }
            switches.forEach {
                it.performClick(); idle(120)
                // Sources that need a permission first show the privacy notice; dismiss it.
                a.overlays.filterIsInstance<FluidDialog>().forEach { d -> d.close(false) }; idle(60)
                it.performClick(); idle(120)
                a.overlays.filterIsInstance<FluidDialog>().forEach { d -> d.close(false) }; idle(60)
            }
            a.onBackPressed(); idle(600)
        }
        a.onBackPressed(); idle(600)
        assertTrue(a.overlays.isEmpty())
        checkModel()

        // Icon style / shape changes.
        listOf("themed_dark", "tinted", "glass", "original").forEach { a.prefs.iconStyle = it; a.applyIconChange(); idle(100) }
        a.prefs.iconStyle = "themed_dark"; a.prefs.iconShape = "circle"; a.applyIconChange(); idle(300)
        shot("18_themed_icons")
        a.prefs.iconStyle = "original"; a.prefs.iconShape = "squircle"; a.applyIconChange(); idle(300)

        // Grid change to 5 columns and back keeps the model valid.
        a.prefs.columns = 5; a.applyLayoutChange(); idle(500); checkModel(); shot("19_five_columns")
        a.prefs.columns = 4; a.applyLayoutChange(); idle(500); checkModel()

        // Dock styles.
        a.prefs.dockStyle = "glass"; a.applyLayoutChange(); idle(400); shot("20_glass_dock")
        a.prefs.dockStyle = "clear"; a.applyLayoutChange(); idle(400)

        // App launch morph and return.
        val launchIcon = a.dock.icons.first()
        a.launchApp(launchIcon.entry!!, launchIcon, IconView.SOURCE_DOCK)
        idle(120); shot("21_launch_mid")
        idle(600)
        controller.pause().stop(); idle(100)
        controller.restart().start().resume(); idle(100)
        shot("22_return_start")
        idle(120); shot("23_return_mid")
        idle(1200)
        assertEquals(1f, a.contentLayer.alpha)
        assertEquals(View.GONE, a.morphView.visibility)
        assertEquals(1f, launchIcon.alpha.coerceAtLeast(a.dock.icons.first().alpha))

        // Unlock animation.
        a.previewUnlock(); idle(260); shot("24_unlock_mid"); idle(1500)
        assertEquals(1f, a.contentLayer.alpha)
        shot("25_after_unlock")

        // Wallpapers render.
        Wallpapers.presets.forEach { p ->
            val bmp = Wallpapers.render(p, 360, 780)
            FileOutputStream(File(shots, "wp_${p.id}.png")).use { bmp.compress(Bitmap.CompressFormat.PNG, 90, it) }
        }

        // Recreate (process restart) keeps the layout.
        val before = a.model.pages.flatten().map { "${it.type}${it.x}${it.y}${it.appKey}" }.sorted()
        controller.pause().stop().destroy()
        controller = Robolectric.buildActivity(MainActivity::class.java).setup()
        a = controller.get()
        waitFor("wallpaper again") { a.wallpaperView.hasWallpaper }
        idle(1500)
        val after = a.model.pages.flatten().map { "${it.type}${it.x}${it.y}${it.appKey}" }.sorted()
        assertEquals(before, after)
        shot("26_recreated")
    }
}
