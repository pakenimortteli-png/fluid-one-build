package com.fluidone.launcher

import android.graphics.Matrix
import android.graphics.PointF
import android.graphics.RectF
import android.os.SystemClock
import android.view.MotionEvent
import android.view.View
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import org.robolectric.annotation.GraphicsMode
import org.robolectric.annotation.LooperMode

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [35], qualifiers = "w384dp-h832dp-xxhdpi")
@GraphicsMode(GraphicsMode.Mode.NATIVE)
@LooperMode(LooperMode.Mode.PAUSED)
class InteractionTest : LauncherTestBase() {

    /** Long-presses at [from], drags along a path to [to], optionally holds, then releases. */
    private fun dragGesture(from: PointF, to: PointF, holdMs: Long = 400, beforeUp: (() -> Unit)? = null) {
        val down = SystemClock.uptimeMillis()
        touch(MotionEvent.ACTION_DOWN, from.x, from.y, down)
        idle(520)
        val steps = 16
        for (i in 1..steps) {
            touch(MotionEvent.ACTION_MOVE, lerp(from.x, to.x, i / steps.toFloat()), lerp(from.y, to.y, i / steps.toFloat()), down)
            idle(24)
        }
        idle(holdMs)
        touch(MotionEvent.ACTION_MOVE, to.x + 1f, to.y + 1f, down)
        idle(32)
        beforeUp?.invoke()
        touch(MotionEvent.ACTION_UP, to.x, to.y, down)
        idle(900)
    }

    private fun cellPoint(page: Int, x: Int, y: Int, fx: Float = 0.5f, fy: Float = 0.42f): PointF {
        val cl = a.workspace.pages[page]
        val r = cl.cellRect(x, y)
        val pt = floatArrayOf(r.left + r.width() * fx, r.top + r.height() * fy)
        val m = Matrix(); cl.transformMatrixToGlobal(m); m.mapPoints(pt)
        return PointF(pt[0], pt[1])
    }

    private fun center(v: View): PointF {
        val r = if (v is IconView) v.iconRectInWindow() else RectF(0f, 0f, v.width.toFloat(), v.height.toFloat()).also {
            val m = Matrix(); v.transformMatrixToGlobal(m); m.mapRect(it)
        }
        return PointF(r.centerX(), r.centerY())
    }

    private fun goToPage(p: Int) { a.workspace.snapTo(p); idle(700); assertEquals(p, a.workspace.currentPage) }

    @Test
    fun pushReorderShiftsNeighbours() {
        val row = a.model.pages[0].filter { it.type == HomeItem.APP && it.y == 4 }.sortedBy { it.x }
        assertEquals(4, row.size)
        val (aa, b, c, d) = row
        // Drop D on the left edge of B's cell (not its centre) → push reorder instead of a folder.
        dragGesture(center(a.workspace.pages[0].childFor(d)!!), cellPoint(0, 1, 4, fx = 0.12f, fy = 0.4f), beforeUp = {
        })
        checkModel()
        assertEquals(0, aa.x)
        assertEquals(1 to 4, d.x to d.y)
        assertEquals(2 to 4, b.x to b.y)
        assertEquals(3 to 4, c.x to c.y)
        assertTrue(a.model.pages[0].none { it.type == HomeItem.FOLDER && it.apps.contains(d.appKey) })
        shot("i01_push_reorder")
    }

    @Test
    fun dockAndHomeExchange() {
        val dockKey = a.model.dock.first()
        goToPage(1)
        assertTrue(a.model.isRegionFree(1, 0, 5, 1, 1, a.prefs.columns, a.prefs.rows))
        dragGesture(center(a.dock.icons.first()), cellPoint(1, 0, 5))
        checkModel()
        assertEquals(3, a.model.dock.size)
        assertFalse(dockKey in a.model.dock)
        val placed = a.model.findAppItem(dockKey)
        assertNotNull(placed)
        assertEquals(1 to (0 to 5), a.model.pageOf(placed!!) to (placed.x to placed.y))
        assertEquals(1f, a.workspace.pages[1].childFor(placed)!!.alpha)
        shot("i02_dock_to_home")

        // And back into the dock, between the first two icons.
        val target = a.dock.icons[0].iconRectInWindow()
        dragGesture(center(a.workspace.pages[1].childFor(placed)!!), PointF(target.right + 4f, target.centerY()))
        checkModel()
        assertEquals(4, a.model.dock.size)
        assertEquals(1, a.model.dock.indexOf(dockKey))
        assertTrue(a.model.findAppItem(dockKey) == null)
        a.dock.icons.forEach { assertEquals(1f, it.alpha) }
        shot("i03_home_to_dock")
    }

    @Test
    fun dragFromDrawerToHomeKeepsDrawerIconVisible() {
        goToPage(1)
        a.openDrawer(); idle(900)
        val src = (0 until a.drawer.grid.childCount).map { a.drawer.grid.getChildAt(it) as IconView }.first { it.isAttachedToWindow }
        val key = src.entry!!.key
        assertTrue(a.model.isRegionFree(1, 2, 5, 1, 1, a.prefs.columns, a.prefs.rows))
        dragGesture(center(src), cellPoint(1, 2, 5), holdMs = 600)
        checkModel()
        assertFalse(a.isDrawerOpen)
        assertTrue(a.model.pages[1].any { it.type == HomeItem.APP && it.appKey == key && it.x == 2 && it.y == 5 })
        a.openDrawer(); idle(900)
        val again = a.drawer.iconFor(key)
        assertNotNull(again)
        assertEquals(1f, again!!.alpha)
        shot("i04_drawer_after_drag")
        a.setDrawerOpen(false); idle(600)
    }

    @Test
    fun dragOutOfFolderToAnotherPage() {
        val folder = a.model.pages[0].first { it.type == HomeItem.FOLDER }
        val fv = a.workspace.pages[0].childFor(folder) as FolderIconView
        val countBefore = folder.apps.size
        FolderOverlay(a, folder, fv).show(); idle(900)
        val fo = a.openFolder!!
        val first = fo.iconFor(folder.apps.first())!!
        val key = first.entry!!.key
        val w = a.rootView.width.toFloat()
        // Drag out of the panel to the right edge and hold to flip to page 2, then drop in an empty cell.
        val start = center(first)
        val down = SystemClock.uptimeMillis()
        touch(MotionEvent.ACTION_DOWN, start.x, start.y, down); idle(520)
        val edge = PointF(w - a.dp(8f), a.rootView.height * 0.5f)
        for (i in 1..16) { touch(MotionEvent.ACTION_MOVE, lerp(start.x, edge.x, i / 16f), lerp(start.y, edge.y, i / 16f), down); idle(24) }
        assertTrue(a.drag.isDragging)
        assertTrue("folder closes once the icon leaves it", a.openFolder == null)
        idle(1100)
        assertEquals(1, a.workspace.currentPage)
        val dst = cellPoint(1, 3, 5)
        for (i in 1..10) { touch(MotionEvent.ACTION_MOVE, lerp(edge.x, dst.x, i / 10f), lerp(edge.y, dst.y, i / 10f), down); idle(24) }
        idle(400)
        touch(MotionEvent.ACTION_UP, dst.x, dst.y, down); idle(900)
        checkModel()
        assertEquals(countBefore - 1, folder.apps.size)
        val placed = a.model.findAppItem(key)
        assertNotNull(placed)
        assertEquals(1, a.model.pageOf(placed!!))
        shot("i05_out_of_folder")
    }

    @Test
    fun removeTargetRemovesFromHome() {
        val item = a.model.pages[0].first { it.type == HomeItem.APP }
        val v = a.workspace.pages[0].childFor(item)!!
        var sawBar = false
        dragGesture(center(v), PointF(a.rootView.width * 0.25f, a.insetTop + a.dp(24f)), beforeUp = { sawBar = a.removeBar.isShown; shot("i06_remove_bar") })
        assertTrue(sawBar)
        assertTrue(a.model.findAppItem(item.appKey) == null)
        assertTrue(a.apps.contains(item.appKey))
        checkModel()
    }

    @Test
    fun widgetResizeAndBuiltinMenu() {
        val cal = a.model.pages[0].first { it.type == HomeItem.BUILTIN && it.builtin == Builtins.CALENDAR }
        val v = a.workspace.pages[0].childFor(cal)!!
        a.onItemLongPress(v); idle(600)
        shot("i07_widget_menu")
        val popup = a.overlays.last() as ItemPopup
        assertNotNull(popup)
        clickText("2×3")
        idle(600)
        checkModel()
        assertTrue(a.overlays.isEmpty())
        // Either resized in place / moved, or there was no room: the model must stay valid either way.
        assertTrue(cal.spanX == 2 && (cal.spanY == 3 || cal.spanY == 2))
    }

    @Test
    fun largeFolderTileLaunchesAndReturns() {
        a.prefs.launchAnim = "morph"   // the classic in-launcher morph (Zoom is drawn by the system)
        val folder = a.model.pages[0].first { it.type == HomeItem.FOLDER && it.isLargeFolder }
        val fv = a.workspace.pages[0].childFor(folder) as FolderIconView
        val r = fv.previewRectInWindow(0)
        val down = SystemClock.uptimeMillis()
        touch(MotionEvent.ACTION_DOWN, r.centerX(), r.centerY(), down); idle(48)
        touch(MotionEvent.ACTION_UP, r.centerX(), r.centerY(), down); idle(150)
        assertTrue("launch morph runs", a.morphView.visibility == View.VISIBLE)
        assertTrue(a.overlays.isEmpty())
        idle(600)
        controller.pause().stop(); idle(50)
        controller.restart().start().resume(); idle(1400)
        assertEquals(View.GONE, a.morphView.visibility)
        assertEquals(1f, a.contentLayer.alpha)
        assertEquals(1f, fv.alpha)
    }

    @Test
    fun deletePageThroughDialog() {
        val pages = a.model.pages.size
        a.enterEditMode(); idle(900)
        a.requestDeletePage(1); idle(600)
        shot("i08_delete_dialog")
        clickText("Delete")
        idle(900)
        assertEquals(pages - 1, a.model.pages.size)
        checkModel()
        a.exitEditMode(); idle(800)
    }

    @Test
    fun iconEditorAndDarkTheme() {
        val entry = a.apps.apps.first()
        IconEditorSheet(a, entry).show(); idle(900)
        shot("i09_icon_editor")
        a.onBackPressed(); idle(600)
        a.prefs.theme = "dark"; a.applyThemeChange(); idle(300)
        assertTrue(a.ui.dark)
        a.openSettings(); idle(800); shot("i10_settings_dark")
        clickText("Blur & Fluid Glass"); shot("i11_blur_dark")
        a.onBackPressed(); idle(500); a.onBackPressed(); idle(600)
        val icon = a.workspace.pages[0].childList().first { it is IconView && it !is FolderIconView }
        a.onItemLongPress(icon); idle(600); shot("i12_popup_dark")
        a.onBackPressed(); idle(600)
        assertTrue(a.overlays.isEmpty())
    }

    @Test
    fun pageEffectsMidSwipe() {
        val w = a.rootView.width.toFloat(); val h = a.rootView.height.toFloat()
        for (effect in listOf("cube", "depth", "carousel", "fade")) {
            a.prefs.pageEffect = effect; a.applyLayoutChange(); idle(200)
            val down = SystemClock.uptimeMillis()
            touch(MotionEvent.ACTION_DOWN, w * 0.85f, h * 0.55f, down)
            for (i in 1..8) { idle(16); touch(MotionEvent.ACTION_MOVE, w * 0.85f - i * w * 0.06f, h * 0.55f, down) }
            idle(16)
            shot("i13_effect_$effect")
            touch(MotionEvent.ACTION_UP, w * 0.37f, h * 0.55f, down); idle(900)
            a.workspace.snapTo(0); idle(700)
        }
        a.prefs.pageEffect = "slide"
    }

    @Test
    fun foldersSmallAndLargeToggle() {
        val folder = a.model.pages[0].first { it.type == HomeItem.FOLDER }
        val v = a.workspace.pages[0].childFor(folder)!!
        a.onItemLongPress(v); idle(600)
        clickText("Small"); idle(600)
        assertFalse(folder.isLargeFolder)
        checkModel()
        shot("i14_small_folder")
    }
}
