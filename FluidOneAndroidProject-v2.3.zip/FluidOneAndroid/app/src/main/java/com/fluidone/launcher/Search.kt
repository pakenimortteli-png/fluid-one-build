package com.fluidone.launcher

import android.Manifest
import android.app.SearchManager
import android.content.ClipData
import android.content.ClipboardManager
import android.content.ContentUris
import android.content.Context
import android.content.Intent
import android.content.pm.ShortcutInfo
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.BitmapShader
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Shader
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.provider.AlarmClock
import android.provider.CalendarContract
import android.provider.ContactsContract
import android.text.SpannableString
import android.text.Spanned
import android.text.format.DateUtils
import android.text.style.ForegroundColorSpan
import android.text.style.TypefaceSpan
import android.util.LruCache
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.util.Locale
import java.util.concurrent.Executors
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/** One search result row. */
class SearchHit(
    val title: String,
    val subtitle: String? = null,
    val icon: Int = 0,
    val iconColor: Int = 0,
    val bitmap: Bitmap? = null,
    val avatar: String? = null,
    val avatarColor: Int = 0,
    val actions: List<HitAction> = emptyList(),
    val loadImage: ((ImageView) -> Unit)? = null,
    val open: (View) -> Unit
)

class HitAction(val icon: Int, val label: String, val run: (View) -> Unit)

/**
 * A group of results. [priority] orders the groups (lower first). [style]: "apps" (icon grid), "list" (card of
 * rows), "calc" (big answer card), "web" (chips) or "prompt" (permission card).
 */
class SearchSection(
    val id: String,
    val title: String?,
    val priority: Int,
    val style: String = "list",
    val hits: List<SearchHit> = emptyList(),
    val apps: List<AppEntry> = emptyList(),
    val limit: Int = 4
)

/** Turns the flashlight on and off without any permission (CameraManager torch mode). */
class Torch(context: Context) {
    private val cm = context.getSystemService(CameraManager::class.java)
    private var id: String? = null
    var on = false
        private set

    init {
        try {
            id = cm?.cameraIdList?.firstOrNull { cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true }
            if (id != null) cm?.registerTorchCallback(object : CameraManager.TorchCallback() {
                override fun onTorchModeChanged(cameraId: String, enabled: Boolean) { if (cameraId == id) on = enabled }
            }, Handler(Looper.getMainLooper()))
        } catch (_: Exception) { id = null }
    }

    val available: Boolean get() = id != null

    fun toggle(): Boolean = try {
        cm!!.setTorchMode(id!!, !on); on = !on; true
    } catch (_: Exception) { false }
}

/**
 * Finds things on the phone: apps, app shortcuts, contacts, calendar events, Android and Fluid One settings,
 * wallpapers, a calculator, unit conversions and quick actions. Nothing is sent anywhere; web searches only
 * happen when you tap one and then run in your browser.
 */
class SearchEngine(private val launcher: MainActivity) {
    private val worker = Executors.newSingleThreadExecutor { r ->
        Thread({ android.os.Process.setThreadPriority(android.os.Process.THREAD_PRIORITY_BACKGROUND); r.run() }, "fluid-search").apply { isDaemon = true }
    }
    private val main = Handler(Looper.getMainLooper())
    @Volatile private var shortcutCache: List<ShortcutInfo>? = null
    private val images = LruCache<String, Bitmap>(48)
    private val torch by lazy { Torch(launcher) }
    private val prefs get() = launcher.prefs

    fun invalidate() { shortcutCache = null }

    fun has(permission: String) = launcher.checkSelfPermission(permission) == android.content.pm.PackageManager.PERMISSION_GRANTED

    // ---- Instant sources (UI thread) -------------------------------------------------------------------------

    fun quick(query: String): List<SearchSection> {
        val q = query.trim()
        val nq = SearchText.norm(q)
        val out = ArrayList<SearchSection>()
        val apps = matchApps(nq)
        if (apps.isNotEmpty()) out += SearchSection("apps", "Apps", if (apps.first().second >= 900) 4 else 30, "apps", apps = apps.map { it.first })

        if (prefs.searchCalc) {
            if (Calc.looksLikeMath(q)) Calc.eval(q)?.let { v ->
                val answer = SearchText.formatNumber(v)
                if (answer != q.replace(" ", "")) out += SearchSection("calc", "Calculator", 1, "calc", listOf(copyHit(answer, q.removeSuffix("=").trim() + " =", R.drawable.ic_calc)))
            } else Units.convert(q)?.let { r ->
                out += SearchSection("calc", r.category, 2, "calc", listOf(copyHit(r.to, r.from + " =", R.drawable.ic_swap)))
            }
        }

        if (prefs.searchActions) {
            val (hits, strong) = actions(q)
            if (hits.isNotEmpty()) out += SearchSection("actions", "Quick actions", if (strong) 3 else 45, hits = hits, limit = 4)
        }

        if (prefs.searchSettings && nq.length >= 2) {
            val fluid = SearchCatalog.launcher.mapNotNull { s ->
                val score = SearchCatalog.scoreSetting(s.title, s.keywords, nq)
                if (score > 0) Pair(s, score) else null
            }.sortedWith(Comparator { a, b -> b.second - a.second }).map { (s, _) ->
                SearchHit(s.title, "Fluid One", s.icon, s.color) { launcher.openSettingsPage(s.page) }
            }.toMutableList()
            Wallpapers.presets.forEach { p ->
                if (SearchText.score(p.name, nq) >= 600 || (nq.length >= 4 && "wallpapers".startsWith(nq))) {
                    fluid += SearchHit(p.name, if (p.hasGlass) "Wallpaper · Fluid Glass" else "Wallpaper",
                        loadImage = { iv -> launcher.wallpaperThumbnail(p.id, launcher.dpi(36), launcher.dpi(36)) { iv.setImageBitmap(it) } }) {
                        launcher.setWallpaper(p.id); launcher.toast("Wallpaper set to ${p.name}")
                    }
                }
            }
            if (fluid.isNotEmpty()) out += SearchSection("fluid", "Fluid One", 60, hits = fluid, limit = 3)

            val system = SearchCatalog.system.mapNotNull { s ->
                val score = SearchCatalog.scoreSetting(s.title, s.keywords, nq)
                if (score > 0) Pair(s, score) else null
            }.sortedWith(Comparator { a, b -> b.second - a.second }).map { (s, _) ->
                SearchHit(s.title, "Android settings", R.drawable.ic_settings, s.color) { v -> openSystemSetting(s, v) }
            }
            if (system.isNotEmpty()) out += SearchSection("system", "Settings", 65, hits = system, limit = 4)
        }

        // Offer contacts/calendar access only for searches that could be a name, not for sums or conversions.
        if (q.length >= 2 && out.none { it.id == "calc" } && !prefs.searchPromptDismissed && missingPermissions().isNotEmpty()) {
            out += SearchSection("prompt", null, 90, "prompt")
        }
        if (prefs.searchWeb) out += SearchSection("web", null, 100, "web")
        return out
    }

    /** Permissions that an enabled search source still needs. */
    fun missingPermissions(): List<Pair<String, String>> {
        val list = ArrayList<Pair<String, String>>()
        if (prefs.searchContacts && !has(Manifest.permission.READ_CONTACTS)) list += Manifest.permission.READ_CONTACTS to "contacts"
        if (prefs.searchCalendar && !has(Manifest.permission.READ_CALENDAR)) list += Manifest.permission.READ_CALENDAR to "calendar"
        return list
    }

    fun matchApps(nq: String): List<Pair<AppEntry, Int>> {
        if (nq.isEmpty()) return emptyList()
        val counts = prefs.launchCounts()
        val scored = ArrayList<Pair<AppEntry, Int>>()
        for (e in launcher.apps.drawerApps()) {
            val label = launcher.apps.label(e)
            var s = SearchText.score(label, nq, e.packageName)
            if (s == 0 && label != e.systemLabel) s = SearchText.score(e.systemLabel, nq) * 9 / 10
            if (s > 0) scored += e to s + min(counts[e.key] ?: 0, 60)
        }
        return scored.sortedWith(Comparator { a, b ->
            if (a.second != b.second) b.second - a.second else launcher.apps.label(a.first).compareTo(launcher.apps.label(b.first), ignoreCase = true)
        })
    }

    /** Apps opened most often, for suggestions. */
    fun suggestedApps(max: Int): List<AppEntry> {
        val counts = prefs.launchCounts()
        val hidden = prefs.hiddenApps
        return counts.entries.sortedWith(Comparator { a, b -> b.value - a.value })
            .mapNotNull { launcher.apps[it.key]?.takeIf { e -> e.key !in hidden } }
            .take(max)
    }

    private fun copyHit(answer: String, expression: String, icon: Int) = SearchHit(answer, expression, icon, launcher.prefs.accent,
        actions = listOf(HitAction(R.drawable.ic_copy, "Copy") { copy(answer) })) { copy(answer) }

    private fun copy(text: String) {
        launcher.getSystemService(ClipboardManager::class.java)?.setPrimaryClip(ClipData.newPlainText("Fluid One", text))
        launcher.toast("Copied $text")
    }

    private fun start(intent: Intent, v: View?) = launcher.startSafely(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK), v)

    private fun openSystemSetting(s: SystemSetting, v: View) {
        val pm = launcher.packageManager
        for (action in s.actions) {
            val i = Intent(action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            if (i.resolveActivity(pm) != null) { launcher.startSafely(i, v); return }
        }
        launcher.startSafely(Intent(android.provider.Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK), v)
    }

    // ---- Quick actions --------------------------------------------------------------------------------------

    private val phoneRe = Regex("^\\+?[0-9][0-9 ()\\-.]{2,}$")
    private val emailRe = Regex("^[\\w.+-]+@[\\w-]+(\\.[\\w-]+)+$")
    private val urlRe = Regex("^(https?://)?([a-z0-9-]+\\.)+[a-z]{2,}(:[0-9]+)?(/\\S*)?$", RegexOption.IGNORE_CASE)
    private val timerRe = Regex("^(?:set\\s+)?(?:an?\\s+)?(?:timer\\s+(?:for\\s+)?)?([0-9]+(?:[.,][0-9]+)?)\\s*(s|sec|secs|seconds?|m|min|mins|minutes?|h|hr|hrs|hours?)\\s*(?:timer)?$")
    private val alarmRe = Regex("^(?:set\\s+)?(?:an?\\s+)?(?:alarm|wake(?:\\s+me)?(?:\\s+up)?)\\s*(?:at|for)?\\s*([0-9]{1,2})(?:[:.]([0-9]{2}))?\\s*(am|pm)?$")
    private val alarmRe2 = Regex("^([0-9]{1,2})(?:[:.]([0-9]{2}))?\\s*(am|pm)?\\s+alarm$")

    private fun prefixOf(q: String, vararg words: String) = q.length >= 3 && words.any { it.startsWith(q) }

    /** Contextual actions for what was typed, and whether they should lead the results. */
    fun actions(query: String): Pair<List<SearchHit>, Boolean> {
        val q = query.trim()
        val l = q.lowercase(Locale.ROOT)
        val hits = ArrayList<SearchHit>()
        var strong = false
        val digits = q.count { it.isDigit() }
        val isPhone = phoneRe.matches(q) && digits >= 3 && !(digits < 7 && Calc.looksLikeMath(q))
        if (isPhone) {
            val number = q.filter { it.isDigit() || it == '+' }
            strong = true
            hits += SearchHit("Call $q", "Phone", R.drawable.ic_phone, Color.rgb(36, 186, 104)) { v -> start(Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + Uri.encode(number))), v) }
            hits += SearchHit("Send a message", q, R.drawable.ic_message, Color.rgb(47, 123, 246)) { v -> start(Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:" + Uri.encode(number))), v) }
            hits += SearchHit("Add to contacts", q, R.drawable.ic_person_add, Color.rgb(255, 140, 40)) { v ->
                start(Intent(ContactsContract.Intents.Insert.ACTION).setType(ContactsContract.RawContacts.CONTENT_TYPE).putExtra(ContactsContract.Intents.Insert.PHONE, number), v)
            }
        }
        if (emailRe.matches(q)) {
            strong = true
            hits += SearchHit("Email $q", "Mail", R.drawable.ic_mail, Color.rgb(242, 80, 90)) { v -> start(Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:" + q)), v) }
        } else if (urlRe.matches(q) && !q.contains(' ')) {
            strong = true
            val url = if (l.startsWith("http://") || l.startsWith("https://")) q else "https://$q"
            hits += SearchHit("Open ${q.removePrefix("https://").removePrefix("http://")}", "Website", R.drawable.ic_link, Color.rgb(47, 123, 246)) { v -> start(Intent(Intent.ACTION_VIEW, Uri.parse(url)), v) }
        }
        timerRe.matchEntire(l)?.takeIf { l.contains("timer") }?.let { m ->
            val n = m.groupValues[1].replace(',', '.').toDoubleOrNull() ?: return@let
            val unit = m.groupValues[2]
            val seconds = (n * when { unit.startsWith("h") -> 3600; unit.startsWith("m") -> 60; else -> 1 }).roundToInt()
            if (seconds in 1..86399) {
                strong = true
                val label = SearchText.formatNumber(n) + " " + when { unit.startsWith("h") -> "h"; unit.startsWith("m") -> "min"; else -> "s" }
                hits += SearchHit("Start a $label timer", "Clock", R.drawable.ic_timer, Color.rgb(255, 128, 41)) { v ->
                    start(Intent(AlarmClock.ACTION_SET_TIMER).putExtra(AlarmClock.EXTRA_LENGTH, seconds).putExtra(AlarmClock.EXTRA_SKIP_UI, false), v)
                }
            }
        }
        (alarmRe.matchEntire(l) ?: alarmRe2.matchEntire(l))?.let { m ->
            var h = m.groupValues[1].toIntOrNull() ?: return@let
            val min = m.groupValues[2].toIntOrNull() ?: 0
            val ampm = m.groupValues[3]
            if (ampm == "pm" && h in 1..11) h += 12
            if (ampm == "am" && h == 12) h = 0
            if (h in 0..23 && min in 0..59) {
                strong = true
                val text = String.format(Locale.getDefault(), "%02d:%02d", h, min)
                hits += SearchHit("Set an alarm for $text", "Clock", R.drawable.ic_alarm, Color.rgb(255, 128, 41)) { v ->
                    start(Intent(AlarmClock.ACTION_SET_ALARM).putExtra(AlarmClock.EXTRA_HOUR, h).putExtra(AlarmClock.EXTRA_MINUTES, min).putExtra(AlarmClock.EXTRA_SKIP_UI, false), v)
                }
            }
        }
        if (hits.isEmpty()) {
            if (prefixOf(l, "flashlight", "torch", "flash") && torch.available) {
                hits += SearchHit(if (torch.on) "Turn off flashlight" else "Turn on flashlight", "Quick action", R.drawable.ic_flash, Color.rgb(255, 176, 32)) { v ->
                    if (torch.toggle()) { launcher.haptic(v, HapticFeedbackConstants.CONFIRM); launcher.drawer.refreshSearch() } else launcher.toast("The flashlight is busy")
                }
            }
            if (prefixOf(l, "timer", "stopwatch", "countdown")) hits += SearchHit("Timers", "Clock", R.drawable.ic_timer, Color.rgb(255, 128, 41)) { v -> start(Intent(AlarmClock.ACTION_SHOW_TIMERS), v) }
            if (prefixOf(l, "alarm", "alarms", "wake")) hits += SearchHit("Alarms", "Clock", R.drawable.ic_alarm, Color.rgb(255, 128, 41)) { v -> start(Intent(AlarmClock.ACTION_SHOW_ALARMS), v) }
        }
        return hits to strong
    }

    // ---- Web ------------------------------------------------------------------------------------------------

    class WebTarget(val icon: Int, val label: String, val open: (String, View) -> Unit)

    val webTargets: List<WebTarget> = listOf(
        WebTarget(R.drawable.ic_globe, "Web") { q, v ->
            val i = Intent(Intent.ACTION_WEB_SEARCH).putExtra(SearchManager.QUERY, q)
            if (i.resolveActivity(launcher.packageManager) != null) start(i, v)
            else start(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + Uri.encode(q))), v)
        },
        WebTarget(R.drawable.ic_store, "Play Store") { q, v ->
            val i = Intent(Intent.ACTION_VIEW, Uri.parse("market://search?q=" + Uri.encode(q)))
            if (i.resolveActivity(launcher.packageManager) != null) start(i, v)
            else start(Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/search?q=" + Uri.encode(q))), v)
        },
        WebTarget(R.drawable.ic_play, "YouTube") { q, v -> start(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/results?search_query=" + Uri.encode(q))), v) },
        WebTarget(R.drawable.ic_place, "Maps") { q, v -> start(Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=" + Uri.encode(q))), v) }
    )

    // ---- Background sources ---------------------------------------------------------------------------------

    /** Contacts, calendar and app shortcuts, on a worker thread; [done] runs on the main thread. */
    fun slow(query: String, done: (List<SearchSection>) -> Unit) {
        val q = query.trim()
        val wantContacts = prefs.searchContacts && has(Manifest.permission.READ_CONTACTS)
        val wantCalendar = prefs.searchCalendar && has(Manifest.permission.READ_CALENDAR)
        val wantShortcuts = prefs.searchShortcuts
        if (q.isEmpty() || (!wantContacts && !wantCalendar && !wantShortcuts)) { done(emptyList()); return }
        val iconSize = launcher.dpi(36)
        worker.execute {
            val out = ArrayList<SearchSection>()
            if (wantContacts) try { contacts(q, iconSize)?.let { out += it } } catch (_: Exception) { }
            if (wantShortcuts) try { shortcuts(q, iconSize)?.let { out += it } } catch (_: Exception) { }
            if (wantCalendar) try { calendar(q)?.let { out += it } } catch (_: Exception) { }
            main.post { done(out) }
        }
    }

    private class ContactRow(val id: Long, val lookup: String, val name: String, val photo: String?, val starred: Boolean) {
        var number: String? = null
        var type: String? = null
        var score = 0
    }

    private fun contacts(q: String, size: Int): SearchSection? {
        val cr = launcher.contentResolver
        val found = LinkedHashMap<Long, ContactRow>()
        val proj = arrayOf(ContactsContract.Contacts._ID, ContactsContract.Contacts.LOOKUP_KEY, ContactsContract.Contacts.DISPLAY_NAME_PRIMARY,
            ContactsContract.Contacts.PHOTO_THUMBNAIL_URI, ContactsContract.Contacts.STARRED)
        val uri = ContactsContract.Contacts.CONTENT_FILTER_URI.buildUpon().appendPath(q).appendQueryParameter(ContactsContract.LIMIT_PARAM_KEY, "20").build()
        cr.query(uri, proj, null, null, null)?.use { c ->
            while (c.moveToNext() && found.size < 20) {
                val name = c.getString(2) ?: continue
                found[c.getLong(0)] = ContactRow(c.getLong(0), c.getString(1) ?: "", name, c.getString(3), c.getInt(4) == 1)
            }
        }
        if (q.count { it.isDigit() } >= 3) {
            val pu = ContactsContract.CommonDataKinds.Phone.CONTENT_FILTER_URI.buildUpon().appendPath(q).build()
            cr.query(pu, arrayOf(ContactsContract.CommonDataKinds.Phone.CONTACT_ID, ContactsContract.CommonDataKinds.Phone.LOOKUP_KEY,
                ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME_PRIMARY, ContactsContract.CommonDataKinds.Phone.PHOTO_THUMBNAIL_URI,
                ContactsContract.CommonDataKinds.Phone.STARRED), null, null, null)?.use { c ->
                while (c.moveToNext() && found.size < 24) {
                    val id = c.getLong(0)
                    if (id in found) continue
                    val name = c.getString(2) ?: continue
                    found[id] = ContactRow(id, c.getString(1) ?: "", name, c.getString(3), c.getInt(4) == 1)
                }
            }
        }
        if (found.isEmpty()) return null
        val ids = found.keys.joinToString(",")
        cr.query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(ContactsContract.CommonDataKinds.Phone.CONTACT_ID, ContactsContract.CommonDataKinds.Phone.NUMBER,
                ContactsContract.CommonDataKinds.Phone.TYPE, ContactsContract.CommonDataKinds.Phone.LABEL),
            "${ContactsContract.CommonDataKinds.Phone.CONTACT_ID} IN ($ids)", null,
            "${ContactsContract.CommonDataKinds.Phone.IS_SUPER_PRIMARY} DESC")?.use { c ->
            while (c.moveToNext()) {
                val row = found[c.getLong(0)] ?: continue
                if (row.number != null) continue
                row.number = c.getString(1)
                row.type = ContactsContract.CommonDataKinds.Phone.getTypeLabel(launcher.resources, c.getInt(2), c.getString(3)).toString()
            }
        }
        val nq = SearchText.norm(q)
        found.values.forEach { it.score = SearchText.score(it.name, nq) + (if (it.starred) 50 else 0) + (if (it.number != null) 10 else 0) }
        val rows = found.values.sortedWith(Comparator { a, b -> if (a.score != b.score) b.score - a.score else a.name.compareTo(b.name, ignoreCase = true) }).take(10)
        val hits = rows.mapIndexed { i, r ->
            val photo = if (i < 6 && r.photo != null) photo(r.photo, size) else null
            val number = r.number
            val dial = number?.filter { it.isDigit() || it == '+' || it == '*' || it == '#' }
            val actions = if (number != null && !dial.isNullOrEmpty()) listOf(
                HitAction(R.drawable.ic_phone, "Call ${r.name}") { v -> start(Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + Uri.encode(dial))), v) },
                HitAction(R.drawable.ic_message, "Message ${r.name}") { v -> start(Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:" + Uri.encode(dial))), v) }
            ) else emptyList()
            SearchHit(r.name, if (number != null) listOfNotNull(r.type, number).joinToString(" · ") else "Contact",
                bitmap = photo, avatar = if (photo == null) initials(r.name) else null, avatarColor = avatarColor(r.name), actions = actions) { v ->
                start(Intent(Intent.ACTION_VIEW, ContactsContract.Contacts.getLookupUri(r.id, r.lookup)), v)
            }
        }
        return SearchSection("contacts", "Contacts", 40, hits = hits, limit = 3)
    }

    private fun photo(uri: String, size: Int): Bitmap? {
        images.get(uri)?.let { return it }
        return try {
            val raw = launcher.contentResolver.openInputStream(Uri.parse(uri))?.use { BitmapFactory.decodeStream(it) } ?: return null
            circle(raw, size).also { images.put(uri, it) }
        } catch (_: Exception) { null }
    }

    private fun circle(src: Bitmap, size: Int): Bitmap {
        val out = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val c = Canvas(out)
        val p = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
        val shader = BitmapShader(src, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP)
        val s = size / min(src.width, src.height).toFloat()
        val m = android.graphics.Matrix()
        m.setScale(s, s)
        m.postTranslate((size - src.width * s) / 2f, (size - src.height * s) / 2f)
        shader.setLocalMatrix(m)
        p.shader = shader
        c.drawCircle(size / 2f, size / 2f, size / 2f, p)
        return out
    }

    private fun initials(name: String): String {
        val parts = name.trim().split(Regex("\\s+")).filter { it.isNotEmpty() && it[0].isLetterOrDigit() }
        return when {
            parts.isEmpty() -> name.take(1).uppercase()
            parts.size == 1 -> parts[0].take(1).uppercase()
            else -> (parts[0].take(1) + parts[parts.size - 1].take(1)).uppercase()
        }
    }

    private fun avatarColor(name: String): Int {
        val palette = intArrayOf(Color.rgb(47, 123, 246), Color.rgb(36, 186, 104), Color.rgb(255, 128, 41), Color.rgb(132, 94, 247),
            Color.rgb(242, 80, 128), Color.rgb(24, 178, 172), Color.rgb(230, 90, 70))
        return palette[(name.hashCode() and 0x7fffffff) % palette.size]
    }

    private fun shortcuts(q: String, size: Int): SearchSection? {
        val all = shortcutCache ?: launcher.allShortcuts().also { shortcutCache = it }
        if (all.isEmpty()) return null
        val nq = SearchText.norm(q)
        val scored = ArrayList<Pair<ShortcutInfo, Int>>()
        for (si in all) {
            val short = si.shortLabel?.toString() ?: continue
            var s = max(SearchText.score(short, nq), si.longLabel?.toString()?.let { SearchText.score(it, nq) } ?: 0)
            if (s < 600) {
                val app = launcher.apps.forPackage(si.`package`).firstOrNull { it.user == si.userHandle }
                if (app != null && nq.length >= 3 && SearchText.score(launcher.apps.label(app), nq) >= 900) s = 500 - si.rank
                else s = 0
            }
            if (s > 0) scored += si to s
        }
        if (scored.isEmpty()) return null
        val top = scored.sortedWith(Comparator { a, b -> b.second - a.second }).take(8)
        val hits = top.map { (si, _) ->
            val app = launcher.apps.forPackage(si.`package`).firstOrNull { it.user == si.userHandle }
            val icon = launcher.shortcutIcon(si, size) ?: app?.let { launcher.icons.cachedIcon(it, launcher.iconSizePx) }
            SearchHit(si.shortLabel?.toString() ?: "", app?.let { launcher.apps.label(it) } ?: "Shortcut", R.drawable.ic_open, Color.rgb(90, 98, 120), bitmap = icon) { v ->
                val r = android.graphics.RectF(0f, 0f, v.width.toFloat(), v.height.toFloat())
                val m = android.graphics.Matrix(); v.transformMatrixToGlobal(m); m.mapRect(r)
                launcher.launchShortcut(si, r)
            }
        }
        return SearchSection("shortcuts", "App shortcuts", 50, hits = hits, limit = 3)
    }

    private fun calendar(q: String): SearchSection? {
        val now = System.currentTimeMillis()
        val day = 86_400_000L
        val b = CalendarContract.Instances.CONTENT_SEARCH_URI.buildUpon()
        ContentUris.appendId(b, now - day)
        ContentUris.appendId(b, now + 400 * day)
        b.appendPath(q)
        val seen = HashSet<Long>()
        val hits = ArrayList<SearchHit>()
        launcher.contentResolver.query(b.build(), arrayOf(CalendarContract.Instances.EVENT_ID, CalendarContract.Instances.TITLE,
            CalendarContract.Instances.BEGIN, CalendarContract.Instances.END, CalendarContract.Instances.ALL_DAY,
            CalendarContract.Instances.EVENT_LOCATION, CalendarContract.Instances.DISPLAY_COLOR), null, null,
            "${CalendarContract.Instances.BEGIN} ASC")?.use { c ->
            while (c.moveToNext() && hits.size < 6) {
                val id = c.getLong(0)
                if (!seen.add(id)) continue
                val title = c.getString(1)?.takeIf { it.isNotBlank() } ?: "(No title)"
                val begin = c.getLong(2); val end = c.getLong(3)
                val allDay = c.getInt(4) == 1
                val flags = DateUtils.FORMAT_SHOW_DATE or DateUtils.FORMAT_SHOW_WEEKDAY or DateUtils.FORMAT_ABBREV_ALL or
                    (if (allDay) DateUtils.FORMAT_UTC else DateUtils.FORMAT_SHOW_TIME)
                val time = DateUtils.formatDateTime(launcher, begin, flags)
                val where = c.getString(5)?.takeIf { it.isNotBlank() }
                val color = if (c.isNull(6)) Color.rgb(242, 80, 90) else (c.getInt(6) or 0xFF000000.toInt())
                hits += SearchHit(title, listOfNotNull(time, where).joinToString(" · "), R.drawable.ic_calendar, color) { v ->
                    start(Intent(Intent.ACTION_VIEW, ContentUris.withAppendedId(CalendarContract.Events.CONTENT_URI, id))
                        .putExtra(CalendarContract.EXTRA_EVENT_BEGIN_TIME, begin).putExtra(CalendarContract.EXTRA_EVENT_END_TIME, end), v)
                }
            }
        }
        return if (hits.isEmpty()) null else SearchSection("calendar", "Calendar", 70, hits = hits, limit = 3)
    }
}

/**
 * The results screen inside the app drawer. Instant results appear as you type; contacts, calendar and shortcuts
 * join a moment later. With an empty query it shows suggested apps and recent searches.
 */
class SearchPanel(private val launcher: MainActivity, private val drawer: AppDrawer) : ScrollView(launcher) {
    val engine = SearchEngine(launcher)
    private val content = LinearLayout(launcher).apply { orientation = LinearLayout.VERTICAL }
    var query = ""
        private set
    private var suggestions = false
    private var gen = 0
    private var quick: List<SearchSection> = emptyList()
    private var slow: List<SearchSection> = emptyList()
    private var slowFor = ""
    private val expanded = HashSet<String>()
    val appIcons = ArrayList<IconView>()
    private var top: (() -> Unit)? = null
    private var touching = false
    private val slowTask = Runnable { runSlow() }

    private val textMain = Color.WHITE
    private val textDim = Color.argb(170, 255, 255, 255)
    private val cardColor = Color.argb(34, 255, 255, 255)
    private val pressColor = Color.argb(46, 255, 255, 255)

    init {
        isVerticalScrollBarEnabled = false
        overScrollMode = OVER_SCROLL_IF_CONTENT_SCROLLS
        clipToPadding = false
        isVerticalFadingEdgeEnabled = true
        setFadingEdgeLength(launcher.dpi(18))
        addView(content, flp(MATCH, WRAP))
        visibility = GONE
    }

    val isActive: Boolean get() = visibility == VISIBLE

    /** Shows results for [q], or suggestions when [q] is empty and [showSuggestions]. Returns whether visible. */
    fun update(q: String, showSuggestions: Boolean): Boolean {
        val nq = q.trim()
        if (nq != query) expanded.clear()
        query = nq
        suggestions = showSuggestions
        gen++
        removeCallbacks(slowTask)
        if (query.isEmpty()) {
            quick = emptyList(); slow = emptyList(); slowFor = ""
        } else {
            quick = engine.quick(query)
            if (slowFor.isEmpty() || !query.startsWith(slowFor, ignoreCase = true)) slow = emptyList()
            postDelayed(slowTask, 110)
        }
        render()
        val show = query.isNotEmpty() || (suggestions && content.childCount > 0)
        setShown(show)
        return show
    }

    fun refresh() { update(query, suggestions) }

    private fun runSlow() {
        val g = gen
        val q = query
        engine.slow(q) { res -> if (g == gen && isAttachedToWindow) { slow = res; slowFor = q; render() } }
    }

    private fun setShown(show: Boolean) {
        if (show == isActive) return
        if (show) {
            visibility = VISIBLE
            alpha = 0f; translationY = launcher.dp(10f)
            animate().alpha(1f).translationY(0f).setDuration(Motion.d(180)).setInterpolator(Motion.decel).start()
            scrollTo(0, 0)
        } else {
            animate().cancel()
            visibility = GONE
        }
    }

    /** Runs the best result (keyboard Search key). */
    fun runTop(): Boolean {
        val t = top ?: return false
        t(); return true
    }

    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN -> touching = true
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> touching = false
        }
        return super.dispatchTouchEvent(ev)
    }

    override fun onScrollChanged(l: Int, t: Int, oldl: Int, oldt: Int) {
        super.onScrollChanged(l, t, oldl, oldt)
        if (touching && abs(t - oldt) > 0) drawer.hideKeyboard()
    }

    private fun opened() {
        if (query.isNotEmpty()) launcher.prefs.addSearchHistory(query)
    }

    // ---- Rendering ----------------------------------------------------------------------------------------

    private fun render() {
        content.removeAllViews()
        appIcons.clear()
        top = null
        if (query.isEmpty()) { if (suggestions) renderSuggestions(); return }
        val sections = (quick + slow).sortedWith(Comparator { a, b -> a.priority - b.priority })
        val real = sections.filter { it.style != "web" && it.style != "prompt" }
        if (real.isEmpty()) {
            content.addView(launcher.textView("No apps, contacts or settings match “$query”", 14f, textDim, Fonts.medium, Gravity.CENTER).apply {
                setPadding(launcher.dpi(24), launcher.dpi(28), launcher.dpi(24), launcher.dpi(6))
            }, llp(MATCH, WRAP))
        }
        for (s in sections) when (s.style) {
            "apps" -> renderApps(s)
            "calc" -> renderCalc(s)
            "web" -> renderWeb()
            "prompt" -> renderPrompt()
            else -> renderList(s)
        }
        content.addView(privacyFooter(), llp(MATCH, WRAP))
    }

    private fun header(title: String, action: String? = null, onAction: (() -> Unit)? = null) {
        val row = LinearLayout(launcher).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(launcher.dpi(16), launcher.dpi(16), launcher.dpi(8), launcher.dpi(6))
        }
        row.addView(launcher.textView(title.uppercase(Locale.getDefault()), 11.5f, textDim, Fonts.semibold).apply { letterSpacing = 0.07f }, llp(0, WRAP, 1f))
        if (action != null && onAction != null) {
            row.addView(launcher.textView(action, 13f, Color.WHITE, Fonts.medium).apply {
                setPadding(launcher.dpi(10), launcher.dpi(4), launcher.dpi(10), launcher.dpi(4))
                background = pressable(null, pressColor, launcher.dp(12f))
                isClickable = true
                setOnClickListener { launcher.haptic(it, HapticFeedbackConstants.CONTEXT_CLICK); onAction() }
            })
        }
        content.addView(row, llp(MATCH, WRAP))
    }

    private fun card(): LinearLayout = LinearLayout(launcher).apply {
        orientation = LinearLayout.VERTICAL
        background = roundRect(cardColor, launcher.dp(22f))
        clipToOutline = true
    }

    private fun addCard(card: View) = content.addView(card, llp(MATCH, WRAP).apply { marginStart = launcher.dpi(6); marginEnd = launcher.dpi(6) })

    private fun renderApps(s: SearchSection) {
        val cols = launcher.prefs.drawerColumns.coerceIn(3, 6)
        val limit = if ("apps" in expanded) s.apps.size else cols * 2
        val list = s.apps.take(limit)
        header("Apps", if (s.apps.size > limit) "Show all ${s.apps.size}" else null) { expanded += "apps"; render() }
        list.chunked(cols).forEach { chunk ->
            val row = LinearLayout(launcher).apply { orientation = LinearLayout.HORIZONTAL }
            chunk.forEach { e ->
                val v = launcher.createAppIcon(e, IconView.SOURCE_DRAWER)
                v.darkLabel = false
                appIcons += v
                row.addView(v, llp(0, launcher.iconSizePx + launcher.dpi(42), 1f))
            }
            repeat(cols - chunk.size) { row.addView(View(launcher), llp(0, 1, 1f)) }
            content.addView(row, llp(MATCH, WRAP))
        }
        if (top == null) list.firstOrNull()?.let { e -> top = { opened(); launcher.launchApp(e, appIcons.firstOrNull(), IconView.SOURCE_DRAWER) } }
    }

    private fun renderCalc(s: SearchSection) {
        val h = s.hits.firstOrNull() ?: return
        header(s.title ?: "Calculator")
        val card = card()
        val row = LinearLayout(launcher).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(launcher.dpi(18), launcher.dpi(14), launcher.dpi(10), launcher.dpi(14))
            background = pressable(null, pressColor, 0f)
            isClickable = true
            contentDescription = "${h.subtitle} ${h.title}"
            setOnClickListener { launcher.haptic(it, HapticFeedbackConstants.CONTEXT_CLICK); opened(); h.open(it) }
        }
        val texts = LinearLayout(launcher).apply { orientation = LinearLayout.VERTICAL }
        texts.addView(launcher.textView(h.subtitle ?: "", 13.5f, textDim, maxLines = 1))
        texts.addView(launcher.textView(h.title, 30f, textMain, Fonts.semibold, maxLines = 1).apply { setPadding(0, launcher.dpi(4), 0, 0) })
        row.addView(texts, llp(0, WRAP, 1f))
        h.actions.forEach { a -> row.addView(actionButton(a), llp(launcher.dpi(42), launcher.dpi(42)).apply { marginStart = launcher.dpi(6) }) }
        card.addView(row)
        addCard(card)
        if (top == null) top = { opened(); h.open(this) }
    }

    private fun renderList(s: SearchSection) {
        if (s.hits.isEmpty()) return
        val all = s.id in expanded
        val limit = if (all) s.hits.size else s.limit
        header(s.title ?: "", if (s.hits.size > limit) "Show all ${s.hits.size}" else null) { expanded += s.id; render() }
        val card = card()
        s.hits.take(limit).forEachIndexed { i, h ->
            if (i > 0) card.addView(View(launcher).apply { setBackgroundColor(Color.argb(26, 255, 255, 255)) }, llp(MATCH, 1).apply { marginStart = launcher.dpi(66); marginEnd = launcher.dpi(14) })
            card.addView(row(h), llp(MATCH, WRAP))
        }
        addCard(card)
        if (top == null) s.hits.firstOrNull()?.let { h -> top = { opened(); h.open(this) } }
    }

    private fun row(h: SearchHit): View {
        val row = LinearLayout(launcher).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            minimumHeight = launcher.dpi(60)
            setPadding(launcher.dpi(14), launcher.dpi(8), launcher.dpi(8), launcher.dpi(8))
            background = pressable(null, pressColor, 0f)
            isClickable = true
            contentDescription = h.title
            setOnClickListener { launcher.haptic(it, HapticFeedbackConstants.CONTEXT_CLICK); opened(); h.open(it) }
        }
        row.addView(iconFor(h), llp(launcher.dpi(38), launcher.dpi(38)).apply { marginEnd = launcher.dpi(14) })
        val texts = LinearLayout(launcher).apply { orientation = LinearLayout.VERTICAL }
        texts.addView(launcher.textView(highlighted(h.title), 15.5f, Color.argb(235, 255, 255, 255), Fonts.medium, maxLines = 1))
        if (!h.subtitle.isNullOrEmpty()) texts.addView(launcher.textView(h.subtitle, 12.5f, textDim, maxLines = 1).apply { setPadding(0, launcher.dpi(3), 0, 0) })
        row.addView(texts, llp(0, WRAP, 1f))
        h.actions.forEach { a -> row.addView(actionButton(a), llp(launcher.dpi(40), launcher.dpi(40)).apply { marginStart = launcher.dpi(6) }) }
        return row
    }

    private fun actionButton(a: HitAction): View = launcher.iconImage(a.icon, Color.WHITE, 10).apply {
        background = pressable(oval(Color.argb(38, 255, 255, 255)), pressColor, launcher.dp(20f))
        isClickable = true
        contentDescription = a.label
        setOnClickListener { launcher.haptic(it, HapticFeedbackConstants.CONTEXT_CLICK); opened(); a.run(it) }
    }

    private fun iconFor(h: SearchHit): View {
        if (h.bitmap != null) return ImageView(launcher).apply { setImageBitmap(h.bitmap); scaleType = ImageView.ScaleType.FIT_CENTER }
        if (h.loadImage != null) return ImageView(launcher).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            background = roundRect(Color.argb(40, 255, 255, 255), launcher.dp(11f))
            clipToOutline = true
            h.loadImage.invoke(this)
        }
        if (h.avatar != null) return launcher.textView(h.avatar, 15f, Color.WHITE, Fonts.semibold, Gravity.CENTER).apply { background = oval(h.avatarColor) }
        val chip = FrameLayout(launcher).apply { background = roundRect(if (h.iconColor != 0) h.iconColor else Color.argb(60, 255, 255, 255), launcher.dp(11f)) }
        chip.addView(launcher.iconImage(if (h.icon != 0) h.icon else R.drawable.ic_search, Color.WHITE, 8), flp(MATCH, MATCH))
        return chip
    }

    private fun highlighted(title: String): CharSequence {
        val range = SearchText.highlight(title, SearchText.norm(query)) ?: return title
        val s = SpannableString(title)
        s.setSpan(ForegroundColorSpan(Color.WHITE), range.first, range.last + 1, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        if (android.os.Build.VERSION.SDK_INT >= 28) s.setSpan(TypefaceSpan(Fonts.bold), range.first, range.last + 1, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        return s
    }

    private fun chip(icon: Int, label: String, onClick: (View) -> Unit): View {
        val chip = LinearLayout(launcher).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(launcher.dpi(12), 0, launcher.dpi(16), 0)
            background = pressable(roundRect(cardColor, launcher.dp(19f)), pressColor, launcher.dp(19f))
            isClickable = true
            contentDescription = label
            setOnClickListener { launcher.haptic(it, HapticFeedbackConstants.CONTEXT_CLICK); onClick(it) }
        }
        chip.addView(launcher.iconImage(icon, Color.WHITE, 0), llp(launcher.dpi(17), launcher.dpi(17)).apply { marginEnd = launcher.dpi(8) })
        chip.addView(launcher.textView(label, 14f, Color.WHITE, Fonts.medium, maxLines = 1))
        return chip
    }

    private fun chipRow(chips: List<View>): View {
        val scroll = HorizontalScrollView(launcher).apply { isHorizontalScrollBarEnabled = false; overScrollMode = OVER_SCROLL_NEVER; clipToPadding = false }
        val row = LinearLayout(launcher).apply { orientation = LinearLayout.HORIZONTAL; setPadding(launcher.dpi(8), 0, launcher.dpi(8), 0) }
        chips.forEach { row.addView(it, llp(WRAP, launcher.dpi(38)).apply { marginEnd = launcher.dpi(8) }) }
        scroll.addView(row)
        return scroll
    }

    private fun renderWeb() {
        header("Search for “${query.take(24)}”")
        content.addView(chipRow(engine.webTargets.map { t -> chip(t.icon, t.label) { v -> opened(); t.open(query, v) } }), llp(MATCH, WRAP))
    }

    private fun renderPrompt() {
        val missing = engine.missingPermissions()
        if (missing.isEmpty()) return
        val names = missing.joinToString(" and ") { it.second }
        content.addView(View(launcher), llp(MATCH, launcher.dpi(14)))
        val card = card()
        val body = LinearLayout(launcher).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(launcher.dpi(16), launcher.dpi(14), launcher.dpi(12), launcher.dpi(12))
        }
        val chip = FrameLayout(launcher).apply { background = roundRect(Color.rgb(20, 150, 120), launcher.dp(11f)) }
        chip.addView(launcher.iconImage(R.drawable.ic_shield, Color.WHITE, 8), flp(MATCH, MATCH))
        body.addView(chip, llp(launcher.dpi(38), launcher.dpi(38)).apply { marginEnd = launcher.dpi(14) })
        val texts = LinearLayout(launcher).apply { orientation = LinearLayout.VERTICAL }
        texts.addView(launcher.textView("Also search your $names", 15.5f, Color.WHITE, Fonts.medium))
        texts.addView(launcher.textView("Searched only on this phone. Fluid One never shares your data with third parties.", 12.5f, textDim).apply {
            setPadding(0, launcher.dpi(3), 0, 0); setLineSpacing(launcher.dp(1.5f), 1f)
        })
        val buttons = LinearLayout(launcher).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.END; setPadding(0, launcher.dpi(10), 0, 0) }
        buttons.addView(launcher.textView("Not now", 14f, textDim, Fonts.medium, Gravity.CENTER).apply {
            setPadding(launcher.dpi(14), 0, launcher.dpi(14), 0)
            background = pressable(null, pressColor, launcher.dp(17f)); isClickable = true
            setOnClickListener { launcher.prefs.searchPromptDismissed = true; refresh() }
        }, llp(WRAP, launcher.dpi(34)))
        buttons.addView(launcher.textView("Allow", 14f, Color.WHITE, Fonts.semibold, Gravity.CENTER).apply {
            setPadding(launcher.dpi(18), 0, launcher.dpi(18), 0)
            background = pressable(roundRect(launcher.prefs.accent, launcher.dp(17f)), pressColor, launcher.dp(17f)); isClickable = true
            contentDescription = "Allow search access"
            setOnClickListener {
                drawer.hideKeyboard()
                launcher.requestWithPrivacy(missing, "Find people and events right from the search bar.") { refresh() }
            }
        }, llp(WRAP, launcher.dpi(34)).apply { marginStart = launcher.dpi(6) })
        texts.addView(buttons, llp(MATCH, WRAP))
        body.addView(texts, llp(0, WRAP, 1f))
        card.addView(body)
        addCard(card)
    }

    private fun privacyFooter(): View {
        val row = LinearLayout(launcher).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(launcher.dpi(16), launcher.dpi(22), launcher.dpi(16), launcher.dpi(8))
        }
        row.addView(launcher.iconImage(R.drawable.ic_shield, Color.argb(130, 255, 255, 255), 0), llp(launcher.dpi(13), launcher.dpi(13)).apply { marginEnd = launcher.dpi(6) })
        row.addView(launcher.textView("Searched on this phone only", 11.5f, Color.argb(130, 255, 255, 255)))
        return row
    }

    private fun renderSuggestions() {
        val p = launcher.prefs
        if (p.searchSuggest) {
            val cols = p.drawerColumns.coerceIn(3, 6)
            val apps = engine.suggestedApps(cols)
            if (apps.isNotEmpty()) {
                header("Suggested")
                val row = LinearLayout(launcher).apply { orientation = LinearLayout.HORIZONTAL }
                apps.forEach { e ->
                    val v = launcher.createAppIcon(e, IconView.SOURCE_DRAWER)
                    v.darkLabel = false
                    appIcons += v
                    row.addView(v, llp(0, launcher.iconSizePx + launcher.dpi(42), 1f))
                }
                repeat(cols - apps.size) { row.addView(View(launcher), llp(0, 1, 1f)) }
                content.addView(row, llp(MATCH, WRAP))
            }
        }
        val history = if (p.searchKeepHistory) p.searchHistory else emptyList()
        if (history.isNotEmpty()) {
            header("Recent searches", "Clear") { p.searchHistory = emptyList(); refresh() }
            content.addView(chipRow(history.map { h -> chip(R.drawable.ic_history, h) { drawer.setQuery(h) } }), llp(MATCH, WRAP))
        }
        val tries = listOf("Wi-Fi", "12*7", "10 km to mi", "timer 5 min").filter { t ->
            when (t) { "12*7", "10 km to mi" -> p.searchCalc; "timer 5 min" -> p.searchActions; else -> p.searchSettings }
        }
        if (tries.isNotEmpty()) {
            header("Try")
            content.addView(chipRow(tries.map { t -> chip(R.drawable.ic_search, t) { drawer.setQuery(t) } }), llp(MATCH, WRAP))
        }
        if (content.childCount > 0) content.addView(privacyFooter(), llp(MATCH, WRAP))
    }

    override fun onDetachedFromWindow() {
        removeCallbacks(slowTask)
        super.onDetachedFromWindow()
    }
}
