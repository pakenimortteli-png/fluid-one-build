package com.fluidone.launcher

import android.content.ComponentName
import android.content.pm.ApplicationInfo
import android.content.pm.LauncherActivityInfo
import android.content.pm.LauncherApps
import android.os.Process
import android.os.UserHandle
import java.text.Collator
import java.util.Locale

/** An installed, launchable activity. */
class AppEntry(val info: LauncherActivityInfo) {
    val component: ComponentName = info.componentName
    val user: UserHandle = info.user
    val packageName: String = component.packageName
    val key: String = keyFor(component, user)
    val systemLabel: String = info.label?.toString()?.trim().orEmpty().ifEmpty { packageName }
    val isSystemApp: Boolean = (info.applicationInfo.flags and ApplicationInfo.FLAG_SYSTEM) != 0 &&
        (info.applicationInfo.flags and ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) == 0
    val isWorkProfile: Boolean = user != Process.myUserHandle()

    companion object {
        fun keyFor(component: ComponentName, user: UserHandle): String = "${user.hashCode()}|${component.flattenToShortString()}"
    }
}

/** Installed-app discovery through LauncherApps, including work profiles. */
class AppRepository(private val launcherApps: LauncherApps, private val prefs: LauncherPrefs, private val selfPackage: String) {
    var apps: List<AppEntry> = emptyList()
        private set
    private val byKey = HashMap<String, AppEntry>()
    private val collator: Collator = Collator.getInstance(Locale.getDefault()).apply { strength = Collator.PRIMARY }

    fun refresh() {
        val found = try {
            launcherApps.profiles.flatMap { profile -> launcherApps.getActivityList(null, profile) ?: emptyList() }
                .filter { it.componentName.packageName != selfPackage }
                .map { AppEntry(it) }
                .distinctBy { it.key }
        } catch (_: Exception) { emptyList() }
        byKey.clear()
        found.forEach { byKey[it.key] = it }
        apps = found.sortedWith { a, b -> collator.compare(label(a), label(b)) }
    }

    operator fun get(key: String): AppEntry? = byKey[key]

    fun contains(key: String) = byKey.containsKey(key)

    fun label(entry: AppEntry): String = prefs.customLabel(entry.key) ?: entry.systemLabel

    fun drawerApps(): List<AppEntry> {
        val hidden = prefs.hiddenApps
        return apps.filter { it.key !in hidden }
    }

    fun forPackage(pkg: String): List<AppEntry> = apps.filter { it.packageName == pkg }

    /** First installed app matching any package (in order) or, failing that, any label hint. */
    fun pick(packages: List<String>, labelHints: List<String> = emptyList(), exclude: Set<String> = emptySet()): AppEntry? {
        for (pkg in packages) apps.firstOrNull { it.packageName == pkg && it.key !in exclude && !it.isWorkProfile }?.let { return it }
        for (hint in labelHints) apps.firstOrNull {
            it.key !in exclude && !it.isWorkProfile && it.systemLabel.lowercase(Locale.ROOT).contains(hint)
        }?.let { return it }
        return null
    }

    /** Section letter used by the drawer's alphabet index. */
    fun sectionOf(entry: AppEntry): String {
        val c = label(entry).trim().firstOrNull() ?: return "#"
        return if (c.isLetter()) c.uppercaseChar().toString() else "#"
    }
}
