package com.fluidone.launcher

import android.graphics.Bitmap
import android.graphics.BlurMaskFilter
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * Renders [GlassShape]s into a wallpaper on the CPU, using the same optics as the Fluid Glass shader:
 * a curved rim that bends what lies around it, a slightly magnified centre, a touch of blur, slight dispersion,
 * a crisp rim of light with a thin inner shadow line, and a soft shadow. Safe on a background thread.
 */
object GlassRender {
    private const val LIGHT_X = -0.55f
    private const val LIGHT_Y = -0.835f

    fun draw(out: Bitmap, c: Canvas, s: GlassShape) {
        val w = out.width
        val h = out.height
        val cx = s.x * w
        val cy = s.y * h
        val hw = s.w * w / 2f
        val hh = s.h * w / 2f
        val short = min(hw, hh)
        if (short < 2f) return
        val r = (s.corner.coerceIn(0f, 1f) * short)
        val rad = Math.toRadians(s.angle.toDouble())
        val ca = cos(rad).toFloat()
        val sa = sin(rad).toFloat()

        // Soft contact shadow, a little below the glass.
        if (s.shadow > 0f) {
            val sp = Paint(Paint.ANTI_ALIAS_FLAG)
            sp.color = Color.argb((s.shadow * 255).roundToInt().coerceIn(0, 255), 0, 0, 0)
            sp.maskFilter = BlurMaskFilter(max(2f, short * 0.32f), BlurMaskFilter.Blur.NORMAL)
            val save = c.save()
            c.translate(cx, cy + short * 0.16f)
            c.rotate(s.angle)
            c.drawRoundRect(-hw * 0.96f, -hh * 0.96f, hw * 0.96f, hh * 0.96f, r, r, sp)
            c.restoreToCount(save)
        }
        if (Color.alpha(s.solid) > 0) {
            val sp = Paint(Paint.ANTI_ALIAS_FLAG)
            sp.color = s.solid
            val save = c.save()
            c.translate(cx, cy); c.rotate(s.angle)
            c.drawRoundRect(-hw, -hh, hw, hh, r, r, sp)
            c.restoreToCount(save)
            return
        }

        // Pixel bounds of the rotated shape.
        val ex = abs(hw * ca) + abs(hh * sa)
        val ey = abs(hw * sa) + abs(hh * ca)
        val left = max(0, floor(cx - ex - 2).toInt())
        val top = max(0, floor(cy - ey - 2).toInt())
        val right = min(w, ceil(cx + ex + 2).toInt())
        val bottom = min(h, ceil(cy + ey + 2).toInt())
        if (right <= left || bottom <= top) return

        // Same optics as the Fluid Glass shader, at the wallpaper's own scale (unit ~ 1 dp).
        val unit = w / 390f
        val bevel = max(2f, s.bevel.coerceIn(0.05f, 1f) * short)
        val rn = min(max(r, bevel), short)
        val refraction = bevel * 0.62f
        val blurR = 1.5f * unit
        val rimW = 1.25f * unit

        // Source region, padded so refracted lookups stay inside it.
        val pad = (refraction + blurR * 3f + 4f).toInt()
        val sl = max(0, left - pad); val st = max(0, top - pad)
        val sr = min(w, right + pad); val sb = min(h, bottom + pad)
        val sw = sr - sl; val sh = sb - st
        val src = IntArray(sw * sh)
        out.getPixels(src, 0, sw, sl, st, sw, sh)
        val frosted: IntArray? = if (s.frost > 0f) {
            val region = Bitmap.createBitmap(src, sw, sh, Bitmap.Config.ARGB_8888)
            val radius = max(2, (short * 0.05f).roundToInt()).coerceAtMost(24)
            val small = BlurEngine.blur(region, 0.25f, radius)
            val big = Bitmap.createScaledBitmap(small, sw, sh, true)
            val px = IntArray(sw * sh); big.getPixels(px, 0, sw, 0, 0, sw, sh)
            region.recycle(); if (small !== big) small.recycle(); big.recycle()
            px
        } else null

        val bw = right - left
        val bh = bottom - top
        val dst = IntArray(bw * bh)
        out.getPixels(dst, 0, bw, left, top, bw, bh)

        val tintA = Color.alpha(s.tint) / 255f
        val tintR = Color.red(s.tint) / 255f
        val tintG = Color.green(s.tint) / 255f
        val tintB = Color.blue(s.tint) / 255f
        val rgb = FloatArray(3)
        val acc = FloatArray(3)
        val bd = blurR * 0.7071f

        for (py in top until bottom) {
            for (px in left until right) {
                val gx = px + 0.5f - cx
                val gy = py + 0.5f - cy
                // Into the shape's own (unrotated) frame.
                val lx = gx * ca + gy * sa
                val ly = -gx * sa + gy * ca
                val d = sd(lx, ly, hw, hh, r)
                if (d > 0.5f) continue
                // Normal from a rounder twin of the shape: a smooth, crease-free surface.
                var nlx = sd(lx + 1f, ly, hw, hh, rn) - sd(lx - 1f, ly, hw, hh, rn)
                var nly = sd(lx, ly + 1f, hw, hh, rn) - sd(lx, ly - 1f, hw, hh, rn)
                val nl = sqrt(nlx * nlx + nly * nly).coerceAtLeast(1e-5f)
                nlx /= nl; nly /= nl
                val nx = nlx * ca - nly * sa
                val ny = nlx * sa + nly * ca
                val dn = sd(lx, ly, hw, hh, rn)

                val k = (1f + dn / bevel).coerceIn(0f, 1f)
                val f = k * k * (0.55f + 0.45f * k)
                val shift = refraction * f
                val bx = cx + gx * 0.93f + nx * shift - sl
                val by = cy + gy * 0.93f + ny * shift - st
                // A touch of blur, a little more on the curve.
                val br = blurR * (1f + 1.6f * f)
                val bdr = bd * (1f + 1.6f * f)
                sample(src, sw, sh, bx, by, rgb); acc[0] = rgb[0] * 0.2f; acc[1] = rgb[1] * 0.2f; acc[2] = rgb[2] * 0.2f
                sample(src, sw, sh, bx + bdr, by + bdr, rgb); acc[0] += rgb[0] * 0.2f; acc[1] += rgb[1] * 0.2f; acc[2] += rgb[2] * 0.2f
                sample(src, sw, sh, bx - bdr, by - bdr, rgb); acc[0] += rgb[0] * 0.2f; acc[1] += rgb[1] * 0.2f; acc[2] += rgb[2] * 0.2f
                sample(src, sw, sh, bx + br, by - bdr * 0.4f, rgb); acc[0] += rgb[0] * 0.2f; acc[1] += rgb[1] * 0.2f; acc[2] += rgb[2] * 0.2f
                sample(src, sw, sh, bx - br, by + bdr * 0.4f, rgb); acc[0] += rgb[0] * 0.2f; acc[1] += rgb[1] * 0.2f; acc[2] += rgb[2] * 0.2f
                var red = acc[0]; var green = acc[1]; var blue = acc[2]
                // Slight dispersion on the curve.
                val spread = min(shift * 0.035f, 1.2f * unit)
                val edge = min(1f, f * 1.2f) * 0.8f
                if (edge > 0.01f) {
                    sample(src, sw, sh, bx + nx * spread, by + ny * spread, rgb); red += (rgb[0] - red) * edge
                    sample(src, sw, sh, bx - nx * spread, by - ny * spread, rgb); blue += (rgb[2] - blue) * edge
                }
                if (frosted != null) {
                    sample(frosted, sw, sh, px + 0.5f - sl + nx * shift * 0.5f, py + 0.5f - st + ny * shift * 0.5f, rgb)
                    val l = rgb[0] * 0.2126f + rgb[1] * 0.7152f + rgb[2] * 0.0722f
                    val fr = l + (rgb[0] - l) * 1.25f; val fg = l + (rgb[1] - l) * 1.25f; val fb = l + (rgb[2] - l) * 1.25f
                    val fa = s.frost * (1f - 0.3f * f)
                    red += (fr - red) * fa; green += (fg - green) * fa; blue += (fb - blue) * fa
                }
                if (tintA > 0f) {
                    red += (tintR - red) * tintA; green += (tintG - green) * tintA; blue += (tintB - blue) * tintA
                }
                // Glass is a material: a faint even haze.
                red = red * 0.95f + 0.035f; green = green * 0.95f + 0.035f; blue = blue * 0.95f + 0.035f

                // Crisp rim of light (brightest facing the light and at the opposite corner) and a thin shadow
                // line just inside it for thickness. No broad highlights.
                val facing = nx * LIGHT_X + ny * LIGHT_Y
                val glint = facing * facing
                val rimBand = ((d + rimW + 0.5f) / rimW).coerceIn(0f, 1f)
                val lum = red * 0.2126f + green * 0.7152f + blue * 0.0722f
                val bright = smooth(0.62f, 0.95f, lum)
                val rim = rimBand * (0.22f + 0.68f * glint) * (1f - 0.7f * bright)
                red += (1f - red) * rim; green += (1f - green) * rim; blue += (1f - blue) * rim
                val grey = 1f - rimBand * bright * (0.16f + 0.14f * (1f - glint))
                red *= grey; green *= grey; blue *= grey
                val inner = (d + 2.6f * unit) / (1.2f * unit)
                val shade = 1f - exp(-inner * inner) * (1f - 0.7f * glint) * 0.12f
                red *= shade; green *= shade; blue *= shade

                val a = (0.5f - d).coerceIn(0f, 1f)
                val i = (py - top) * bw + (px - left)
                val o = dst[i]
                val oR = Color.red(o) / 255f; val oG = Color.green(o) / 255f; val oB = Color.blue(o) / 255f
                dst[i] = Color.rgb(
                    ((oR + (red.coerceIn(0f, 1f) - oR) * a) * 255f).roundToInt().coerceIn(0, 255),
                    ((oG + (green.coerceIn(0f, 1f) - oG) * a) * 255f).roundToInt().coerceIn(0, 255),
                    ((oB + (blue.coerceIn(0f, 1f) - oB) * a) * 255f).roundToInt().coerceIn(0, 255)
                )
            }
        }
        out.setPixels(dst, 0, bw, left, top, bw, bh)
    }

    /** Signed distance to a rounded rectangle with half size (bx, by) and corner radius r. */
    private fun sd(x: Float, y: Float, bx: Float, by: Float, r: Float): Float {
        val qx = abs(x) - bx + r
        val qy = abs(y) - by + r
        val ox = max(qx, 0f); val oy = max(qy, 0f)
        return min(max(qx, qy), 0f) + sqrt(ox * ox + oy * oy) - r
    }

    /** Bilinear lookup, clamped to the buffer, into [out] as 0..1 floats. */
    private fun sample(px: IntArray, w: Int, h: Int, x: Float, y: Float, out: FloatArray) {
        val fx = (x - 0.5f).coerceIn(0f, (w - 1).toFloat())
        val fy = (y - 0.5f).coerceIn(0f, (h - 1).toFloat())
        val x0 = fx.toInt(); val y0 = fy.toInt()
        val x1 = min(x0 + 1, w - 1); val y1 = min(y0 + 1, h - 1)
        val tx = fx - x0; val ty = fy - y0
        val c00 = px[y0 * w + x0]; val c10 = px[y0 * w + x1]
        val c01 = px[y1 * w + x0]; val c11 = px[y1 * w + x1]
        for (ch in 0 until 3) {
            val shift = 16 - ch * 8
            val a = ((c00 shr shift) and 0xFF).toFloat()
            val b = ((c10 shr shift) and 0xFF).toFloat()
            val c = ((c01 shr shift) and 0xFF).toFloat()
            val d = ((c11 shr shift) and 0xFF).toFloat()
            val top = a + (b - a) * tx
            val bot = c + (d - c) * tx
            out[ch] = (top + (bot - top) * ty) / 255f
        }
    }

    private fun smooth(e0: Float, e1: Float, x: Float): Float {
        val t = ((x - e0) / (e1 - e0)).coerceIn(0f, 1f)
        return t * t * (3 - 2 * t)
    }
}
