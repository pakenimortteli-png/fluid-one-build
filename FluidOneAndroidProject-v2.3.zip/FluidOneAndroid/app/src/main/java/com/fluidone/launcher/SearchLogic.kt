package com.fluidone.launcher

import android.graphics.Color
import java.math.BigDecimal
import java.math.MathContext
import java.text.Normalizer
import java.util.Locale
import kotlin.math.abs
import kotlin.math.ln
import kotlin.math.log10
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sqrt

/** Text helpers shared by every search source. */
object SearchText {
    private val marks = Regex("\\p{Mn}+")
    private val splitter = Regex("[\\s\\-_.:/&+,()]+")

    /** Lower case without accents, so "cafe" finds "Café". */
    fun norm(s: String): String = marks.replace(Normalizer.normalize(s.lowercase(Locale.getDefault()), Normalizer.Form.NFD), "")

    /** Words of a label, also splitting CamelCase ("WhatsApp" → whats, app). */
    fun words(label: String): List<String> {
        val camel = StringBuilder()
        for (i in label.indices) {
            val c = label[i]
            if (i > 0 && c.isUpperCase() && label[i - 1].isLowerCase()) camel.append(' ')
            camel.append(c)
        }
        return norm(camel.toString()).split(splitter).filter { it.isNotEmpty() }
    }

    /**
     * How well [q] (already normalised) matches [label]: 0 = no match. Exact > prefix > word prefix > initials >
     * contains > in-order letters > one typo.
     */
    fun score(label: String, q: String, extra: String? = null): Int {
        if (q.isEmpty()) return 0
        val l = norm(label)
        if (l == q) return 1000
        if (l.startsWith(q)) return 900
        val w = words(label)
        if (w.any { it.startsWith(q) }) return 800
        if (q.length >= 2 && w.size >= 2 && w.joinToString("") { it.take(1) }.startsWith(q)) return 720
        if (l.contains(q)) return 600
        if (extra != null && q.length >= 3 && norm(extra).contains(q)) return 420
        if (q.length >= 3 && isSubsequence(q, l.replace(" ", "")) && q.length * 2 >= min(l.length, 12)) return 320
        if (q.length >= 4 && w.any { typo(q, it) }) return 260
        return 0
    }

    private fun isSubsequence(q: String, s: String): Boolean {
        var i = 0
        for (c in s) { if (i < q.length && q[i] == c) i++ }
        return i == q.length && s.isNotEmpty() && s[0] == q[0]
    }

    /** One wrong, missing or extra letter compared with the start of [word] (two for long queries). */
    private fun typo(q: String, word: String): Boolean {
        val allowed = if (q.length >= 7) 2 else 1
        for (len in max(1, q.length - 1)..min(word.length, q.length + 1)) {
            if (distance(q, word.substring(0, len), allowed) <= allowed) return true
        }
        return false
    }

    private fun distance(a: String, b: String, cap: Int): Int {
        if (abs(a.length - b.length) > cap) return cap + 1
        var prev = IntArray(b.length + 1) { it }
        var cur = IntArray(b.length + 1)
        for (i in 1..a.length) {
            cur[0] = i
            var best = cur[0]
            for (j in 1..b.length) {
                val cost = if (a[i - 1] == b[j - 1]) 0 else 1
                cur[j] = min(min(cur[j - 1] + 1, prev[j] + 1), prev[j - 1] + cost)
                if (cur[j] < best) best = cur[j]
            }
            if (best > cap) return cap + 1
            val t = prev; prev = cur; cur = t
        }
        return prev[b.length]
    }

    /** Start/end of the visible match of [q] in [label] for highlighting, or null. */
    fun highlight(label: String, q: String): IntRange? {
        if (q.isEmpty()) return null
        val l = norm(label)
        if (l.length != label.length) return null
        val idx = l.indexOf(q)
        if (idx >= 0) return idx until idx + q.length
        return null
    }

    fun formatNumber(v: Double, digits: Int = 10): String {
        if (v.isNaN() || v.isInfinite()) return "—"
        if (v == 0.0) return "0"
        val a = abs(v)
        if (a >= 1e15 || a < 1e-7) return String.format(Locale.US, "%.6e", v).replace(Regex("\\.?0+e"), "e")
        return BigDecimal(v).round(MathContext(digits)).stripTrailingZeros().toPlainString()
    }
}

/** A small, safe calculator: + − × ÷ ^ %, brackets, √, sin/cos/tan (degrees), log, ln, π, e, n!. */
object Calc {
    private val phoneLike = Regex("^\\+?[0-9][0-9 \\-]{6,}$")
    private val hasOperator = Regex("[0-9)πe.]\\s*[-+*/×÷x^%]\\s*[-+(0-9πe.√a-z]|[0-9)]\\s*!|√|\\b(sqrt|sin|cos|tan|log|ln)\\s*\\(?|[0-9]\\s*%")

    fun looksLikeMath(q: String): Boolean {
        val s = q.trim().lowercase(Locale.ROOT).removeSuffix("=").trim()
        if (s.length < 2 || phoneLike.matches(s)) return false
        if (!s.any { it.isDigit() } && !s.contains("pi") && !s.contains('π')) return false
        if (s.any { it.isLetter() && it !in "xepisqrtcongalπ" }) return false
        return hasOperator.containsMatchIn(s)
    }

    fun eval(q: String): Double? = try {
        val v = Parser(normalize(q)).parse()
        if (v.isNaN() || v.isInfinite()) null else v
    } catch (_: Exception) { null }

    private fun normalize(q: String): String {
        var s = q.trim().lowercase(Locale.ROOT).removeSuffix("=")
        s = s.replace('×', '*').replace('÷', '/').replace('−', '-').replace("π", "pi").replace("√", "sqrt")
        s = s.replace(Regex("(?<=[0-9)])\\s*x\\s*(?=[0-9(])"), "*")
        if (s.contains(',') && !s.contains('.')) s = s.replace(',', '.') else s = s.replace(",", "")
        return s.replace(" ", "")
    }

    private class Parser(val s: String) {
        var i = 0
        fun parse(): Double {
            val v = expr()
            if (i != s.length) throw IllegalArgumentException("trailing")
            return v
        }
        private fun peek(): Char = if (i < s.length) s[i] else '\u0000'
        private fun eat(c: Char): Boolean { if (peek() == c) { i++; return true }; return false }
        private fun expr(): Double {
            var v = term()
            while (true) v = when {
                eat('+') -> v + term()
                eat('-') -> v - term()
                else -> return v
            }
        }
        private fun term(): Double {
            var v = power()
            while (true) v = when {
                eat('*') -> v * power()
                eat('/') -> { val d = power(); if (d == 0.0) throw ArithmeticException(); v / d }
                peek() == '(' || peek().isLetter() -> v * power()   // implicit: 2(3+4), 2pi
                else -> return v
            }
        }
        private fun power(): Double {
            val base = unary()
            return if (eat('^')) base.pow(power()) else base
        }
        private fun unary(): Double = when {
            eat('-') -> -unary()
            eat('+') -> unary()
            else -> postfix()
        }
        private fun postfix(): Double {
            var v = primary()
            while (true) {
                if (eat('%')) v /= 100.0
                else if (eat('!')) v = factorial(v)
                else return v
            }
        }
        private fun factorial(v: Double): Double {
            if (v < 0 || v > 170 || v != Math.floor(v)) throw ArithmeticException()
            var r = 1.0; var k = 2
            while (k <= v) { r *= k; k++ }
            return r
        }
        private fun primary(): Double {
            if (eat('(')) { val v = expr(); eat(')'); return v }
            val start = i
            if (peek().isDigit() || peek() == '.') {
                while (peek().isDigit() || peek() == '.') i++
                if (peek() == 'e' && i + 1 < s.length && (s[i + 1].isDigit() || s[i + 1] == '-')) {
                    i++; if (peek() == '-') i++
                    while (peek().isDigit()) i++
                }
                return s.substring(start, i).toDouble()
            }
            while (peek().isLetter()) i++
            val name = s.substring(start, i)
            return when (name) {
                "pi" -> Math.PI
                "e" -> Math.E
                "sqrt" -> sqrt(arg())
                "sin" -> Math.sin(Math.toRadians(arg()))
                "cos" -> Math.cos(Math.toRadians(arg()))
                "tan" -> Math.tan(Math.toRadians(arg()))
                "log" -> log10(arg())
                "ln" -> ln(arg())
                else -> throw IllegalArgumentException(name)
            }
        }
        private fun arg(): Double = if (eat('(')) { val v = expr(); eat(')'); v } else unary()
    }
}

/** "10 km", "5 ft to cm", "72 f in c", "2 cups = ml". */
object Units {
    class UnitDef(val cat: String, val factor: Double, val label: String, vararg names: String) { val names = names.toList() }

    private val all = listOf(
        UnitDef("Length", 0.001, "mm", "mm", "millimeter", "millimeters", "millimetre", "millimetres"),
        UnitDef("Length", 0.01, "cm", "cm", "centimeter", "centimeters", "centimetre", "centimetres"),
        UnitDef("Length", 1.0, "m", "m", "meter", "meters", "metre", "metres"),
        UnitDef("Length", 1000.0, "km", "km", "kilometer", "kilometers", "kilometre", "kilometres"),
        UnitDef("Length", 0.0254, "in", "in", "inch", "inches", "\""),
        UnitDef("Length", 0.3048, "ft", "ft", "foot", "feet", "'"),
        UnitDef("Length", 0.9144, "yd", "yd", "yard", "yards"),
        UnitDef("Length", 1609.344, "mi", "mi", "mile", "miles"),
        UnitDef("Weight", 1e-6, "mg", "mg", "milligram", "milligrams"),
        UnitDef("Weight", 0.001, "g", "g", "gram", "grams", "gr"),
        UnitDef("Weight", 1.0, "kg", "kg", "kilo", "kilos", "kilogram", "kilograms"),
        UnitDef("Weight", 1000.0, "t", "t", "tonne", "tonnes", "ton", "tons"),
        UnitDef("Weight", 0.028349523125, "oz", "oz", "ounce", "ounces"),
        UnitDef("Weight", 0.45359237, "lb", "lb", "lbs", "pound", "pounds"),
        UnitDef("Weight", 6.35029318, "st", "st", "stone", "stones"),
        UnitDef("Volume", 0.001, "ml", "ml", "milliliter", "milliliters", "millilitre", "millilitres"),
        UnitDef("Volume", 0.01, "cl", "cl"),
        UnitDef("Volume", 0.1, "dl", "dl"),
        UnitDef("Volume", 1.0, "L", "l", "liter", "liters", "litre", "litres"),
        UnitDef("Volume", 3.785411784, "gal", "gal", "gallon", "gallons"),
        UnitDef("Volume", 0.946352946, "qt", "qt", "quart", "quarts"),
        UnitDef("Volume", 0.473176473, "pt", "pt", "pint", "pints"),
        UnitDef("Volume", 0.2365882365, "cups", "cup", "cups"),
        UnitDef("Volume", 0.0295735295625, "fl oz", "floz", "fluidounce", "fluidounces"),
        UnitDef("Speed", 1 / 3.6, "km/h", "km/h", "kmh", "kph", "kmph"),
        UnitDef("Speed", 0.44704, "mph", "mph", "mi/h"),
        UnitDef("Speed", 1.0, "m/s", "m/s", "mps"),
        UnitDef("Speed", 0.514444, "kn", "kn", "knot", "knots"),
        UnitDef("Data", 1.0, "B", "b", "byte", "bytes"),
        UnitDef("Data", 1e3, "KB", "kb", "kilobyte", "kilobytes"),
        UnitDef("Data", 1e6, "MB", "mb", "megabyte", "megabytes"),
        UnitDef("Data", 1e9, "GB", "gb", "gigabyte", "gigabytes"),
        UnitDef("Data", 1e12, "TB", "tb", "terabyte", "terabytes"),
        UnitDef("Time", 1.0, "s", "s", "sec", "secs", "second", "seconds"),
        UnitDef("Time", 60.0, "min", "min", "mins", "minute", "minutes"),
        UnitDef("Time", 3600.0, "h", "h", "hr", "hrs", "hour", "hours"),
        UnitDef("Time", 86400.0, "days", "d", "day", "days"),
        UnitDef("Time", 604800.0, "weeks", "wk", "week", "weeks"),
        UnitDef("Temperature", 0.0, "°C", "c", "°c", "celsius", "centigrade"),
        UnitDef("Temperature", 0.0, "°F", "f", "°f", "fahrenheit"),
        UnitDef("Temperature", 0.0, "K", "k", "kelvin")
    )
    private val byName = HashMap<String, UnitDef>().apply { all.forEach { u -> u.names.forEach { put(it, u) } } }
    private val defaults = mapOf(
        "km" to "mi", "mi" to "km", "m" to "ft", "ft" to "m", "cm" to "in", "in" to "cm", "mm" to "in", "yd" to "m",
        "kg" to "lb", "lb" to "kg", "g" to "oz", "oz" to "g", "st" to "kg", "t" to "lb", "mg" to "g",
        "L" to "gal", "gal" to "L", "ml" to "fl oz", "fl oz" to "ml", "cups" to "ml", "pt" to "L", "qt" to "L", "cl" to "ml", "dl" to "ml",
        "km/h" to "mph", "mph" to "km/h", "m/s" to "km/h", "kn" to "km/h",
        "°C" to "°F", "°F" to "°C", "K" to "°C",
        "B" to "KB", "KB" to "MB", "MB" to "GB", "GB" to "MB", "TB" to "GB",
        "s" to "min", "min" to "s", "h" to "min", "days" to "h", "weeks" to "days"
    )
    private val number = Regex("^(-?[0-9]+(?:[.,][0-9]+)?)\\s*(.+)$")
    private val separators = listOf(" to ", " in ", " into ", "=", "->", "→", " as ")

    class Result(val category: String, val from: String, val to: String, val value: Double)

    fun convert(query: String): Result? {
        val m = number.matchEntire(query.trim().lowercase(Locale.ROOT)) ?: return null
        val amount = m.groupValues[1].replace(',', '.').toDoubleOrNull() ?: return null
        var rest = " " + m.groupValues[2].trim() + " "
        var target: String? = null
        for (sep in separators) {
            val idx = rest.lastIndexOf(sep)
            if (idx > 0) {
                target = rest.substring(idx + sep.length).trim()
                rest = rest.substring(0, idx)
                break
            }
        }
        val from = byName[key(rest)] ?: return null
        val to = if (target != null) byName[key(target)] ?: return null else byName[key(defaults[from.label] ?: return null)] ?: return null
        if (to.cat != from.cat || to === from) return null
        val value = if (from.cat == "Temperature") temperature(amount, from.label, to.label) else amount * from.factor / to.factor
        return Result(from.cat, "${SearchText.formatNumber(amount, 8)} ${from.label}", "${SearchText.formatNumber(value, 6)} ${to.label}", value)
    }

    private fun key(s: String) = s.trim().replace(" ", "").lowercase(Locale.ROOT)

    private fun temperature(v: Double, from: String, to: String): Double {
        val c = when (from) { "°F" -> (v - 32) * 5 / 9; "K" -> v - 273.15; else -> v }
        return when (to) { "°F" -> c * 9 / 5 + 32; "K" -> c + 273.15; else -> c }
    }
}

/** An Android system settings screen that can be found by search. */
class SystemSetting(val title: String, val keywords: String, val actions: List<String>, val color: Int)

/** A Fluid One setting that opens one of its own settings pages. */
class LauncherSetting(val title: String, val keywords: String, val page: String, val icon: Int, val color: Int)

object SearchCatalog {
    private val blue = Color.rgb(47, 123, 246)
    private val green = Color.rgb(36, 186, 104)
    private val orange = Color.rgb(255, 140, 40)
    private val purple = Color.rgb(132, 94, 247)
    private val red = Color.rgb(242, 80, 90)
    private val grey = Color.rgb(110, 118, 134)
    private val teal = Color.rgb(24, 168, 172)

    val system = listOf(
        SystemSetting("Wi-Fi", "wifi wi-fi wlan wireless internet network hotspot", listOf("android.settings.WIFI_SETTINGS"), blue),
        SystemSetting("Internet panel", "internet mobile data wifi connection quick panel", listOf("android.settings.panel.action.INTERNET_CONNECTIVITY", "android.settings.WIRELESS_SETTINGS"), blue),
        SystemSetting("Bluetooth", "bluetooth headphones earbuds pair devices", listOf("android.settings.BLUETOOTH_SETTINGS"), blue),
        SystemSetting("Connections", "mobile network sim data roaming connections", listOf("android.settings.WIRELESS_SETTINGS"), blue),
        SystemSetting("Airplane mode", "airplane aeroplane flight mode offline", listOf("android.settings.AIRPLANE_MODE_SETTINGS"), blue),
        SystemSetting("Mobile hotspot", "hotspot tethering share internet", listOf("android.settings.TETHER_SETTINGS", "android.settings.WIRELESS_SETTINGS"), blue),
        SystemSetting("Data usage", "data usage mobile data limit", listOf("android.settings.DATA_USAGE_SETTINGS", "android.settings.WIRELESS_SETTINGS"), blue),
        SystemSetting("NFC & payments", "nfc contactless tap pay payments wallet", listOf("android.settings.NFC_SETTINGS"), blue),
        SystemSetting("VPN", "vpn private network", listOf("android.settings.VPN_SETTINGS"), blue),
        SystemSetting("Display", "display screen brightness dark mode refresh rate font size resolution", listOf("android.settings.DISPLAY_SETTINGS"), orange),
        SystemSetting("Night light / Eye comfort", "eye comfort shield night light blue light filter", listOf("android.settings.NIGHT_DISPLAY_SETTINGS", "android.settings.DISPLAY_SETTINGS"), orange),
        SystemSetting("Sounds & vibration", "sound sounds volume ringtone vibration silent mute", listOf("android.settings.SOUND_SETTINGS"), purple),
        SystemSetting("Volume panel", "volume loudness media volume", listOf("android.settings.panel.action.VOLUME", "android.settings.SOUND_SETTINGS"), purple),
        SystemSetting("Do not disturb", "do not disturb dnd silent focus quiet", listOf("android.settings.ZEN_MODE_PRIORITY_SETTINGS", "android.settings.SOUND_SETTINGS"), purple),
        SystemSetting("Notifications", "notifications alerts badges", listOf("android.settings.ALL_APPS_NOTIFICATION_SETTINGS", "android.settings.NOTIFICATION_SETTINGS", "android.settings.SETTINGS"), red),
        SystemSetting("Apps", "apps applications uninstall permissions app info", listOf("android.settings.MANAGE_APPLICATIONS_SETTINGS"), teal),
        SystemSetting("Default apps", "default apps browser phone sms home app", listOf("android.settings.MANAGE_DEFAULT_APPS_SETTINGS"), teal),
        SystemSetting("Home app", "home launcher default home screen", listOf("android.settings.HOME_SETTINGS"), teal),
        SystemSetting("Battery", "battery power usage charging", listOf("android.intent.action.POWER_USAGE_SUMMARY", "android.settings.BATTERY_SAVER_SETTINGS"), green),
        SystemSetting("Power saving", "power saving battery saver low power", listOf("android.settings.BATTERY_SAVER_SETTINGS"), green),
        SystemSetting("Storage", "storage space memory files clean", listOf("android.settings.INTERNAL_STORAGE_SETTINGS"), green),
        SystemSetting("Location", "location gps maps position", listOf("android.settings.LOCATION_SOURCE_SETTINGS"), green),
        SystemSetting("Security", "security lock screen fingerprint face unlock password pin biometrics", listOf("android.settings.SECURITY_SETTINGS"), grey),
        SystemSetting("Privacy", "privacy permissions permission manager", listOf("android.settings.PRIVACY_SETTINGS"), grey),
        SystemSetting("Accounts & sync", "accounts sync backup google samsung account", listOf("android.settings.SYNC_SETTINGS"), grey),
        SystemSetting("Accessibility", "accessibility vision hearing talkback magnification", listOf("android.settings.ACCESSIBILITY_SETTINGS"), grey),
        SystemSetting("Language", "language languages locale region", listOf("android.settings.LOCALE_SETTINGS"), grey),
        SystemSetting("Keyboard", "keyboard input typing samsung keyboard gboard", listOf("android.settings.INPUT_METHOD_SETTINGS"), grey),
        SystemSetting("Date & time", "date time clock timezone time zone", listOf("android.settings.DATE_SETTINGS"), grey),
        SystemSetting("Smart View / Cast", "cast smart view screen mirroring chromecast", listOf("android.settings.CAST_SETTINGS"), grey),
        SystemSetting("Printing", "print printing printer", listOf("android.settings.ACTION_PRINT_SETTINGS"), grey),
        SystemSetting("Developer options", "developer options usb debugging animation scale", listOf("android.settings.APPLICATION_DEVELOPMENT_SETTINGS"), grey),
        SystemSetting("About phone", "about phone device info software version model build", listOf("android.settings.DEVICE_INFO_SETTINGS"), grey),
        SystemSetting("All settings", "settings system phone settings", listOf("android.settings.SETTINGS"), grey)
    )

    val launcher = listOf(
        LauncherSetting("Fluid Glass", "fluid glass liquid glass lens refraction intensity frosted", "blur", R.drawable.ic_blur, Color.rgb(32, 160, 230)),
        LauncherSetting("Blur strength", "blur frosted glass tint transparency", "blur", R.drawable.ic_blur, Color.rgb(32, 160, 230)),
        LauncherSetting("Home screen layout", "layout grid columns rows icon size app names labels", "layout", R.drawable.ic_grid, Color.rgb(64, 132, 255)),
        LauncherSetting("Page transition", "page transition effect cube depth carousel fade slide", "layout", R.drawable.ic_grid, Color.rgb(64, 132, 255)),
        LauncherSetting("Lock home screen layout", "lock layout prevent moving", "layout", R.drawable.ic_grid, Color.rgb(64, 132, 255)),
        LauncherSetting("Dock & search bar", "dock search bar capsule", "dock", R.drawable.ic_dock, Color.rgb(0, 168, 160)),
        LauncherSetting("Wallpapers", "wallpaper wallpapers background lock screen parallax", "wallpapers", R.drawable.ic_wallpaper, Color.rgb(146, 92, 255)),
        LauncherSetting("Icons", "icons icon pack shape style themed monochrome", "icons", R.drawable.ic_palette, Color.rgb(242, 80, 128)),
        LauncherSetting("Theme & accent colour", "theme dark mode light mode accent color colour", "theme", R.drawable.ic_tune, Color.rgb(90, 98, 120)),
        LauncherSetting("Animations", "animations animation speed app open close unlock", "animations", R.drawable.ic_animation, Color.rgb(255, 98, 72)),
        LauncherSetting("Gestures", "gestures swipe up swipe down pinch haptics vibration", "gestures", R.drawable.ic_gesture, Color.rgb(52, 186, 110)),
        LauncherSetting("App drawer", "app drawer columns keyboard", "drawer", R.drawable.ic_apps, Color.rgb(70, 110, 240)),
        LauncherSetting("Hidden apps", "hidden apps hide apps", "hidden", R.drawable.ic_hide, Color.rgb(70, 110, 240)),
        LauncherSetting("Search settings", "search contacts calendar history privacy permissions", "search", R.drawable.ic_search, Color.rgb(20, 150, 120)),
        LauncherSetting("Samsung mode", "samsung galaxy one ui s pen s25 ultra refresh rate", "samsung", R.drawable.ic_device, Color.rgb(20, 40, 160)),
        LauncherSetting("Edit home screen", "edit home screen pages add page widgets", "edit", R.drawable.ic_widgets, Color.rgb(255, 140, 40)),
        LauncherSetting("Widgets", "widgets add widget clock calendar battery", "widgets", R.drawable.ic_widgets, Color.rgb(255, 140, 40)),
        LauncherSetting("Fluid One settings", "fluid one launcher settings preferences", "main", R.drawable.ic_settings, Color.rgb(120, 126, 140)),
        LauncherSetting("About Fluid One", "about version privacy", "about", R.drawable.ic_info, Color.rgb(120, 126, 140))
    )

    fun scoreSetting(title: String, keywords: String, q: String): Int {
        val t = SearchText.score(title, q)
        if (t > 0) return t
        if (q.length < 2) return 0
        val k = SearchText.words(keywords)
        return when {
            k.any { it == q } -> 560
            k.any { it.startsWith(q) } -> 500
            q.contains(' ') && SearchText.norm(keywords).contains(q) -> 480
            else -> 0
        }
    }
}
