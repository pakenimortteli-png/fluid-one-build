package com.fluidone.launcher

import android.Manifest
import android.appwidget.AppWidgetHost
import android.appwidget.AppWidgetHostView
import android.appwidget.AppWidgetProviderInfo
import android.content.BroadcastReceiver
import android.content.ContentUris
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Shader
import android.os.BatteryManager
import android.os.Bundle
import android.provider.AlarmClock
import android.provider.CalendarContract
import android.text.format.DateFormat
import android.util.SizeF
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import java.util.Calendar
import java.util.Locale
import java.util.concurrent.Executors
import kotlin.math.abs
import kotlin.math.min
import kotlin.math.roundToInt

/** Long-press detection that works even when the child (a widget) consumes touches. */
class LongPressDetector(private val view: View, private val onLong: () -> Unit) {
    private val slop = ViewConfiguration.get(view.context).scaledTouchSlop
    private var downX = 0f
    private var downY = 0f
    var fired = false
        private set
    private var pending = false
    private val runnable = Runnable { if (pending) { pending = false; fired = true; onLong() } }

    /** Returns true once a long press fired, so the caller intercepts the rest of the gesture. */
    fun handle(ev: MotionEvent): Boolean {
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downX = ev.rawX; downY = ev.rawY; fired = false; pending = true
                view.postDelayed(runnable, min(ViewConfiguration.getLongPressTimeout(), 420).toLong())
            }
            MotionEvent.ACTION_MOVE -> if (pending && (abs(ev.rawX - downX) > slop || abs(ev.rawY - downY) > slop)) cancel()
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> cancel()
            MotionEvent.ACTION_POINTER_DOWN -> cancel()
        }
        return fired
    }

    fun cancel() { pending = false; view.removeCallbacks(runnable) }
}

/** Frame for built-in widgets: routes long presses to the launcher (menu / drag). */
open class WidgetFrame(context: Context) : FrameLayout(context) {
    var item: HomeItem? = null
    var onLongPress: ((View) -> Unit)? = null
    private val detector = LongPressDetector(this) { onLongPress?.invoke(this) }

    init { clipChildren = false; clipToPadding = false }

    override fun onInterceptTouchEvent(ev: MotionEvent): Boolean = detector.handle(ev)
    override fun onTouchEvent(ev: MotionEvent): Boolean { detector.handle(ev); return true }
    override fun onDetachedFromWindow() { detector.cancel(); super.onDetachedFromWindow() }
}

/** Host view for real Android widgets with long-press and size reporting (Android 12+ responsive widgets). */
class FluidWidgetHostView(context: Context) : AppWidgetHostView(context) {
    var item: HomeItem? = null
    var onLongPress: ((View) -> Unit)? = null
    private val detector = LongPressDetector(this) { onLongPress?.invoke(this) }
    private var lastW = -1
    private var lastH = -1

    override fun onInterceptTouchEvent(ev: MotionEvent): Boolean = detector.handle(ev) || super.onInterceptTouchEvent(ev)
    override fun onTouchEvent(ev: MotionEvent): Boolean { detector.handle(ev); return super.onTouchEvent(ev) || true }
    override fun onDetachedFromWindow() { detector.cancel(); super.onDetachedFromWindow() }

    fun reportSize() {
        if (width == lastW && height == lastH || width == 0 || height == 0) return
        lastW = width; lastH = height
        val d = resources.displayMetrics.density
        try { updateAppWidgetSize(Bundle(), listOf(SizeF(width / d, height / d))) } catch (_: Exception) { }
    }
}

class LauncherWidgetHost(context: Context, id: Int) : AppWidgetHost(context, id) {
    override fun onCreateView(context: Context, appWidgetId: Int, appWidget: AppWidgetProviderInfo?): AppWidgetHostView =
        FluidWidgetHostView(context)
}

object Builtins {
    const val CLOCK = "clock"
    const val CALENDAR = "calendar"
    const val BATTERY = "battery"
    val all = listOf(CLOCK, CALENDAR, BATTERY)
    fun name(id: String) = when (id) { CLOCK -> "Clock & date"; CALENDAR -> "Calendar"; BATTERY -> "Battery"; else -> id }
    fun defaultSpan(id: String, cols: Int): Pair<Int, Int> = when (id) {
        CLOCK -> cols to 2
        else -> 2 to 2
    }

    fun create(launcher: MainActivity, id: String): View = when (id) {
        CLOCK -> ClockWidget(launcher)
        CALENDAR -> CalendarWidget(launcher)
        else -> BatteryWidget(launcher)
    }
}

/**
 * Big home clock: date line plus large time with a soft lavender-to-white gradient, like the ColorOS 17
 * home screen. Drawn directly so it never re-measures itself mid-layout; refreshed by the system minute tick.
 */
class ClockWidget(private val launcher: MainActivity) : View(launcher) {
    private val datePaint = android.text.TextPaint(Paint.ANTI_ALIAS_FLAG).apply { typeface = Fonts.medium; textAlign = Paint.Align.CENTER }
    private val timePaint = android.text.TextPaint(Paint.ANTI_ALIAS_FLAG).apply { typeface = Fonts.semibold; textAlign = Paint.Align.CENTER; letterSpacing = -0.02f }
    private var dateText = ""
    private var timeText = ""
    private var dark = false
    private var dateBottom = 0f
    private var downX = 0f
    private var downY = 0f
    private var downTime = 0L
    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, intent: Intent) = tick()
    }

    init {
        isClickable = true
        tick()
        applyColors()
    }

    fun tick() {
        val now = java.util.Date()
        val locale = Locale.getDefault()
        dateText = java.text.SimpleDateFormat(DateFormat.getBestDateTimePattern(locale, "EEEMMMMd"), locale).format(now)
        timeText = java.text.SimpleDateFormat(if (DateFormat.is24HourFormat(context)) "H:mm" else "h:mm", locale).format(now)
        contentDescription = "$timeText, $dateText"
        invalidate()
    }

    fun applyColors() {
        dark = launcher.wallpaperIsLight
        datePaint.color = if (dark) Color.argb(205, 30, 26, 46) else Color.argb(230, 255, 255, 255)
        if (dark) { datePaint.clearShadowLayer(); timePaint.clearShadowLayer() }
        else {
            datePaint.setShadowLayer(dp(4f), 0f, dp(1f), Color.argb(70, 0, 0, 0))
            timePaint.setShadowLayer(dp(14f), 0f, dp(2f), Color.argb(46, 20, 0, 60))
        }
        timePaint.shader = null
        invalidate()
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        val filter = IntentFilter().apply {
            addAction(Intent.ACTION_TIME_TICK); addAction(Intent.ACTION_TIME_CHANGED); addAction(Intent.ACTION_TIMEZONE_CHANGED)
        }
        try { context.registerReceiver(receiver, filter, Context.RECEIVER_EXPORTED) } catch (_: Exception) { }
        tick()
    }

    override fun onDetachedFromWindow() {
        try { context.unregisterReceiver(receiver) } catch (_: Exception) { }
        super.onDetachedFromWindow()
    }

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        if (w <= 0f || h <= 0f) return
        timePaint.textSize = minOf(h * 0.56f, w * 0.3f)
        datePaint.textSize = (timePaint.textSize * 0.2f).coerceIn(dp(13f), dp(19f))
        val dateH = datePaint.descent() - datePaint.ascent()
        val capTop = -timePaint.fontMetrics.ascent * 0.72f   // digits are roughly cap height
        val gap = dp(6f)
        val total = dateH + gap + capTop
        val top = (h - total) / 2f
        val dateBaseline = top - datePaint.ascent()
        dateBottom = top + dateH
        canvas.drawText(dateText, w / 2f, dateBaseline, datePaint)
        val timeBaseline = top + dateH + gap + capTop
        if (timePaint.shader == null) {
            val colors = if (dark) intArrayOf(Color.rgb(46, 38, 82), Color.rgb(96, 78, 160))
                         else intArrayOf(Color.rgb(222, 210, 255), Color.WHITE, Color.rgb(198, 184, 255))
            timePaint.shader = LinearGradient(0f, timeBaseline - capTop, 0f, timeBaseline, colors, null, Shader.TileMode.CLAMP)
        }
        canvas.drawText(timeText, w / 2f, timeBaseline, timePaint)
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        timePaint.shader = null
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> { downX = event.x; downY = event.y; downTime = event.eventTime }
            MotionEvent.ACTION_UP -> {
                val slop = ViewConfiguration.get(context).scaledTouchSlop
                if (abs(event.x - downX) < slop && abs(event.y - downY) < slop && event.eventTime - downTime < ViewConfiguration.getLongPressTimeout()) {
                    performClick()
                    if (downY < dateBottom + dp(4f)) {
                        val uri = CalendarContract.CONTENT_URI.buildUpon().appendPath("time")
                        ContentUris.appendId(uri, System.currentTimeMillis())
                        launcher.startSafely(Intent(Intent.ACTION_VIEW).setData(uri.build()).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK), this)
                    } else {
                        launcher.startSafely(Intent(AlarmClock.ACTION_SHOW_ALARMS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK), this)
                    }
                }
            }
        }
        return true
    }
}

/** White calendar card showing today's date and the next events (Calendar permission optional). */
class CalendarWidget(private val launcher: MainActivity) : GlassView(launcher, launcher.dp(26f), Style.CARD_LIGHT) {
    private val day = context.textView("", 30f, Color.rgb(20, 20, 26), Fonts.bold)
    private val weekday = context.textView("", 13f, launcher.prefs.accent, Fonts.semibold)
    private val list = LinearLayout(context).apply { orientation = LinearLayout.VERTICAL }

    init {
        setPadding(dpi(15), dpi(12), dpi(13), dpi(12))
        val col = LinearLayout(context).apply { orientation = LinearLayout.VERTICAL }
        val head = LinearLayout(context).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.BOTTOM }
        head.addView(day)
        head.addView(weekday, llp(WRAP, WRAP).apply { marginStart = dpi(8); bottomMargin = dpi(4) })
        col.addView(head)
        col.addView(list, llp(MATCH, WRAP).apply { topMargin = dpi(8) })
        addView(col, flp(MATCH, MATCH))
        isClickable = true
        setOnClickListener {
            if (!hasPermission()) launcher.requestCalendarPermission()
            else {
                val uri = CalendarContract.CONTENT_URI.buildUpon().appendPath("time")
                ContentUris.appendId(uri, System.currentTimeMillis())
                launcher.startSafely(Intent(Intent.ACTION_VIEW).setData(uri.build()).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK), this)
            }
        }
        refresh()
    }

    private fun hasPermission() = context.checkSelfPermission(Manifest.permission.READ_CALENDAR) == PackageManager.PERMISSION_GRANTED

    override fun onAttachedToWindow() { super.onAttachedToWindow(); refresh() }

    fun refresh() {
        val now = Calendar.getInstance()
        day.text = now.get(Calendar.DAY_OF_MONTH).toString()
        weekday.text = now.getDisplayName(Calendar.DAY_OF_WEEK, Calendar.LONG, Locale.getDefault()) ?: ""
        weekday.setTextColor(launcher.prefs.accent)
        if (!hasPermission()) {
            showMessage("Tap to show your events")
            return
        }
        val start = System.currentTimeMillis()
        val end = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, 23); set(Calendar.MINUTE, 59); set(Calendar.SECOND, 59)
        }.timeInMillis + 24L * 3600_000L
        executor.execute {
            val events = mutableListOf<Triple<String, Long, Boolean>>()
            try {
                val uri = CalendarContract.Instances.CONTENT_URI.buildUpon()
                ContentUris.appendId(uri, start); ContentUris.appendId(uri, end)
                context.contentResolver.query(uri.build(),
                    arrayOf(CalendarContract.Instances.TITLE, CalendarContract.Instances.BEGIN, CalendarContract.Instances.ALL_DAY),
                    null, null, CalendarContract.Instances.BEGIN + " ASC")?.use { c ->
                    while (c.moveToNext() && events.size < 3) {
                        events.add(Triple(c.getString(0) ?: "(No title)", c.getLong(1), c.getInt(2) == 1))
                    }
                }
            } catch (_: Exception) { }
            post { showEvents(events) }
        }
    }

    private fun showMessage(text: String) {
        list.removeAllViews()
        list.addView(context.textView(text, 12f, Color.argb(150, 0, 0, 0), Fonts.regular, maxLines = 3))
    }

    private fun showEvents(events: List<Triple<String, Long, Boolean>>) {
        if (events.isEmpty()) { showMessage("No upcoming events"); return }
        list.removeAllViews()
        val fmt = DateFormat.getTimeFormat(context)
        events.take(2).forEach { (title, begin, allDay) ->
            val row = LinearLayout(context).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, dpi(3), 0, dpi(3)) }
            row.addView(View(context).apply { background = roundRect(launcher.prefs.accent, dp(2f)) }, llp(dpi(3), MATCH).apply { marginEnd = dpi(7) })
            val col = LinearLayout(context).apply { orientation = LinearLayout.VERTICAL }
            col.addView(context.textView(title, 12f, Color.rgb(28, 28, 34), Fonts.medium, maxLines = 1))
            col.addView(context.textView(if (allDay) "All day" else fmt.format(java.util.Date(begin)), 10.5f, Color.argb(140, 0, 0, 0), maxLines = 1).apply { setPadding(0, dpi(2), 0, 0) })
            row.addView(col)
            list.addView(row, llp(MATCH, WRAP))
        }
        if (events.size > 2) list.addView(context.textView("${events.size - 2} more", 10.5f, Color.argb(130, 0, 0, 0)).apply { setPadding(dpi(10), dpi(2), 0, 0) })
    }

    companion object { private val executor = Executors.newSingleThreadExecutor() }
}

/** Battery ring. */
class BatteryWidget(private val launcher: MainActivity) : GlassView(launcher, launcher.dp(26f), Style.HOME) {
    private var level = -1
    private var charging = false
    private val ring = object : View(context) {
        private val track = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND }
        private val arc = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND }
        private val r = RectF()
        override fun onDraw(canvas: Canvas) {
            val s = min(width, height).toFloat()
            val sw = s * 0.09f
            r.set((width - s) / 2f + sw, (height - s) / 2f + sw, (width + s) / 2f - sw, (height + s) / 2f - sw)
            track.strokeWidth = sw; arc.strokeWidth = sw
            track.color = Color.argb(60, 255, 255, 255)
            arc.color = if (charging) Color.rgb(52, 211, 120) else if (level in 0..15) Color.rgb(255, 90, 80) else Color.WHITE
            canvas.drawArc(r, 0f, 360f, false, track)
            if (level >= 0) canvas.drawArc(r, -90f, 360f * level / 100f, false, arc)
        }
    }
    private val percent = context.textView("--", 20f, Color.WHITE, Fonts.semibold, Gravity.CENTER)
    private val caption = context.textView("Battery", 11f, Color.argb(200, 255, 255, 255), Fonts.medium, Gravity.CENTER)
    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, intent: Intent) = update(intent)
    }

    init {
        val col = LinearLayout(context).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER }
        val ringFrame = FrameLayout(context)
        ringFrame.addView(ring, flp(MATCH, MATCH))
        ringFrame.addView(percent, flp(MATCH, MATCH))
        col.addView(ringFrame, llp(MATCH, 0, 1f))
        col.addView(caption, llp(MATCH, WRAP).apply { topMargin = dpi(6) })
        setPadding(dpi(14), dpi(14), dpi(14), dpi(12))
        addView(col, flp(MATCH, MATCH))
    }

    private fun update(intent: Intent?) {
        intent ?: return
        val l = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
        val s = intent.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
        level = if (l >= 0 && s > 0) (l * 100f / s).roundToInt() else -1
        val status = intent.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
        charging = status == BatteryManager.BATTERY_STATUS_CHARGING || status == BatteryManager.BATTERY_STATUS_FULL
        percent.text = if (level >= 0) "$level%" else "--"
        caption.text = if (charging) "Charging" else "Battery"
        ring.invalidate()
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        val sticky = try { context.registerReceiver(receiver, IntentFilter(Intent.ACTION_BATTERY_CHANGED), Context.RECEIVER_NOT_EXPORTED) } catch (_: Exception) { null }
        update(sticky)
    }

    override fun onDetachedFromWindow() {
        try { context.unregisterReceiver(receiver) } catch (_: Exception) { }
        super.onDetachedFromWindow()
    }
}
