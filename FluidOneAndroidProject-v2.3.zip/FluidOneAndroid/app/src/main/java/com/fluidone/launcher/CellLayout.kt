package com.fluidone.launcher

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.DashPathEffect
import android.graphics.Paint
import android.graphics.Point
import android.graphics.RectF
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.ViewGroup
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.roundToInt

/**
 * One home page: a fixed grid (no scrolling) where each child occupies cellX/cellY/spanX/spanY.
 * In edit mode it draws itself as a rounded "page card"; during drags it draws the drop outline.
 */
class CellLayout(context: Context, private val launcher: MainActivity) : ViewGroup(context) {
    class LP(var cellX: Int, var cellY: Int, var spanX: Int = 1, var spanY: Int = 1) : ViewGroup.LayoutParams(MATCH, MATCH)

    var cols = 4
        set(v) { field = v; requestLayout() }
    var rows = 6
        set(v) { field = v; requestLayout() }
    var cellW = 0f
        private set
    var cellH = 0f
        private set

    var editProgress = 0f
        set(v) { field = v; invalidate() }
    /** Drop outline in cell units, or null. */
    private var hint: android.graphics.Rect? = null
    private var hintValid = true
    private var hintAlpha = 0f

    var onEmptyLongPress: ((CellLayout, Float, Float) -> Unit)? = null
    var onEmptyTap: ((CellLayout) -> Unit)? = null

    private val cardFill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val cardStroke = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val hintPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val hintStroke = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val rect = RectF()

    private val slop = ViewConfiguration.get(context).scaledTouchSlop
    private var downX = 0f
    private var downY = 0f
    private var trackingEmpty = false
    private var longFired = false
    private val emptyLong = Runnable {
        if (trackingEmpty) {
            longFired = true
            onEmptyLongPress?.invoke(this, downX, downY)
        }
    }

    init {
        setWillNotDraw(false)
        clipChildren = false
        clipToPadding = false
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val w = MeasureSpec.getSize(widthMeasureSpec)
        val h = MeasureSpec.getSize(heightMeasureSpec)
        setMeasuredDimension(w, h)
        cellW = (w - paddingLeft - paddingRight) / cols.toFloat()
        cellH = (h - paddingTop - paddingBottom) / rows.toFloat()
        for (i in 0 until childCount) {
            val c = getChildAt(i)
            val lp = c.layoutParams as? LP ?: continue
            c.measure(
                MeasureSpec.makeMeasureSpec((cellW * lp.spanX).roundToInt().coerceAtLeast(0), MeasureSpec.EXACTLY),
                MeasureSpec.makeMeasureSpec((cellH * lp.spanY).roundToInt().coerceAtLeast(0), MeasureSpec.EXACTLY)
            )
        }
    }

    override fun onLayout(changed: Boolean, l: Int, t: Int, r: Int, b: Int) {
        for (i in 0 until childCount) {
            val c = getChildAt(i)
            val lp = c.layoutParams as? LP ?: continue
            val left = (paddingLeft + lp.cellX * cellW).roundToInt()
            val top = (paddingTop + lp.cellY * cellH).roundToInt()
            c.layout(left, top, left + c.measuredWidth, top + c.measuredHeight)
            if (c is FluidWidgetHostView) c.reportSize()
        }
    }

    override fun generateLayoutParams(p: ViewGroup.LayoutParams?): ViewGroup.LayoutParams = p as? LP ?: LP(0, 0)
    override fun checkLayoutParams(p: ViewGroup.LayoutParams?): Boolean = p is LP

    /** Cell under a local point (clamped into the grid). */
    fun cellAt(x: Float, y: Float): Point {
        val cx = ((x - paddingLeft) / max(1f, cellW)).toInt().coerceIn(0, cols - 1)
        val cy = ((y - paddingTop) / max(1f, cellH)).toInt().coerceIn(0, rows - 1)
        return Point(cx, cy)
    }

    /** Top-left cell for a multi-cell item centred under a local point. */
    fun spanOrigin(x: Float, y: Float, sx: Int, sy: Int): Point {
        val cx = ((x - paddingLeft) / max(1f, cellW) - sx / 2f + 0.5f).toInt().coerceIn(0, max(0, cols - sx))
        val cy = ((y - paddingTop) / max(1f, cellH) - sy / 2f + 0.5f).toInt().coerceIn(0, max(0, rows - sy))
        return Point(cx, cy)
    }

    fun cellRect(x: Int, y: Int, sx: Int = 1, sy: Int = 1): RectF =
        RectF(paddingLeft + x * cellW, paddingTop + y * cellH, paddingLeft + (x + sx) * cellW, paddingTop + (y + sy) * cellH)

    fun childFor(item: HomeItem): View? {
        for (i in 0 until childCount) {
            val c = getChildAt(i)
            if (c.getTag(R.id.tag_item) === item) return c
        }
        return null
    }

    /** Moves a child to a new cell, animating from where it currently appears. */
    fun animateChildTo(child: View, x: Int, y: Int, delay: Long = 0L) {
        val lp = child.layoutParams as? LP ?: return
        if (lp.cellX == x && lp.cellY == y) return
        val oldLeft = child.left + child.translationX
        val oldTop = child.top + child.translationY
        lp.cellX = x; lp.cellY = y
        val newLeft = (paddingLeft + x * cellW).roundToInt()
        val newTop = (paddingTop + y * cellH).roundToInt()
        child.layout(newLeft, newTop, newLeft + child.measuredWidth, newTop + child.measuredHeight)
        child.translationX = oldLeft - newLeft
        child.translationY = oldTop - newTop
        child.animate().translationX(0f).translationY(0f).setStartDelay(delay)
            .setDuration(Motion.d(300)).setInterpolator(Motion.move).start()
    }

    fun setDropHint(r: android.graphics.Rect?, valid: Boolean = true) {
        if (r == hint && valid == hintValid) return
        hint = r
        hintValid = valid
        hintAlpha = if (r != null) 1f else 0f
        invalidate()
    }

    override fun dispatchDraw(canvas: Canvas) {
        if (editProgress > 0.001f) {
            rect.set(dp(2f), dp(2f), width - dp(2f), height - dp(2f))
            val radius = dp(30f)
            cardFill.color = Color.argb((editProgress * 26).roundToInt(), 255, 255, 255)
            canvas.drawRoundRect(rect, radius, radius, cardFill)
            cardStroke.strokeWidth = dp(1.4f)
            cardStroke.color = Color.argb((editProgress * 92).roundToInt(), 255, 255, 255)
            canvas.drawRoundRect(rect, radius, radius, cardStroke)
        }
        hint?.let { h ->
            val r = cellRect(h.left, h.top, h.width(), h.height())
            r.inset(dp(6f), dp(6f))
            hintPaint.color = if (hintValid) Color.argb((hintAlpha * 46).roundToInt(), 255, 255, 255) else Color.argb(40, 255, 80, 80)
            canvas.drawRoundRect(r, dp(20f), dp(20f), hintPaint)
            hintStroke.strokeWidth = dp(1.5f)
            hintStroke.pathEffect = DashPathEffect(floatArrayOf(dp(6f), dp(5f)), 0f)
            hintStroke.color = Color.argb((hintAlpha * 150).roundToInt(), 255, 255, 255)
            canvas.drawRoundRect(r, dp(20f), dp(20f), hintStroke)
        }
        super.dispatchDraw(canvas)
    }

    /** Only reached when the touch is on empty space (children consume their own touches). */
    override fun onTouchEvent(event: MotionEvent): Boolean {
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downX = event.x; downY = event.y
                trackingEmpty = true
                longFired = false
                postDelayed(emptyLong, ViewConfiguration.getLongPressTimeout().toLong().coerceAtMost(420L))
                return true
            }
            MotionEvent.ACTION_MOVE -> if (trackingEmpty && (abs(event.x - downX) > slop || abs(event.y - downY) > slop)) {
                trackingEmpty = false
                removeCallbacks(emptyLong)
            }
            MotionEvent.ACTION_UP -> {
                removeCallbacks(emptyLong)
                if (trackingEmpty && !longFired) onEmptyTap?.invoke(this)
                trackingEmpty = false
            }
            MotionEvent.ACTION_CANCEL -> {
                removeCallbacks(emptyLong)
                trackingEmpty = false
            }
        }
        return true
    }

    override fun onDetachedFromWindow() {
        removeCallbacks(emptyLong)
        super.onDetachedFromWindow()
    }
}
