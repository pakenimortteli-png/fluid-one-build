package com.fluidone.launcher

import android.animation.ValueAnimator
import android.content.pm.ShortcutInfo
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.RectF
import android.text.InputType
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * Blur/dim of everything behind overlays. Several owners (drawer, folder, popup, edit mode…) can request a
 * level at once; the strongest wins. The wallpaper crossfades to its pre-blurred copy and the home content
 * gets a live GPU blur, so the effect is real blur on any Android 12+ device.
 */
class Backdrop(private val launcher: MainActivity) {
    private val blur = HashMap<Any, Float>()
    private val wallDim = HashMap<Any, Float>()
    private val contentDim = HashMap<Any, Float>()
    private val contentBlur = HashMap<Any, Float>()

    /**
     * [blurContent] owners (menus, folders, dialogs) blur and dim the icons too; others (edit mode, drawer)
     * only affect the wallpaper so the icons stay crisp and bright.
     */
    fun set(owner: Any, blurLevel: Float, dimLevel: Float = blurLevel * 0.28f, blurContent: Boolean = true) {
        blur[owner] = clamp01(blurLevel)
        if (blurContent) { contentDim[owner] = clamp01(dimLevel); wallDim.remove(owner) }
        else { wallDim[owner] = clamp01(dimLevel); contentDim.remove(owner) }
        contentBlur[owner] = if (blurContent) clamp01(blurLevel) else 0f
        apply()
    }

    fun clear(owner: Any) {
        blur.remove(owner); wallDim.remove(owner); contentDim.remove(owner); contentBlur.remove(owner)
        apply()
    }

    fun clearAll() { blur.clear(); wallDim.clear(); contentDim.clear(); contentBlur.clear(); apply() }

    private fun apply() {
        val b = blur.values.maxOrNull() ?: 0f
        val c = contentBlur.values.maxOrNull() ?: 0f
        launcher.wallpaperView.blurAmount = b
        launcher.wallpaperView.dim = wallDim.values.maxOrNull() ?: 0f
        val live = launcher.prefs.liveBlur && launcher.liveBlurAllowed()
        launcher.setContentBlur(if (live) c * launcher.dp(26f) else 0f)
        // Without live blur, a deeper scrim keeps overlays readable over sharp icons.
        val scrim = (contentDim.values.maxOrNull() ?: 0f) + if (live) 0f else c * 0.3f
        launcher.setScrim(scrim.coerceIn(0f, 0.75f))
    }
}

abstract class Overlay(val launcher: MainActivity) {
    val root: FrameLayout = object : FrameLayout(launcher) {
        override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
            if (closing) return true
            return super.dispatchTouchEvent(ev)
        }
    }
    var closing = false
        protected set

    open fun onBack(): Boolean { close(); return true }
    abstract fun close(animate: Boolean = true)

    /** Called when the IME inset changes so input fields stay visible. */
    open fun onImeInset(bottom: Int) {}

    protected fun finish() {
        root.removeFromParent()
        launcher.overlays.remove(this)
        launcher.backdrop.clear(this)
        launcher.onOverlayClosed(this)
    }
}

class PopupAction(val icon: Int, val label: String, val danger: Boolean = false, val action: () -> Unit)

/**
 * Long-press menu: the background blurs and dims, the pressed icon lifts, and a frosted card springs out of it
 * with app shortcuts and round action buttons. Moving the finger turns the press into a drag.
 */
class ItemPopup(
    launcher: MainActivity,
    private val anchor: View,
    private val anchorRect: RectF,
    private val lift: Bitmap?,
    private val title: String?,
    shortcuts: List<ShortcutInfo>,
    actions: List<PopupAction>,
    extra: View? = null
) : Overlay(launcher) {
    private val ui = launcher.ui
    private val card = GlassView(launcher, launcher.dp(26f), GlassView.Style.MENU).apply { heavyBlur = true }
    private val lifted = ImageView(launcher)
    private var progressAnim: ValueAnimator? = null
    private var above = true
    var handedToDrag = false
        private set

    init {
        root.isClickable = true
        root.setOnClickListener { close() }
        val content = LinearLayout(launcher).apply { orientation = LinearLayout.VERTICAL }
        if (title != null) {
            content.addView(launcher.textView(title, 13f, ui.textSecondary, Fonts.medium, maxLines = 1).apply {
                setPadding(launcher.dpi(18), launcher.dpi(14), launcher.dpi(18), launcher.dpi(4))
            })
        }
        shortcuts.take(4).forEach { si ->
            val row = LinearLayout(launcher).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(launcher.dpi(16), 0, launcher.dpi(16), 0)
                background = pressable(null, ui.cardPressed, launcher.dp(12f))
                isClickable = true
                setOnClickListener { close(); launcher.launchShortcut(si, anchorRect) }
            }
            val icon = ImageView(launcher)
            launcher.loadShortcutIcon(si, icon)
            row.addView(icon, llp(launcher.dpi(26), launcher.dpi(26)).apply { marginEnd = launcher.dpi(12) })
            row.addView(launcher.textView(si.shortLabel ?: si.longLabel ?: "", 14.5f, ui.text, Fonts.regular, maxLines = 1), llp(0, WRAP, 1f))
            content.addView(row, llp(MATCH, launcher.dpi(48)))
        }
        if (shortcuts.isNotEmpty() && actions.isNotEmpty()) {
            content.addView(View(launcher).apply { setBackgroundColor(ui.divider) }, llp(MATCH, 1).apply {
                topMargin = launcher.dpi(4); bottomMargin = launcher.dpi(2); marginStart = launcher.dpi(16); marginEnd = launcher.dpi(16)
            })
        }
        if (extra != null) content.addView(extra, llp(MATCH, WRAP))
        if (actions.isNotEmpty()) {
            val perRow = min(4, actions.size)
            actions.chunked(perRow).forEach { chunk ->
                val row = LinearLayout(launcher).apply {
                    orientation = LinearLayout.HORIZONTAL
                    setPadding(launcher.dpi(6), launcher.dpi(8), launcher.dpi(6), launcher.dpi(8))
                }
                chunk.forEach { a -> row.addView(actionButton(a), llp(0, WRAP, 1f)) }
                repeat(perRow - chunk.size) { row.addView(View(launcher), llp(0, 1, 1f)) }
                content.addView(row, llp(MATCH, WRAP))
            }
        }
        card.addView(content, flp(MATCH, WRAP))
        lifted.setImageBitmap(lift)
        lifted.scaleType = ImageView.ScaleType.FIT_XY
    }

    private fun actionButton(a: PopupAction): View {
        val col = LinearLayout(launcher).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(0, launcher.dpi(4), 0, launcher.dpi(2))
            isClickable = true
            background = pressable(null, ui.cardPressed, launcher.dp(14f))
            contentDescription = a.label
            setOnClickListener {
                launcher.haptic(this, HapticFeedbackConstants.CONTEXT_CLICK)
                close()
                a.action()
            }
        }
        val color = if (a.danger) ui.danger else ui.text
        val bubble = FrameLayout(launcher).apply { background = oval(ui.chip) }
        bubble.addView(launcher.iconImage(a.icon, color, 9), flp(MATCH, MATCH))
        col.addView(bubble, llp(launcher.dpi(42), launcher.dpi(42)))
        col.addView(launcher.textView(a.label, 11f, if (a.danger) ui.danger else ui.textSecondary, Fonts.medium, Gravity.CENTER, maxLines = 1).apply {
            setPadding(launcher.dpi(2), launcher.dpi(6), launcher.dpi(2), 0)
        }, llp(MATCH, WRAP))
        return col
    }

    fun show() {
        launcher.showOverlay(this)
        val w = root.width.takeIf { it > 0 } ?: launcher.rootView.width
        val h = root.height.takeIf { it > 0 } ?: launcher.rootView.height
        val cardW = min(launcher.dpi(260), w - launcher.dpi(32))
        card.measure(View.MeasureSpec.makeMeasureSpec(cardW, View.MeasureSpec.EXACTLY), View.MeasureSpec.makeMeasureSpec(h, View.MeasureSpec.AT_MOST))
        val cardH = card.measuredHeight
        val gap = launcher.dpi(14)
        val topLimit = launcher.insetTop + launcher.dpi(8)
        val labelSpace = if (anchor is IconView && (anchor as IconView).showLabel) launcher.dpi(20) else 0
        var top = anchorRect.top - gap - cardH
        above = top >= topLimit
        if (!above) top = anchorRect.bottom + labelSpace + gap
        top = top.coerceIn(topLimit.toFloat(), max(topLimit.toFloat(), (h - launcher.insetBottom - cardH - launcher.dpi(8)).toFloat()))
        val left = (anchorRect.centerX() - cardW / 2f).coerceIn(launcher.dp(16f), w - cardW - launcher.dp(16f))
        root.addView(card, flp(cardW, WRAP).apply { leftMargin = left.roundToInt(); topMargin = top.roundToInt() })
        if (lift != null) {
            root.addView(lifted, flp(anchorRect.width().roundToInt(), anchorRect.height().roundToInt()).apply {
                leftMargin = anchorRect.left.roundToInt(); topMargin = anchorRect.top.roundToInt()
            })
            anchor.alpha = 0f
        }
        card.pivotX = (anchorRect.centerX() - left).coerceIn(0f, cardW.toFloat())
        card.pivotY = if (above) cardH.toFloat() else 0f
        launcher.haptic(anchor, HapticFeedbackConstants.LONG_PRESS)
        animate(true)
    }

    private fun animate(open: Boolean, end: (() -> Unit)? = null) {
        progressAnim?.cancel()
        val spring = if (open) Spring(0.78f, 0.36f) else null
        val from = if (open) 0f else currentProgress
        progressAnim = ValueAnimator.ofFloat(from, if (open) 1f else 0f).apply {
            duration = if (open) spring!!.ms else Motion.d(180)
            interpolator = spring ?: Motion.accel
            addUpdateListener {
                val p = it.animatedValue as Float
                currentProgress = p
                apply(p)
            }
            addListener(object : android.animation.AnimatorListenerAdapter() {
                override fun onAnimationEnd(animation: android.animation.Animator) { end?.invoke() }
            })
            start()
        }
    }

    private var currentProgress = 0f

    private fun apply(p: Float) {
        val c = p.coerceIn(0f, 1.2f)
        card.alpha = clamp01(p * 1.6f)
        val s = 0.72f + 0.28f * c
        card.scaleX = s; card.scaleY = s
        card.translationY = (1f - c) * launcher.dp(if (above) 14f else -14f)
        val lift = 1f + 0.1f * c
        lifted.scaleX = lift; lifted.scaleY = lift
        launcher.backdrop.set(this, clamp01(p), clamp01(p) * 0.3f)
    }

    /** The press became a drag: fade the menu, keep the anchor hidden for the drag controller. */
    fun handOffToDrag() {
        if (closing) return
        handedToDrag = true
        closing = true
        lifted.visibility = View.INVISIBLE
        animate(false) { finish() }
    }

    override fun close(animate: Boolean) {
        if (closing) return
        closing = true
        val restore = {
            if (!handedToDrag) anchor.alpha = 1f
            finish()
        }
        if (animate) animate(false, restore) else { progressAnim?.cancel(); restore() }
    }
}

/** Centred ColorOS-style dialog with optional text input. */
class FluidDialog(
    launcher: MainActivity,
    title: String,
    message: String?,
    private val positive: String,
    private val negative: String? = "Cancel",
    private val destructive: Boolean = false,
    inputInitial: String? = null,
    icon: Int? = null,
    private val onPositive: (String) -> Unit
) : Overlay(launcher) {
    private val ui = launcher.ui
    private val card = FrameLayout(launcher)
    private val input: EditText? = inputInitial?.let { initial ->
        EditText(launcher).apply {
            setText(initial)
            setSelection(initial.length)
            setSingleLine(true)
            textSize = 16f
            setTextColor(ui.text)
            setHintTextColor(ui.textTertiary)
            background = roundRect(ui.chip, launcher.dp(14f))
            setPadding(launcher.dpi(14), launcher.dpi(12), launcher.dpi(14), launcher.dpi(12))
            imeOptions = EditorInfo.IME_ACTION_DONE
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
            setOnEditorActionListener { _, id, _ -> if (id == EditorInfo.IME_ACTION_DONE) { confirm(); true } else false }
        }
    }

    init {
        root.isClickable = true
        root.setOnClickListener { close() }
        card.background = roundRect(ui.card, launcher.dp(28f))
        card.isClickable = true
        card.elevation = launcher.dp(16f)
        val col = LinearLayout(launcher).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(launcher.dpi(24), launcher.dpi(22), launcher.dpi(24), launcher.dpi(10))
        }
        if (icon != null) {
            val badge = FrameLayout(launcher).apply { background = oval(withAlpha(ui.accent, 0.14f)) }
            badge.addView(launcher.iconImage(icon, ui.accent, 12), flp(MATCH, MATCH))
            col.addView(badge, llp(launcher.dpi(52), launcher.dpi(52)).apply { gravity = Gravity.CENTER_HORIZONTAL; bottomMargin = launcher.dpi(14) })
        }
        col.addView(launcher.textView(title, 18f, ui.text, Fonts.semibold, Gravity.CENTER), llp(MATCH, WRAP))
        if (!message.isNullOrEmpty()) col.addView(launcher.textView(message, 14f, ui.textSecondary, Fonts.regular, Gravity.CENTER).apply {
            setLineSpacing(launcher.dp(3f), 1f)
        }, llp(MATCH, WRAP).apply { topMargin = launcher.dpi(10) })
        input?.let { col.addView(it, llp(MATCH, WRAP).apply { topMargin = launcher.dpi(16) }) }
        val buttons = LinearLayout(launcher).apply { orientation = LinearLayout.HORIZONTAL }
        if (negative != null) {
            buttons.addView(button(negative, ui.text) { close() }, llp(0, launcher.dpi(48), 1f))
            buttons.addView(View(launcher).apply { setBackgroundColor(ui.divider) }, llp(1, launcher.dpi(22)).apply { gravity = Gravity.CENTER_VERTICAL })
        }
        buttons.addView(button(positive, if (destructive) ui.danger else ui.accent) { confirm() }, llp(0, launcher.dpi(48), 1f))
        col.addView(buttons, llp(MATCH, WRAP).apply { topMargin = launcher.dpi(16) })
        card.addView(col, flp(MATCH, WRAP))
    }

    private fun button(text: String, color: Int, click: () -> Unit): TextView =
        launcher.textView(text, 16f, color, Fonts.medium, Gravity.CENTER).apply {
            background = pressable(null, ui.cardPressed, launcher.dp(14f))
            isClickable = true
            setOnClickListener { click() }
        }

    private fun confirm() {
        val value = input?.text?.toString().orEmpty()
        close()
        onPositive(value)
    }

    fun show() {
        launcher.showOverlay(this)
        val w = min(launcher.rootView.width - launcher.dpi(48), launcher.dpi(360))
        root.addView(card, flp(w, WRAP, Gravity.CENTER))
        card.alpha = 0f; card.scaleX = 0.88f; card.scaleY = 0.88f
        val spring = Spring(0.8f, 0.34f)
        card.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(spring.ms).setInterpolator(spring).start()
        Motion.animate(240, Motion.decel, update = { launcher.backdrop.set(this, it * 0.85f, it * 0.4f) })
        input?.let { field ->
            field.requestFocus()
            field.postDelayed({ launcher.getSystemService(InputMethodManager::class.java)?.showSoftInput(field, 0) }, 120)
        }
    }

    override fun onImeInset(bottom: Int) {
        val target = if (bottom > 0) -(bottom / 2f) + launcher.insetBottom else 0f
        card.animate().translationY(target).setDuration(180).setInterpolator(Motion.decel).start()
    }

    override fun close(animate: Boolean) {
        if (closing) return
        closing = true
        input?.let { launcher.getSystemService(InputMethodManager::class.java)?.hideSoftInputFromWindow(it.windowToken, 0) }
        if (!animate) { finish(); return }
        card.animate().alpha(0f).scaleX(0.94f).scaleY(0.94f).setDuration(Motion.d(160)).setInterpolator(Motion.accel).start()
        Motion.animate(180, Motion.accel, update = { launcher.backdrop.set(this, (1 - it) * 0.85f, (1 - it) * 0.4f) }, end = { finish() })
    }
}

/**
 * Frosted bottom sheet that springs up from the bottom edge. Drag the handle down or tap outside to close.
 */
open class BottomSheet(launcher: MainActivity, title: String, private val dimBackground: Boolean = true) : Overlay(launcher) {
    protected val ui = launcher.ui
    val sheet = GlassView(launcher, launcher.dp(30f), GlassView.Style.MENU).apply { heavyBlur = true; isClickable = true }
    val body = LinearLayout(launcher).apply { orientation = LinearLayout.VERTICAL }
    val scroll = ScrollView(launcher).apply {
        isVerticalScrollBarEnabled = false
        overScrollMode = View.OVER_SCROLL_NEVER
        isFillViewport = false
    }
    private var downY = 0f
    private var dragging = false

    init {
        root.isClickable = true
        root.setOnClickListener { close() }
        val col = LinearLayout(launcher).apply { orientation = LinearLayout.VERTICAL }
        val handle = FrameLayout(launcher)
        handle.addView(View(launcher).apply { background = roundRect(ui.textTertiary, launcher.dp(3f)) }, flp(launcher.dpi(36), launcher.dpi(5), Gravity.CENTER))
        col.addView(handle, llp(MATCH, launcher.dpi(22)))
        col.addView(launcher.textView(title, 20f, ui.text, Fonts.semibold).apply {
            setPadding(launcher.dpi(22), 0, launcher.dpi(22), launcher.dpi(10))
        })
        scroll.addView(body, flp(MATCH, WRAP))
        col.addView(scroll, llp(MATCH, WRAP))
        sheet.addView(col, flp(MATCH, WRAP))
        handle.setOnTouchListener { _, e -> dragHandle(e) }
    }

    private fun dragHandle(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> { downY = e.rawY; dragging = true }
            MotionEvent.ACTION_MOVE -> if (dragging) sheet.translationY = max(0f, e.rawY - downY)
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                dragging = false
                if (sheet.translationY > sheet.height * 0.25f) close()
                else sheet.animate().translationY(0f).setDuration(Motion.d(240)).setInterpolator(Motion.emphasized).start()
            }
        }
        return true
    }

    fun show() {
        launcher.showOverlay(this)
        val h = launcher.rootView.height
        scroll.layoutParams = (scroll.layoutParams as LinearLayout.LayoutParams).apply { height = WRAP }
        root.addView(sheet, flp(MATCH, WRAP, Gravity.BOTTOM).apply {
            leftMargin = launcher.dpi(8); rightMargin = launcher.dpi(8); bottomMargin = launcher.insetBottom + launcher.dpi(8)
        })
        sheet.measure(View.MeasureSpec.makeMeasureSpec(launcher.rootView.width - launcher.dpi(16), View.MeasureSpec.EXACTLY), View.MeasureSpec.makeMeasureSpec(h, View.MeasureSpec.AT_MOST))
        val maxH = (h * 0.74f).roundToInt()
        if (sheet.measuredHeight > maxH) {
            val extra = sheet.measuredHeight - maxH
            scroll.layoutParams = (scroll.layoutParams as LinearLayout.LayoutParams).apply { height = max(launcher.dpi(160), scroll.measuredHeight - extra) }
        }
        sheet.translationY = h * 0.6f
        val spring = Spring(0.86f, 0.42f)
        sheet.animate().translationY(0f).setDuration(spring.ms).setInterpolator(spring).start()
        if (dimBackground) Motion.animate(260, Motion.decel, update = { launcher.backdrop.set(this, it * 0.5f, it * 0.32f, blurContent = false) })
        onShown()
    }

    protected open fun onShown() {}

    override fun onImeInset(bottom: Int) {
        val lp = sheet.layoutParams as? FrameLayout.LayoutParams ?: return
        lp.bottomMargin = max(launcher.insetBottom, bottom) + launcher.dpi(8)
        sheet.layoutParams = lp
    }

    override fun close(animate: Boolean) {
        if (closing) return
        closing = true
        onClosing()
        if (!animate) { finish(); return }
        sheet.animate().translationY(sheet.height.toFloat() + launcher.dp(24f)).setDuration(Motion.d(230)).setInterpolator(Motion.accel).start()
        Motion.animate(230, Motion.accel, update = { if (dimBackground) launcher.backdrop.set(this, (1 - it) * 0.5f, (1 - it) * 0.32f, blurContent = false) }, end = { finish() })
    }

    protected open fun onClosing() {}

    /** A rounded section inside a sheet. */
    fun section(label: String? = null): LinearLayout {
        if (label != null) body.addView(launcher.textView(label.uppercase(), 11.5f, ui.textSecondary, Fonts.semibold).apply {
            letterSpacing = 0.06f
            setPadding(launcher.dpi(24), launcher.dpi(12), launcher.dpi(24), launcher.dpi(8))
        })
        val box = LinearLayout(launcher).apply { orientation = LinearLayout.VERTICAL; setPadding(launcher.dpi(16), 0, launcher.dpi(16), launcher.dpi(6)) }
        body.addView(box, llp(MATCH, WRAP))
        return box
    }
}

