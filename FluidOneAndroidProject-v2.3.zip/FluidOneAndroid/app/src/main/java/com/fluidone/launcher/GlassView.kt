package com.fluidone.launcher

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Outline
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import android.view.MotionEvent
import android.view.View
import android.view.ViewOutlineProvider
import android.widget.FrameLayout
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * Real frosted glass: draws the pre-blurred wallpaper region that is exactly behind this view, a tint, and a
 * subtle light edge. Because the blur comes from [WallpaperView], it keeps working on One UI even when the
 * system's own window blur is disabled.
 */
open class GlassView(context: Context, cornerRadiusPx: Float, var style: Style = Style.HOME) : FrameLayout(context) {
    enum class Style { HOME, MENU, CARD_LIGHT }

    var cornerRadius = cornerRadiusPx
        set(v) { field = v; invalidateOutline(); invalidate() }
    /** Overrides the computed tint when non-null. */
    var tintOverride: Int? = null
        set(v) { field = v; invalidate() }
    var glassAlpha = 1f
        set(v) { field = v.coerceIn(0f, 1f); invalidate() }
    var drawStroke = true
    var heavyBlur = false

    private val path = Path()
    private val rect = RectF()
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private var strokeShaderHeight = -1

    init {
        setWillNotDraw(false)
        clipChildren = true
        outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(view: View, outline: Outline) {
                outline.setRoundRect(0, 0, view.width, view.height, cornerRadius)
            }
        }
        clipToOutline = true
    }

    private val launcher: MainActivity? get() = context as? MainActivity

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        launcher?.registerGlass(this)
    }

    override fun onDetachedFromWindow() {
        launcher?.unregisterGlass(this)
        if (press != 0f) { pressSpring.snapTo(0f); scaleX = 1f; scaleY = 1f }
        super.onDetachedFromWindow()
    }

    fun tintColor(): Int {
        tintOverride?.let { return it }
        val l = launcher ?: return Color.argb(120, 20, 20, 24)
        val strength = l.prefs.glassTint / 100f
        return when (style) {
            Style.HOME -> if (l.wallpaperIsLight) Color.argb((40 + 120 * strength).toInt(), 255, 255, 255)
                          else Color.argb((24 + 150 * strength).toInt(), 18, 18, 26)
            Style.MENU -> l.ui.glassTint
            Style.CARD_LIGHT -> Color.argb(214, 252, 252, 255)
        }
    }

    private val painter by lazy { GlassPainter(context) }
    private val sharpMatrix = android.graphics.Matrix()
    private val blurMatrix = android.graphics.Matrix()

    // ---- Liquid press ------------------------------------------------------------------------------------
    // Touching glass makes it swell toward the finger and light up under it; letting go, it settles with a
    // soft, jelly-like wobble. Driven by a real spring so it never jumps when interrupted.

    private var press = 0f
    private var lightX = -1f
    private var lightY = -1f
    private val pressSpring by lazy { SpringValue(0f) { press = it; applyPress() } }
    private val tmpMatrix = android.graphics.Matrix()
    private val tmpPts = FloatArray(2)

    /** Makes this glass react to touches on [source] (itself by default) without taking over its clicks. */
    fun enableLiquidPress(source: View = this) {
        source.setOnTouchListener { v, ev -> onPressEvent(v, ev); false }
    }

    /** Swells the glass as if pressed, e.g. while a dragged app hovers over a drop target. */
    fun setLiquidPressed(pressed: Boolean) {
        if (pressed) { lightX = width / 2f; lightY = height / 2f; pressSpring.animateTo(1f, 520f, 0.6f) }
        else pressSpring.animateTo(0f, 260f, 0.32f)
    }

    private fun onPressEvent(src: View, ev: MotionEvent) {
        if (!liquidMotion()) return
        // Finger position in this view's own coordinates.
        tmpPts[0] = ev.x; tmpPts[1] = ev.y
        tmpMatrix.reset(); src.transformMatrixToGlobal(tmpMatrix); tmpMatrix.mapPoints(tmpPts)
        tmpMatrix.reset(); transformMatrixToLocal(tmpMatrix); tmpMatrix.mapPoints(tmpPts)
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN -> { lightX = tmpPts[0]; lightY = tmpPts[1]; pressSpring.animateTo(1f, 600f, 0.62f) }
            MotionEvent.ACTION_MOVE -> { lightX = tmpPts[0]; lightY = tmpPts[1]; applyPress() }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> pressSpring.animateTo(0f, 240f, 0.3f)
        }
    }

    private fun liquidMotion(): Boolean = launcher?.prefs?.fluidGlass != false

    private fun applyPress() {
        val w = width.toFloat(); val h = height.toFloat()
        if (w <= 0f || h <= 0f) return
        val p = press
        val ox = ((lightX - w / 2f) / (w / 2f)).coerceIn(-1f, 1f)
        val oy = ((lightY - h / 2f) / (h / 2f)).coerceIn(-1f, 1f)
        // Grow by about 12 dp at most, a little more toward the finger, like a drop of liquid reaching out.
        val grow = min(0.12f, dp(12f) / max(w, h))
        scaleX = 1f + p * (grow + 0.035f * abs(ox) - 0.015f * abs(oy))
        scaleY = 1f + p * (grow + 0.035f * abs(oy) - 0.015f * abs(ox))
        pivotX = w / 2f - ox * w * 0.18f * min(1f, abs(p))
        pivotY = h / 2f - oy * h * 0.18f * min(1f, abs(p))
        invalidate()
    }


    /** Fluid Glass: a curved, refracting lens drawn by the GPU. Returns false to use plain frosted glass. */
    private fun drawFluid(canvas: Canvas): Boolean {
        val l = launcher ?: return false
        val intensity = l.fluidIntensity(style)
        if (intensity <= 0f) return false
        val sources = l.wallpaperView.glassSources(this, heavyBlur, sharpMatrix, blurMatrix) ?: return false
        val layer = if (glassAlpha < 1f) canvas.saveLayerAlpha(rect, (glassAlpha * 255).toInt()) else -1
        val drew = painter.draw(canvas, rect, cornerRadius.coerceAtMost(min(width, height) / 2f), intensity, tintColor(),
            sources[0], sharpMatrix, sources[1], blurMatrix, press, lightX, lightY)
        if (layer >= 0) canvas.restoreToCount(layer)
        return drew
    }

    override fun onDraw(canvas: Canvas) {
        if (width == 0 || height == 0 || glassAlpha <= 0f) return
        rect.set(0f, 0f, width.toFloat(), height.toFloat())
        if (drawFluid(canvas)) return
        path.reset()
        path.addRoundRect(rect, cornerRadius, cornerRadius, Path.Direction.CW)
        val save = canvas.save()
        canvas.clipPath(path)
        val layer = if (glassAlpha < 1f) canvas.saveLayerAlpha(rect, (glassAlpha * 255).toInt()) else -1
        val drewWallpaper = launcher?.wallpaperView?.drawGlass(canvas, this, heavyBlur) == true
        if (!drewWallpaper) canvas.drawColor(Color.argb(200, 26, 26, 34))
        fill.color = tintColor()
        canvas.drawRect(rect, fill)
        if (layer >= 0) canvas.restoreToCount(layer)
        canvas.restoreToCount(save)
        if (drawStroke) {
            if (strokeShaderHeight != height) {
                strokeShaderHeight = height
                val light = style == Style.CARD_LIGHT
                stroke.shader = LinearGradient(0f, 0f, 0f, height.toFloat(),
                    intArrayOf(Color.argb(if (light) 140 else 70, 255, 255, 255), Color.argb(if (light) 60 else 18, 255, 255, 255)),
                    null, Shader.TileMode.CLAMP)
            }
            stroke.strokeWidth = dp(1f)
            stroke.alpha = (glassAlpha * 255).toInt()
            val half = stroke.strokeWidth / 2f
            rect.inset(half, half)
            canvas.drawRoundRect(rect, cornerRadius - half, cornerRadius - half, stroke)
        }
    }
}
