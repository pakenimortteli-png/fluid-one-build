package com.fluidone.launcher

import android.graphics.Bitmap
import android.graphics.RenderEffect
import android.graphics.Shader
import android.view.View
import kotlin.math.max
import kotlin.math.roundToInt

/**
 * CPU blur used for glass surfaces. It works on every device and does not depend on the system's
 * cross-window blur, which One UI turns off with power saving or "Reduce transparency and blur".
 * The source is downscaled first, then three box passes approximate a gaussian.
 */
object BlurEngine {
    fun blur(src: Bitmap, scale: Float, radius: Int): Bitmap {
        val soft = if (src.config == Bitmap.Config.HARDWARE) src.copy(Bitmap.Config.ARGB_8888, false) else src
        val w = max(1, (soft.width * scale).roundToInt())
        val h = max(1, (soft.height * scale).roundToInt())
        val small = Bitmap.createScaledBitmap(soft, w, h, true).let {
            if (it.config != Bitmap.Config.ARGB_8888 || !it.isMutable) it.copy(Bitmap.Config.ARGB_8888, true) else it
        }
        if (radius <= 0) return small
        val a = IntArray(w * h)
        val b = IntArray(w * h)
        small.getPixels(a, 0, w, 0, 0, w, h)
        val r = radius.coerceAtMost(max(1, max(w, h) / 2))
        repeat(3) {
            boxHorizontal(a, b, w, h, r)
            boxVertical(b, a, w, h, r)
        }
        small.setPixels(a, 0, w, 0, 0, w, h)
        return small
    }

    private fun boxHorizontal(src: IntArray, dst: IntArray, w: Int, h: Int, r: Int) {
        val div = 2 * r + 1
        val last = w - 1
        for (y in 0 until h) {
            val row = y * w
            var sa = 0; var sr = 0; var sg = 0; var sb = 0
            for (i in -r..r) {
                val p = src[row + i.coerceIn(0, last)]
                sa += p ushr 24; sr += (p shr 16) and 255; sg += (p shr 8) and 255; sb += p and 255
            }
            for (x in 0 until w) {
                dst[row + x] = ((sa / div) shl 24) or ((sr / div) shl 16) or ((sg / div) shl 8) or (sb / div)
                val pOut = src[row + (x - r).coerceIn(0, last)]
                val pIn = src[row + (x + r + 1).coerceIn(0, last)]
                sa += (pIn ushr 24) - (pOut ushr 24)
                sr += ((pIn shr 16) and 255) - ((pOut shr 16) and 255)
                sg += ((pIn shr 8) and 255) - ((pOut shr 8) and 255)
                sb += (pIn and 255) - (pOut and 255)
            }
        }
    }

    private fun boxVertical(src: IntArray, dst: IntArray, w: Int, h: Int, r: Int) {
        val div = 2 * r + 1
        val last = h - 1
        for (x in 0 until w) {
            var sa = 0; var sr = 0; var sg = 0; var sb = 0
            for (i in -r..r) {
                val p = src[i.coerceIn(0, last) * w + x]
                sa += p ushr 24; sr += (p shr 16) and 255; sg += (p shr 8) and 255; sb += p and 255
            }
            for (y in 0 until h) {
                dst[y * w + x] = ((sa / div) shl 24) or ((sr / div) shl 16) or ((sg / div) shl 8) or (sb / div)
                val pOut = src[(y - r).coerceIn(0, last) * w + x]
                val pIn = src[(y + r + 1).coerceIn(0, last) * w + x]
                sa += (pIn ushr 24) - (pOut ushr 24)
                sr += ((pIn shr 16) and 255) - ((pOut shr 16) and 255)
                sg += ((pIn shr 8) and 255) - ((pOut shr 8) and 255)
                sb += (pIn and 255) - (pOut and 255)
            }
        }
    }
}

/** GPU blur for live view content (API 31+ RenderEffect). Radius in px; 0 removes the effect. */
fun View.setLiveBlur(radiusPx: Float) {
    if (radiusPx < 0.5f) {
        if (getTag(R.id.tag_blur_radius) != null) {
            setRenderEffect(null)
            setTag(R.id.tag_blur_radius, null)
        }
        return
    }
    val previous = getTag(R.id.tag_blur_radius) as? Float
    if (previous != null && kotlin.math.abs(previous - radiusPx) < 0.35f) return
    setRenderEffect(RenderEffect.createBlurEffect(radiusPx, radiusPx, Shader.TileMode.CLAMP))
    setTag(R.id.tag_blur_radius, radiusPx)
}
