package com.fluidone.launcher

import android.animation.ValueAnimator
import android.graphics.Color
import android.graphics.RectF
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import kotlin.math.ceil
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/** Grid inside an open folder. Children follow [order]; a drag gap can be opened at any index. */
class FolderGrid(private val launcher: MainActivity) : ViewGroup(launcher) {
    var columns = 3
    var cellH = 0
    private var gap = -1

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val w = MeasureSpec.getSize(widthMeasureSpec)
        val cellW = w / columns
        val visible = (0 until childCount).count { getChildAt(it).visibility != GONE } + if (gap >= 0) 1 else 0
        val rows = max(1, ceil(visible / columns.toFloat()).toInt())
        for (i in 0 until childCount) getChildAt(i).measure(
            MeasureSpec.makeMeasureSpec(cellW, MeasureSpec.EXACTLY), MeasureSpec.makeMeasureSpec(cellH, MeasureSpec.EXACTLY))
        setMeasuredDimension(w, rows * cellH)
    }

    override fun onLayout(changed: Boolean, l: Int, t: Int, r: Int, b: Int) {
        val cellW = width / columns
        var slot = 0
        for (i in 0 until childCount) {
            val c = getChildAt(i)
            if (c.visibility == GONE) continue
            if (slot == gap) slot++
            val x = (slot % columns) * cellW
            val y = (slot / columns) * cellH
            c.layout(x, y, x + c.measuredWidth, y + c.measuredHeight)
            slot++
        }
    }

    fun setGap(index: Int) {
        if (index == gap) return
        val before = (0 until childCount).associate { getChildAt(it) to Pair(getChildAt(it).left + getChildAt(it).translationX, getChildAt(it).top + getChildAt(it).translationY) }
        gap = index
        measure(MeasureSpec.makeMeasureSpec(width, MeasureSpec.EXACTLY), MeasureSpec.makeMeasureSpec(0, MeasureSpec.UNSPECIFIED))
        layout(left, top, left + measuredWidth, top + measuredHeight)
        for ((v, pos) in before) {
            v.translationX = pos.first - v.left
            v.translationY = pos.second - v.top
            v.animate().translationX(0f).translationY(0f).setDuration(Motion.d(260)).setInterpolator(Motion.move).start()
        }
    }

    fun indexAt(x: Float, y: Float, count: Int): Int {
        val cellW = width / columns.toFloat()
        val col = (x / cellW).toInt().coerceIn(0, columns - 1)
        val row = max(0, (y / max(1, cellH)).toInt())
        return (row * columns + col).coerceIn(0, count)
    }
}

/**
 * Open folder. The frosted panel grows out of the folder icon on a spring, the title can be renamed in place,
 * and apps can be reordered or dragged out onto the home screen.
 */
class FolderOverlay(launcher: MainActivity, val item: HomeItem, private var iconView: View?) : Overlay(launcher) {
    private val panel = GlassView(launcher, launcher.dp(34f), GlassView.Style.HOME).apply { heavyBlur = true; isClickable = true }
    val grid = FolderGrid(launcher)
    private val scroll = ScrollView(launcher).apply { isVerticalScrollBarEnabled = false; overScrollMode = View.OVER_SCROLL_NEVER }
    private val title = EditText(launcher)
    private val panelRect = RectF()
    private var anim: ValueAnimator? = null
    private var progress = 0f
    private val iconViews = mutableListOf<IconView>()

    init {
        root.isClickable = true
        root.setOnClickListener { if (title.hasFocus()) commitTitle() else close() }
        title.apply {
            setText(item.title.ifEmpty { "Folder" })
            textSize = 26f
            typeface = Fonts.semibold
            setTextColor(Color.WHITE)
            setShadowLayer(dp(6f), 0f, dp(1f), Color.argb(80, 0, 0, 0))
            background = transparentDrawable
            gravity = Gravity.CENTER
            setSingleLine(true)
            imeOptions = EditorInfo.IME_ACTION_DONE
            setSelectAllOnFocus(true)
            setOnEditorActionListener { _, id, _ -> if (id == EditorInfo.IME_ACTION_DONE) { commitTitle(); true } else false }
            setOnFocusChangeListener { _, has -> if (!has) commitTitle() }
            contentDescription = "Folder name"
        }
        scroll.addView(grid, flp(MATCH, WRAP))
        panel.addView(scroll, flp(MATCH, WRAP))
        panel.setPadding(launcher.dpi(10), launcher.dpi(18), launcher.dpi(10), launcher.dpi(14))
    }

    private fun commitTitle() {
        val t = title.text.toString().trim().ifEmpty { "Folder" }
        if (t != item.title) {
            item.title = t
            launcher.model.save()
            launcher.syncFolderIcon(item)
        }
        title.clearFocus()
        launcher.getSystemService(InputMethodManager::class.java)?.hideSoftInputFromWindow(title.windowToken, 0)
    }

    fun rebuild() {
        grid.removeAllViews()
        iconViews.clear()
        val size = launcher.iconSizePx
        grid.cellH = size + launcher.dpi(48)
        val apps = item.apps.mapNotNull { launcher.apps[it] }
        grid.columns = if (apps.size > 12 && launcher.rootView.width > launcher.dpi(400)) 4 else 3
        for (entry in apps) {
            val v = launcher.createAppIcon(entry, IconView.SOURCE_FOLDER)
            v.folder = item
            v.darkLabel = false
            grid.addView(v)
            iconViews.add(v)
        }
    }

    fun show() {
        rebuild()
        launcher.showOverlay(this)
        val w = launcher.rootView.width
        val h = launcher.rootView.height
        val panelW = min(w - launcher.dpi(40), launcher.dpi(420))
        panel.measure(View.MeasureSpec.makeMeasureSpec(panelW, View.MeasureSpec.EXACTLY), View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED))
        val maxPanelH = (h * 0.56f).roundToInt()
        val panelH = min(panel.measuredHeight, maxPanelH)
        val left = (w - panelW) / 2f
        val top = (h - panelH) / 2f - launcher.dp(12f)
        panelRect.set(left, top, left + panelW, top + panelH)
        root.addView(title, flp(panelW, WRAP).apply { leftMargin = left.roundToInt(); topMargin = (top - launcher.dp(64f)).roundToInt() })
        root.addView(panel, flp(panelW, panelH).apply { leftMargin = left.roundToInt(); topMargin = top.roundToInt() })
        panel.pivotX = 0f; panel.pivotY = 0f
        iconView?.alpha = 0f
        animateTo(true)
    }

    private fun startRect(): RectF {
        val v = iconView
        if (v != null && v.isAttachedToWindow) {
            return if (v is IconView) v.iconRectInWindow() else RectF().also { r ->
                val m = android.graphics.Matrix(); v.transformMatrixToGlobal(m)
                r.set(0f, 0f, v.width.toFloat(), v.height.toFloat()); m.mapRect(r)
            }
        }
        val cx = panelRect.centerX(); val cy = panelRect.centerY()
        return RectF(cx - 40f, cy - 40f, cx + 40f, cy + 40f)
    }

    private fun animateTo(open: Boolean, end: (() -> Unit)? = null) {
        anim?.cancel()
        val start = startRect()
        val spring = if (open) Spring(0.84f, 0.4f) else Spring(0.95f, 0.3f)
        anim = ValueAnimator.ofFloat(progress, if (open) 1f else 0f).apply {
            duration = spring.ms
            interpolator = spring
            addUpdateListener {
                progress = it.animatedValue as Float
                applyProgress(progress, start)
            }
            addListener(object : android.animation.AnimatorListenerAdapter() {
                override fun onAnimationEnd(animation: android.animation.Animator) { end?.invoke() }
            })
            start()
        }
    }

    private fun applyProgress(p: Float, start: RectF) {
        val sx = lerp(start.width() / panelRect.width(), 1f, p)
        val sy = lerp(start.height() / panelRect.height(), 1f, p)
        panel.scaleX = sx; panel.scaleY = sy
        panel.translationX = lerp(start.left - panelRect.left, 0f, p)
        panel.translationY = lerp(start.top - panelRect.top, 0f, p)
        panel.alpha = clamp01(p * 2.5f)
        panel.invalidate()
        val contentAlpha = clamp01((p - 0.35f) / 0.65f)
        scroll.alpha = contentAlpha
        title.alpha = contentAlpha
        title.translationY = (1f - contentAlpha) * launcher.dp(16f)
        launcher.backdrop.set(this, clamp01(p), clamp01(p) * 0.25f)
    }

    fun panelRectInWindow(): RectF = RectF(panelRect)

    fun iconFor(key: String): IconView? = iconViews.firstOrNull { it.entry?.key == key }

    /** Window point → insertion index inside the folder. */
    fun indexAtWindow(x: Float, y: Float, count: Int): Int {
        val loc = IntArray(2); grid.getLocationInWindow(loc)
        return grid.indexAt(x - loc[0], y - loc[1], count)
    }

    fun setDragGap(index: Int) = grid.setGap(index)

    /** Window rect for the icon at [index] after layout. */
    fun slotRect(index: Int): RectF {
        val loc = IntArray(2); grid.getLocationInWindow(loc)
        val cellW = grid.width / grid.columns.toFloat()
        val size = launcher.iconSizePx
        val cx = loc[0] + (index % grid.columns + 0.5f) * cellW
        val top = loc[1] + (index / grid.columns) * grid.cellH + (grid.cellH - size - launcher.dpi(24)) / 2f
        return RectF(cx - size / 2f, top, cx + size / 2f, top + size)
    }

    fun refreshAfterChange() {
        if (item.apps.isEmpty() || launcher.model.pageOf(item) < 0) { close(); return }
        rebuild()
        grid.setGap(-1)
        grid.requestLayout()
    }

    /** Closes quickly when an app is dragged out of the panel. */
    fun closeForDrag() {
        if (closing) return
        closing = true
        launcher.getSystemService(InputMethodManager::class.java)?.hideSoftInputFromWindow(title.windowToken, 0)
        anim?.cancel()
        Motion.animate(160, Motion.accel, update = {
            val a = 1f - it
            panel.alpha = a; title.alpha = a
            panel.scaleX = 1f - 0.06f * it; panel.scaleY = panel.scaleX
            launcher.backdrop.set(this, a, a * 0.25f)
        }, end = { iconView?.alpha = 1f; finish() })
    }

    override fun close(animate: Boolean) {
        if (closing) return
        closing = true
        commitTitle()
        iconView = launcher.findFolderIconView(item) ?: iconView
        if (!animate) { iconView?.alpha = 1f; finish(); return }
        animateTo(false) {
            iconView?.alpha = 1f
            finish()
        }
    }

    override fun onImeInset(bottom: Int) {
        val shift = if (bottom > 0) -max(0f, panelRect.bottom - (launcher.rootView.height - bottom - launcher.dp(16f))) else 0f
        root.animate().translationY(shift).setDuration(180).setInterpolator(Motion.decel).start()
    }
}

fun ViewGroup.childList(): List<View> = (0 until childCount).map { getChildAt(it) }
