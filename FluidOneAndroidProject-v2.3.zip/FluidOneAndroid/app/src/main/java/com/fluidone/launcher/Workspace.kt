package com.fluidone.launcher

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.DashPathEffect
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.RectF
import android.view.Gravity
import android.view.MotionEvent
import android.view.VelocityTracker
import android.view.View
import android.view.ViewConfiguration
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * Horizontal home pager. Pages follow the finger 1:1, settle with a ColorOS deceleration curve, rubber-band at
 * the ends and support page transition effects. Edit mode shrinks pages into cards with neighbours peeking.
 * There is deliberately no vertical scrolling inside pages.
 */
class Workspace(context: Context, private val launcher: MainActivity) : FrameLayout(context) {
    val pages = mutableListOf<CellLayout>()
    private val headers = mutableListOf<PageHeader>()
    val addCard = AddPageCard(context)

    var scrollPos = 0f
        private set
    var editProgress = 0f
        set(v) { field = v; applyTransforms() }
    var effect = "slide"

    var onScroll: ((Float) -> Unit)? = null
    var onSettled: ((Int) -> Unit)? = null

    private var snapAnim: ValueAnimator? = null
    private var velocity: VelocityTracker? = null
    private val slop = ViewConfiguration.get(context).scaledTouchSlop
    private val pagingSlop = ViewConfiguration.get(context).scaledPagingTouchSlop
    private val flingVelocity = ViewConfiguration.get(context).scaledMinimumFlingVelocity * 6
    private var downX = 0f
    private var downY = 0f
    private var startScroll = 0f
    private var dragging = false
    private var caught = false

    val currentPage: Int get() = scrollPos.roundToInt().coerceIn(0, max(0, maxPos()))
    val pageCount: Int get() = pages.size

    init {
        clipChildren = false
        clipToPadding = false
        addCard.alpha = 0f
        addCard.visibility = INVISIBLE
        addCard.setOnClickListener { launcher.addPageFromEditMode() }
        addView(addCard, LayoutParams(MATCH, MATCH))
    }

    fun setPageCount(count: Int, factory: (Int) -> CellLayout) {
        while (pages.size > count) {
            val p = pages.removeAt(pages.lastIndex)
            removeView(p)
            removeView(headers.removeAt(headers.lastIndex))
        }
        while (pages.size < count) {
            val index = pages.size
            val page = factory(index)
            pages.add(page)
            addView(page, indexOfChild(addCard), LayoutParams(MATCH, MATCH))
            val header = PageHeader(context, launcher, index)
            headers.add(header)
            addView(header, LayoutParams(WRAP, dpi(40)))
        }
        headers.forEachIndexed { i, h -> h.index = i; h.refresh() }
        scrollPos = scrollPos.coerceIn(0f, max(0, maxPos()).toFloat())
        applyTransforms()
    }

    private fun maxPos(): Int = if (editProgress > 0.5f) pages.size else pages.size - 1

    fun pitch(): Float = width * lerp(1f, EDIT_PITCH, editProgress)

    fun editScale(): Float = lerp(1f, EDIT_SCALE, editProgress)

    fun pivotYFor(): Float = height * EDIT_PIVOT_Y

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        applyTransforms()
    }

    override fun onLayout(changed: Boolean, left: Int, top: Int, right: Int, bottom: Int) {
        super.onLayout(changed, left, top, right, bottom)
        applyTransforms()
    }

    fun applyTransforms() {
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f) return
        val p = pitch()
        val s = editScale()
        val pivotY = pivotYFor()
        val editing = editProgress > 0.001f
        for (i in 0..pages.size) {
            val v: View = if (i < pages.size) pages[i] else addCard
            val o = i - scrollPos
            v.pivotX = w / 2f
            v.pivotY = pivotY
            v.translationX = o * p
            v.translationY = 0f
            v.scaleX = s
            v.scaleY = s
            v.rotationY = 0f
            v.alpha = if (v === addCard) editProgress else 1f
            if (!editing && v !== addCard && abs(o) < 1f) applyEffect(v, o, w, h)
            val visible = abs(o) < (if (editing) 2.2f else 1.02f) && (v !== addCard || editing)
            v.visibility = if (visible) VISIBLE else INVISIBLE
            if (v is CellLayout) v.editProgress = editProgress
        }
        headers.forEachIndexed { i, header ->
            val o = i - scrollPos
            header.visibility = if (editing && abs(o) < 2.2f) VISIBLE else INVISIBLE
            header.alpha = editProgress
            val cardTop = pivotY - pivotY * s
            header.translationX = o * p + (w - header.width) / 2f
            header.translationY = cardTop - header.height - dp(6f) * editProgress
        }
        launcher.invalidateGlass()
    }

    private fun applyEffect(v: View, o: Float, w: Float, h: Float) {
        when (effect) {
            "depth" -> {
                if (o < 0f) {
                    val t = -o
                    v.translationX = 0f + o * w * 0.3f
                    v.scaleX = 1f - 0.22f * t; v.scaleY = v.scaleX
                    v.alpha = 1f - t
                }
            }
            "cube" -> {
                v.cameraDistance = 9000f * resources.displayMetrics.density
                v.pivotX = if (o < 0f) w else 0f
                v.pivotY = h / 2f
                v.rotationY = -o * 70f
            }
            "fade" -> {
                v.translationX = o * w * 0.22f
                v.alpha = 1f - abs(o)
                v.scaleX = 1f - abs(o) * 0.06f; v.scaleY = v.scaleX
            }
            "carousel" -> {
                v.cameraDistance = 9000f * resources.displayMetrics.density
                v.scaleX = 1f - abs(o) * 0.16f; v.scaleY = v.scaleX
                v.rotationY = -o * 24f
                v.alpha = 1f - abs(o) * 0.35f
            }
        }
    }

    fun setScroll(pos: Float) {
        scrollPos = pos
        applyTransforms()
        onScroll?.invoke(pos)
    }

    fun snapTo(page: Int, animate: Boolean = true, velocityPx: Float = 0f, end: (() -> Unit)? = null) {
        snapAnim?.cancel()
        val target = page.coerceIn(0, max(0, maxPos())).toFloat()
        if (!animate || width == 0) {
            setScroll(target)
            onSettled?.invoke(target.roundToInt())
            end?.invoke()
            return
        }
        val from = scrollPos
        val distance = abs(target - from)
        if (distance < 0.001f) { setScroll(target); onSettled?.invoke(target.roundToInt()); end?.invoke(); return }
        val speed = abs(velocityPx) / max(1f, pitch())
        var duration = (260 + 260 * min(distance, 2f)).toLong()
        if (speed > 0.5f) duration = (duration / min(2f, 0.6f + speed * 0.4f)).toLong()
        snapAnim = ValueAnimator.ofFloat(from, target).apply {
            this.duration = Motion.d(duration.coerceIn(180L, 560L))
            interpolator = Motion.emphasized
            addUpdateListener { setScroll(it.animatedValue as Float) }
            addListener(object : android.animation.AnimatorListenerAdapter() {
                private var cancelled = false
                override fun onAnimationCancel(animation: android.animation.Animator) { cancelled = true }
                override fun onAnimationEnd(animation: android.animation.Animator) {
                    if (!cancelled) { onSettled?.invoke(target.roundToInt()); end?.invoke() }
                }
            })
            start()
        }
    }

    val isSettling: Boolean get() = snapAnim?.isRunning == true

    override fun onInterceptTouchEvent(ev: MotionEvent): Boolean {
        if (!launcher.canPageWorkspace()) return false
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downX = ev.x; downY = ev.y
                dragging = false
                velocity?.recycle(); velocity = VelocityTracker.obtain()
                velocity?.addMovement(ev)
                if (snapAnim?.isRunning == true && abs(scrollPos - scrollPos.roundToInt()) > 0.02f) {
                    // Catch the moving page, but leave vertical gestures to the parent until we know.
                    snapAnim?.cancel()
                    caught = true
                    startScroll = scrollPos
                    return true
                }
                caught = false
            }
            MotionEvent.ACTION_MOVE -> {
                velocity?.addMovement(ev)
                val dx = ev.x - downX
                val dy = ev.y - downY
                if (!dragging && abs(dx) > pagingSlop && abs(dx) > abs(dy) * 1.15f) {
                    beginDrag(ev)
                    return true
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> dragging = false
        }
        return dragging
    }

    private fun beginDrag(ev: MotionEvent) {
        dragging = true
        snapAnim?.cancel()
        downX = ev.x
        startScroll = scrollPos
        parent?.requestDisallowInterceptTouchEvent(true)
        launcher.onWorkspaceDragStart()
    }

    override fun onTouchEvent(ev: MotionEvent): Boolean {
        if (!launcher.canPageWorkspace()) return false
        if (velocity == null) velocity = VelocityTracker.obtain()
        velocity?.addMovement(ev)
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN -> { if (!caught) { downX = ev.x; downY = ev.y }; return true }
            MotionEvent.ACTION_MOVE -> {
                if (!dragging) {
                    val dx = ev.x - downX
                    if (abs(dx) > slop && abs(dx) > abs(ev.y - downY)) {
                        val keep = if (caught) scrollPos else -1f
                        beginDrag(ev)
                        if (keep >= -0.5f) startScroll = keep
                    } else return true
                }
                val raw = startScroll - (ev.x - downX) / max(1f, pitch())
                setScroll(rubberBand(raw))
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                if (dragging) {
                    velocity?.computeCurrentVelocity(1000)
                    val vx = velocity?.xVelocity ?: 0f
                    val base = startScroll.roundToInt()
                    val target = when {
                        ev.actionMasked == MotionEvent.ACTION_CANCEL -> scrollPos.roundToInt()
                        vx < -flingVelocity -> ceil(scrollPos).toInt().coerceAtMost(base + 1)
                        vx > flingVelocity -> floor(scrollPos).toInt().coerceAtLeast(base - 1)
                        else -> scrollPos.roundToInt()
                    }
                    if (target != base) launcher.haptic(this, android.view.HapticFeedbackConstants.CLOCK_TICK)
                    snapTo(target, velocityPx = vx)
                } else if (caught || abs(scrollPos - scrollPos.roundToInt()) > 0.001f) {
                    snapTo(scrollPos.roundToInt())
                } else if (ev.actionMasked == MotionEvent.ACTION_UP && editProgress > 0.5f &&
                    abs(ev.x - downX) < slop && abs(ev.y - downY) < slop) {
                    // Tap in the gap between page cards leaves edit mode, like ColorOS.
                    launcher.exitEditMode()
                }
                caught = false
                dragging = false
                velocity?.recycle(); velocity = null
            }
        }
        return true
    }

    // ---- Scrolling driven by another finger while an icon is being dragged ---------------------------

    private var externalBase = 0
    fun beginExternalDrag() {
        snapAnim?.cancel()
        startScroll = scrollPos
        externalBase = scrollPos.roundToInt()
    }

    fun externalDrag(dxPx: Float) = setScroll(rubberBand(startScroll - dxPx / max(1f, pitch())))

    fun endExternalDrag(vx: Float, end: (() -> Unit)? = null) {
        val target = when {
            vx < -flingVelocity -> ceil(scrollPos).toInt().coerceAtMost(externalBase + 1)
            vx > flingVelocity -> floor(scrollPos).toInt().coerceAtLeast(externalBase - 1)
            else -> scrollPos.roundToInt()
        }
        if (target != externalBase) launcher.haptic(this, android.view.HapticFeedbackConstants.CLOCK_TICK)
        snapTo(target, velocityPx = vx, end = end)
    }

    private fun rubberBand(raw: Float): Float {
        val maxP = max(0, maxPos()).toFloat()
        return when {
            raw < 0f -> -damp(-raw)
            raw > maxP -> maxP + damp(raw - maxP)
            else -> raw
        }
    }

    private fun damp(x: Float): Float = 0.35f * (1f - 1f / (x * 1.6f + 1f))

    /** Page whose (transformed) bounds contain the window point, or the current page. */
    fun pageAtWindowPoint(wx: Float, wy: Float): Int {
        val inv = Matrix()
        for (i in pages.indices) {
            val p = pages[i]
            if (p.visibility != VISIBLE) continue
            val m = Matrix(); p.transformMatrixToGlobal(m)
            if (!m.invert(inv)) continue
            val pts = floatArrayOf(wx, wy); inv.mapPoints(pts)
            if (pts[0] >= 0 && pts[0] <= p.width && pts[1] >= -dp(40f) && pts[1] <= p.height + dp(40f)) return i
        }
        return currentPage.coerceAtMost(pages.size - 1)
    }

    fun refreshHeaders() = headers.forEach { it.refresh() }
}

/** "Add page" card shown after the last page in edit mode. */
class AddPageCard(context: Context) : FrameLayout(context) {
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        color = Color.argb(150, 255, 255, 255)
    }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(18, 255, 255, 255) }
    private val rect = RectF()

    init {
        setWillNotDraw(false)
        isClickable = true
        val col = LinearLayout(context).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER }
        val plus = FrameLayout(context).apply { background = oval(Color.argb(46, 255, 255, 255)) }
        plus.addView(context.iconImage(R.drawable.ic_plus, Color.WHITE, 14), flp(MATCH, MATCH))
        col.addView(plus, llp(context.dpi(64), context.dpi(64)))
        col.addView(context.textView("Add page", 15f, Color.WHITE, Fonts.medium, Gravity.CENTER).apply { setPadding(0, context.dpi(14), 0, 0) })
        addView(col, flp(WRAP, WRAP, Gravity.CENTER))
        contentDescription = "Add home page"
    }

    override fun onDraw(canvas: Canvas) {
        stroke.strokeWidth = dp(1.6f)
        stroke.pathEffect = DashPathEffect(floatArrayOf(dp(10f), dp(8f)), 0f)
        rect.set(dp(2f), dp(2f), width - dp(2f), height - dp(2f))
        canvas.drawRoundRect(rect, dp(30f), dp(30f), fill)
        canvas.drawRoundRect(rect, dp(30f), dp(30f), stroke)
    }
}

/** Buttons above each page card in edit mode: make default page, delete page. */
class PageHeader(context: Context, private val launcher: MainActivity, var index: Int) : LinearLayout(context) {
    private val home: ImageView
    private val delete: ImageView

    init {
        orientation = HORIZONTAL
        gravity = Gravity.CENTER
        home = button(R.drawable.ic_home, "Set as main page") { launcher.setDefaultPage(index) }
        delete = button(R.drawable.ic_delete, "Delete page") { launcher.requestDeletePage(index) }
        addView(home, llp(dpi(36), dpi(36)).apply { marginEnd = dpi(14) })
        addView(delete, llp(dpi(36), dpi(36)))
    }

    private fun button(res: Int, desc: String, action: () -> Unit): ImageView = context.iconImage(res, Color.WHITE, 8).apply {
        background = oval(Color.argb(60, 255, 255, 255))
        contentDescription = desc
        isClickable = true
        setOnClickListener { launcher.haptic(this, android.view.HapticFeedbackConstants.CONTEXT_CLICK); action() }
    }

    fun refresh() {
        val isDefault = launcher.prefs.defaultPage == index
        home.background = oval(if (isDefault) launcher.prefs.accent else Color.argb(60, 255, 255, 255))
        delete.alpha = if (launcher.workspacePageCount() > 1) 1f else 0.35f
    }
}

/**
 * Page dots that move continuously with the scroll position: the active dot stretches into a pill.
 */
class PageIndicator(context: Context) : View(context) {
    var count = 1
        set(v) { field = v; invalidate() }
    var position = 0f
        set(v) { field = v; invalidate() }
    var dark = false
        set(v) { field = v; invalidate() }
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val r = RectF()

    override fun onDraw(canvas: Canvas) {
        if (count <= 1) return
        val dot = dp(6f)
        val active = dp(16f)
        val gap = dp(7f)
        val total = (count - 1) * (dot + gap) + active
        var x = (width - total) / 2f
        val cy = height / 2f
        for (i in 0 until count) {
            val t = (1f - abs(position - i)).coerceIn(0f, 1f)
            val w = lerp(dot, active, t)
            r.set(x, cy - dot / 2f, x + w, cy + dot / 2f)
            val base = if (dark) Color.BLACK else Color.WHITE
            paint.color = withAlpha(base, lerp(0.38f, 0.95f, t))
            canvas.drawRoundRect(r, dot / 2f, dot / 2f, paint)
            x += w + gap
        }
    }
}

const val EDIT_SCALE = 0.74f
const val EDIT_PITCH = 0.79f
const val EDIT_PIVOT_Y = 0.36f
