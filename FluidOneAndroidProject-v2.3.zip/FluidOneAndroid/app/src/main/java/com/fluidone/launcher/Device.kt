package com.fluidone.launcher

import android.app.Activity
import android.content.Context
import android.graphics.Rect
import android.os.Build
import android.os.PowerManager
import android.provider.Settings
import android.view.RoundedCorner
import android.view.View
import android.view.WindowManager
import java.util.Locale
import kotlin.math.roundToInt

/** Samsung / Galaxy S25 Ultra detection and the device-specific tuning Samsung mode applies. */
object Device {
    fun isS25Ultra(): Boolean {
        val model = Build.MODEL.orEmpty().uppercase(Locale.ROOT)
        val device = Build.DEVICE.orEmpty().lowercase(Locale.ROOT)
        return Build.MANUFACTURER.equals("samsung", ignoreCase = true) &&
            (model.startsWith("SM-S938") || device.startsWith("pa3q"))
    }

    fun isSamsung(): Boolean = Build.MANUFACTURER.equals("samsung", ignoreCase = true)

    /** Requests the panel's highest refresh rate (120 Hz on the S25 Ultra) at the current resolution. */
    fun applyRefreshRate(activity: Activity, high: Boolean) {
        val window = activity.window
        @Suppress("DEPRECATION")
        val display = try { activity.display } catch (_: Exception) { activity.windowManager.defaultDisplay } ?: return
        val attrs = window.attributes
        if (!high) {
            if (attrs.preferredDisplayModeId != 0) {
                attrs.preferredDisplayModeId = 0
                window.attributes = attrs
            }
            return
        }
        val current = display.mode
        val best = display.supportedModes
            .filter { it.physicalWidth == current.physicalWidth && it.physicalHeight == current.physicalHeight }
            .maxByOrNull { it.refreshRate } ?: return
        if (attrs.preferredDisplayModeId != best.modeId) {
            attrs.preferredDisplayModeId = best.modeId
            window.attributes = attrs
        }
    }

    fun maxRefreshRate(activity: Activity): Float = try {
        activity.display?.supportedModes?.maxOfOrNull { it.refreshRate } ?: 60f
    } catch (_: Exception) {
        @Suppress("DEPRECATION")
        activity.windowManager.defaultDisplay.supportedModes.maxOfOrNull { it.refreshRate } ?: 60f
    }

    /** Display corner radius, so launch morphs end exactly on the screen's rounded corners. */
    fun screenCornerRadius(view: View): Float {
        val insets = view.rootWindowInsets
        val r = insets?.getRoundedCorner(RoundedCorner.POSITION_TOP_LEFT)?.radius ?: 0
        return if (r > 0) r.toFloat() else view.dp(28f)
    }

    /** Keeps One UI's back gesture from stealing drags that pass near the screen edges. */
    fun guardEdges(root: View, centerY: Float, enabled: Boolean) {
        if (!enabled) {
            if (root.systemGestureExclusionRects.isNotEmpty()) root.systemGestureExclusionRects = emptyList()
            return
        }
        val h = root.dpi(190)
        val w = root.dpi(36)
        val top = (centerY - h / 2f).roundToInt().coerceIn(0, (root.height - h).coerceAtLeast(0))
        root.systemGestureExclusionRects = listOf(Rect(0, top, w, top + h), Rect(root.width - w, top, root.width, top + h))
    }

    fun animatorScale(context: Context): Float =
        try { Settings.Global.getFloat(context.contentResolver, Settings.Global.ANIMATOR_DURATION_SCALE, 1f) } catch (_: Exception) { 1f }

    fun transitionScale(context: Context): Float =
        try { Settings.Global.getFloat(context.contentResolver, Settings.Global.TRANSITION_ANIMATION_SCALE, 1f) } catch (_: Exception) { 1f }

    /** One UI's "Reduce transparency and blur" accessibility switch. */
    fun samsungReduceTransparency(context: Context): Boolean =
        try { Settings.System.getInt(context.contentResolver, "accessibility_reduce_transparency", 0) == 1 } catch (_: Exception) { false }

    fun crossWindowBlurEnabled(context: Context): Boolean =
        try { context.getSystemService(WindowManager::class.java)?.isCrossWindowBlurEnabled == true } catch (_: Exception) { false }

    fun powerSave(context: Context): Boolean =
        try { context.getSystemService(PowerManager::class.java)?.isPowerSaveMode == true } catch (_: Exception) { false }

    fun description(activity: Activity): String {
        val m = activity.resources.displayMetrics
        val bounds = activity.windowManager.currentWindowMetrics.bounds
        return buildString {
            append("Device: ${Build.MANUFACTURER} ${Build.MODEL} (${Build.DEVICE})\n")
            append("Android ${Build.VERSION.RELEASE} · API ${Build.VERSION.SDK_INT}\n")
            append("Display: ${bounds.width()} × ${bounds.height()} px · ${m.densityDpi} dpi · up to ${maxRefreshRate(activity).roundToInt()} Hz\n")
            append("Animator scale: ${animatorScale(activity)}× · Transition scale: ${transitionScale(activity)}×\n")
            append("System window blur: ${if (crossWindowBlurEnabled(activity)) "available" else "off"} (Fluid blur does not need it)\n")
            append("Power saving: ${if (powerSave(activity)) "on" else "off"}")
        }
    }
}
