package com.fluidone.launcher

import android.content.Context
import android.content.SharedPreferences
import android.graphics.Color
import org.json.JSONObject
import kotlin.properties.ReadWriteProperty
import kotlin.reflect.KProperty

/** Typed access to every launcher setting. Defaults favour a ColorOS 17 look on a Galaxy S25 Ultra. */
class LauncherPrefs(context: Context) {
    val sp: SharedPreferences = context.getSharedPreferences("fluid_one", Context.MODE_PRIVATE)
    private val isS25 = Device.isS25Ultra()
    private val isSamsung = Device.isSamsung()
    private val shortScreen = context.resources.configuration.screenHeightDp in 1..679

    // Home layout
    var columns by intPref("grid_columns") { 4 }
    var rows by intPref("grid_rows") { if (shortScreen) 5 else 6 }
    var iconScale by intPref("icon_scale") { 100 }
    var showLabels by boolPref("show_labels") { true }
    var labelSize by intPref("label_size") { 12 }
    var dockStyle by stringPref("dock_style") { "clear" }
    var dockLabels by boolPref("dock_labels") { false }
    var searchBar by boolPref("search_bar") { true }
    var pageEffect by stringPref("page_effect") { "slide" }
    var lockLayout by boolPref("lock_layout") { false }
    var addNewApps by boolPref("add_new_apps") { true }
    var defaultPage by intPref("default_page") { 0 }
    var drawerColumns by intPref("drawer_columns") { 4 }
    var drawerKeyboard by boolPref("drawer_keyboard") { false }

    // Icons
    var iconShape by stringPref("icon_shape") { "squircle" }
    var iconStyle by stringPref("icon_style") { "original" }
    var iconPack by stringPref("icon_pack") { "" }
    var normalizeLegacy by boolPref("normalize_legacy") { true }

    // Wallpaper & blur
    var wallpaper by stringPref("wallpaper_id") { Wallpapers.DEFAULT_ID }
    var lockWallpaper by boolPref("lock_wallpaper") { false }
    var parallax by boolPref("parallax") { true }
    var blurStrength by intPref("blur_strength") { 70 }
    var glassTint by intPref("glass_tint") { 32 }
    var liveBlur by boolPref("live_blur") { true }
    var fluidGlass by boolPref("fluid_glass") { true }
    var fluidIntensity by intPref("fluid_glass_intensity") { 80 }

    // Motion
    var launchAnim by stringPref("launch_anim") { "morph" }
    var returnAnim by boolPref("return_anim") { true }
    var unlockAnim by stringPref("unlock_anim") { "gather" }
    var animSpeed by intPref("anim_speed") { 100 }
    var haptics by boolPref("haptics") { true }

    // Gestures
    var swipeUp by stringPref("swipe_up") { "drawer" }
    var swipeDown by stringPref("swipe_down") { "notifications" }
    var pinchIn by stringPref("pinch_in") { "edit" }

    // Theme
    var theme by stringPref("theme") { "system" }
    var accent by intPref("accent") { DEFAULT_ACCENT }

    // Samsung mode: optimizations for every Galaxy device (older builds stored "s25_mode").
    var samsungMode by boolPref("samsung_mode") { sp.getBoolean("s25_mode", isSamsung) }
    var oneUiIcons by boolPref("samsung_oneui_icons") { true }
    var highRefresh by boolPref("s25_high_refresh") { true }
    var gestureGuard by boolPref("s25_gesture_guard") { true }
    var batteryBlur by boolPref("samsung_battery_blur") { true }

    // Galaxy S25 Ultra optimizations, inside Samsung mode and only effective on an S25 Ultra.
    var s25Optimizations by boolPref("s25_optimizations") { isS25 }
    var spenHover by boolPref("s25_spen_hover") { true }
    var spenButton by boolPref("s25_spen_button") { true }

    // Search (2.2). Everything is searched on the phone; nothing is sent anywhere.
    var searchContacts by boolPref("search_contacts") { true }
    var searchCalendar by boolPref("search_calendar") { true }
    var searchShortcuts by boolPref("search_shortcuts") { true }
    var searchSettings by boolPref("search_settings") { true }
    var searchCalc by boolPref("search_calc") { true }
    var searchActions by boolPref("search_actions") { true }
    var searchWeb by boolPref("search_web") { true }
    var searchSuggest by boolPref("search_suggest") { true }
    var searchKeepHistory by boolPref("search_keep_history") { true }
    var searchPromptDismissed by boolPref("search_perm_prompt_dismissed") { false }

    var searchHistory: List<String>
        get() = try {
            val a = org.json.JSONArray(sp.getString("search_history", "[]") ?: "[]")
            (0 until a.length()).map { a.optString(it) }.filter { it.isNotBlank() }
        } catch (_: Exception) { emptyList() }
        set(value) = sp.edit().putString("search_history", org.json.JSONArray(value.take(HISTORY_SIZE)).toString()).apply()

    fun addSearchHistory(query: String) {
        val q = query.trim()
        if (q.length < 2 || !searchKeepHistory) return
        searchHistory = listOf(q) + searchHistory.filter { !it.equals(q, ignoreCase = true) }
    }

    fun removeSearchHistory(query: String) { searchHistory = searchHistory.filter { it != query } }

    /** How often each app was opened, for search ranking and suggestions. */
    fun launchCounts(): Map<String, Int> = try {
        val o = JSONObject(sp.getString("launch_counts", "{}") ?: "{}")
        val out = HashMap<String, Int>()
        o.keys().forEach { k -> out[k] = o.optInt(k) }
        out
    } catch (_: Exception) { emptyMap() }

    fun recordLaunch(key: String) {
        val counts = HashMap(launchCounts())
        counts[key] = (counts[key] ?: 0) + 1
        val kept = counts.entries.sortedWith(Comparator { a, b -> b.value - a.value }).take(60)
        val o = JSONObject()
        kept.forEach { o.put(it.key, it.value) }
        sp.edit().putString("launch_counts", o.toString()).apply()
    }

    var hiddenApps: Set<String>
        get() = sp.getStringSet("hidden_apps", emptySet())?.toSet() ?: emptySet()
        set(value) = sp.edit().putStringSet("hidden_apps", value).apply()

    fun customLabel(key: String): String? = sp.getString("label|$key", null)?.takeIf { it.isNotBlank() }
    fun setCustomLabel(key: String, label: String?) {
        sp.edit().apply { if (label.isNullOrBlank()) remove("label|$key") else putString("label|$key", label) }.apply()
    }

    fun iconOverride(key: String): IconOverride? = sp.getString("icon|$key", null)?.let { IconOverride.fromJson(it) }
    fun setIconOverride(key: String, value: IconOverride?) {
        sp.edit().apply { if (value == null) remove("icon|$key") else putString("icon|$key", value.toJson()) }.apply()
    }

    fun resetAppearance() {
        val keep = setOf("home_model", "hidden_apps", "wallpaper_id", "search_history", "launch_counts")
        val e = sp.edit()
        sp.all.keys.filter { it !in keep && !it.startsWith("label|") && !it.startsWith("icon|") }.forEach { e.remove(it) }
        e.apply()
    }

    private fun intPref(key: String, def: () -> Int) = object : ReadWriteProperty<Any?, Int> {
        override fun getValue(thisRef: Any?, property: KProperty<*>) = sp.getInt(key, def())
        override fun setValue(thisRef: Any?, property: KProperty<*>, value: Int) = sp.edit().putInt(key, value).apply()
    }

    private fun boolPref(key: String, def: () -> Boolean) = object : ReadWriteProperty<Any?, Boolean> {
        override fun getValue(thisRef: Any?, property: KProperty<*>) = sp.getBoolean(key, def())
        override fun setValue(thisRef: Any?, property: KProperty<*>, value: Boolean) = sp.edit().putBoolean(key, value).apply()
    }

    private fun stringPref(key: String, def: () -> String) = object : ReadWriteProperty<Any?, String> {
        override fun getValue(thisRef: Any?, property: KProperty<*>) = sp.getString(key, null) ?: def()
        override fun setValue(thisRef: Any?, property: KProperty<*>, value: String) = sp.edit().putString(key, value).apply()
    }

    companion object {
        const val HISTORY_SIZE = 8
        val DEFAULT_ACCENT = Color.rgb(47, 123, 246)
        val ACCENTS = listOf(
            "Ocean blue" to Color.rgb(47, 123, 246),
            "ColorOS green" to Color.rgb(36, 186, 104),
            "Sunset orange" to Color.rgb(255, 128, 41),
            "Iris purple" to Color.rgb(132, 94, 247),
            "Coral pink" to Color.rgb(242, 80, 128),
            "Lagoon teal" to Color.rgb(24, 178, 172),
            "Graphite" to Color.rgb(120, 126, 140)
        )
    }
}

/** A per-app icon customization. */
data class IconOverride(
    val mode: String,            // "style", "pack", "image"
    val style: String = "",      // for mode=style
    val pack: String = "",       // for mode=pack
    val drawable: String = "",   // for mode=pack
    val file: String = ""        // for mode=image
) {
    fun toJson(): String = JSONObject()
        .put("mode", mode).put("style", style).put("pack", pack).put("drawable", drawable).put("file", file).toString()

    companion object {
        fun fromJson(s: String): IconOverride? = try {
            val o = JSONObject(s)
            IconOverride(o.optString("mode"), o.optString("style"), o.optString("pack"), o.optString("drawable"), o.optString("file"))
        } catch (_: Exception) { null }
    }
}
