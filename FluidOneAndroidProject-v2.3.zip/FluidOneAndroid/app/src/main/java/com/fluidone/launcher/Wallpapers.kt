package com.fluidone.launcher

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.BitmapShader
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.ImageDecoder
import android.graphics.LinearGradient
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Shader
import android.net.Uri
import android.view.View
import java.io.File
import java.io.FileOutputStream
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlin.random.Random

/** A soft colour field. Positions are fractions of width/height, radius is a fraction of width. */
class Blob(val x: Float, val y: Float, val r: Float, val color: Int)

/**
 * A flowing silk band. The centre line is a cubic bezier (fractions of width/height, may lie off-screen),
 * width is a fraction of screen width, colours run along the band.
 */
class Ribbon(
    val pts: FloatArray,
    val width: Float,
    val colors: IntArray,
    val twist: Float = 1.2f,
    val phase: Float = 0f,
    val glow: Float = 0.85f,
    val sheen: Float = 0.22f
)

/**
 * A piece of glass resting on the wallpaper: a rounded rectangle (or circle) that refracts what is behind it
 * like Fluid Glass. Centre is a fraction of width/height; [w] and [h] are fractions of the screen width so
 * circles stay round. [corner] is a fraction of half the short side (1 = pill / circle), [bevel] how much of
 * it curves (1 = a full dome, like a glass marble). A [solid] colour draws an opaque shape instead.
 */
class GlassShape(
    val x: Float, val y: Float, val w: Float, val h: Float,
    val corner: Float = 1f,
    val angle: Float = 0f,
    val bevel: Float = 0.5f,
    val frost: Float = 0f,
    val tint: Int = Color.TRANSPARENT,
    val solid: Int = Color.TRANSPARENT,
    val shadow: Float = 0.3f,
    val glint: Float = 0f
)

class WallpaperPreset(
    val id: String,
    val name: String,
    val background: IntArray,
    val blobs: List<Blob>,
    val ribbons: List<Ribbon>,
    val vignette: Float = 0.32f,
    val grain: Int = 9,
    val glass: List<GlassShape> = emptyList(),
    val stars: Int = 0
) {
    val hasGlass: Boolean get() = glass.any { Color.alpha(it.solid) == 0 }
}

object Wallpapers {
    const val DEFAULT_ID = "violet_horizon"
    const val GLASS_VERSION = 2
    const val CUSTOM_PREFIX = "custom:"

    val presets: List<WallpaperPreset> = listOf(
        WallpaperPreset(
            "violet_horizon", "Violet Horizon",
            intArrayOf(0xFF140F3A.toInt(), 0xFF2A1F66.toInt(), 0xFF0E0B2A.toInt()),
            listOf(Blob(0.15f, 0.18f, 0.9f, 0xFF5B3FD6.toInt()), Blob(0.95f, 0.55f, 0.8f, 0xFFE04E8F.toInt()), Blob(0.2f, 0.92f, 0.7f, 0xFF3A2C9A.toInt())),
            listOf(
                Ribbon(floatArrayOf(-0.35f, 0.70f, 0.25f, 0.38f, 0.75f, 0.78f, 1.35f, 0.46f), 0.62f,
                    intArrayOf(0xFFFF8A3D.toInt(), 0xFFFF4F7B.toInt(), 0xFFB04BFF.toInt(), 0xFF6A5CFF.toInt()), 1.4f, 0.1f),
                Ribbon(floatArrayOf(-0.3f, 0.86f, 0.35f, 0.66f, 0.7f, 1.02f, 1.3f, 0.80f), 0.34f,
                    intArrayOf(0xFFFFB067.toInt(), 0xFFFF6F91.toInt(), 0xFF8E5BFF.toInt()), 1.1f, 0.6f, 0.7f, 0.18f)
            )
        ),
        WallpaperPreset(
            "ember_silk", "Ember Silk",
            intArrayOf(0xFF1C0907.toInt(), 0xFF3B130B.toInt(), 0xFF0D0403.toInt()),
            listOf(Blob(0.85f, 0.2f, 0.8f, 0xFFB8361B.toInt()), Blob(0.1f, 0.7f, 0.9f, 0xFF7A1F2C.toInt())),
            listOf(
                Ribbon(floatArrayOf(1.3f, 0.30f, 0.6f, 0.62f, 0.3f, 0.30f, -0.3f, 0.66f), 0.55f,
                    intArrayOf(0xFFFFD27A.toInt(), 0xFFFF8A2B.toInt(), 0xFFE2412A.toInt(), 0xFF8E1F3A.toInt()), 1.6f, 0.3f),
                Ribbon(floatArrayOf(1.2f, 0.78f, 0.55f, 0.95f, 0.35f, 0.62f, -0.3f, 0.92f), 0.28f,
                    intArrayOf(0xFFFFB25C.toInt(), 0xFFF2553B.toInt(), 0xFF9A2443.toInt()), 1.2f, 0.2f, 0.75f, 0.2f)
            )
        ),
        WallpaperPreset(
            "glacier", "Glacier",
            intArrayOf(0xFF04122B.toInt(), 0xFF0A2E5E.toInt(), 0xFF030B1B.toInt()),
            listOf(Blob(0.8f, 0.15f, 0.9f, 0xFF1A6BD8.toInt()), Blob(0.1f, 0.65f, 0.8f, 0xFF0E8FB8.toInt())),
            listOf(
                Ribbon(floatArrayOf(-0.3f, 0.36f, 0.3f, 0.70f, 0.7f, 0.22f, 1.3f, 0.60f), 0.58f,
                    intArrayOf(0xFF8FF3FF.toInt(), 0xFF39B6FF.toInt(), 0xFF2F6BFF.toInt(), 0xFF5A3FE0.toInt()), 1.3f, 0.4f),
                Ribbon(floatArrayOf(-0.25f, 0.84f, 0.4f, 0.62f, 0.65f, 1.0f, 1.3f, 0.74f), 0.26f,
                    intArrayOf(0xFFA8FFF4.toInt(), 0xFF4FC3F7.toInt(), 0xFF3D5AFE.toInt()), 1.0f, 0.1f, 0.7f, 0.2f)
            )
        ),
        WallpaperPreset(
            "mint_flow", "Mint Flow",
            intArrayOf(0xFF03201B.toInt(), 0xFF07362E.toInt(), 0xFF021210.toInt()),
            listOf(Blob(0.2f, 0.25f, 0.8f, 0xFF11806B.toInt()), Blob(0.9f, 0.75f, 0.8f, 0xFF1C5E8C.toInt())),
            listOf(
                Ribbon(floatArrayOf(1.3f, 0.48f, 0.7f, 0.18f, 0.3f, 0.82f, -0.3f, 0.42f), 0.6f,
                    intArrayOf(0xFFC8FFB8.toInt(), 0xFF5CF2C0.toInt(), 0xFF1FB5A5.toInt(), 0xFF1D6E95.toInt()), 1.5f, 0.7f)
            )
        ),
        WallpaperPreset(
            "rose_quartz", "Rose Quartz",
            intArrayOf(0xFFF6E6EF.toInt(), 0xFFE8D6F3.toInt(), 0xFFD6D4F6.toInt()),
            listOf(Blob(0.85f, 0.2f, 0.7f, 0xFFFFC7D9.toInt()), Blob(0.1f, 0.8f, 0.8f, 0xFFB8C8FF.toInt())),
            listOf(
                Ribbon(floatArrayOf(-0.3f, 0.62f, 0.3f, 0.32f, 0.7f, 0.80f, 1.3f, 0.44f), 0.6f,
                    intArrayOf(0xFFFFB3C6.toInt(), 0xFFF59BD0.toInt(), 0xFFC4A6FF.toInt(), 0xFF9EC0FF.toInt()), 1.3f, 0.2f, 0.55f, 0.35f)
            ), vignette = 0.06f, grain = 6
        ),
        WallpaperPreset(
            "dusk_bloom", "Dusk Bloom",
            intArrayOf(0xFF1A1438.toInt(), 0xFF4A1E5E.toInt(), 0xFFF08A6A.toInt()),
            listOf(Blob(0.5f, 1.0f, 1.1f, 0xFFFFA16B.toInt()), Blob(0.9f, 0.35f, 0.7f, 0xFFB03E8C.toInt()), Blob(0.0f, 0.1f, 0.8f, 0xFF2B2A7A.toInt())),
            listOf(
                Ribbon(floatArrayOf(-0.3f, 0.52f, 0.3f, 0.80f, 0.7f, 0.40f, 1.3f, 0.70f), 0.5f,
                    intArrayOf(0xFFFFD0A1.toInt(), 0xFFFF7E8C.toInt(), 0xFFC452C9.toInt(), 0xFF6C4DE6.toInt()), 1.2f, 0.5f)
            )
        ),
        WallpaperPreset(
            "aurora", "Aurora",
            intArrayOf(0xFF020B12.toInt(), 0xFF06202A.toInt(), 0xFF01060A.toInt()),
            listOf(Blob(0.3f, 0.3f, 0.8f, 0xFF0B5E52.toInt()), Blob(0.85f, 0.6f, 0.7f, 0xFF3A1F78.toInt())),
            listOf(
                Ribbon(floatArrayOf(-0.3f, 0.20f, 0.2f, 0.62f, 0.8f, 0.10f, 1.3f, 0.52f), 0.42f,
                    intArrayOf(0xFF7CFFB2.toInt(), 0xFF2EE6C5.toInt(), 0xFF2F9BFF.toInt(), 0xFF7A4DFF.toInt()), 1.8f, 0.1f, 1.0f, 0.15f),
                Ribbon(floatArrayOf(1.3f, 0.70f, 0.6f, 0.50f, 0.4f, 0.96f, -0.3f, 0.74f), 0.24f,
                    intArrayOf(0xFF6BFFCE.toInt(), 0xFF2BC4E6.toInt(), 0xFF5B5CFF.toInt()), 1.4f, 0.3f, 0.9f, 0.12f)
            )
        ),
        WallpaperPreset(
            "graphite", "Graphite",
            intArrayOf(0xFF111214.toInt(), 0xFF1D1F24.toInt(), 0xFF08090A.toInt()),
            listOf(Blob(0.8f, 0.25f, 0.8f, 0xFF3B414D.toInt())),
            listOf(
                Ribbon(floatArrayOf(-0.3f, 0.45f, 0.3f, 0.78f, 0.75f, 0.32f, 1.3f, 0.66f), 0.5f,
                    intArrayOf(0xFFF4F6FA.toInt(), 0xFFAEB6C4.toInt(), 0xFF6B7385.toInt(), 0xFF3A3F4B.toInt()), 1.5f, 0.3f, 0.5f, 0.3f)
            ), vignette = 0.4f
        ),
        WallpaperPreset(
            "lagoon", "Lagoon",
            intArrayOf(0xFF061A2E.toInt(), 0xFF0B3D4F.toInt(), 0xFF140C30.toInt()),
            listOf(Blob(0.1f, 0.3f, 0.8f, 0xFF00A3A3.toInt()), Blob(0.9f, 0.85f, 0.9f, 0xFF6B2FD6.toInt())),
            listOf(
                Ribbon(floatArrayOf(1.3f, 0.26f, 0.65f, 0.60f, 0.35f, 0.22f, -0.3f, 0.58f), 0.48f,
                    intArrayOf(0xFF9BFFF0.toInt(), 0xFF2ED3D3.toInt(), 0xFF3C7BFF.toInt(), 0xFF8E4DFF.toInt()), 1.4f, 0.8f),
                Ribbon(floatArrayOf(-0.3f, 0.86f, 0.4f, 0.68f, 0.7f, 1.0f, 1.3f, 0.82f), 0.22f,
                    intArrayOf(0xFF7DF9FF.toInt(), 0xFF5A8CFF.toInt(), 0xFFB25CFF.toInt()), 1.0f, 0.4f, 0.8f, 0.18f)
            )
        ),
        WallpaperPreset(
            "midnight_amoled", "Midnight AMOLED",
            intArrayOf(0xFF000000.toInt(), 0xFF05040C.toInt(), 0xFF000000.toInt()),
            emptyList(),
            listOf(
                Ribbon(floatArrayOf(-0.3f, 0.58f, 0.35f, 0.40f, 0.65f, 0.76f, 1.3f, 0.52f), 0.36f,
                    intArrayOf(0xFF6E7BFF.toInt(), 0xFF9C5CFF.toInt(), 0xFFFF5CA8.toInt()), 1.6f, 0.2f, 0.6f, 0.2f)
            ), vignette = 0.0f, grain = 4
        ),

        // ---- 2.2: Fluid Glass wallpapers -----------------------------------------------------------------
        WallpaperPreset(
            "liquid_glass", "Liquid Glass",
            intArrayOf(0xFF0B0B10.toInt(), 0xFF16141F.toInt(), 0xFF050507.toInt()),
            listOf(Blob(0.9f, 0.2f, 0.7f, 0xFF3A2470.toInt()), Blob(0.1f, 0.85f, 0.7f, 0xFF5A1E3C.toInt())),
            listOf(
                Ribbon(floatArrayOf(-0.35f, 0.78f, 0.2f, 0.30f, 0.8f, 0.72f, 1.35f, 0.22f), 0.5f,
                    intArrayOf(0xFFFFB25C.toInt(), 0xFFFF5D7A.toInt(), 0xFFB24BFF.toInt(), 0xFF4F6BFF.toInt()), 1.5f, 0.2f, 0.8f, 0.24f)
            ),
            glass = listOf(
                GlassShape(0.60f, 0.43f, 0.86f, 0.30f, angle = -32f, bevel = 0.55f, shadow = 0.35f),
                GlassShape(0.27f, 0.64f, 0.52f, 0.19f, angle = -32f, bevel = 0.6f, shadow = 0.3f)
            )
        ),
        WallpaperPreset(
            "crimson_glass", "Crimson Glass",
            intArrayOf(0xFFB0141D.toInt(), 0xFFF0C2C8.toInt(), 0xFFF4EEEA.toInt()),
            listOf(Blob(0.5f, 0.0f, 1.0f, 0xFFC4121C.toInt()), Blob(0.5f, 0.6f, 0.85f, 0xFFFF5A62.toInt()),
                Blob(0.5f, 0.98f, 0.55f, 0xFF8EC4FF.toInt())),
            emptyList(),
            glass = listOf(
                GlassShape(0.5f, 0.24f, 1.18f, 1.18f, bevel = 0.55f, shadow = 0.1f),
                GlassShape(0.5f, 0.55f, 1.02f, 0.92f, corner = 0.62f, bevel = 0.6f, shadow = 0.14f),
                GlassShape(0.5f, 0.81f, 0.98f, 0.74f, corner = 0.92f, bevel = 0.7f, shadow = 0.12f)
            ), vignette = 0f, grain = 5
        ),
        WallpaperPreset(
            "azure_glass", "Azure Glass",
            intArrayOf(0xFF0A2F7A.toInt(), 0xFFB9D3F2.toInt(), 0xFFEEF2F8.toInt()),
            listOf(Blob(0.25f, 0.55f, 0.85f, 0xFF2F7BFF.toInt()), Blob(0.85f, 0.85f, 0.65f, 0xFFB48CFF.toInt()),
                Blob(0.7f, 0.1f, 0.8f, 0xFF0B4FC4.toInt())),
            emptyList(),
            glass = listOf(
                GlassShape(0.3f, 0.36f, 0.92f, 0.92f, bevel = 0.6f, shadow = 0.12f),
                GlassShape(0.74f, 0.52f, 0.92f, 0.92f, bevel = 0.6f, shadow = 0.14f),
                GlassShape(0.5f, 0.83f, 0.94f, 0.5f, bevel = 0.8f, shadow = 0.12f)
            ), vignette = 0f, grain = 5
        ),
        WallpaperPreset(
            "glass_orbs", "Glass Orbs",
            intArrayOf(0xFF1B1446.toInt(), 0xFF5A2470.toInt(), 0xFFF2896A.toInt()),
            listOf(Blob(0.85f, 0.25f, 0.8f, 0xFFE0508F.toInt()), Blob(0.1f, 0.5f, 0.8f, 0xFF4A3FD0.toInt()), Blob(0.6f, 1.0f, 1.0f, 0xFFFFB06B.toInt())),
            listOf(
                Ribbon(floatArrayOf(-0.3f, 0.48f, 0.3f, 0.76f, 0.7f, 0.36f, 1.3f, 0.66f), 0.36f,
                    intArrayOf(0xFFFFD7A0.toInt(), 0xFFFF7E9C.toInt(), 0xFFB45CFF.toInt()), 1.3f, 0.4f, 0.7f, 0.22f)
            ),
            glass = listOf(
                GlassShape(0.66f, 0.30f, 0.64f, 0.64f, bevel = 1f, shadow = 0.3f, glint = 1f),
                GlassShape(0.24f, 0.60f, 0.40f, 0.40f, bevel = 1f, shadow = 0.28f, glint = 1f),
                GlassShape(0.76f, 0.79f, 0.22f, 0.22f, bevel = 1f, shadow = 0.25f, glint = 1f)
            ), vignette = 0.2f
        ),
        WallpaperPreset(
            "prism", "Prism",
            intArrayOf(0xFFF7F5FB.toInt(), 0xFFEDE7F8.toInt(), 0xFFDCE4F7.toInt()),
            listOf(Blob(0.9f, 0.15f, 0.7f, 0xFFFFD6E4.toInt()), Blob(0.05f, 0.75f, 0.8f, 0xFFC9DAFF.toInt())),
            listOf(
                Ribbon(floatArrayOf(-0.3f, 0.30f, 0.3f, 0.66f, 0.7f, 0.30f, 1.3f, 0.70f), 0.46f,
                    intArrayOf(0xFFFF9EB5.toInt(), 0xFFFFC27A.toInt(), 0xFF8FE3C8.toInt(), 0xFF8AA8FF.toInt(), 0xFFC49BFF.toInt()), 1.2f, 0.3f, 0.45f, 0.32f)
            ),
            glass = listOf(
                GlassShape(0.52f, 0.46f, 0.52f, 1.12f, corner = 0.42f, angle = 16f, bevel = 0.5f, shadow = 0.12f)
            ), vignette = 0.04f, grain = 6
        ),
        WallpaperPreset(
            "frosted_cobalt", "Frosted Cobalt",
            intArrayOf(0xFF030A24.toInt(), 0xFF0A1F5C.toInt(), 0xFF020617.toInt()),
            listOf(Blob(0.85f, 0.2f, 0.8f, 0xFF1D4ED8.toInt()), Blob(0.1f, 0.75f, 0.8f, 0xFF0E7490.toInt())),
            listOf(
                Ribbon(floatArrayOf(1.3f, 0.30f, 0.6f, 0.68f, 0.35f, 0.24f, -0.3f, 0.62f), 0.56f,
                    intArrayOf(0xFF9BE7FF.toInt(), 0xFF38BDF8.toInt(), 0xFF2563EB.toInt(), 0xFF6D28D9.toInt()), 1.5f, 0.3f)
            ),
            glass = listOf(
                GlassShape(0.40f, 0.36f, 0.70f, 0.48f, corner = 0.32f, angle = -9f, bevel = 0.3f, frost = 0.85f, tint = 0x22FFFFFF, shadow = 0.35f),
                GlassShape(0.62f, 0.60f, 0.70f, 0.48f, corner = 0.32f, angle = 7f, bevel = 0.3f, frost = 0.6f, tint = 0x18FFFFFF, shadow = 0.4f)
            )
        ),
        WallpaperPreset(
            "ocean_lens", "Ocean Lens",
            intArrayOf(0xFF021B26.toInt(), 0xFF053B4A.toInt(), 0xFF020D14.toInt()),
            listOf(Blob(0.2f, 0.2f, 0.8f, 0xFF0E9AA7.toInt()), Blob(0.9f, 0.7f, 0.8f, 0xFF1E3A8A.toInt())),
            listOf(
                Ribbon(floatArrayOf(-0.3f, 0.40f, 0.3f, 0.72f, 0.7f, 0.26f, 1.3f, 0.58f), 0.5f,
                    intArrayOf(0xFFB5FFF1.toInt(), 0xFF3FE0D0.toInt(), 0xFF1EA7FF.toInt(), 0xFF3B4BDB.toInt()), 1.4f, 0.6f),
                Ribbon(floatArrayOf(1.3f, 0.80f, 0.6f, 0.62f, 0.4f, 0.98f, -0.3f, 0.76f), 0.24f,
                    intArrayOf(0xFF8CFFE6.toInt(), 0xFF22C3E6.toInt(), 0xFF4361EE.toInt()), 1.1f, 0.2f, 0.8f, 0.2f)
            ),
            glass = listOf(GlassShape(0.54f, 0.40f, 0.78f, 0.78f, bevel = 0.42f, shadow = 0.32f))
        ),
        WallpaperPreset(
            "silver_capsules", "Silver Capsules",
            intArrayOf(0xFFE9ECF1.toInt(), 0xFFCDD3DC.toInt(), 0xFF9EA6B3.toInt()),
            listOf(Blob(0.85f, 0.2f, 0.7f, 0xFFF7F9FC.toInt()), Blob(0.1f, 0.8f, 0.8f, 0xFF8C96A6.toInt())),
            listOf(
                Ribbon(floatArrayOf(-0.3f, 0.52f, 0.3f, 0.82f, 0.7f, 0.36f, 1.3f, 0.64f), 0.5f,
                    intArrayOf(0xFFFFFFFF.toInt(), 0xFFC6CCD6.toInt(), 0xFF7C8596.toInt(), 0xFF4A5262.toInt()), 1.4f, 0.3f, 0.45f, 0.34f)
            ),
            glass = listOf(
                GlassShape(0.25f, 0.25f, 0.46f, 0.16f, angle = 38f, bevel = 0.7f, shadow = 0.18f),
                GlassShape(0.70f, 0.50f, 0.66f, 0.21f, angle = 38f, bevel = 0.7f, shadow = 0.2f),
                GlassShape(0.36f, 0.76f, 0.42f, 0.15f, angle = 38f, bevel = 0.7f, shadow = 0.18f)
            ), vignette = 0.1f, grain = 6
        ),

        // ---- 2.2: more abstract wallpapers -----------------------------------------------------------------
        WallpaperPreset(
            "nebula", "Nebula",
            intArrayOf(0xFF05030F.toInt(), 0xFF120A2E.toInt(), 0xFF020108.toInt()),
            listOf(Blob(0.75f, 0.28f, 0.75f, 0xFF7A1FA2.toInt()), Blob(0.25f, 0.55f, 0.8f, 0xFF1F3FAF.toInt()), Blob(0.6f, 0.85f, 0.6f, 0xFFB0306A.toInt())),
            listOf(
                Ribbon(floatArrayOf(-0.3f, 0.66f, 0.3f, 0.40f, 0.7f, 0.70f, 1.3f, 0.36f), 0.3f,
                    intArrayOf(0xFFFF9AD5.toInt(), 0xFFB57BFF.toInt(), 0xFF6A8CFF.toInt()), 1.7f, 0.2f, 1.0f, 0.14f)
            ), vignette = 0.3f, grain = 5, stars = 260
        ),
        WallpaperPreset(
            "sakura", "Sakura",
            intArrayOf(0xFFFFF1F4.toInt(), 0xFFFBDDE6.toInt(), 0xFFF4D3E8.toInt()),
            listOf(Blob(0.15f, 0.2f, 0.7f, 0xFFFFC2D4.toInt()), Blob(0.9f, 0.8f, 0.8f, 0xFFE8C2F2.toInt())),
            listOf(
                Ribbon(floatArrayOf(1.3f, 0.36f, 0.65f, 0.70f, 0.3f, 0.30f, -0.3f, 0.66f), 0.58f,
                    intArrayOf(0xFFFFD1DC.toInt(), 0xFFFF9EB8.toInt(), 0xFFF06292.toInt(), 0xFFC2185B.toInt()), 1.3f, 0.4f, 0.5f, 0.3f)
            ), vignette = 0.05f, grain = 6
        ),
        WallpaperPreset(
            "emerald", "Emerald",
            intArrayOf(0xFF02140D.toInt(), 0xFF06301F.toInt(), 0xFF010A06.toInt()),
            listOf(Blob(0.85f, 0.25f, 0.8f, 0xFF0F7A4A.toInt()), Blob(0.15f, 0.8f, 0.8f, 0xFF3B5A12.toInt())),
            listOf(
                Ribbon(floatArrayOf(-0.3f, 0.34f, 0.3f, 0.70f, 0.7f, 0.24f, 1.3f, 0.62f), 0.54f,
                    intArrayOf(0xFFF4E3A1.toInt(), 0xFFB6E36A.toInt(), 0xFF2FBF71.toInt(), 0xFF0B6E4F.toInt()), 1.5f, 0.2f),
                Ribbon(floatArrayOf(1.3f, 0.82f, 0.6f, 0.66f, 0.35f, 1.0f, -0.3f, 0.80f), 0.22f,
                    intArrayOf(0xFFE8D27A.toInt(), 0xFF5ED38F.toInt(), 0xFF117A65.toInt()), 1.1f, 0.5f, 0.8f, 0.2f)
            )
        ),
        WallpaperPreset(
            "dune", "Dune",
            intArrayOf(0xFFF6E7D3.toInt(), 0xFFEBC9A3.toInt(), 0xFFB9774E.toInt()),
            listOf(Blob(0.85f, 0.15f, 0.7f, 0xFFFFF2DE.toInt()), Blob(0.1f, 0.9f, 0.9f, 0xFF9C4F2E.toInt())),
            listOf(
                Ribbon(floatArrayOf(-0.3f, 0.50f, 0.3f, 0.78f, 0.7f, 0.42f, 1.3f, 0.70f), 0.6f,
                    intArrayOf(0xFFFFE3B8.toInt(), 0xFFF0A868.toInt(), 0xFFC8643C.toInt(), 0xFF7E3420.toInt()), 1.3f, 0.3f, 0.55f, 0.3f)
            ), vignette = 0.12f, grain = 7
        ),
        WallpaperPreset(
            "neon_night", "Neon Night",
            intArrayOf(0xFF000000.toInt(), 0xFF07040F.toInt(), 0xFF000000.toInt()),
            emptyList(),
            listOf(
                Ribbon(floatArrayOf(-0.3f, 0.30f, 0.35f, 0.62f, 0.65f, 0.22f, 1.3f, 0.50f), 0.3f,
                    intArrayOf(0xFF00F0FF.toInt(), 0xFF2F7BFF.toInt(), 0xFF8A3DFF.toInt()), 1.6f, 0.2f, 1.0f, 0.2f),
                Ribbon(floatArrayOf(1.3f, 0.70f, 0.6f, 0.52f, 0.4f, 0.92f, -0.3f, 0.66f), 0.3f,
                    intArrayOf(0xFFFF3DCB.toInt(), 0xFFFF2E63.toInt(), 0xFFFF9B3D.toInt()), 1.4f, 0.6f, 1.0f, 0.2f)
            ), vignette = 0.0f, grain = 4
        )
    )

    fun preset(id: String): WallpaperPreset = presets.firstOrNull { it.id == id } ?: presets[0]

    /** Renders a preset at the given pixel size. Safe on a background thread. */
    fun render(preset: WallpaperPreset, w: Int, h: Int, seed: Int = preset.id.hashCode()): Bitmap {
        val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(out)
        val p = Paint(Paint.ANTI_ALIAS_FLAG or Paint.DITHER_FLAG)
        val wf = w.toFloat()
        val hf = h.toFloat()

        // 1. Vertical base gradient.
        p.shader = LinearGradient(0f, 0f, 0f, hf, preset.background, floatArrayOf(0f, 0.55f, 1f), Shader.TileMode.CLAMP)
        c.drawRect(0f, 0f, wf, hf, p)

        // 2. Mesh-like colour blobs.
        for (b in preset.blobs) {
            val r = b.r * wf
            p.shader = RadialGradient(b.x * wf, b.y * hf, r,
                intArrayOf(withAlpha(b.color, 0.85f), withAlpha(b.color, 0.35f), withAlpha(b.color, 0f)),
                floatArrayOf(0f, 0.45f, 1f), Shader.TileMode.CLAMP)
            c.drawCircle(b.x * wf, b.y * hf, r, p)
        }
        p.shader = null

        // 2b. Stars.
        if (preset.stars > 0) drawStars(c, preset.stars, wf, hf, seed)

        // 3. Silk ribbons: lit 3D meshes with a soft glow underneath.
        if (preset.ribbons.isNotEmpty()) {
            val layer = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
            val lc = Canvas(layer)
            for (ribbon in preset.ribbons) drawRibbon(lc, ribbon, wf, hf)
            val glow = BlurEngine.blur(layer, 0.125f, max(2, (w * 0.004f).roundToInt()))
            val bp = Paint(Paint.FILTER_BITMAP_FLAG or Paint.DITHER_FLAG)
            bp.alpha = (preset.ribbons.maxOf { it.glow } * 230).roundToInt().coerceIn(0, 255)
            c.drawBitmap(glow, null, RectF(0f, 0f, wf, hf), bp)
            glow.recycle()
            bp.alpha = 255
            c.drawBitmap(layer, 0f, 0f, bp)
            layer.recycle()
        }

        // 3b. Fluid Glass pieces that refract everything drawn so far.
        for (g in preset.glass) GlassRender.draw(out, c, g)

        // 4. Vignette for depth and icon legibility.
        if (preset.vignette > 0f) {
            p.shader = RadialGradient(wf / 2f, hf * 0.42f, max(wf, hf) * 0.78f,
                intArrayOf(Color.TRANSPARENT, Color.TRANSPARENT, Color.argb((preset.vignette * 255).roundToInt(), 0, 0, 0)),
                floatArrayOf(0f, 0.55f, 1f), Shader.TileMode.CLAMP)
            c.drawRect(0f, 0f, wf, hf, p)
            p.shader = null
        }

        // 5. Fine grain to prevent gradient banding on OLED panels.
        if (preset.grain > 0) {
            val tile = noiseTile(128, preset.grain, seed)
            p.shader = BitmapShader(tile, Shader.TileMode.REPEAT, Shader.TileMode.REPEAT)
            c.drawRect(0f, 0f, wf, hf, p)
            p.shader = null
        }
        return out
    }

    /**
     * Draws a ribbon as a triangle mesh. Across its width the band is treated as a rolled surface lit from the
     * upper left (diffuse + specular); along its length it twists, which narrows it, moves the highlight and
     * shows the slightly darker back face. Edges fade out for a soft, photographic finish.
     */
    private fun drawRibbon(c: Canvas, r: Ribbon, w: Float, h: Float) {
        val steps = 140
        val across = 24
        val p = r.pts
        val cols = across + 1
        val verts = FloatArray((steps + 1) * cols * 2)
        val colors = IntArray((steps + 1) * cols)
        val positions = FloatArray(r.colors.size) { it / (r.colors.size - 1f) }
        for (i in 0..steps) {
            val t = i / steps.toFloat()
            val u = 1 - t
            val x = (u * u * u * p[0] + 3 * u * u * t * p[2] + 3 * u * t * t * p[4] + t * t * t * p[6]) * w
            val y = (u * u * u * p[1] + 3 * u * u * t * p[3] + 3 * u * t * t * p[5] + t * t * t * p[7]) * h
            val dx = (3 * u * u * (p[2] - p[0]) + 6 * u * t * (p[4] - p[2]) + 3 * t * t * (p[6] - p[4])) * w
            val dy = (3 * u * u * (p[3] - p[1]) + 6 * u * t * (p[5] - p[3]) + 3 * t * t * (p[7] - p[5])) * h
            val len = max(1e-4f, hypot(dx, dy))
            val nx = -dy / len
            val ny = dx / len
            val phi = (t * r.twist + r.phase) * PI.toFloat()
            val cosPhi = kotlin.math.cos(phi)
            // Smooth |cos| so folds round off instead of pinching to a point.
            val e = 0.08f
            val fold = (kotlin.math.sqrt(cosPhi * cosPhi + e) - kotlin.math.sqrt(e)) / (kotlin.math.sqrt(1f + e) - kotlin.math.sqrt(e))
            val taper = 0.6f + 0.4f * sin(t * PI.toFloat())
            val half = r.width * w * 0.5f * (0.3f + 0.7f * fold) * taper
            val base = gradientAt(r.colors, positions, t)
            // Blend smoothly into the slightly darker back face as the ribbon turns over.
            val faceShade = 0.84f + 0.16f * smooth(-0.3f, 0.3f, cosPhi)
            val tilt = sin(phi) * 0.9f
            for (k in 0..across) {
                val v = -1f + 2f * k / across
                val idx = i * cols + k
                verts[idx * 2] = x + nx * half * v
                verts[idx * 2 + 1] = y + ny * half * v
                val angle = v * 1.05f + tilt
                val diffuse = max(0f, kotlin.math.cos(angle + 0.55f))
                val spec = max(0f, kotlin.math.cos(angle - 0.25f)).pow(22f) * (0.55f + 0.45f * fold)
                var light = 0.52f + 0.62f * diffuse
                light *= faceShade
                val edge = 1f - smooth(0.78f, 1f, abs(v))
                val rr = (Color.red(base) * light + 255 * spec * r.sheen * 2.2f).coerceIn(0f, 255f)
                val gg = (Color.green(base) * light + 255 * spec * r.sheen * 2.2f).coerceIn(0f, 255f)
                val bb = (Color.blue(base) * light + 255 * spec * r.sheen * 2.2f).coerceIn(0f, 255f)
                colors[idx] = Color.argb((edge * 245).roundToInt(), rr.roundToInt(), gg.roundToInt(), bb.roundToInt())
            }
        }
        val indices = ShortArray(steps * across * 6)
        var n = 0
        for (i in 0 until steps) for (k in 0 until across) {
            val a = (i * cols + k).toShort()
            val b = (i * cols + k + 1).toShort()
            val cc = ((i + 1) * cols + k).toShort()
            val d = ((i + 1) * cols + k + 1).toShort()
            indices[n++] = a; indices[n++] = b; indices[n++] = cc
            indices[n++] = b; indices[n++] = d; indices[n++] = cc
        }
        val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.DITHER_FLAG)
        c.drawVertices(Canvas.VertexMode.TRIANGLES, verts.size, verts, 0, null, 0, colors, 0, indices, 0, indices.size, paint)
    }

    private fun smooth(e0: Float, e1: Float, x: Float): Float {
        val t = ((x - e0) / (e1 - e0)).coerceIn(0f, 1f)
        return t * t * (3 - 2 * t)
    }

    private fun gradientAt(colors: IntArray, positions: FloatArray, t: Float): Int {
        if (t <= positions[0]) return colors[0]
        for (i in 1 until colors.size) {
            if (t <= positions[i]) {
                val f = (t - positions[i - 1]) / (positions[i] - positions[i - 1])
                return blendColors(colors[i - 1], colors[i], f)
            }
        }
        return colors.last()
    }

    private fun drawStars(c: Canvas, count: Int, w: Float, h: Float, seed: Int) {
        val rnd = Random(seed xor 0x5f3759df)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        val unit = w / 1080f
        repeat(count) {
            val x = rnd.nextFloat() * w
            val y = rnd.nextFloat() * h
            val big = rnd.nextFloat() < 0.06f
            val r = (if (big) 2.2f + rnd.nextFloat() * 1.6f else 0.6f + rnd.nextFloat() * 1.3f) * unit
            val a = if (big) 0.85f else 0.25f + rnd.nextFloat() * 0.55f
            val tint = when (rnd.nextInt(4)) { 0 -> Color.rgb(200, 215, 255); 1 -> Color.rgb(255, 225, 240); else -> Color.WHITE }
            if (big) {
                p.shader = RadialGradient(x, y, r * 5f, intArrayOf(withAlpha(tint, 0.5f), withAlpha(tint, 0f)), null, Shader.TileMode.CLAMP)
                c.drawCircle(x, y, r * 5f, p)
                p.shader = null
            }
            p.color = withAlpha(tint, a)
            c.drawCircle(x, y, r, p)
        }
    }

    private fun noiseTile(size: Int, strength: Int, seed: Int): Bitmap {
        val rnd = Random(seed)
        val px = IntArray(size * size) {
            val v = rnd.nextInt(256)
            val a = rnd.nextInt(strength + 1)
            Color.argb(a, v, v, v)
        }
        return Bitmap.createBitmap(px, size, size, Bitmap.Config.ARGB_8888)
    }
}

/**
 * Loads, renders and caches wallpapers. Rendering happens off the main thread; results are cached as
 * high quality JPEG files so later starts are instant.
 */
class WallpaperStore(private val context: Context) {
    private val dir = File(context.filesDir, "wallpapers").apply { mkdirs() }

    /** Glass wallpapers carry a render version, so improvements to the glass replace old cached images. */
    fun cacheFile(id: String, w: Int, h: Int): File {
        val version = if (Wallpapers.preset(id).glass.isNotEmpty()) "_g${Wallpapers.GLASS_VERSION}" else ""
        return File(dir, "${id.hashCode().toUInt().toString(16)}_${w}x$h$version.jpg")
    }

    /** Blocking. Call from a worker thread. */
    fun load(id: String, w: Int, h: Int): Bitmap? {
        if (id.startsWith(Wallpapers.CUSTOM_PREFIX)) {
            val file = File(id.removePrefix(Wallpapers.CUSTOM_PREFIX))
            return decodeFile(file, w, h)
        }
        val preset = Wallpapers.preset(id)
        val cached = cacheFile(preset.id, w, h)
        if (cached.exists()) decodeFile(cached, w, h)?.let { return it }
        return try {
            val bmp = Wallpapers.render(preset, w, h)
            try { FileOutputStream(cached).use { bmp.compress(Bitmap.CompressFormat.JPEG, 96, it) } } catch (_: Exception) { }
            bmp
        } catch (_: OutOfMemoryError) {
            Wallpapers.render(preset, w / 2, h / 2)
        }
    }

    /** Copies a picked image into private storage (decoded to screen size) and returns its id. Blocking. */
    fun importImage(uri: Uri, w: Int, h: Int): String? = try {
        val src = ImageDecoder.createSource(context.contentResolver, uri)
        val bmp = ImageDecoder.decodeBitmap(src) { decoder, info, _ ->
            decoder.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
            val s = max(w / info.size.width.toFloat(), h / info.size.height.toFloat()).coerceAtMost(1f)
            decoder.setTargetSize(max(1, (info.size.width * s).roundToInt()), max(1, (info.size.height * s).roundToInt()))
        }
        val file = File(dir, "custom_${System.currentTimeMillis()}.jpg")
        FileOutputStream(file).use { bmp.compress(Bitmap.CompressFormat.JPEG, 95, it) }
        dir.listFiles()?.filter { it.name.startsWith("custom_") && it != file }?.forEach { it.delete() }
        Wallpapers.CUSTOM_PREFIX + file.absolutePath
    } catch (_: Exception) { null }

    private fun decodeFile(file: File, w: Int, h: Int): Bitmap? = try {
        if (!file.exists()) null else {
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeFile(file.absolutePath, bounds)
            var sample = 1
            while (bounds.outWidth / (sample * 2) >= w && bounds.outHeight / (sample * 2) >= h) sample *= 2
            BitmapFactory.decodeFile(file.absolutePath, BitmapFactory.Options().apply {
                inSampleSize = sample
                inPreferredConfig = Bitmap.Config.ARGB_8888
            })
        }
    } catch (_: Exception) { null } catch (_: OutOfMemoryError) { null }
}

/**
 * Draws the wallpaper with ColorOS-style depth: parallax across pages, zoom during unlock/app launch and a
 * smooth blur crossfade for menus, folders, the drawer and edit mode. Glass surfaces sample [glass].
 */
class WallpaperView(context: Context) : View(context) {
    private var bitmap: Bitmap? = null
    private var previous: Bitmap? = null
    private var previousAlpha = 0f
    var glass: Bitmap? = null
        private set
    private var heavy: Bitmap? = null

    var blurAmount = 0f
        set(v) { val c = clamp01(v); if (field != c) { field = c; invalidate() } }
    var dim = 0f
        set(v) { val c = clamp01(v); if (field != c) { field = c; invalidate() } }
    var zoom = 1f
        set(v) { if (field != v) { field = v; invalidate(); onGeometryChanged?.invoke() } }
    /** 0 = first page, 1 = last page. */
    var parallaxFraction = 0.5f
        set(v) { if (field != v) { field = v; invalidate(); onGeometryChanged?.invoke() } }
    var parallaxEnabled = true
        set(v) { field = v; invalidate(); onGeometryChanged?.invoke() }
    var onGeometryChanged: (() -> Unit)? = null

    /** True when the wallpaper is bright behind the home screen, so labels should turn dark. */
    var isLight = false
        private set
    var isLightAtTop = false
        private set

    private val paint = Paint(Paint.FILTER_BITMAP_FLAG or Paint.DITHER_FLAG)
    private val tmp = Matrix()
    private val glassPaint = Paint(Paint.FILTER_BITMAP_FLAG or Paint.DITHER_FLAG).apply {
        colorFilter = ColorMatrixColorFilter(ColorMatrix().apply { setSaturation(1.35f) })
    }

    val hasWallpaper: Boolean get() = bitmap != null

    fun setWallpaper(sharp: Bitmap, glassBlur: Bitmap, heavyBlur: Bitmap, animate: Boolean) {
        if (animate && bitmap != null) {
            previous = bitmap
            previousAlpha = 1f
            Motion.animate(420, Motion.standard, update = { previousAlpha = 1f - it; invalidate() }, end = {
                previous = null; invalidate()
            })
        }
        bitmap = sharp
        glass = glassBlur
        heavy = heavyBlur
        analyse(sharp)
        invalidate()
        onGeometryChanged?.invoke()
    }

    private fun analyse(b: Bitmap) {
        val small = Bitmap.createScaledBitmap(b, 24, 48, true)
        var top = 0f; var body = 0f; var tc = 0; var bc = 0
        for (y in 0 until 48) for (x in 0 until 24) {
            val l = luminance(small.getPixel(x, y))
            if (y < 5) { top += l; tc++ } else if (y > 12) { body += l; bc++ }
        }
        isLightAtTop = top / max(1, tc) > 0.66f
        isLight = body / max(1, bc) > 0.68f
        if (small != b) small.recycle()
    }

    /** Maps wallpaper bitmap pixels to this view's local coordinates. */
    fun computeMatrix(bw: Int, bh: Int, out: Matrix) {
        val vw = max(1, width).toFloat()
        val vh = max(1, height).toFloat()
        val overscan = if (parallaxEnabled) 1.08f else 1f
        val s = max(vw / bw, vh / bh) * overscan * zoom
        val drawnW = bw * s
        val drawnH = bh * s
        val spare = (drawnW - vw) / 2f
        val parallax = if (parallaxEnabled) spare * (1f - 2f * parallaxFraction.coerceIn(0f, 1f)) * 0.75f else 0f
        out.reset()
        out.setScale(s, s)
        out.postTranslate((vw - drawnW) / 2f + parallax, (vh - drawnH) / 2f)
    }

    override fun onDraw(canvas: Canvas) {
        val b = bitmap
        if (b == null || b.isRecycled) {
            canvas.drawColor(Color.rgb(12, 10, 30))
            return
        }
        computeMatrix(b.width, b.height, tmp)
        paint.alpha = 255
        canvas.drawBitmap(b, tmp, paint)
        val prev = previous
        if (prev != null && !prev.isRecycled && previousAlpha > 0f) {
            computeMatrix(prev.width, prev.height, tmp)
            paint.alpha = (previousAlpha * 255).roundToInt()
            canvas.drawBitmap(prev, tmp, paint)
            paint.alpha = 255
        }
        val hv = heavy
        if (blurAmount > 0.001f && hv != null) {
            computeMatrix(b.width, b.height, tmp)
            tmp.preScale(b.width / hv.width.toFloat(), b.height / hv.height.toFloat())
            paint.alpha = (blurAmount * 255).roundToInt()
            canvas.drawBitmap(hv, tmp, paint)
            paint.alpha = 255
        }
        if (dim > 0.001f) canvas.drawColor(Color.argb((dim * 255).roundToInt(), 0, 0, 0))
    }

    private val g1 = Matrix()
    private val g2 = Matrix()
    private val inv = Matrix()

    /**
     * Draws the blurred wallpaper into [target]'s canvas so it lines up exactly with the wallpaper on
     * screen, whatever transforms (page scroll, edit-mode scaling, folder zoom) the target has.
     */
    private val sharpTmp = Matrix()

    /**
     * Fluid Glass inputs for [target]: the sharp and blurred wallpaper with matrices mapping each bitmap into
     * the target's local coordinates. Also records where the target is, like [drawGlass].
     */
    fun glassSources(target: View, heavyBlur: Boolean, sharpOut: Matrix, blurOut: Matrix): Array<Bitmap>? {
        val b = bitmap ?: return null
        val src = (if (heavyBlur) heavy else glass) ?: return null
        if (src.isRecycled || b.isRecycled || !target.isAttachedToWindow || !isAttachedToWindow) return null
        g1.reset(); target.transformMatrixToGlobal(g1)
        val stamp = (target.getTag(R.id.tag_glass_matrix) as? FloatArray) ?: FloatArray(9).also { target.setTag(R.id.tag_glass_matrix, it) }
        g1.getValues(stamp)
        g2.reset(); transformMatrixToGlobal(g2)
        if (!g1.invert(inv)) return null
        computeMatrix(b.width, b.height, sharpTmp)
        sharpOut.set(sharpTmp); sharpOut.postConcat(g2); sharpOut.postConcat(inv)
        blurOut.set(sharpTmp); blurOut.preScale(b.width / src.width.toFloat(), b.height / src.height.toFloat())
        blurOut.postConcat(g2); blurOut.postConcat(inv)
        return arrayOf(b, src)
    }

    fun drawGlass(canvas: Canvas, target: View, heavyBlur: Boolean = false): Boolean {
        val b = bitmap ?: return false
        val src = (if (heavyBlur) heavy else glass) ?: return false
        if (src.isRecycled || b.isRecycled || !target.isAttachedToWindow || !isAttachedToWindow) return false
        computeMatrix(b.width, b.height, tmp)
        tmp.preScale(b.width / src.width.toFloat(), b.height / src.height.toFloat())
        g1.reset(); target.transformMatrixToGlobal(g1)
        // Remember where the target was when it was drawn; the launcher redraws it if it moves later.
        val stamp = (target.getTag(R.id.tag_glass_matrix) as? FloatArray) ?: FloatArray(9).also { target.setTag(R.id.tag_glass_matrix, it) }
        g1.getValues(stamp)
        g2.reset(); transformMatrixToGlobal(g2)
        if (!g1.invert(inv)) return false
        tmp.postConcat(g2)
        tmp.postConcat(inv)
        canvas.drawBitmap(src, tmp, glassPaint)
        return true
    }

    /** Average colour of the blurred wallpaper under a screen rect; used to tint morphs and labels. */
    fun sampleColor(screen: Rect): Int {
        val src = glass ?: return Color.DKGRAY
        val b = bitmap ?: return Color.DKGRAY
        computeMatrix(b.width, b.height, tmp)
        tmp.preScale(b.width / src.width.toFloat(), b.height / src.height.toFloat())
        val inverse = Matrix()
        if (!tmp.invert(inverse)) return Color.DKGRAY
        val pts = floatArrayOf(screen.exactCenterX(), screen.exactCenterY())
        inverse.mapPoints(pts)
        val x = pts[0].roundToInt().coerceIn(0, src.width - 1)
        val y = pts[1].roundToInt().coerceIn(0, src.height - 1)
        return src.getPixel(x, y)
    }

    fun thumbnailSource(): Bitmap? = bitmap

    companion object {
        /** Blur parameters derived from the user's 0..100 strength. */
        fun glassRadius(strength: Int): Int = (2 + strength * 0.1f).roundToInt()
        fun heavyRadius(strength: Int): Int = (4 + strength * 0.12f).roundToInt()
        const val GLASS_SCALE = 0.125f
        const val HEAVY_SCALE = 0.1f
        fun minDim(a: Int, b: Int) = min(a, b)
    }
}
