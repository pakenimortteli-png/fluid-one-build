package com.fluidone.launcher

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.text.TextPaint
import android.text.TextUtils
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import kotlin.math.abs
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * An app icon with label. Drawn directly (no nested views) so pages with many icons stay at 120 Hz.
 * Press: icon eases down to 90% and darkens slightly, then springs back, like ColorOS.
 */
open class IconView(context: Context) : View(context) {
    var bitmap: Bitmap? = null
        set(v) { field = v; invalidate() }
    var label: String = ""
        set(v) { field = v; ellipsized = null; invalidate() }
    var showLabel = true
        set(v) { field = v; requestLayout(); invalidate() }
    var iconSize = dpi(56)
        set(v) { if (field != v) { field = v; requestLayout(); invalidate() } }
    var darkLabel = false
        set(v) { field = v; updateTextPaint(); invalidate() }

    var item: HomeItem? = null
    var entry: AppEntry? = null
    var source = SOURCE_WORKSPACE
    /** For icons inside an open folder: the folder item. */
    var folder: HomeItem? = null

    var onTap: ((IconView, Float, Float) -> Unit)? = null
    var onLongPress: ((IconView) -> Unit)? = null

    /** 0..1: animated folder-creation plate shown while another icon hovers on this one. */
    var hoverPlate = 0f
        set(v) { field = v; invalidate() }
    var iconAlpha = 1f
        set(v) { field = v; invalidate() }
    var hoverScale = 1f
        set(v) { field = v; invalidate() }
    private var hoverAnim: ValueAnimator? = null

    /**
     * Shows or hides the folder-creation plate. One animator per icon: a new request always cancels the
     * previous one, so a hover that ends mid-animation can never leave the plate stuck on.
     */
    fun animateHover(on: Boolean) {
        hoverAnim?.cancel()
        val from = hoverPlate
        val to = if (on) 1f else 0f
        if (from == to) { hoverScale = 1f + 0.06f * to; return }
        val spring = if (on) Spring(0.7f, 0.32f) else Spring(1f, 0.2f)
        hoverAnim = ValueAnimator.ofFloat(from, to).apply {
            duration = spring.ms
            interpolator = spring
            addUpdateListener { val p = it.animatedValue as Float; hoverPlate = p.coerceAtLeast(0f); hoverScale = 1f + 0.06f * p }
            addListener(object : android.animation.AnimatorListenerAdapter() {
                private var cancelled = false
                override fun onAnimationCancel(animation: android.animation.Animator) { cancelled = true }
                override fun onAnimationEnd(animation: android.animation.Animator) {
                    if (!cancelled) { hoverPlate = to; hoverScale = 1f + 0.06f * to }
                }
            })
            start()
        }
    }

    /** Clears any folder-hover state immediately. */
    fun resetHover() {
        hoverAnim?.cancel()
        hoverAnim = null
        if (hoverPlate != 0f) hoverPlate = 0f
        if (hoverScale != 1f) hoverScale = 1f
    }

    protected val textPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { typeface = Fonts.medium }
    private val bmpPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val platePaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val shadePaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private var ellipsized: CharSequence? = null
    private var press = 0f
    private var pressAnim: ValueAnimator? = null
    private val dst = RectF()
    protected val iconRect = RectF()

    private val touchSlop = ViewConfiguration.get(context).scaledTouchSlop
    private val longPressTimeout = min(ViewConfiguration.getLongPressTimeout(), 380).toLong()
    private var downX = 0f
    private var downY = 0f
    private var longPressed = false
    private var tracking = false
    private val longPressRunnable = Runnable {
        if (tracking) {
            longPressed = true
            setPressedState(false)
            onLongPress?.invoke(this)
        }
    }

    init {
        isClickable = true
        isFocusable = true
        updateTextPaint()
    }

    private fun updateTextPaint() {
        textPaint.color = if (darkLabel) Color.argb(230, 20, 20, 24) else Color.WHITE
        if (darkLabel) textPaint.clearShadowLayer() else textPaint.setShadowLayer(dp(3f), 0f, dp(0.5f), Color.argb(120, 0, 0, 0))
    }

    fun setLabelSizeSp(sp: Float) {
        textPaint.textSize = android.util.TypedValue.applyDimension(android.util.TypedValue.COMPLEX_UNIT_SP, sp, resources.displayMetrics)
        ellipsized = null
        requestLayout(); invalidate()
    }

    protected val labelHeight: Float get() = if (showLabel) textPaint.fontSpacing + dp(6f) else 0f

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val w = MeasureSpec.getSize(widthMeasureSpec)
        val contentH = (iconSize + labelHeight + dp(4f)).roundToInt()
        val h = when (MeasureSpec.getMode(heightMeasureSpec)) {
            MeasureSpec.EXACTLY -> MeasureSpec.getSize(heightMeasureSpec)
            MeasureSpec.AT_MOST -> min(contentH, MeasureSpec.getSize(heightMeasureSpec))
            else -> contentH
        }
        setMeasuredDimension(if (MeasureSpec.getMode(widthMeasureSpec) == MeasureSpec.UNSPECIFIED) iconSize + dpi(16) else w, h)
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        ellipsized = null
    }

    /** Icon bounds in local coordinates. */
    open fun computeIconRect(out: RectF) {
        val contentH = iconSize + labelHeight
        val top = ((height - contentH) / 2f).coerceAtLeast(0f)
        val left = (width - iconSize) / 2f
        out.set(left, top, left + iconSize, top + iconSize)
    }

    /** Icon bounds in window coordinates (accounts for page scroll, edit-mode scale, etc.). */
    fun iconRectInWindow(): RectF {
        val r = RectF()
        computeIconRect(r)
        val m = Matrix()
        transformMatrixToGlobal(m)
        m.mapRect(r)
        return r
    }

    override fun onDraw(canvas: Canvas) {
        computeIconRect(iconRect)
        val s = (1f - 0.1f * press) * hoverScale
        if (hoverPlate > 0f) drawHoverPlate(canvas)
        canvas.save()
        canvas.scale(s, s, iconRect.centerX(), iconRect.centerY())
        drawIcon(canvas, iconRect)
        if (press > 0f) {
            shadePaint.color = Color.argb((press * 50).roundToInt(), 0, 0, 0)
            val path = IconShapes.path(launcherShape(), iconRect.width(), Path(), iconRect.left, iconRect.top)
            canvas.drawPath(path, shadePaint)
        }
        canvas.restore()
        if (showLabel && label.isNotEmpty() && iconAlpha > 0f) {
            val avail = width - dp(4f)
            val text = ellipsized ?: TextUtils.ellipsize(label, textPaint, avail, TextUtils.TruncateAt.END).also { ellipsized = it }
            val tw = textPaint.measureText(text, 0, text.length)
            val baseline = iconRect.bottom + dp(6f) - textPaint.ascent()
            textPaint.alpha = (iconAlpha * 255).roundToInt()
            canvas.drawText(text, 0, text.length, (width - tw) / 2f, baseline, textPaint)
        }
    }

    private fun drawHoverPlate(canvas: Canvas) {
        val grow = iconSize * (0.12f + 0.16f * hoverPlate)
        val r = RectF(iconRect.left - grow, iconRect.top - grow, iconRect.right + grow, iconRect.bottom + grow)
        platePaint.color = Color.argb((hoverPlate * 90).roundToInt(), 255, 255, 255)
        val radius = r.width() * 0.26f
        canvas.drawRoundRect(r, radius, radius, platePaint)
    }

    protected open fun drawIcon(canvas: Canvas, r: RectF) {
        val b = bitmap
        if (b == null) {
            // Still being built in the background: a faint plate keeps the grid calm.
            shadePaint.color = Color.argb((iconAlpha * 34).roundToInt(), 255, 255, 255)
            canvas.drawPath(IconShapes.path(launcherShape(), r.width(), Path(), r.left, r.top), shadePaint)
            return
        }
        bmpPaint.alpha = (iconAlpha * 255).roundToInt()
        dst.set(r)
        canvas.drawBitmap(b, null, dst, bmpPaint)
    }

    protected fun launcherShape(): String = (context as? MainActivity)?.prefs?.iconShape ?: "squircle"

    private fun setPressedState(down: Boolean) {
        pressAnim?.cancel()
        val from = press
        val to = if (down) 1f else 0f
        if (from == to) return
        pressAnim = ValueAnimator.ofFloat(from, to).apply {
            duration = if (down) 110L else 320L
            interpolator = if (down) Motion.decel else Spring(0.55f, 0.3f)
            addUpdateListener { press = it.animatedValue as Float; invalidate() }
            start()
        }
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        if (!isEnabled) return false
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downX = event.x; downY = event.y
                longPressed = false
                tracking = true
                setPressedState(true)
                if (onLongPress != null) postDelayed(longPressRunnable, longPressTimeout)
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                if (tracking && (abs(event.x - downX) > touchSlop || abs(event.y - downY) > touchSlop)) {
                    if (!longPressed) {
                        removeCallbacks(longPressRunnable)
                        tracking = false
                        setPressedState(false)
                    }
                }
            }
            MotionEvent.ACTION_UP -> {
                removeCallbacks(longPressRunnable)
                val wasTracking = tracking
                tracking = false
                setPressedState(false)
                if (wasTracking && !longPressed) {
                    playSoundEffect(android.view.SoundEffectConstants.CLICK)
                    onTap?.invoke(this, event.x, event.y)
                }
            }
            MotionEvent.ACTION_CANCEL -> {
                removeCallbacks(longPressRunnable)
                tracking = false
                setPressedState(false)
            }
        }
        return true
    }

    override fun onHoverEvent(event: MotionEvent): Boolean {
        val launcher = context as? MainActivity
        if (launcher != null && launcher.spenHoverEnabled() && event.getToolType(0) == MotionEvent.TOOL_TYPE_STYLUS) {
            when (event.actionMasked) {
                MotionEvent.ACTION_HOVER_ENTER -> animate().scaleX(1.08f).scaleY(1.08f).setDuration(160).setInterpolator(Motion.decel).start()
                MotionEvent.ACTION_HOVER_EXIT -> animate().scaleX(1f).scaleY(1f).setDuration(220).setInterpolator(Motion.decel).start()
            }
        }
        return super.onHoverEvent(event)
    }

    /** S25 Ultra: pressing the S Pen button while hovering an icon opens its menu, like a long press. */
    override fun onGenericMotionEvent(event: MotionEvent): Boolean {
        val launcher = context as? MainActivity
        if (launcher != null && launcher.spenButtonEnabled() && event.actionMasked == MotionEvent.ACTION_BUTTON_PRESS &&
            event.getToolType(0) == MotionEvent.TOOL_TYPE_STYLUS && (event.buttonState and MotionEvent.BUTTON_STYLUS_PRIMARY) != 0) {
            onLongPress?.let { it(this); return true }
        }
        return super.onGenericMotionEvent(event)
    }

    override fun onDetachedFromWindow() {
        removeCallbacks(longPressRunnable)
        pressAnim?.cancel()
        resetHover()
        super.onDetachedFromWindow()
    }

    companion object {
        const val SOURCE_WORKSPACE = 0
        const val SOURCE_DOCK = 1
        const val SOURCE_DRAWER = 2
        const val SOURCE_FOLDER = 3
    }
}

/**
 * Folder icon: a frosted plate (real wallpaper blur) holding a 3x3 preview. Large (2x2) folders behave like
 * ColorOS large folders: the first eight apps can be launched directly, the last tile opens the folder.
 */
class FolderIconView(context: Context, private val launcher: MainActivity) : IconView(context) {
    private val platePath = Path()
    private val plateRect = RectF()
    private val tint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val bmp = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val tmp = RectF()

    val isLarge: Boolean get() = item?.isLargeFolder == true
    private val painter = GlassPainter(context)
    private val sharpMatrix = android.graphics.Matrix()
    private val blurMatrix = android.graphics.Matrix()

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        launcher.registerGlass(this)
    }

    override fun onDetachedFromWindow() {
        launcher.unregisterGlass(this)
        super.onDetachedFromWindow()
    }

    override fun computeIconRect(out: RectF) {
        if (!isLarge) { super.computeIconRect(out); return }
        val size = min(width - dp(14f), height - labelHeight - dp(10f))
        val top = ((height - size - labelHeight) / 2f).coerceAtLeast(0f)
        out.set((width - size) / 2f, top, (width + size) / 2f, top + size)
    }

    override fun drawIcon(canvas: Canvas, r: RectF) {
        val folder = item ?: return
        plateRect.set(r)
        val radius = r.width() * if (isLarge) 0.2f else 0.26f
        platePath.reset()
        platePath.addRoundRect(plateRect, radius, radius, Path.Direction.CW)
        val plateTint = if (launcher.wallpaperIsLight) Color.argb(110, 255, 255, 255) else Color.argb(70, 255, 255, 255)
        val fluid = launcher.fluidIntensity(GlassView.Style.HOME)
        val sources = if (fluid > 0f && iconAlpha >= 1f) launcher.wallpaperView.glassSources(this, false, sharpMatrix, blurMatrix) else null
        if (sources == null || !painter.draw(canvas, plateRect, radius, fluid, plateTint, sources[0], sharpMatrix, sources[1], blurMatrix)) {
            val save = canvas.save()
            canvas.clipPath(platePath)
            launcher.wallpaperView.drawGlass(canvas, this)
            tint.color = plateTint
            tint.alpha = (Color.alpha(plateTint) * iconAlpha).roundToInt()
            canvas.drawRect(plateRect, tint)
            canvas.restoreToCount(save)
            stroke.strokeWidth = dp(0.8f)
            stroke.color = Color.argb((60 * iconAlpha).roundToInt(), 255, 255, 255)
            canvas.drawRoundRect(plateRect, radius, radius, stroke)
        }

        val apps = folder.apps.mapNotNull { launcher.apps[it] }
        val pad = r.width() * if (isLarge) 0.1f else 0.14f
        val gap = r.width() * if (isLarge) 0.06f else 0.05f
        val cell = (r.width() - 2 * pad - 2 * gap) / 3f
        val sizePx = cell.roundToInt().coerceAtLeast(8)
        bmp.alpha = (iconAlpha * 255).roundToInt()
        for (i in 0 until min(9, apps.size)) {
            val cx = i % 3; val cy = i / 3
            tmp.set(r.left + pad + cx * (cell + gap), r.top + pad + cy * (cell + gap), 0f, 0f)
            tmp.right = tmp.left + cell; tmp.bottom = tmp.top + cell
            if (isLarge && i == 8 && apps.size > 9) {
                drawOverflow(canvas, apps.subList(8, min(12, apps.size)), tmp)
                continue
            }
            canvas.drawBitmap(launcher.icons.appIcon(apps[i], sizePx), null, tmp, bmp)
        }
    }

    private fun drawOverflow(canvas: Canvas, apps: List<AppEntry>, r: RectF) {
        val half = r.width() / 2f - dp(1f)
        val size = half.roundToInt().coerceAtLeast(6)
        apps.forEachIndexed { i, entry ->
            val x = r.left + (i % 2) * (half + dp(2f))
            val y = r.top + (i / 2) * (half + dp(2f))
            canvas.drawBitmap(launcher.icons.appIcon(entry, size), null, RectF(x, y, x + half, y + half), bmp)
        }
    }

    /** For large folders: index of the preview app under a local point, or -1 to open the folder. */
    fun appIndexAt(x: Float, y: Float): Int {
        if (!isLarge) return -1
        val r = RectF(); computeIconRect(r)
        val pad = r.width() * 0.1f
        val gap = r.width() * 0.06f
        val cell = (r.width() - 2 * pad - 2 * gap) / 3f
        val cx = ((x - r.left - pad) / (cell + gap)).toInt()
        val cy = ((y - r.top - pad) / (cell + gap)).toInt()
        if (x < r.left + pad || y < r.top + pad || cx !in 0..2 || cy !in 0..2) return -1
        val index = cy * 3 + cx
        val count = item?.apps?.size ?: 0
        if (index == 8 && count > 9) return -1
        return if (index < count) index else -1
    }

    /** Window rect of one preview tile (for launch morphs from a large folder). */
    fun previewRectInWindow(index: Int): RectF {
        val r = RectF(); computeIconRect(r)
        val pad = r.width() * 0.1f
        val gap = r.width() * 0.06f
        val cell = (r.width() - 2 * pad - 2 * gap) / 3f
        val left = r.left + pad + (index % 3) * (cell + gap)
        val top = r.top + pad + (index / 3) * (cell + gap)
        val out = RectF(left, top, left + cell, top + cell)
        val m = Matrix(); transformMatrixToGlobal(m); m.mapRect(out)
        return out
    }
}
