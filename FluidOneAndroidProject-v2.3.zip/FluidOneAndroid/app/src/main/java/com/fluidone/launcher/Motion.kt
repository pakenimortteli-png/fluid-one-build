package com.fluidone.launcher

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.TimeInterpolator
import android.animation.ValueAnimator
import android.view.animation.PathInterpolator
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.ln
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * Motion vocabulary modelled on ColorOS: short, decisive movement curves plus physically based springs.
 * Every duration passes through [d] so the user's animation-speed setting applies everywhere.
 */
object Motion {
    /** 1.0 = normal. Smaller is faster. */
    var speed = 1f

    /** ColorOS "move ease" (0.3, 0, 0.1, 1): used for most positional motion. */
    val move: TimeInterpolator = PathInterpolator(0.3f, 0f, 0.1f, 1f)
    /** Emphasized deceleration: fast start, long gentle settle. */
    val emphasized: TimeInterpolator = PathInterpolator(0.2f, 0f, 0f, 1f)
    val standard: TimeInterpolator = PathInterpolator(0.33f, 0f, 0.67f, 1f)
    val decel: TimeInterpolator = PathInterpolator(0f, 0f, 0.2f, 1f)
    val accel: TimeInterpolator = PathInterpolator(0.4f, 0f, 1f, 1f)
    val sharp: TimeInterpolator = PathInterpolator(0.4f, 0f, 0.2f, 1f)
    val linear: TimeInterpolator = TimeInterpolator { it }

    fun d(ms: Long): Long = (ms * speed).toLong().coerceAtLeast(1L)

    /** Spring presets (damping ratio, response seconds). */
    val springSoft get() = Spring(0.86f, 0.42f)
    val springBouncy get() = Spring(0.72f, 0.38f)
    val springSnappy get() = Spring(0.9f, 0.3f)
    val springGentle get() = Spring(0.95f, 0.5f)

    /** Runs [update] with a value from 0 to 1 on the given curve. */
    fun animate(
        durationMs: Long,
        interpolator: TimeInterpolator,
        delayMs: Long = 0L,
        update: (Float) -> Unit,
        end: (() -> Unit)? = null
    ): ValueAnimator = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = d(durationMs)
        startDelay = d(delayMs)
        this.interpolator = interpolator
        addUpdateListener { update(it.animatedValue as Float) }
        if (end != null) addListener(object : AnimatorListenerAdapter() {
            private var done = false
            override fun onAnimationEnd(animation: Animator) { if (!done) { done = true; end() } }
        })
        start()
    }

    /** Runs a spring from 0 to 1; duration comes from the spring's settle time. */
    fun spring(spring: Spring, delayMs: Long = 0L, update: (Float) -> Unit, end: (() -> Unit)? = null): ValueAnimator =
        animate(spring.durationMs, spring, delayMs, update, end)
}

/**
 * Analytic damped harmonic oscillator mapped onto [0, 1] animation time.
 * dampingRatio < 1 overshoots slightly (ColorOS uses ~0.8 - 0.9 for most UI springs).
 */
class Spring(private val dampingRatio: Float, private val response: Float) : TimeInterpolator {
    private val omega = 2.0 * PI / response
    private val zeta = dampingRatio.toDouble()
    private val settleSeconds: Double = run {
        val decay = if (zeta < 1.0) zeta * omega else omega
        (ln(1000.0) / decay).coerceIn(0.18, 1.6)
    }
    val durationMs: Long get() = (settleSeconds * 1000).toLong()
    /** Duration scaled by the user's animation-speed setting. */
    val ms: Long get() = Motion.d(durationMs)

    override fun getInterpolation(input: Float): Float {
        if (input >= 1f) return 1f
        if (input <= 0f) return 0f
        val t = input * settleSeconds
        val value = if (zeta < 1.0) {
            val wd = omega * sqrt(1 - zeta * zeta)
            1 - exp(-zeta * omega * t) * (cos(wd * t) + (zeta * omega / wd) * sin(wd * t))
        } else {
            1 - exp(-omega * t) * (1 + omega * t)
        }
        return value.toFloat()
    }
}
