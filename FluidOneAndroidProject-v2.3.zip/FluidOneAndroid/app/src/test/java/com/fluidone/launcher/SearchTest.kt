package com.fluidone.launcher

import android.Manifest
import android.content.ContentProvider
import android.content.ContentValues
import android.database.Cursor
import android.database.MatrixCursor
import android.net.Uri
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.Robolectric
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.Shadows.shadowOf
import org.robolectric.annotation.Config
import org.robolectric.annotation.GraphicsMode
import org.robolectric.annotation.LooperMode

/** A tiny stand-in for the phone's contacts database. */
class FakeContactsProvider : ContentProvider() {
    private val people = listOf(
        Triple(1L, "Anna Virtanen", "+358 40 111 2222"),
        Triple(2L, "Annika Laine", "+358 50 333 4444"),
        Triple(3L, "Mikko Korhonen", "+358 44 555 6666")
    )

    override fun onCreate() = true

    override fun query(uri: Uri, projection: Array<out String>?, selection: String?, selectionArgs: Array<out String>?, sortOrder: String?): Cursor {
        val cols = projection?.map { it }?.toTypedArray() ?: arrayOf("_id")
        val c = MatrixCursor(cols)
        val path = uri.path ?: return c
        fun person(p: Triple<Long, String, String>) = cols.map { col ->
            when (col) {
                "_id", "contact_id" -> p.first
                "lookup" -> "lookup${p.first}"
                "display_name" -> p.second
                "starred" -> if (p.first == 2L) 1 else 0
                else -> null
            }
        }.toTypedArray()
        when {
            path.startsWith("/contacts/filter/") -> {
                val q = uri.lastPathSegment.orEmpty().lowercase()
                people.filter { it.second.lowercase().split(" ").any { w -> w.startsWith(q) } }.forEach { c.addRow(person(it)) }
            }
            path.startsWith("/data/phones/filter/") -> {
                val q = uri.lastPathSegment.orEmpty().filter { it.isDigit() }
                people.filter { it.third.filter { ch -> ch.isDigit() }.contains(q) }.forEach { c.addRow(person(it)) }
            }
            path == "/data/phones" -> {
                val ids = Regex("[0-9]+").findAll(selection.orEmpty()).map { it.value.toLong() }.toSet()
                people.filter { it.first in ids }.forEach { p ->
                    c.addRow(cols.map { col -> when (col) { "contact_id" -> p.first; "data1" -> p.third; "data2" -> 2; else -> null } }.toTypedArray())
                }
            }
        }
        return c
    }

    override fun getType(uri: Uri): String? = null
    override fun insert(uri: Uri, values: ContentValues?): Uri? = null
    override fun delete(uri: Uri, selection: String?, selectionArgs: Array<out String>?) = 0
    override fun update(uri: Uri, values: ContentValues?, selection: String?, selectionArgs: Array<out String>?) = 0
}

/** Universal search: every source, the privacy-first permission flow, keyboard and back behaviour. */
@RunWith(RobolectricTestRunner::class)
@Config(sdk = [35], qualifiers = "w384dp-h832dp-xxhdpi")
@GraphicsMode(GraphicsMode.Mode.NATIVE)
@LooperMode(LooperMode.Mode.PAUSED)
class SearchTest : LauncherTestBase() {
    override fun beforeLaunch() {
        Robolectric.buildContentProvider(FakeContactsProvider::class.java).create("com.android.contacts")
    }

    private fun type(q: String) {
        a.drawer.search.setText(q)
        idle(400)
    }

    private fun openSearch() {
        a.openDrawer(focusSearch = true); idle(900)
        assertTrue(a.isDrawerOpen)
        assertTrue("search screen is up", a.drawer.searchMode)
    }

    @Test
    fun suggestionsAppsCalculatorConversionsAndActions() {
        // Launch counts feed the suggestions.
        repeat(3) { a.prefs.recordLaunch(a.apps.apps.first { it.systemLabel == "Spotify" }.key) }
        a.prefs.recordLaunch(a.apps.apps.first { it.systemLabel == "Gmail" }.key)
        a.prefs.addSearchHistory("weather")
        openSearch()
        assertTrue(a.drawer.results.isActive)
        val t0 = texts()
        val suggested = a.drawer.results.appIcons.map { it.label }
        assertEquals("suggested apps, most used first", listOf("Spotify", "Gmail"), suggested.take(2))
        assertTrue("recent searches", "weather" in t0)
        assertTrue("try chips", "12*7" in t0)
        shot("q01_suggestions")

        type("wha")
        assertEquals("WhatsApp", a.drawer.results.appIcons.first().label)
        shot("q02_apps")

        type("whtsapp")   // typo
        assertTrue(a.drawer.results.appIcons.any { it.label == "WhatsApp" })

        type("vr")        // initials
        assertEquals("Voice Recorder", a.drawer.results.appIcons.first().label)

        type("12*7")
        assertTrue("calculator answer", "84" in texts())
        shot("q03_calculator")
        type("(2+3)^2 - 15% ")
        assertTrue(texts().any { it == "24.85" })
        type("sqrt(81)+2!")
        assertTrue("11" in texts())

        type("10 km to mi")
        assertTrue(texts().toString(), texts().any { it.startsWith("6.21371") && it.endsWith("mi") })
        type("72 f")
        assertTrue(texts().any { it.startsWith("22.2222") && it.endsWith("°C") })
        type("2 cups = ml")
        assertTrue(texts().any { it.startsWith("473.176") })
        shot("q04_conversion")

        type("+358 40 123 4567")
        val t1 = texts()
        assertTrue("call action", t1.any { it.startsWith("Call +358") })
        assertTrue(t1.contains("Send a message"))
        assertFalse("no bogus calculator answer for a number", t1.contains("Calculator".uppercase()))
        shot("q05_phone")

        type("timer 5 min")
        assertTrue(texts().contains("Start a 5 min timer"))
        type("alarm 7:30 pm")
        assertTrue(texts().contains("Set an alarm for 19:30"))
        type("example.com")
        assertTrue(texts().contains("Open example.com"))
        type("hello@example.com")
        assertTrue(texts().contains("Email hello@example.com"))

        type("nothing matches this")
        val t2 = texts()
        assertTrue(t2.any { it.startsWith("No apps, contacts or settings match") })
        assertTrue("web chips", t2.containsAll(listOf("Web", "Play Store", "YouTube", "Maps")))
        shot("q06_web")
    }

    @Test
    fun settingsAndWallpapersOpenFromSearch() {
        openSearch()
        type("wifi")
        assertTrue(texts().contains("Wi-Fi"))
        shadowOf(a.packageManager).addResolveInfoForIntent(android.content.Intent("android.settings.WIFI_SETTINGS"),
            android.content.pm.ResolveInfo().apply { activityInfo = android.content.pm.ActivityInfo().apply { packageName = "com.android.settings"; name = "WifiSettings" } })
        clickText("Wi-Fi")
        val started = shadowOf(a).nextStartedActivity
        assertNotNull(started)
        assertEquals("android.settings.WIFI_SETTINGS", started.action)
        assertTrue("the search is remembered", a.prefs.searchHistory.first() == "wifi")

        type("bluetoth")   // typo
        assertTrue(texts().contains("Bluetooth"))

        type("orbs")
        assertTrue(texts().contains("Glass Orbs"))
        clickText("Glass Orbs")
        assertEquals("glass_orbs", a.prefs.wallpaper)

        type("fluid glass")
        shot("q07_fluid_result")
        clickText("Fluid Glass")
        idle(600)
        assertTrue("settings opened", a.overlays.any { it is SettingsPanel })
        val t = texts()
        assertTrue(t.contains("Fluid Glass intensity"))
        assertTrue(t.contains("Blur & Fluid Glass"))
        assertTrue(all(a.rootView).any { it is FluidGlassPreview && it.isShown })
        shot("q08_fluid_settings")
        a.onBackPressed(); idle(500); a.onBackPressed(); idle(500)
    }

    @Test
    fun contactsNeedPermissionWithPrivacyNoticeFirst() {
        openSearch()
        type("ann")
        // No access yet: a clean card offers it, and no contacts are read.
        assertTrue(texts().any { it.startsWith("Also search your contacts") })
        assertFalse(texts().contains("Anna Virtanen"))
        shot("q09_permission_card")
        clickText("Allow")
        // Before Android's permission dialog, Fluid One explains its privacy promise.
        val dialog = texts().joinToString("\n")
        assertTrue(dialog, dialog.contains("never share your data with third parties"))
        assertTrue(dialog.contains("no internet access"))
        assertTrue("Android not asked yet", shadowOf(a).lastRequestedPermission == null)
        shot("q10_privacy_notice")
        clickText("Continue")
        val req = shadowOf(a).lastRequestedPermission
        assertNotNull(req)
        assertTrue(req.requestedPermissions.contains(Manifest.permission.READ_CONTACTS))
        shadowOf(RuntimeEnvironment.getApplication()).grantPermissions(*req.requestedPermissions)
        a.onRequestPermissionsResult(req.requestCode, req.requestedPermissions, IntArray(req.requestedPermissions.size))
        waitFor("contacts") { texts().contains("Anna Virtanen") }
        val t = texts()
        assertTrue(t.contains("Annika Laine"))
        assertFalse(t.contains("Mikko Korhonen"))
        assertFalse("card gone once allowed", t.any { it.startsWith("Also search your") })
        assertTrue("starred contact first", t.indexOf("Annika Laine") < t.indexOf("Anna Virtanen"))
        shot("q11_contacts")
        // Call button dials the number without needing the phone permission.
        val call = all(a.rootView).first { it.contentDescription == "Call Annika Laine" && it.isShown }
        call.performClick(); idle(200)
        val dial = shadowOf(a).nextStartedActivity
        assertEquals(android.content.Intent.ACTION_DIAL, dial.action)
        assertEquals("tel:%2B358503334444", dial.data.toString())
        // Searching by number finds the person too.
        type("5556666")
        waitFor("by number") { texts().contains("Mikko Korhonen") }
    }

    @Test
    fun keyboardSearchKeyBackAndClear() {
        openSearch()
        type("spot")
        a.drawer.search.onEditorAction(android.view.inputmethod.EditorInfo.IME_ACTION_SEARCH)
        idle(300)
        val launched = shadowOf(a).nextStartedActivity
        // The top app result is opened through LauncherApps (Robolectric records nothing for that), and it counts.
        assertTrue(launched == null || launched.component?.packageName == "com.spotify.music")
        assertTrue((a.prefs.launchCounts().values.sum()) >= 1)
        assertEquals("spot", a.prefs.searchHistory.first())
        idle(600)
        controller.pause().stop(); idle(50)
        controller.restart().start().resume(); idle(1400)
        if (a.isDrawerOpen) { a.setDrawerOpen(false); idle(900) }
        // Back clears the search and returns to the app grid; the next back closes the drawer.
        openSearch(); type("spot")
        a.onBackPressed(); idle(500)
        assertTrue(a.isDrawerOpen)
        assertEquals("", a.drawer.search.text.toString())
        assertFalse(a.drawer.searchMode)
        assertFalse(a.drawer.results.isActive)
        assertEquals(android.view.View.VISIBLE, a.drawer.grid.visibility)
        a.onBackPressed(); idle(900)
        assertFalse(a.isDrawerOpen)
        // Turning a source off removes it.
        a.prefs.searchCalc = false
        openSearch(); type("12*7")
        assertFalse("84" in texts())
        a.prefs.searchCalc = true
    }
}
