package com.fluidone.launcher

import android.graphics.Matrix
import android.graphics.PointF
import android.graphics.RectF
import android.os.SystemClock
import android.view.MotionEvent
import android.view.View
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import org.robolectric.annotation.GraphicsMode
import org.robolectric.annotation.LooperMode

/** Multi-icon stacks (tap other apps with a second finger) and paging with a second finger while dragging. */
@RunWith(RobolectricTestRunner::class)
@Config(sdk = [35], qualifiers = "w384dp-h832dp-xxhdpi")
@GraphicsMode(GraphicsMode.Mode.NATIVE)
@LooperMode(LooperMode.Mode.PAUSED)
class StackTest : LauncherTestBase() {
    private val down = SystemClock.uptimeMillis()
    private var hold = PointF()

    private fun center(v: View): PointF {
        val r = if (v is IconView) v.iconRectInWindow() else RectF(0f, 0f, v.width.toFloat(), v.height.toFloat()).also {
            val m = Matrix(); v.transformMatrixToGlobal(m); m.mapRect(it)
        }
        return PointF(r.centerX(), r.centerY())
    }

    private fun cellPoint(page: Int, x: Int, y: Int, fx: Float = 0.5f, fy: Float = 0.42f): PointF {
        val cl = a.workspace.pages[page]
        val r = cl.cellRect(x, y)
        val pt = floatArrayOf(r.left + r.width() * fx, r.top + r.height() * fy)
        val m = Matrix(); cl.transformMatrixToGlobal(m); m.mapPoints(pt)
        return PointF(pt[0], pt[1])
    }

    private fun item(page: Int, x: Int, y: Int): HomeItem = a.model.pages[page].first { it.x == x && it.y == y && it.type == HomeItem.APP }

    /** Long-presses [v] with finger 0 and starts dragging it. */
    private fun pickUp(v: View) {
        hold = center(v)
        multi(MotionEvent.ACTION_DOWN, down, listOf(Triple(0, hold.x, hold.y)))
        idle(520)
        for (i in 1..6) { hold = PointF(hold.x + 4f, hold.y - 10f); multi(MotionEvent.ACTION_MOVE, down, listOf(Triple(0, hold.x, hold.y))); idle(16) }
        assertTrue("drag started", a.drag.isDragging)
    }

    /** Moves the holding finger in steps. */
    private fun holdTo(p: PointF, steps: Int = 12) {
        val from = hold
        for (i in 1..steps) {
            hold = PointF(lerp(from.x, p.x, i / steps.toFloat()), lerp(from.y, p.y, i / steps.toFloat()))
            multi(MotionEvent.ACTION_MOVE, down, listOf(Triple(0, hold.x, hold.y)))
            idle(16)
        }
    }

    /** Taps [v] with finger 1 while finger 0 keeps holding. */
    private fun tapWithSecondFinger(v: View) {
        val t = center(v)
        multi(MotionEvent.ACTION_POINTER_DOWN, down, listOf(Triple(0, hold.x, hold.y), Triple(1, t.x, t.y)), index = 1)
        idle(60)
        multi(MotionEvent.ACTION_POINTER_UP, down, listOf(Triple(0, hold.x, hold.y), Triple(1, t.x, t.y)), index = 1)
        idle(420)
    }

    private fun release() {
        idle(400)
        multi(MotionEvent.ACTION_MOVE, down, listOf(Triple(0, hold.x + 1f, hold.y)))
        idle(32)
        multi(MotionEvent.ACTION_UP, down, listOf(Triple(0, hold.x, hold.y)))
        idle(1200)
    }

    private fun assertClean() {
        checkModel()
        assertFalse(a.drag.isDragging)
        assertEquals("no stray drag views", 0, a.dragLayer.childCount)
        a.workspace.pages.forEach { cl -> cl.childList().forEach { assertEquals(1f, it.alpha) } }
        a.dock.icons.forEach { assertEquals(1f, it.alpha) }
    }

    @Test
    fun stackFromPageAndDockThenPageSwipeAndDrop() {
        val primary = item(0, 0, 5); val second = item(0, 1, 5)
        val dockKey = a.model.dock.first()
        pickUp(a.workspace.pages[0].childFor(primary)!!)
        tapWithSecondFinger(a.workspace.pages[0].childFor(second)!!)
        assertEquals(2, a.drag.stackSize)
        tapWithSecondFinger(a.dock.icons.first())
        assertEquals(3, a.drag.stackSize)
        // Move fast so the stacked apps trail behind, and capture it.
        val w = a.rootView.width.toFloat(); val h = a.rootView.height.toFloat()
        for (i in 1..4) { hold = PointF(hold.x + 40f, hold.y - 30f); multi(MotionEvent.ACTION_MOVE, down, listOf(Triple(0, hold.x, hold.y))); idle(16) }
        shot("s01_stack_moving")
        idle(400)
        shot("s02_stack_still")

        // Swipe to page 2 with a second finger while still holding the stack.
        val y1 = h * 0.35f
        multi(MotionEvent.ACTION_POINTER_DOWN, down, listOf(Triple(0, hold.x, hold.y), Triple(1, w * 0.85f, y1)), index = 1)
        for (i in 1..10) {
            idle(16)
            multi(MotionEvent.ACTION_MOVE, down, listOf(Triple(0, hold.x, hold.y), Triple(1, w * 0.85f - i * w * 0.07f, y1)))
            if (i == 5) shot("s03_second_finger_paging")
        }
        multi(MotionEvent.ACTION_POINTER_UP, down, listOf(Triple(0, hold.x, hold.y), Triple(1, w * 0.15f, y1)), index = 1)
        idle(800)
        assertEquals(1, a.workspace.currentPage)
        assertTrue(a.drag.isDragging)

        assertTrue(a.model.isRegionFree(1, 1, 5, 1, 1, a.prefs.columns, a.prefs.rows))
        holdTo(cellPoint(1, 1, 5))
        release()
        assertClean()
        assertEquals(1 to (1 to 5), a.model.pageOf(primary) to (primary.x to primary.y))
        assertEquals(1 to (2 to 5), a.model.pageOf(second) to (second.x to second.y))
        val docked = a.model.findAppItem(dockKey)
        assertNotNull(docked)
        assertEquals(1 to (3 to 5), a.model.pageOf(docked!!) to (docked.x to docked.y))
        assertFalse(dockKey in a.model.dock)
        assertEquals(3, a.model.dock.size)
        shot("s04_stack_dropped")
    }

    @Test
    fun cancelPutsEverythingBack() {
        val primary = item(0, 0, 5); val second = item(0, 2, 5)
        val dockBefore = a.model.dock.toList()
        pickUp(a.workspace.pages[0].childFor(primary)!!)
        tapWithSecondFinger(a.workspace.pages[0].childFor(second)!!)
        tapWithSecondFinger(a.dock.icons[1])
        assertEquals(3, a.drag.stackSize)
        multi(MotionEvent.ACTION_CANCEL, down, listOf(Triple(0, hold.x, hold.y)))
        idle(1200)
        assertClean()
        assertEquals(0 to (0 to 5), a.model.pageOf(primary) to (primary.x to primary.y))
        assertEquals(0 to (2 to 5), a.model.pageOf(second) to (second.x to second.y))
        assertEquals(dockBefore, a.model.dock)
    }

    @Test
    fun stackIntoAFolder() {
        val primary = item(0, 0, 5); val second = item(0, 1, 5); val target = item(0, 3, 5)
        pickUp(a.workspace.pages[0].childFor(primary)!!)
        tapWithSecondFinger(a.workspace.pages[0].childFor(second)!!)
        holdTo(center(a.workspace.pages[0].childFor(target)!!))
        idle(500)
        shot("s05_stack_folder_hover")
        release()
        assertClean()
        val folder = a.model.pages[0].first { it.type == HomeItem.FOLDER && target.appKey in it.apps }
        assertTrue(folder.apps.containsAll(listOf(target.appKey, primary.appKey, second.appKey)))
        assertEquals(3, folder.apps.size)
    }

    @Test
    fun stackOnRemoveTarget() {
        val primary = item(0, 0, 5); val second = item(0, 1, 5)
        pickUp(a.workspace.pages[0].childFor(primary)!!)
        tapWithSecondFinger(a.workspace.pages[0].childFor(second)!!)
        assertFalse("uninstall is not offered for several apps", a.removeBar.uninstallVisible)
        holdTo(PointF(a.rootView.width * 0.3f, a.insetTop + a.dp(24f)))
        release()
        assertClean()
        assertTrue(a.model.findAppItem(primary.appKey) == null)
        assertTrue(a.model.findAppItem(second.appKey) == null)
        assertTrue(a.apps.contains(primary.appKey))
    }

    @Test
    fun stackIntoDockOverflowsToPage() {
        val primary = item(0, 0, 5); val second = item(0, 1, 5)
        a.model.dock.removeAt(0); a.model.save(); a.syncAll(); idle(300)
        assertEquals(3, a.model.dock.size)
        pickUp(a.workspace.pages[0].childFor(primary)!!)
        tapWithSecondFinger(a.workspace.pages[0].childFor(second)!!)
        val firstDock = a.dock.icons[0].iconRectInWindow()
        holdTo(PointF(firstDock.right + 2f, firstDock.centerY()))
        release()
        assertClean()
        assertTrue(primary.appKey in a.model.dock)
        assertTrue(second.appKey in a.model.dock)
        assertEquals(5, a.model.dock.size)
    }
}
