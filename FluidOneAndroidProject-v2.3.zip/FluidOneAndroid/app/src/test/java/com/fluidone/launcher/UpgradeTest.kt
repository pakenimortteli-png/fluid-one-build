package com.fluidone.launcher

import android.content.Context
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.annotation.Config
import org.robolectric.annotation.GraphicsMode
import org.robolectric.annotation.LooperMode

/**
 * Installing 2.2 over 2.1 keeps every customization: the settings written by 2.1 are read unchanged, the new
 * settings get their defaults (Fluid Glass on), and the home layout survives a restart.
 */
@RunWith(RobolectricTestRunner::class)
@Config(sdk = [35], qualifiers = "w384dp-h832dp-xxhdpi")
@GraphicsMode(GraphicsMode.Mode.NATIVE)
@LooperMode(LooperMode.Mode.PAUSED)
class UpgradeTest : LauncherTestBase() {
    override fun beforeLaunch() {
        // Exactly the keys and value types Fluid One 2.1 stored.
        RuntimeEnvironment.getApplication().getSharedPreferences("fluid_one", Context.MODE_PRIVATE).edit()
            .putInt("grid_columns", 5).putInt("grid_rows", 6).putInt("icon_scale", 90)
            .putString("icon_shape", "circle").putString("icon_style", "themed_dark")
            .putString("wallpaper_id", "aurora").putInt("blur_strength", 40).putInt("glass_tint", 55)
            .putString("dock_style", "glass").putString("page_effect", "cube").putString("theme", "dark")
            .putInt("accent", 0xFF845EF7.toInt()).putBoolean("samsung_mode", true).putBoolean("s25_spen_hover", false)
            .putStringSet("hidden_apps", setOf("0|com.netflix.mediaclient/.MainActivity"))
            .putString("label|0|com.spotify.music/.MainActivity", "Music")
            .commit()
    }

    @Test
    fun customizationsFrom21Survive() {
        val p = a.prefs
        assertEquals(5, p.columns); assertEquals(6, p.rows); assertEquals(90, p.iconScale)
        assertEquals("circle", p.iconShape); assertEquals("themed_dark", p.iconStyle)
        assertEquals("aurora", p.wallpaper); assertEquals(40, p.blurStrength); assertEquals(55, p.glassTint)
        assertEquals("glass", p.dockStyle); assertEquals("cube", p.pageEffect); assertEquals("dark", p.theme)
        assertEquals(0xFF845EF7.toInt(), p.accent)
        assertTrue(!p.spenHover)
        // New in 2.2, with defaults.
        assertTrue("Fluid Glass is on by default", p.fluidGlass)
        assertEquals(80, p.fluidIntensity)
        assertTrue(p.searchContacts && p.searchSettings && p.searchCalc)
        // Hidden apps and custom names still apply.
        val spotify = a.apps.apps.first { it.packageName == "com.spotify.music" }
        assertEquals("Music", a.apps.label(spotify))
        assertTrue(a.apps.drawerApps().none { it.packageName == "com.netflix.mediaclient" })
        assertTrue(a.workspace.pages.all { it.cols == 5 })
        shot("u01_upgraded_home")

        // Move something, then restart the launcher like an app update does: the layout is kept.
        val folder = a.model.pages.flatten().first { it.type == HomeItem.FOLDER }
        folder.title = "Upgraded"
        a.model.dock.removeAt(a.model.dock.lastIndex)
        a.model.save(); idle(50)
        val before = a.prefs.sp.getString("home_model", null)
        controller.pause().stop().destroy()
        idle(100)
        controller = org.robolectric.Robolectric.buildActivity(MainActivity::class.java).setup()
        a = controller.get()
        waitFor("wallpaper") { a.wallpaperView.hasWallpaper }
        idle(800)
        assertEquals(before, a.prefs.sp.getString("home_model", null))
        a.model.save()
        assertEquals(before, a.prefs.sp.getString("home_model", null))
        assertEquals("aurora", a.prefs.wallpaper)
        assertTrue(a.model.pages.flatten().any { it.type == HomeItem.FOLDER && it.title == "Upgraded" })
        checkModel()
    }
}
