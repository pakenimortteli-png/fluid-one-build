package com.fluidone.launcher

import android.graphics.Color
import android.os.SystemClock
import android.view.MotionEvent
import android.view.View
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import org.robolectric.annotation.GraphicsMode
import org.robolectric.annotation.LooperMode
import org.robolectric.shadows.ShadowBuild
import kotlin.math.abs

/** Fluid Glass on real launcher surfaces, rendered through the GPU path like on the S25 Ultra. */
@RunWith(RobolectricTestRunner::class)
@Config(sdk = [35], qualifiers = "w384dp-h832dp-xxhdpi")
@GraphicsMode(GraphicsMode.Mode.NATIVE)
@LooperMode(LooperMode.Mode.PAUSED)
class FluidGlassTest : LauncherTestBase() {
    override fun beforeLaunch() {
        ShadowBuild.setManufacturer("samsung"); ShadowBuild.setModel("SM-S938B"); ShadowBuild.setDevice("pa3q")
    }

    private fun diff(a: Int, b: Int) = abs(Color.red(a) - Color.red(b)) + abs(Color.green(a) - Color.green(b)) + abs(Color.blue(a) - Color.blue(b))

    @Test
    fun homeDockMenuFolderAndSettings() {
        assertTrue("on by default", a.prefs.fluidGlass)
        a.prefs.dockStyle = "glass"; a.applyLayoutChange(); idle(600)
        val pill = a.searchPill
        val m = android.graphics.Matrix(); pill.transformMatrixToGlobal(m)
        val pt = floatArrayOf(pill.width * 0.5f, pill.height * 0.12f); m.mapPoints(pt)
        val clear = hwShot("fg01_home_fluid")
        a.prefs.fluidIntensity = 0; a.invalidateGlass(); idle(32)
        val frosted = hwShot("fg02_home_frosted")
        val x = pt[0].toInt(); val y = pt[1].toInt()
        println("PILL clear=${Integer.toHexString(clear.getPixel(x, y))} frosted=${Integer.toHexString(frosted.getPixel(x, y))}")
        assertTrue("the slider changes how glass looks", diff(clear.getPixel(x, y), frosted.getPixel(x, y)) > 12)
        a.prefs.fluidIntensity = 100; a.invalidateGlass(); idle(32)
        hwShot("fg03_home_full")

        // Long-press menu and an open folder.
        val icon = a.workspace.pages[0].childList().first { it is IconView } as IconView
        a.onItemLongPress(icon); idle(700)
        hwShot("fg04_menu")
        a.onBackPressed(); idle(600)
        val folder = a.workspace.pages[0].childList().firstOrNull { it is FolderIconView && !(it as FolderIconView).isLarge } as? FolderIconView
        if (folder != null) { folder.performClick(); idle(800); hwShot("fg05_folder"); a.onBackPressed(); idle(700) }

        // Settings preview, from frosted to the full liquid look.
        a.openSettingsPage("blur"); idle(900)
        for (i in listOf(0, 50, 100)) { a.prefs.fluidIntensity = i; all(a.rootView).filterIsInstance<FluidGlassPreview>().forEach { it.invalidate() }; idle(32); hwShot("fg06_settings_$i") }
        a.prefs.fluidIntensity = 80
        a.onBackPressed(); idle(500); a.onBackPressed(); idle(500)

        // Turning it off brings back plain frosted glass everywhere.
        a.prefs.fluidGlass = false; a.invalidateGlass(); idle(32)
        val off = hwShot("fg07_off")
        assertTrue(diff(off.getPixel(x, y), frosted.getPixel(x, y)) < 30)
    }

    private fun send(v: View, action: Int, x: Float, y: Float, down: Long) {
        val e = MotionEvent.obtain(down, SystemClock.uptimeMillis(), action, x, y, 0)
        v.dispatchTouchEvent(e); e.recycle()
    }

    @Test
    fun glassIsInteractive() {
        // Pressing the search capsule swells it toward the finger; letting go it wobbles back to rest.
        val pill = a.searchPill.glass
        val t = SystemClock.uptimeMillis()
        send(pill, MotionEvent.ACTION_DOWN, pill.width * 0.75f, pill.height * 0.5f, t); idle(160)
        assertTrue("pressed glass swells (${pill.scaleX})", pill.scaleX > 1.04f)
        assertTrue("and leans toward the finger", pill.pivotX < pill.width / 2f)
        hwShot("fg08_pill_pressed")
        send(pill, MotionEvent.ACTION_CANCEL, pill.width * 0.75f, pill.height * 0.5f, t)
        var undershoot = false
        repeat(40) { idle(16); if (pill.scaleX < 0.999f) undershoot = true }
        assertTrue("jelly wobble on release", undershoot)
        idle(1200)
        assertEquals(1f, pill.scaleX, 0.002f)

        // Settings: switch and slider knobs turn into glass lenses while touched.
        a.openSettingsPage("blur"); idle(900)
        val root = a.overlays.first { it is SettingsPanel }.root
        val sw = all(root).filterIsInstance<ColorSwitch>().first { it.isShown }
        val t2 = SystemClock.uptimeMillis()
        send(sw, MotionEvent.ACTION_DOWN, sw.width / 2f, sw.height / 2f, t2); idle(200)
        hwShot("fg09_switch_glass")
        send(sw, MotionEvent.ACTION_CANCEL, sw.width / 2f, sw.height / 2f, t2); idle(900)
        assertTrue("toggle untouched by a cancelled press", a.prefs.fluidGlass)

        val slider = all(root).filterIsInstance<FluidSlider>().first { it.isShown }
        val before = a.prefs.fluidIntensity
        val t3 = SystemClock.uptimeMillis()
        val x0 = slider.width * 0.8f
        send(slider, MotionEvent.ACTION_DOWN, x0, slider.height / 2f, t3); idle(32)
        for (i in 1..8) { send(slider, MotionEvent.ACTION_MOVE, x0 - i * 12f, slider.height / 2f, t3); idle(16) }
        idle(200)
        hwShot("fg10_slider_glass")
        send(slider, MotionEvent.ACTION_UP, x0 - 96f, slider.height / 2f, t3); idle(900)
        assertTrue("dragging the slider changed the intensity", a.prefs.fluidIntensity != before)
        a.prefs.fluidIntensity = 80; a.invalidateGlass()

        // Playground: drag the lens; it stretches while moving and settles.
        val pv = all(root).filterIsInstance<FluidGlassPreview>().first()
        val t4 = SystemClock.uptimeMillis()
        val lx = pv.width * 0.30f; val ly = pv.height * 0.36f
        send(pv, MotionEvent.ACTION_DOWN, lx, ly, t4); idle(48)
        for (i in 1..6) { send(pv, MotionEvent.ACTION_MOVE, lx + i * 60f, ly + i * 12f, t4); idle(16) }
        hwShot("fg11_preview_dragging")
        send(pv, MotionEvent.ACTION_UP, lx + 360f, ly + 72f, t4); idle(1000)
        hwShot("fg12_preview_settled")
        a.onBackPressed(); idle(500); a.onBackPressed(); idle(500)
    }
}
