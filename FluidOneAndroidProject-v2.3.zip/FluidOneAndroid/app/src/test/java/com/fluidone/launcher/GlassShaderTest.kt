package com.fluidone.launcher

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.RuntimeShader
import android.graphics.Shader
import android.graphics.Typeface
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.annotation.Config
import org.robolectric.annotation.GraphicsMode
import java.io.File
import java.io.FileOutputStream
import kotlin.math.abs

/**
 * Compiles the Fluid Glass AGSL with real Skia and renders it on the GPU path over three kinds of scene - a
 * grid with text, a busy photo and a smooth wallpaper - across the intensity range.
 */
@RunWith(RobolectricTestRunner::class)
@Config(sdk = [35], qualifiers = "xxhdpi")
@GraphicsMode(GraphicsMode.Mode.NATIVE)
class GlassShaderTest {
    private val ctx get() = RuntimeEnvironment.getApplication()
    private val dir = File(System.getProperty("shots.dir", "build/screenshots")).apply { mkdirs() }

    /** Renders [draw] through RenderNode + HardwareRenderer (shaders need a GPU canvas). */
    private fun gpu(w: Int, h: Int, draw: (Canvas) -> Unit): Bitmap {
        val node = android.graphics.RenderNode("lab")
        node.setPosition(0, 0, w, h)
        val rc = node.beginRecording()
        draw(rc)
        node.endRecording()
        val reader = android.media.ImageReader.newInstance(w, h, android.graphics.PixelFormat.RGBA_8888, 1,
            android.hardware.HardwareBuffer.USAGE_GPU_SAMPLED_IMAGE or android.hardware.HardwareBuffer.USAGE_GPU_COLOR_OUTPUT)
        val renderer = android.graphics.HardwareRenderer()
        renderer.setSurface(reader.surface)
        renderer.setContentRoot(node)
        renderer.createRenderRequest().setWaitForPresent(true).syncAndDraw()
        val image = reader.acquireNextImage()
        val plane = image.planes[0]
        val wide = Bitmap.createBitmap(plane.rowStride / plane.pixelStride, h, Bitmap.Config.ARGB_8888)
        wide.copyPixelsFromBuffer(plane.buffer)
        image.close(); renderer.destroy(); reader.close()
        return Bitmap.createBitmap(wide, 0, 0, w, h)
    }

    private fun gridText(w: Int, h: Int): Bitmap {
        val b = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(b)
        c.drawColor(Color.rgb(218, 220, 226))
        val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(150, 255, 255, 255); strokeWidth = 3f }
        var x = 60f; while (x < w) { c.drawLine(x, 0f, x, h.toFloat(), p); x += 190f }
        var y = 40f; while (y < h) { c.drawLine(0f, y, w.toFloat(), y, p); y += 190f }
        p.color = Color.rgb(24, 24, 28); p.textSize = 170f; p.typeface = Typeface.DEFAULT_BOLD
        c.drawText("Liquid", 300f, 330f, p)
        p.color = Color.rgb(110, 110, 118); p.textSize = 110f; p.typeface = Typeface.DEFAULT
        c.drawText("glass", 520f, 470f, p)
        return b
    }

    private fun photo(w: Int, h: Int): Bitmap {
        val b = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(b)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.shader = LinearGradient(0f, 0f, 0f, h.toFloat(), Color.rgb(40, 130, 240), Color.rgb(70, 160, 255), Shader.TileMode.CLAMP)
        c.drawRect(0f, 0f, w.toFloat(), h.toFloat(), p)
        p.shader = null
        p.strokeCap = Paint.Cap.ROUND
        p.color = Color.rgb(205, 30, 40); p.strokeWidth = 46f; c.drawLine(-40f, 120f, w + 40f, 300f, p)
        p.color = Color.rgb(170, 80, 120); p.strokeWidth = 30f; c.drawLine(80f, h + 20f, w * 0.7f, -30f, p)
        p.color = Color.rgb(240, 240, 235); p.strokeWidth = 24f; c.drawLine(40f, h * 0.55f, w * 0.45f, h * 0.95f, p)
        p.color = Color.rgb(120, 20, 30); p.strokeWidth = 14f; c.drawLine(w * 0.3f, 0f, w * 0.95f, h.toFloat(), p)
        return b
    }

    private fun scene(src: Bitmap, intensity: Float, shapes: List<Pair<RectF, Float>>, tint: Int, press: Float = 0f): Bitmap {
        val blurred = BlurEngine.blur(src, 0.25f, 7)
        val bm = Matrix().apply { setScale(src.width / blurred.width.toFloat(), src.height / blurred.height.toFloat()) }
        var drew = true
        val out = gpu(src.width, src.height) { rc ->
            rc.drawBitmap(src, 0f, 0f, null)
            for ((r, radius) in shapes) {
                drew = drew && GlassPainter(ctx).draw(rc, r, radius, intensity, tint, src, Matrix(), blurred, bm, press, r.width() * 0.35f, r.height() * 0.4f)
            }
        }
        assertTrue("shader path drew", drew)
        return out
    }

    @Test fun shaderCompilesAndRenders() {
        RuntimeShader(FluidGlass.AGSL)   // throws IllegalArgumentException with the compiler error if invalid
        val w = 900; val h = 560
        val scenes = listOf(
            gridText(w, h) to listOf(RectF(150f, 150f, 450f, 450f) to 150f),
            photo(w, h) to listOf(RectF(110f, 40f, 330f, 260f) to 110f, RectF(380f, 40f, 600f, 260f) to 110f,
                RectF(110f, 300f, 760f, 500f) to 100f),
            Wallpapers.render(Wallpapers.preset("violet_horizon"), w, h) to listOf(RectF(40f, 330f, 860f, 520f) to 80f,
                RectF(330f, 200f, 570f, 290f) to 45f)
        )
        val tints = listOf(Color.argb(20, 255, 255, 255), Color.argb(26, 255, 255, 255), Color.argb(50, 18, 18, 26))
        val sheet = Bitmap.createBitmap(w * 4, h * 3, Bitmap.Config.ARGB_8888)
        val sc = Canvas(sheet)
        scenes.forEachIndexed { row, (src, shapes) ->
            sc.drawBitmap(src, 0f, (row * h).toFloat(), null)
            listOf(0f, 0.5f, 1f).forEachIndexed { col, i ->
                val img = scene(src, i, shapes, tints[row])
                sc.drawBitmap(img, ((col + 1) * w).toFloat(), (row * h).toFloat(), null)
                if (row == 0) {
                    // The lens middle differs between frosted (0) and clear (1); the rim is lighter than the inside.
                    println("GLASS $i centre=${Integer.toHexString(img.getPixel(300, 300))} rim=${Integer.toHexString(img.getPixel(300, 151))}")
                }
            }
        }
        FileOutputStream(File(dir, "g_glass_lab.png")).use { sheet.compress(Bitmap.CompressFormat.PNG, 100, it) }
        // Pressed glass swells (stronger refraction) and lights up under the finger.
        val pressed = scene(scenes[1].first, 1f, scenes[1].second, tints[1], press = 1f)
        FileOutputStream(File(dir, "g_glass_pressed.png")).use { pressed.compress(Bitmap.CompressFormat.PNG, 100, it) }
        val calm = scene(scenes[1].first, 1f, scenes[1].second, tints[1])
        var changed = 0
        for (x in 120 until 320 step 4) for (y in 50 until 250 step 4) if (abs(Color.red(calm.getPixel(x, y)) - Color.red(pressed.getPixel(x, y))) > 6) changed++
        assertTrue("press changes the glass ($changed)", changed > 40)
    }
}
