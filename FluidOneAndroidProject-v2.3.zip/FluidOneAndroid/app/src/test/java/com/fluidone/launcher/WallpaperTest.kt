package com.fluidone.launcher

import android.graphics.Bitmap
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import org.robolectric.annotation.GraphicsMode
import java.io.File
import java.io.FileOutputStream

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [35])
@GraphicsMode(GraphicsMode.Mode.NATIVE)
class WallpaperTest {
    @Test fun renderAll() {
        val dir = File(System.getProperty("shots.dir", "build/screenshots")).apply { mkdirs() }
        Wallpapers.presets.forEach { p ->
            val t = System.currentTimeMillis()
            val bmp = Wallpapers.render(p, 540, 1170)
            println("WP ${p.id} ${System.currentTimeMillis() - t}ms")
            FileOutputStream(File(dir, "wp_${p.id}.png")).use { bmp.compress(Bitmap.CompressFormat.PNG, 90, it) }
        }
        val t = System.currentTimeMillis()
        Wallpapers.render(Wallpapers.presets[0], 1440, 3120)
        println("WP full-res ${System.currentTimeMillis() - t}ms")
    }
}
