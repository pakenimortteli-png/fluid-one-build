package com.fluidone.launcher

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PointF
import android.graphics.RectF
import android.graphics.drawable.AdaptiveIconDrawable
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.ColorDrawable
import android.os.SystemClock
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import org.robolectric.annotation.GraphicsMode
import org.robolectric.annotation.LooperMode
import org.robolectric.shadows.ShadowBuild
import kotlin.math.abs

/** Regression tests for the glass, drawer and One UI icon fixes, run as a Galaxy S25 Ultra. */
@RunWith(RobolectricTestRunner::class)
@Config(sdk = [35], qualifiers = "w384dp-h832dp-xxhdpi")
@GraphicsMode(GraphicsMode.Mode.NATIVE)
@LooperMode(LooperMode.Mode.PAUSED)
class FixesTest : LauncherTestBase() {
    override fun beforeLaunch() {
        ShadowBuild.setManufacturer("samsung")
        ShadowBuild.setModel("SM-S938B")
        ShadowBuild.setDevice("pa3q")
    }

    @Test
    fun glassRedrawsWhenItsSheetMoves() {
        a.enterEditMode(); idle(900)
        val sheet = LayoutSheet(a)
        sheet.show()
        idle(16)
        shot("f01_sheet_opening")   // draws everything (records where each glass was drawn) and clears dirty flags
        a.refreshMovedGlass()
        assertFalse("unmoved glass is not redrawn", sheet.sheet.isDirty)
        // On a GPU-rendered phone, sliding the sheet reuses its old drawing. Simulate that: the recorded
        // position is 200 px lower than where the sheet now is.
        val stamp = sheet.sheet.getTag(R.id.tag_glass_matrix) as FloatArray
        stamp[5] += 200f
        a.refreshMovedGlass()
        assertTrue("glass that moved since its last draw is redrawn", sheet.sheet.isDirty)
        idle(900)
        shot("f02_sheet_open")
        // Once drawn where it rests, the recorded position matches the real one, so it is not redrawn again.
        val st = sheet.sheet.getTag(R.id.tag_glass_matrix) as FloatArray
        val m = android.graphics.Matrix(); sheet.sheet.transformMatrixToGlobal(m)
        val now = FloatArray(9); m.getValues(now)
        for (i in 0 until 9) assertTrue(abs(st[i] - now[i]) < 0.01f)
    }

    @Test
    fun drawerGridDoesNotPaintOverSearchBar() {
        a.openDrawer(); idle(900)
        assertTrue(a.drawer.clipChildren)
        val grid = a.drawer.grid
        val top = a.drawer.getChildAt(a.drawer.childCount - 1) as ViewGroup
        assertTrue("search header is the top-most child, above the grid", top.getChildAt(0) is GlassView)
        grid.smoothScrollBy(a.dpi(260), 0); grid.scrollListBy(a.dpi(260)); idle(600)
        shot("f03_drawer_scrolled")
        a.setDrawerOpen(false); idle(700)
    }

    /** One UI wraps icons so the foreground layer is a complete opaque icon. */
    private fun oneUiStyleIcon(): AdaptiveIconDrawable {
        val fg = Bitmap.createBitmap(216, 216, Bitmap.Config.ARGB_8888)
        val c = Canvas(fg)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.color = Color.rgb(30, 70, 200)
        c.drawRoundRect(RectF(54f, 54f, 162f, 162f), 26f, 26f, p)
        p.color = Color.WHITE; p.style = Paint.Style.STROKE; p.strokeWidth = 10f
        c.drawCircle(108f, 108f, 30f, p)
        val res = a.resources
        return AdaptiveIconDrawable(ColorDrawable(Color.rgb(238, 240, 245)), BitmapDrawable(res, fg), BitmapDrawable(res, fg))
    }

    @Test
    fun samsungThemedIconsShowTheSymbolNotASquare() {
        assertTrue(Device.isSamsung())
        assertTrue(Device.isS25Ultra())
        assertTrue("Samsung mode is on by default on Samsung", a.samsungOn())
        assertTrue(a.s25On())
        val size = 192
        val plateLight = Color.rgb(246, 247, 250)
        val fixed = a.icons.styled(oneUiStyleIcon(), size, "squircle", "themed_light")
        a.prefs.samsungMode = false
        val broken = a.icons.styled(oneUiStyleIcon(), size, "squircle", "themed_light")
        a.prefs.samsungMode = true
        fun lum(c: Int) = (Color.red(c) + Color.green(c) + Color.blue(c)) / 3
        // Inside the old blue square but away from the ring: should be plate, not glyph.
        val off = fixed.getPixel(40, 40)
        val offBroken = broken.getPixel(40, 40)
        assertTrue("fixed icon shows plate where the square was (${Integer.toHexString(off)})", abs(lum(off) - lum(plateLight)) < 30)
        assertTrue("without the fix this was the rectangle bug", lum(offBroken) < 150)
        // On the ring: glyph colour (dark on the light plate).
        val ring = fixed.getPixel(96 + 41, 96)
        assertTrue("ring drawn as glyph (${Integer.toHexString(ring)})", lum(ring) < 170)
        val dir = java.io.File(System.getProperty("shots.dir", "build/screenshots")).apply { mkdirs() }
        listOf("fixed" to fixed, "before" to broken).forEach { (n, b) ->
            java.io.FileOutputStream(java.io.File(dir, "f04_oneui_icon_$n.png")).use { b.compress(Bitmap.CompressFormat.PNG, 100, it) }
        }
        for (style in listOf("themed_dark", "tinted", "glass")) {
            val b = a.icons.styled(oneUiStyleIcon(), size, "squircle", style)
            java.io.FileOutputStream(java.io.File(dir, "f05_oneui_$style.png")).use { b.compress(Bitmap.CompressFormat.PNG, 100, it) }
        }
    }

    @Test
    fun samsungSettingsPage() {
        a.openSettings(); idle(800)
        clickText("Samsung mode")
        shot("f06_samsung_page")
        val switches = all(a.rootView).filterIsInstance<ColorSwitch>().filter { it.isShown }
        assertTrue(switches.size >= 7)
        switches.forEach { assertTrue("all options usable on an S25 Ultra", it.isEnabled) }
        // Turning Samsung mode off disables everything below it.
        switches.first().performClick(); idle(400)
        assertFalse(a.samsungOn())
        assertFalse(switches.last().isEnabled)
        switches.first().performClick(); idle(400)
        assertTrue(a.samsungOn())
        assertTrue(switches.last().isEnabled)
        // Turning off only the S25 Ultra optimizations keeps the Galaxy ones.
        val s25 = switches.first { it.contentDescription == "S25 Ultra optimizations" }
        s25.performClick(); idle(400)
        assertFalse(a.s25On())
        assertTrue(a.samsungOn())
        assertFalse(a.spenHoverEnabled())
        assertTrue(a.oneUiIconFix())
        s25.performClick(); idle(400)
        assertTrue(a.s25On())
        a.onBackPressed(); idle(500); a.onBackPressed(); idle(500)
    }

    /** 2.1 bug: moving apps around sometimes left one app with a thick outline that never went away. */
    @Test
    fun hoverOutlineNeverSticks() {
        val cl = a.workspace.pages[0]
        val icons = cl.childList().filterIsInstance<IconView>().filter { it !is FolderIconView }
        val src = icons[0]; val target = icons[1]
        // The race itself: the outline's spring-in is still running when the fade-out starts.
        target.animateHover(true); idle(32); target.animateHover(false); idle(800)
        assertEquals(0f, target.hoverPlate); assertEquals(1f, target.hoverScale)

        // A real drag: hover on another app (folder preview), leave quickly, again and again, then drop back home.
        val down = SystemClock.uptimeMillis()
        val home = src.iconRectInWindow().let { PointF(it.centerX(), it.centerY()) }
        var p = home
        fun moveTo(q: PointF, steps: Int) {
            val from = p
            for (i in 1..steps) {
                p = PointF(from.x + (q.x - from.x) * i / steps, from.y + (q.y - from.y) * i / steps)
                multi(MotionEvent.ACTION_MOVE, down, listOf(Triple(0, p.x, p.y))); idle(16)
            }
        }
        multi(MotionEvent.ACTION_DOWN, down, listOf(Triple(0, p.x, p.y))); idle(520)
        moveTo(PointF(home.x + 30f, home.y - 40f), 6)
        assertTrue(a.drag.isDragging)
        val t = target.iconRectInWindow().let { PointF(it.centerX(), it.centerY()) }
        for (dwell in listOf(40L, 120L, 260L, 420L, 90L)) {
            moveTo(t, 5); idle(dwell)
            if (dwell == 420L) shot("f07_folder_hover")
            moveTo(PointF(home.x + 30f, home.y - 40f), 3); idle(30)
        }
        moveTo(home, 6); idle(300)
        multi(MotionEvent.ACTION_UP, down, listOf(Triple(0, p.x, p.y))); idle(1400)
        assertFalse(a.drag.isDragging)
        a.workspace.pages.forEach { page -> page.childList().filterIsInstance<IconView>().forEach {
            assertEquals("no outline left on ${it.label}", 0f, it.hoverPlate)
            assertEquals(1f, it.hoverScale)
        } }
        a.dock.icons.forEach { assertEquals(0f, it.hoverPlate) }
        checkModel()
        shot("f08_after_hover_drag")
    }

    /** 2.1 bug: on Samsung with custom icon styles the drawer lagged because icons were built while scrolling. */
    @Test
    fun drawerIconsAreBuiltOffTheUiThread() {
        a.prefs.iconStyle = "themed_light"; a.applyIconChange(); idle(200)
        a.icons.clear()
        val entries = a.apps.drawerApps().take(12)
        val views = entries.map { e -> IconView(a).also { a.bindAppIcon(it, e, IconView.SOURCE_DRAWER) } }
        assertTrue("binding never builds an icon on the UI thread", views.all { it.bitmap == null })
        waitFor("icons loaded in the background") { views.all { it.bitmap != null } }
        // Once built they are cached: rebinding (what scrolling does) is instant.
        val again = entries.map { e -> IconView(a).also { a.bindAppIcon(it, e, IconView.SOURCE_DRAWER) } }
        assertTrue(again.all { it.bitmap != null && it.iconAlpha == 1f })
        a.openDrawer(); idle(900)
        waitFor("drawer filled") { (0 until a.drawer.grid.childCount).all { (a.drawer.grid.getChildAt(it) as IconView).bitmap != null } }
        shot("f09_drawer_themed_light")
        a.prefs.iconStyle = "original"
    }
}
