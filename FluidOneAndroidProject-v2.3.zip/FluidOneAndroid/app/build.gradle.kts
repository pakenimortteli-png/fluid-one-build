plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.fluidone.launcher"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.fluidone.launcher"
        minSdk = 31
        targetSdk = 35
        versionCode = 5
        versionName = "2.3.0"
    }

    buildTypes {
        debug {
            // Debug builds are signed by Android Gradle Plugin and are directly installable.
        }
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }

    testOptions {
        unitTests.isIncludeAndroidResources = true
        unitTests.all { it.maxHeapSize = "4g" }
    }
}

dependencies {
    // The app itself uses only the Android framework. These are for the Robolectric UI tests in src/test.
    testImplementation("junit:junit:4.13.2")
    testImplementation("org.robolectric:robolectric:4.14.1")
}
